//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B4XQrWki.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CKM_1VWE.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CKM_1VWE.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-YY8jgX_y.js"]
	}
} });
//#endregion
export { tsrStartManifest };
