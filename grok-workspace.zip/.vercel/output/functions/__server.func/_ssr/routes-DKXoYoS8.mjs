import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Settings, c as LogOut, d as ClipboardList, f as ChartColumn, l as LayoutDashboard, m as Bell, n as Wrench, o as Package, p as CalendarClock, r as Users, s as Menu, t as X, u as Cog } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DKXoYoS8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ROLE_LABEL = {
	admin: "مسؤول",
	supervisor: "مشرف صيانة",
	technician: "فني صيانة"
};
var PRIORITY_LABEL = {
	normal: "عادي",
	important: "مهم",
	urgent: "طارئ"
};
var STATUS_LABEL = {
	open: "مفتوح",
	closed: "مغلق"
};
var FREQUENCY_LABEL = {
	daily: "يومي",
	weekly: "أسبوعي",
	monthly: "شهري",
	quarterly: "ربع سنوي",
	semiannual: "نصف سنوي",
	yearly: "سنوي"
};
var FREQUENCY_DAYS = {
	daily: 1,
	weekly: 7,
	monthly: 30,
	quarterly: 90,
	semiannual: 180,
	yearly: 365
};
function canSee(user, permissions, section) {
	if (section === "home" || section === "settings" || section === "notifications") return true;
	if (section === "users") return user.role === "admin";
	if (user.role === "admin") return true;
	const set = user.role === "supervisor" ? permissions.supervisor : permissions.technician;
	if (section === "workorders" || section === "breakdowns") return !!set?.breakdowns;
	if (section === "equipment") return !!set?.equipment;
	if (section === "pm") return !!set?.pm;
	if (section === "parts") return !!set?.parts;
	if (section === "reports") return !!set?.reports;
	return false;
}
function canManageAssets(user) {
	return user.role === "admin" || user.role === "supervisor";
}
function canLogBreakdown(user) {
	return user.role === "admin" || user.role === "technician";
}
function canManagePlans(user) {
	return user.role === "admin" || user.role === "supervisor";
}
function canManageParts(user) {
	return user.role === "admin" || user.role === "supervisor";
}
var SECTIONS = [
	"home",
	"equipment",
	"breakdowns",
	"workorders",
	"pm",
	"parts",
	"reports",
	"notifications",
	"users",
	"settings"
];
function pad(value) {
	return String(value).padStart(2, "0");
}
function toDateInput(date) {
	return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}
function today() {
	return toDateInput(/* @__PURE__ */ new Date());
}
function monthStart() {
	const date = /* @__PURE__ */ new Date();
	return toDateInput(new Date(date.getFullYear(), date.getMonth(), 1));
}
function addDays(iso, days) {
	const [year, month, day] = iso.slice(0, 10).split("-").map(Number);
	const date = new Date(year || 1970, (month || 1) - 1, day || 1);
	date.setDate(date.getDate() + days);
	return toDateInput(date);
}
function nowLocal() {
	const date = /* @__PURE__ */ new Date();
	return `${toDateInput(date)}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}
function atDaysAgo(days, time) {
	return `${addDays(today(), -days)}T${time}`;
}
function parseLocal(value) {
	const [date, time = "00:00"] = value.split("T");
	const [year, month, day] = date.split("-").map(Number);
	const [hour, minute] = time.split(":").map(Number);
	return new Date(year || 1970, (month || 1) - 1, day || 1, hour || 0, minute || 0, 0, 0).getTime();
}
function dateOnly(value) {
	return value ? value.slice(0, 10) : "";
}
function minutesBetween(start, end) {
	if (!start || !end) return 0;
	const diff = parseLocal(end) - parseLocal(start);
	return diff > 0 ? Math.round(diff / 6e4) : 0;
}
function daysUntil(date) {
	if (!date) return 99999;
	const target = parseLocal(date.slice(0, 10));
	const now = /* @__PURE__ */ new Date();
	now.setHours(0, 0, 0, 0);
	return Math.round((target - now.getTime()) / 864e5);
}
function formatMinutes(mins) {
	const total = Math.max(0, Math.round(mins));
	const hours = Math.floor(total / 60);
	const rest = total % 60;
	if (hours <= 0) return `${rest} د`;
	return `${hours} س ${rest} د`;
}
function formatWhen(value, empty = "غير مسجل") {
	if (!value) return empty;
	const time = parseLocal(value);
	if (Number.isNaN(time)) return value;
	return new Date(time).toLocaleString("ar-EG-u-nu-latn", {
		year: "numeric",
		month: "2-digit",
		day: "2-digit",
		hour: "numeric",
		minute: "2-digit"
	});
}
function greeting(name) {
	return `${(/* @__PURE__ */ new Date()).getHours() < 12 ? "صباح الخير" : "مساء الخير"}، ${name}`;
}
var DEMO_PASSWORD = "1234";
var DEMO_HASH = "03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4";
async function sha256(text) {
	const data = new TextEncoder().encode(text);
	const digest = await crypto.subtle.digest("SHA-256", data);
	return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
function uid() {
	if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
	return `id-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}
function nextOrderNumber(orders) {
	const max = orders.reduce((highest, order) => {
		const value = Number(order.number.replace(/\D/g, ""));
		return Number.isFinite(value) ? Math.max(highest, value) : highest;
	}, 1e3);
	return `WO-${String(max + 1).padStart(4, "0")}`;
}
function createSeed() {
	const permissions = {
		technician: {
			equipment: true,
			breakdowns: true,
			pm: true,
			parts: true,
			reports: false
		},
		supervisor: {
			equipment: true,
			breakdowns: true,
			pm: true,
			parts: true,
			reports: true
		}
	};
	const users = [
		{
			id: "user-admin",
			name: "المسؤول",
			username: "admin",
			passwordHash: DEMO_HASH,
			role: "admin",
			active: true
		},
		{
			id: "user-super",
			name: "مشرف الصيانة",
			username: "super",
			passwordHash: DEMO_HASH,
			role: "supervisor",
			active: true
		},
		{
			id: "user-tech",
			name: "فني الصيانة",
			username: "tech",
			passwordHash: DEMO_HASH,
			role: "technician",
			active: true
		}
	];
	const equipment = [
		{
			id: "eq-pack",
			name: "ماكينة التعبئة 01",
			code: "PK-101",
			model: "خط التعبئة أ",
			image: "",
			pdfName: "",
			pdfData: "",
			createdAt: atDaysAgo(40, "08:00")
		},
		{
			id: "eq-air",
			name: "ضاغط الهواء الرئيسي",
			code: "CA-014",
			model: "غرفة المرافق",
			image: "",
			pdfName: "",
			pdfData: "",
			createdAt: atDaysAgo(40, "08:10")
		},
		{
			id: "eq-belt",
			name: "السير الناقل",
			code: "CV-220",
			model: "خط الإنتاج ب",
			image: "",
			pdfName: "",
			pdfData: "",
			createdAt: atDaysAgo(30, "08:00")
		},
		{
			id: "eq-mix",
			name: "خلاط المواد الخام",
			code: "MX-007",
			model: "قسم الخلط",
			image: "",
			pdfName: "",
			pdfData: "",
			createdAt: atDaysAgo(30, "08:20")
		}
	];
	const parts = [
		{
			id: "part-bearing",
			name: "Bearing 6205",
			storeNo: "SP-00025",
			qty: 2,
			minQty: 4,
			equipmentIds: ["eq-pack"],
			machineQty: { "eq-pack": 4 }
		},
		{
			id: "part-sensor",
			name: "حساس تقارب",
			storeNo: "SP-00110",
			qty: 6,
			minQty: 2,
			equipmentIds: ["eq-belt"],
			machineQty: { "eq-belt": 2 }
		},
		{
			id: "part-belt",
			name: "سير نقل",
			storeNo: "SP-00088",
			qty: 1,
			minQty: 2,
			equipmentIds: ["eq-belt", "eq-pack"],
			machineQty: {
				"eq-belt": 1,
				"eq-pack": 2
			}
		},
		{
			id: "part-oil",
			name: "زيت تشحيم ISO 68",
			storeNo: "SP-00301",
			qty: 14,
			minQty: 4,
			equipmentIds: [],
			machineQty: {}
		}
	];
	const breakdowns = [
		{
			id: "bd-open-1",
			equipmentId: "eq-pack",
			description: "توقف مفاجئ مع ارتفاع حرارة وحدة اللحام",
			cause: "تلف مبدئي في الحساس",
			action: "",
			technician: "فني الصيانة",
			priority: "urgent",
			status: "open",
			start: atDaysAgo(0, "07:40"),
			end: "",
			usedParts: [],
			createdAt: atDaysAgo(0, "07:41")
		},
		{
			id: "bd-open-2",
			equipmentId: "eq-air",
			description: "هبوط ضغط الهواء عن 6 بار",
			cause: "تسريب في الوصلة",
			action: "",
			technician: "فني الصيانة",
			priority: "important",
			status: "open",
			start: atDaysAgo(1, "14:10"),
			end: "",
			usedParts: [],
			createdAt: atDaysAgo(1, "14:12")
		},
		{
			id: "bd-closed-1",
			equipmentId: "eq-mix",
			description: "انسداد في فوهة التغذية",
			cause: "تراكم خام",
			action: "تنظيف الفوهة وإعادة الضبط",
			technician: "فني الصيانة",
			priority: "normal",
			status: "closed",
			start: atDaysAgo(4, "08:00"),
			end: atDaysAgo(4, "10:30"),
			usedParts: [],
			createdAt: atDaysAgo(4, "08:05")
		},
		{
			id: "bd-closed-2",
			equipmentId: "eq-belt",
			description: "انحراف السير عن المسار",
			cause: "ارتخاء الشد",
			action: "إعادة الشد",
			technician: "فني الصيانة",
			priority: "important",
			status: "closed",
			start: atDaysAgo(12, "09:00"),
			end: atDaysAgo(12, "09:40"),
			usedParts: [{
				partId: "part-belt",
				name: "سير نقل",
				storeNo: "SP-00088",
				qty: 1
			}],
			createdAt: atDaysAgo(12, "09:02")
		},
		{
			id: "bd-closed-3",
			equipmentId: "eq-pack",
			description: "عطل حساس العد",
			cause: "حساس تالف",
			action: "استبدال الحساس",
			technician: "فني الصيانة",
			priority: "urgent",
			status: "closed",
			start: atDaysAgo(20, "11:00"),
			end: atDaysAgo(20, "12:20"),
			usedParts: [],
			createdAt: atDaysAgo(20, "11:04")
		}
	];
	const workOrders = breakdowns.map((item, index) => ({
		id: `wo-${item.id}`,
		number: `WO-${1001 + index}`,
		breakdownId: item.id,
		equipmentId: item.equipmentId,
		technician: item.technician,
		priority: item.priority,
		status: item.status,
		createdAt: item.createdAt
	}));
	const pmPlans = [
		{
			id: "pm-1",
			equipmentId: "eq-pack",
			title: "تشحيم محامل التعبئة",
			frequency: "weekly",
			intervalDays: 7,
			nextDate: today(),
			lastDate: addDays(today(), -7),
			assignedTo: "فني الصيانة",
			tasks: [
				"إيقاف آمن",
				"تشحيم المحامل",
				"فحص الحرارة"
			],
			active: true
		},
		{
			id: "pm-2",
			equipmentId: "eq-air",
			title: "فحص ضاغط الهواء",
			frequency: "monthly",
			intervalDays: 30,
			nextDate: addDays(today(), -3),
			lastDate: addDays(today(), -33),
			assignedTo: "مشرف الصيانة",
			tasks: [
				"قياس الضغط",
				"فحص التسريب",
				"تنظيف الفلتر"
			],
			active: true
		},
		{
			id: "pm-3",
			equipmentId: "eq-mix",
			title: "مراجعة الخلاط الربع سنوية",
			frequency: "quarterly",
			intervalDays: 90,
			nextDate: addDays(today(), 6),
			lastDate: "",
			assignedTo: "فني الصيانة",
			tasks: ["فحص الشفرات", "ربط الوصلات"],
			active: true
		},
		{
			id: "pm-4",
			equipmentId: "eq-belt",
			title: "فحص شد السير",
			frequency: "semiannual",
			intervalDays: 180,
			nextDate: addDays(today(), 40),
			lastDate: "",
			assignedTo: "فني الصيانة",
			tasks: ["قياس الشد", "فحص البكرات"],
			active: true
		}
	];
	const notifications = [{
		id: "nt-1",
		title: "عطل طارئ: ماكينة التعبئة 01",
		body: "توقف مفاجئ مع ارتفاع حرارة وحدة اللحام",
		breakdownId: "bd-open-1",
		read: false,
		createdAt: atDaysAgo(0, "07:41")
	}, {
		id: "nt-2",
		title: "عطل مهم: ضاغط الهواء الرئيسي",
		body: "هبوط ضغط الهواء عن 6 بار",
		breakdownId: "bd-open-2",
		read: false,
		createdAt: atDaysAgo(1, "14:12")
	}];
	return {
		users,
		permissions,
		equipment,
		breakdowns,
		parts,
		pmPlans,
		pmHistory: [{
			id: "log-1",
			planId: "pm-1",
			equipmentId: "eq-pack",
			title: "تشحيم محامل التعبئة",
			date: addDays(today(), -7),
			technician: "فني الصيانة",
			result: "مكتملة",
			onTime: true,
			note: ""
		}],
		workOrders,
		notifications,
		sessionUserId: null,
		section: "home",
		reportFrom: monthStart(),
		reportTo: today(),
		focus: null
	};
}
function currentUser(state) {
	return state.users.find((user) => user.id === state.sessionUserId) ?? null;
}
function isSection(value) {
	return typeof value === "string" && SECTIONS.includes(value);
}
var memory = /* @__PURE__ */ new Map();
var safeLocalStorage = {
	getItem: (name) => {
		try {
			return localStorage.getItem(name);
		} catch {
			return memory.get(name) ?? null;
		}
	},
	setItem: (name, value) => {
		memory.set(name, value);
		try {
			localStorage.setItem(name, value);
		} catch {}
	},
	removeItem: (name) => {
		memory.delete(name);
		try {
			localStorage.removeItem(name);
		} catch {}
	}
};
var useCmms = create()(persist((set, get) => ({
	...createSeed(),
	login: async (username, password) => {
		const hash = await sha256(password);
		const user = get().users.find((item) => item.active && item.username.trim().toLowerCase() === username.trim().toLowerCase() && item.passwordHash === hash);
		if (!user) return "بيانات الدخول غير صحيحة";
		set({
			sessionUserId: user.id,
			section: "home"
		});
		return null;
	},
	logout: () => set({
		sessionUserId: null,
		section: "home",
		focus: null
	}),
	setSection: (section) => set({ section }),
	setFocus: (focus) => set({ focus }),
	setReportRange: (from, to) => {
		if (!from || !to || from > to) return "حدد فترة صحيحة من تاريخ إلى تاريخ";
		set({
			reportFrom: from,
			reportTo: to
		});
		return null;
	},
	addEquipment: (input) => {
		const user = currentUser(get());
		if (!user || !canSee(user, get().permissions, "equipment") || !canManageAssets(user)) return "ليس لديك صلاحية إضافة المعدات";
		const name = input.name.trim();
		if (!name) return "اسم المعدة مطلوب";
		set({ equipment: [{
			id: uid(),
			name,
			code: input.code.trim(),
			model: input.model.trim(),
			image: input.image,
			pdfName: input.pdfName,
			pdfData: input.pdfData,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		}, ...get().equipment] });
		return null;
	},
	updateEquipment: (id, input) => {
		const user = currentUser(get());
		if (!user || !canManageAssets(user)) return "ليس لديك صلاحية تعديل المعدات";
		const name = input.name.trim();
		if (!name) return "اسم المعدة مطلوب";
		set({ equipment: get().equipment.map((item) => item.id === id ? {
			...item,
			name,
			code: input.code.trim(),
			model: input.model.trim(),
			image: input.image ?? item.image,
			pdfName: input.pdfName ?? item.pdfName,
			pdfData: input.pdfData ?? item.pdfData
		} : item) });
		return null;
	},
	deleteEquipment: (id) => {
		const user = currentUser(get());
		if (!user || user.role !== "admin") return "إزالة المعدات للمسؤول فقط";
		set({
			equipment: get().equipment.filter((item) => item.id !== id),
			parts: get().parts.map((part) => ({
				...part,
				equipmentIds: part.equipmentIds.filter((equipmentId) => equipmentId !== id),
				machineQty: Object.fromEntries(Object.entries(part.machineQty).filter(([key]) => key !== id))
			}))
		});
		return null;
	},
	addBreakdown: (input) => {
		const user = currentUser(get());
		if (!user || !canSee(user, get().permissions, "breakdowns") || !canLogBreakdown(user)) return "ليس لديك صلاحية تسجيل الأعطال";
		const description = input.description.trim();
		if (!input.equipmentId || !description) return "اختر المعدة واكتب وصف العطل";
		const start = input.start || nowLocal();
		const end = input.end;
		if (end && parseEndBeforeStart(start, end)) return "وقت الإغلاق لا يمكن أن يكون قبل وقت البداية";
		const parts = get().parts;
		for (const used of input.used) {
			const part = parts.find((item) => item.id === used.partId);
			if (!part) return "إحدى قطع الغيار لم تعد موجودة";
			if (used.qty < 1) return "كمية قطعة الغيار غير صحيحة";
			if (used.qty > part.qty) return `الكمية المطلوبة من «${part.name}» أكبر من المتاح (${part.qty})`;
		}
		const id = uid();
		const status = end ? "closed" : "open";
		const equipment = get().equipment.find((item) => item.id === input.equipmentId);
		const breakdown = {
			id,
			equipmentId: input.equipmentId,
			description,
			cause: input.cause.trim(),
			action: input.action.trim(),
			technician: user.name,
			priority: input.priority,
			status,
			start,
			end,
			usedParts: input.used,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		const order = {
			id: uid(),
			number: nextOrderNumber(get().workOrders),
			breakdownId: id,
			equipmentId: input.equipmentId,
			technician: user.name,
			priority: input.priority,
			status,
			createdAt: breakdown.createdAt
		};
		const notice = {
			id: uid(),
			title: `عطل ${breakdown.priority === "urgent" ? "طارئ" : breakdown.priority === "important" ? "مهم" : "عادي"}: ${equipment?.name ?? "معدة"}`,
			body: description,
			breakdownId: id,
			read: false,
			createdAt: breakdown.createdAt
		};
		set({
			breakdowns: [breakdown, ...get().breakdowns],
			workOrders: [order, ...get().workOrders],
			notifications: [notice, ...get().notifications],
			parts: parts.map((part) => {
				const used = input.used.find((item) => item.partId === part.id);
				return used ? {
					...part,
					qty: Math.max(0, part.qty - used.qty)
				} : part;
			})
		});
		return null;
	},
	closeBreakdown: (id) => {
		const user = currentUser(get());
		if (!user || !canSee(user, get().permissions, "breakdowns")) return "ليس لديك صلاحية إغلاق الأعطال";
		const current = get().breakdowns.find((item) => item.id === id);
		if (!current) return "العطل غير موجود";
		if (current.status === "closed") return "العطل مغلق بالفعل";
		const end = nowLocal();
		set({
			breakdowns: get().breakdowns.map((item) => item.id === id ? {
				...item,
				status: "closed",
				end
			} : item),
			workOrders: get().workOrders.map((item) => item.breakdownId === id ? {
				...item,
				status: "closed"
			} : item)
		});
		return null;
	},
	addPart: (input) => {
		const user = currentUser(get());
		if (!user || !canSee(user, get().permissions, "parts") || !canManageParts(user)) return "ليس لديك صلاحية إضافة قطع الغيار";
		const name = input.name.trim();
		const storeNo = input.storeNo.trim();
		if (!name || !storeNo) return "اسم القطعة ورقم المخزن مطلوبان";
		if (get().parts.some((part) => part.storeNo.toLowerCase() === storeNo.toLowerCase())) return "رقم المخزن مستخدم بالفعل";
		const machineQty = {};
		input.equipmentIds.forEach((id) => {
			machineQty[id] = 0;
		});
		set({ parts: [{
			id: uid(),
			name,
			storeNo,
			qty: Math.max(0, Math.floor(input.qty)),
			minQty: Math.max(0, Math.floor(input.minQty)),
			equipmentIds: input.equipmentIds,
			machineQty
		}, ...get().parts] });
		return null;
	},
	togglePartLink: (partId, equipmentId) => {
		const user = currentUser(get());
		if (!user || !canManageParts(user)) return;
		set({ parts: get().parts.map((part) => {
			if (part.id !== partId) return part;
			const linked = part.equipmentIds.includes(equipmentId);
			const equipmentIds = linked ? part.equipmentIds.filter((id) => id !== equipmentId) : [...part.equipmentIds, equipmentId];
			const machineQty = { ...part.machineQty };
			if (!linked && machineQty[equipmentId] === void 0) machineQty[equipmentId] = 0;
			if (linked) delete machineQty[equipmentId];
			return {
				...part,
				equipmentIds,
				machineQty
			};
		}) });
	},
	setMachineQty: (partId, equipmentId, qty) => {
		const user = currentUser(get());
		if (!user || !canManageParts(user)) return;
		set({ parts: get().parts.map((part) => part.id === partId ? {
			...part,
			machineQty: {
				...part.machineQty,
				[equipmentId]: Math.max(0, Math.floor(qty))
			}
		} : part) });
	},
	savePlan: (input) => {
		const user = currentUser(get());
		if (!user || !canSee(user, get().permissions, "pm") || !canManagePlans(user)) return "ليس لديك صلاحية تعديل خطط الصيانة";
		const title = input.title.trim();
		if (!input.equipmentId || !title || !input.nextDate) return "أكمل المعدة واسم الخطة وموعد الاستحقاق";
		const tasks = input.tasks.map((task) => task.trim()).filter(Boolean);
		const next = {
			id: input.id || uid(),
			equipmentId: input.equipmentId,
			title,
			frequency: input.frequency,
			intervalDays: Math.max(1, Math.floor(input.intervalDays) || 1),
			nextDate: input.nextDate,
			lastDate: input.id ? get().pmPlans.find((plan) => plan.id === input.id)?.lastDate ?? "" : "",
			assignedTo: input.assignedTo.trim(),
			tasks: tasks.length ? tasks : ["تنفيذ بنود الخطة"],
			active: true
		};
		set({ pmPlans: get().pmPlans.some((plan) => plan.id === next.id) ? get().pmPlans.map((plan) => plan.id === next.id ? next : plan) : [next, ...get().pmPlans] });
		return null;
	},
	executePlan: (id, note) => {
		const user = currentUser(get());
		if (!user || !canSee(user, get().permissions, "pm")) return "ليس لديك صلاحية تنفيذ الصيانة";
		const plan = get().pmPlans.find((item) => item.id === id);
		if (!plan) return "الخطة غير موجودة";
		const onTime = daysUntil(plan.nextDate) >= 0;
		let nextDate = plan.nextDate || today();
		const step = Math.max(1, plan.intervalDays || 1);
		let guard = 0;
		do {
			nextDate = addDays(nextDate, step);
			guard += 1;
		} while (daysUntil(nextDate) <= 0 && guard < 400);
		set({
			pmPlans: get().pmPlans.map((item) => item.id === id ? {
				...item,
				lastDate: today(),
				nextDate
			} : item),
			pmHistory: [{
				id: uid(),
				planId: plan.id,
				equipmentId: plan.equipmentId,
				title: plan.title,
				date: today(),
				technician: user.name,
				result: "مكتملة",
				onTime,
				note: note.trim()
			}, ...get().pmHistory]
		});
		return null;
	},
	addUser: async (input) => {
		const user = currentUser(get());
		if (!user || user.role !== "admin") return "إضافة المستخدمين للمسؤول فقط";
		const name = input.name.trim();
		const username = input.username.trim();
		if (!name || !username || !input.password) return "أكمل بيانات المستخدم";
		if (input.password.length < 4) return "كلمة المرور قصيرة";
		if (get().users.some((item) => item.username.toLowerCase() === username.toLowerCase())) return "اسم المستخدم مستخدم بالفعل";
		const passwordHash = await sha256(input.password);
		set({ users: [...get().users, {
			id: uid(),
			name,
			username,
			passwordHash,
			role: input.role,
			active: true
		}] });
		return null;
	},
	deleteUser: (id) => {
		const user = currentUser(get());
		if (!user || user.role !== "admin") return "حذف المستخدمين للمسؤول فقط";
		const target = get().users.find((item) => item.id === id);
		if (!target) return "المستخدم غير موجود";
		if (target.username === "admin" || target.id === user.id) return "لا يمكن حذف هذا الحساب";
		set({ users: get().users.filter((item) => item.id !== id) });
		return null;
	},
	setPerm: (role, key, value) => {
		const user = currentUser(get());
		if (!user || user.role !== "admin") return "تعديل الصلاحيات للمسؤول فقط";
		set({ permissions: {
			...get().permissions,
			[role]: {
				...get().permissions[role],
				[key]: value
			}
		} });
		return null;
	},
	markRead: (id) => set({ notifications: get().notifications.map((item) => item.id === id ? {
		...item,
		read: true
	} : item) }),
	markAllRead: () => set({ notifications: get().notifications.map((item) => ({
		...item,
		read: true
	})) }),
	resetDemo: () => {
		const user = currentUser(get());
		if (!user || user.role !== "admin") return "استعادة البيانات التجريبية للمسؤول فقط";
		set({
			...createSeed(),
			sessionUserId: "user-admin",
			section: "home",
			focus: null
		});
		return null;
	},
	exportBackup: () => {
		const state = get();
		return JSON.stringify({
			users: state.users,
			permissions: state.permissions,
			equipment: state.equipment,
			breakdowns: state.breakdowns,
			parts: state.parts,
			pmPlans: state.pmPlans,
			pmHistory: state.pmHistory,
			workOrders: state.workOrders,
			notifications: state.notifications,
			reportFrom: state.reportFrom,
			reportTo: state.reportTo
		}, null, 2);
	},
	importBackup: (raw) => {
		const user = currentUser(get());
		if (!user || user.role !== "admin") return "استيراد النسخة للمسؤول فقط";
		if (!raw || typeof raw !== "object") return "الملف غير صالح";
		const data = raw;
		if (!Array.isArray(data.users) || !Array.isArray(data.equipment) || !Array.isArray(data.breakdowns)) return "الملف لا يحتوي بيانات النظام";
		const users = data.users.filter(isUser);
		if (!users.some((item) => item.role === "admin")) return "النسخة يجب أن تحتوي حساب مسؤول";
		const sessionUserId = users.some((item) => item.id === get().sessionUserId) ? get().sessionUserId : users.find((item) => item.role === "admin")?.id ?? null;
		set({
			users,
			permissions: isPermissions(data.permissions) ? data.permissions : get().permissions,
			equipment: data.equipment.filter(isEquipment),
			breakdowns: Array.isArray(data.breakdowns) ? data.breakdowns.filter(isBreakdown) : [],
			parts: Array.isArray(data.parts) ? data.parts.filter(isPart).map(normalizePart) : [],
			pmPlans: Array.isArray(data.pmPlans) ? data.pmPlans.filter(isPlan) : [],
			pmHistory: Array.isArray(data.pmHistory) ? data.pmHistory : [],
			workOrders: Array.isArray(data.workOrders) ? data.workOrders : [],
			notifications: Array.isArray(data.notifications) ? data.notifications : [],
			reportFrom: typeof data.reportFrom === "string" ? data.reportFrom : get().reportFrom,
			reportTo: typeof data.reportTo === "string" ? data.reportTo : get().reportTo,
			sessionUserId,
			focus: null
		});
		return null;
	}
}), {
	name: "maintenance-command-v1",
	skipHydration: true,
	storage: createJSONStorage(() => safeLocalStorage),
	partialize: (state) => ({
		users: state.users,
		permissions: state.permissions,
		equipment: state.equipment,
		breakdowns: state.breakdowns,
		parts: state.parts,
		pmPlans: state.pmPlans,
		pmHistory: state.pmHistory,
		workOrders: state.workOrders,
		notifications: state.notifications,
		sessionUserId: state.sessionUserId,
		section: state.section,
		reportFrom: state.reportFrom,
		reportTo: state.reportTo
	}),
	merge: (persisted, current) => {
		if (!persisted || typeof persisted !== "object") return current;
		const saved = persisted;
		return {
			...current,
			users: Array.isArray(saved.users) && saved.users.length ? saved.users : current.users,
			permissions: isPermissions(saved.permissions) ? saved.permissions : current.permissions,
			equipment: Array.isArray(saved.equipment) ? saved.equipment : current.equipment,
			breakdowns: Array.isArray(saved.breakdowns) ? saved.breakdowns : current.breakdowns,
			parts: Array.isArray(saved.parts) ? saved.parts : current.parts,
			pmPlans: Array.isArray(saved.pmPlans) ? saved.pmPlans : current.pmPlans,
			pmHistory: Array.isArray(saved.pmHistory) ? saved.pmHistory : current.pmHistory,
			workOrders: Array.isArray(saved.workOrders) ? saved.workOrders : current.workOrders,
			notifications: Array.isArray(saved.notifications) ? saved.notifications : current.notifications,
			sessionUserId: saved.sessionUserId ?? null,
			section: isSection(saved.section) ? saved.section : "home",
			reportFrom: saved.reportFrom || current.reportFrom,
			reportTo: saved.reportTo || current.reportTo,
			focus: null
		};
	}
}));
function parseEndBeforeStart(start, end) {
	return parseLocal(end) < parseLocal(start);
}
function isRecord(value) {
	return !!value && typeof value === "object";
}
function isUser(value) {
	if (!isRecord(value)) return false;
	return typeof value.id === "string" && typeof value.username === "string" && typeof value.passwordHash === "string" && (value.role === "admin" || value.role === "supervisor" || value.role === "technician");
}
function isPermSet(value) {
	if (!isRecord(value)) return false;
	return [
		"equipment",
		"breakdowns",
		"pm",
		"parts",
		"reports"
	].every((key) => typeof value[key] === "boolean");
}
function isPermissions(value) {
	return isRecord(value) && isPermSet(value.technician) && isPermSet(value.supervisor);
}
function isEquipment(value) {
	return isRecord(value) && typeof value.id === "string" && typeof value.name === "string";
}
function isBreakdown(value) {
	return isRecord(value) && typeof value.id === "string" && typeof value.equipmentId === "string";
}
function isPart(value) {
	return isRecord(value) && typeof value.id === "string" && typeof value.name === "string";
}
function normalizePart(part) {
	return {
		...part,
		name: part.name || "",
		storeNo: part.storeNo || "",
		qty: Number(part.qty) || 0,
		minQty: Number(part.minQty) || 0,
		equipmentIds: Array.isArray(part.equipmentIds) ? part.equipmentIds.map(String) : [],
		machineQty: part.machineQty && typeof part.machineQty === "object" ? part.machineQty : {}
	};
}
function isPlan(value) {
	return isRecord(value) && typeof value.id === "string" && typeof value.equipmentId === "string";
}
function equipmentName(list, id) {
	return list.find((item) => item.id === id)?.name ?? "معدة محذوفة";
}
function isCritical(part) {
	return part.qty <= part.minQty;
}
function summarize(breakdowns, from, to) {
	const rows = breakdowns.filter((item) => {
		const day = dateOnly(item.start);
		return day >= from && day <= to;
	});
	const closed = rows.filter((item) => item.status === "closed" && item.start && item.end);
	const down = closed.reduce((sum, item) => sum + minutesBetween(item.start, item.end), 0);
	const mttr = closed.length ? Math.round(down / closed.length) : 0;
	const hours = Math.max(0, (parseLocal(`${to}T23:59`) - parseLocal(`${from}T00:00`)) / 36e5);
	const failures = rows.length;
	const uptime = Math.max(0, hours - down / 60);
	return {
		rows,
		closed,
		down,
		mttr,
		mtbf: failures ? Math.round(uptime / failures * 10) / 10 : 0,
		failures,
		open: rows.filter((item) => item.status === "open").length
	};
}
function lifetimeMetrics(breakdowns) {
	const closed = breakdowns.filter((item) => item.status === "closed" && item.start && item.end);
	const down = closed.reduce((sum, item) => sum + minutesBetween(item.start, item.end), 0);
	const mttr = closed.length ? Math.round(down / closed.length) : 0;
	const starts = breakdowns.map((item) => parseLocal(item.start)).filter((value) => !Number.isNaN(value)).sort((a, b) => a - b);
	let mtbf = 0;
	if (starts.length > 1) {
		let gaps = 0;
		for (let index = 1; index < starts.length; index += 1) gaps += (starts[index] - starts[index - 1]) / 36e5;
		mtbf = Math.round(gaps / (starts.length - 1) * 10) / 10;
	}
	return {
		down,
		mttr,
		mtbf
	};
}
function pmDueCount(plans) {
	return plans.filter((plan) => plan.active && daysUntil(plan.nextDate) <= 0).length;
}
function complianceRate(plans, history) {
	const overdue = plans.filter((plan) => plan.active && daysUntil(plan.nextDate) < 0).length;
	const onTime = history.filter((item) => item.onTime).length;
	const dueTotal = history.length + overdue;
	return dueTotal ? Math.round(onTime / dueTotal * 100) : 100;
}
function PageHead({ title, text, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-5 flex flex-wrap items-end justify-between gap-3 border-b border-line pb-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-2xl font-extrabold text-ink",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: text
		})] }), children]
	});
}
function Panel({ title, action, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mb-4 rounded-xl border border-line bg-panel p-4 shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-3 flex items-center justify-between gap-3 border-b border-line pb-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm font-extrabold text-ink",
				children: title
			}), action]
		}), children]
	});
}
function Empty({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "rounded-lg border border-dashed border-line px-4 py-8 text-center text-sm text-muted",
		children
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "field mb-3 block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-xs font-extrabold text-ink",
			children: label
		}), children]
	});
}
function PrimaryButton({ children, type = "button", onClick, disabled, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		onClick,
		disabled,
		className: `inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-accent px-4 text-sm font-extrabold text-on-accent disabled:opacity-60 ${className}`,
		children
	});
}
function SecondaryButton({ children, onClick, disabled, danger }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		disabled,
		className: `inline-flex h-11 items-center justify-center gap-2 rounded-lg border px-4 text-sm font-bold disabled:opacity-60 ${danger ? "border-danger bg-danger text-on-accent" : "border-line bg-soft text-ink"}`,
		children
	});
}
function StatusPill({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `inline-flex rounded-full px-2.5 py-1 text-xs font-extrabold ${status === "open" ? "bg-danger/10 text-danger" : "bg-good/10 text-good"}`,
		children: STATUS_LABEL[status]
	});
}
function PriorityPill({ priority }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `inline-flex rounded-full px-2.5 py-1 text-xs font-extrabold ${priority === "urgent" ? "bg-danger/10 text-danger" : priority === "important" ? "bg-warn/15 text-warn" : "bg-soft text-muted"}`,
		children: PRIORITY_LABEL[priority]
	});
}
function Modal({ title, onClose, children, wide }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-navy/60 p-3 sm:items-center",
		onMouseDown: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			className: `max-h-[90vh] w-full overflow-auto rounded-2xl bg-panel p-5 shadow-xl ${wide ? "max-w-3xl" : "max-w-lg"}`,
			onMouseDown: (event) => event.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-center justify-between gap-3 border-b border-line pb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-base font-extrabold text-ink",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-11 place-items-center rounded-lg border border-line bg-soft",
					onClick: onClose,
					"aria-label": "إغلاق",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				})]
			}), children]
		})
	});
}
function BreakdownsPage({ user }) {
	const data = useCmms();
	const [equipmentId, setEquipmentId] = (0, import_react.useState)(data.equipment[0]?.id ?? "");
	const [description, setDescription] = (0, import_react.useState)("");
	const [cause, setCause] = (0, import_react.useState)("");
	const [action, setAction] = (0, import_react.useState)("");
	const [priority, setPriority] = (0, import_react.useState)("normal");
	const [start, setStart] = (0, import_react.useState)(nowLocal());
	const [end, setEnd] = (0, import_react.useState)("");
	const [picked, setPicked] = (0, import_react.useState)({});
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const focus = data.focus;
	const canLog = canLogBreakdown(user) && canSee(user, data.permissions, "breakdowns");
	(0, import_react.useEffect)(() => {
		if (focus?.kind === "breakdown") {
			setOpenId(focus.id);
			data.markRead(data.notifications.find((item) => item.breakdownId === focus.id)?.id ?? "");
			data.setFocus(null);
		}
	}, [focus, data]);
	const partChoices = (0, import_react.useMemo)(() => data.parts.filter((part) => part.equipmentIds.length === 0 || part.equipmentIds.includes(equipmentId)), [data.parts, equipmentId]);
	const rows = data.breakdowns.filter((item) => filter === "all" || item.equipmentId === filter);
	const current = data.breakdowns.find((item) => item.id === openId) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			title: "بلاغات الأعطال",
			text: "التسجيل يخصم قطع الغيار ويفتح أمر شغل تلقائيًا."
		}),
		canLog ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			title: "تسجيل بلاغ",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: (event) => {
					event.preventDefault();
					const used = Object.entries(picked).filter(([, qty]) => qty > 0).map(([partId, qty]) => {
						const part = data.parts.find((item) => item.id === partId);
						return {
							partId,
							name: part?.name ?? "",
							storeNo: part?.storeNo ?? "",
							qty
						};
					});
					const message = data.addBreakdown({
						equipmentId,
						description,
						cause,
						action,
						priority,
						start,
						end,
						used
					});
					if (message) return toast.error(message);
					setDescription("");
					setCause("");
					setAction("");
					setEnd("");
					setPicked({});
					toast.success("تم تسجيل العطل");
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "المعدة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: equipmentId,
							onChange: (event) => {
								setEquipmentId(event.target.value);
								setPicked({});
							},
							children: data.equipment.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item.id,
								children: item.name
							}, item.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "وصف العطل",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: description,
							onChange: (event) => setDescription(event.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "السبب المبدئي",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: cause,
							onChange: (event) => setCause(event.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الفني",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: user.name,
							readOnly: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "قطع الغيار المستخدمة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-2",
							children: partChoices.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: "لا توجد قطع مرتبطة أو عامة"
							}) : partChoices.map((part) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										className: "size-4",
										checked: picked[part.id] !== void 0,
										onChange: (event) => {
											setPicked((currentPicked) => {
												const next = { ...currentPicked };
												if (event.target.checked) next[part.id] = 1;
												else delete next[part.id];
												return next;
											});
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex-1",
										children: [
											part.name,
											" · متاح ",
											part.qty
										]
									}),
									picked[part.id] !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "h-11 w-20 rounded-lg border border-line bg-panel px-2",
										type: "number",
										min: 1,
										value: picked[part.id],
										onChange: (event) => setPicked((currentPicked) => ({
											...currentPicked,
											[part.id]: Number(event.target.value)
										}))
									}) : null
								]
							}, part.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الإجراء",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: action,
							onChange: (event) => setAction(event.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "البداية",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "datetime-local",
									value: start,
									onChange: (event) => setStart(event.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "الإغلاق (اختياري)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "datetime-local",
									value: end,
									onChange: (event) => setEnd(event.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "الأولوية",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: priority,
									onChange: (event) => setPriority(event.target.value),
									children: Object.keys(PRIORITY_LABEL).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: item,
										children: PRIORITY_LABEL[item]
									}, item))
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						type: "submit",
						disabled: data.equipment.length === 0,
						children: "حفظ العطل"
					})
				]
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			title: "التسجيل",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "تسجيل الأعطال متاح للمسؤول والفني. المشرف يتابع ويغلق."
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			title: "سجل الأعطال",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				className: "h-11 rounded-lg border border-line bg-soft px-2 text-sm",
				value: filter,
				onChange: (event) => setFilter(event.target.value),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: "all",
					children: "كل المعدات"
				}), data.equipment.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: item.id,
					children: item.name
				}, item.id))]
			}),
			children: rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "لا توجد أعطال" }) : rows.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "mb-2 flex items-center gap-3 rounded-lg border border-line p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "block truncate",
							children: equipmentName(data.equipment, item.equipmentId)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate text-sm text-muted",
							children: [
								item.description,
								" · ",
								item.technician
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriorityPill, { priority: item.priority }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: item.status }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
						onClick: () => setOpenId(item.id),
						children: "التفاصيل"
					})
				]
			}, item.id))
		}),
		current ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
			title: "تفاصيل العطل",
			onClose: () => setOpenId(null),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "المعدة: " }), equipmentName(data.equipment, current.equipmentId)]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "الوصف: " }), current.description]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "السبب: " }), current.cause || "غير مسجل"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "الإجراء: " }), current.action || "لم يُسجل"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "الفني: " }), current.technician]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-1 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "البداية: " }),
						formatWhen(current.start),
						" · ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "الإغلاق: " }),
						formatWhen(current.end, "لم يُغلق")
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "التوقف: " }), current.end ? formatMinutes(minutesBetween(current.start, current.end)) : "—"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: current.status }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriorityPill, { priority: current.priority })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "mb-1 font-extrabold",
					children: "قطع الغيار"
				}),
				current.usedParts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "لم تُستخدم قطع"
				}) : current.usedParts.map((part) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm",
					children: [
						part.name,
						" · ",
						part.qty,
						" · ",
						part.storeNo
					]
				}, part.partId)),
				current.status === "open" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						onClick: () => {
							const message = data.closeBreakdown(current.id);
							if (message) toast.error(message);
							else {
								toast.success("تم إغلاق العطل وأمر الشغل");
								setOpenId(null);
							}
						},
						children: "إنهاء وإغلاق العطل"
					})
				}) : null
			]
		}) : null
	] });
}
function WorkOrdersPage() {
	const data = useCmms();
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const current = data.workOrders.find((item) => item.id === openId) ?? null;
	const fault = data.breakdowns.find((item) => item.id === current?.breakdownId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			title: "أوامر الشغل",
			text: "يُنشأ أمر لكل عطل، وتُغلق الحالة مع إغلاق البلاغ."
		}),
		data.workOrders.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "لا توجد أوامر شغل" }) : data.workOrders.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => setOpenId(item.id),
			className: "mb-2 flex w-full items-center gap-3 rounded-xl border border-line bg-panel p-3 text-start shadow-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "block",
						children: item.number
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", {
						className: "text-xs text-muted",
						children: [
							equipmentName(data.equipment, item.equipmentId),
							" · ",
							item.technician
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriorityPill, { priority: item.priority }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: item.status })
			]
		}, item.id)),
		current ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
			title: current.number,
			onClose: () => setOpenId(null),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "المعدة: " }), equipmentName(data.equipment, current.equipmentId)]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "الفني: " }), current.technician]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "أُنشئ: " }), formatWhen(current.createdAt)]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "وصف العطل: " }), fault?.description || "—"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: current.status }),
				fault && fault.status === "open" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						onClick: () => {
							const message = data.closeBreakdown(fault.id);
							if (message) toast.error(message);
							else toast.success("تم إغلاق أمر الشغل");
						},
						children: "إغلاق الأمر"
					})
				}) : null
			]
		}) : null
	] });
}
function readDataUrl(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onerror = () => reject(/* @__PURE__ */ new Error("تعذر قراءة الملف"));
		reader.onload = () => resolve(String(reader.result || ""));
		reader.readAsDataURL(file);
	});
}
function compressImage(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onerror = () => reject(/* @__PURE__ */ new Error("تعذر قراءة الصورة"));
		reader.onload = () => {
			const image = new Image();
			image.onload = () => {
				const scale = Math.min(1, 960 / image.width, 640 / image.height);
				const canvas = document.createElement("canvas");
				canvas.width = Math.max(1, Math.round(image.width * scale));
				canvas.height = Math.max(1, Math.round(image.height * scale));
				const context = canvas.getContext("2d");
				if (!context) {
					reject(/* @__PURE__ */ new Error("تعذر تجهيز الصورة"));
					return;
				}
				context.drawImage(image, 0, 0, canvas.width, canvas.height);
				resolve(canvas.toDataURL("image/jpeg", .72));
			};
			image.onerror = () => reject(/* @__PURE__ */ new Error("تعذر تجهيز الصورة"));
			image.src = String(reader.result || "");
		};
		reader.readAsDataURL(file);
	});
}
function downloadText(filename, content, mime) {
	const blob = new Blob([content], { type: mime });
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = filename;
	link.click();
	URL.revokeObjectURL(url);
}
function EquipmentPage({ user }) {
	const data = useCmms();
	const [name, setName] = (0, import_react.useState)("");
	const [code, setCode] = (0, import_react.useState)("");
	const [model, setModel] = (0, import_react.useState)("");
	const [imageFile, setImageFile] = (0, import_react.useState)(null);
	const [pdfFile, setPdfFile] = (0, import_react.useState)(null);
	const [pending, setPending] = (0, import_react.useState)(false);
	const [open, setOpen] = (0, import_react.useState)(null);
	const [edit, setEdit] = (0, import_react.useState)(null);
	const [removeId, setRemoveId] = (0, import_react.useState)(null);
	const manage = canManageAssets(user);
	async function saveNew(event) {
		event.preventDefault();
		setPending(true);
		try {
			const files = await readFiles(imageFile, pdfFile);
			if (files.error) return toast.error(files.error);
			const message = data.addEquipment({
				name,
				code,
				model,
				image: files.image,
				pdfName: files.pdfName,
				pdfData: files.pdfData
			});
			if (message) return toast.error(message);
			setName("");
			setCode("");
			setModel("");
			setImageFile(null);
			setPdfFile(null);
			toast.success("تم حفظ المعدة");
		} finally {
			setPending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			title: "سجل الأصول والمعدات",
			text: "كل معدة بكودها وصورتها وكتالوجها وقطعها المرتبطة."
		}),
		manage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			title: "إضافة معدة",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: (event) => void saveNew(event),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "اسم المعدة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: name,
							onChange: (event) => setName(event.target.value),
							placeholder: "ماكينة التعبئة 02"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "الكود",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: code,
								onChange: (event) => setCode(event.target.value),
								placeholder: "EQ-102"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "الموديل والقسم",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: model,
								onChange: (event) => setModel(event.target.value),
								placeholder: "خط التعبئة ب"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "صورة المعدة",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								accept: "image/*",
								onChange: (event) => setImageFile(event.target.files?.[0] ?? null)
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "كتالوج PDF حتى 1.2 ميغابايت",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								accept: "application/pdf",
								onChange: (event) => setPdfFile(event.target.files?.[0] ?? null)
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						type: "submit",
						disabled: pending,
						children: pending ? "جاري الحفظ" : "حفظ المعدة"
					})
				]
			})
		}) : null,
		data.equipment.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "لا توجد معدات مسجلة" }) : data.equipment.map((item) => {
			const linked = data.parts.filter((part) => part.equipmentIds.includes(item.id)).length;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "mb-3 flex items-center gap-3 rounded-xl border border-line bg-panel p-3 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex min-w-0 flex-1 items-center gap-3 text-start",
					onClick: () => setOpen(item),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thumb, { equipment: item }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "block truncate",
							children: item.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", {
							className: "text-xs text-muted",
							children: [
								item.code || "بدون كود",
								" · ",
								item.model || "بدون قسم",
								" · ",
								linked,
								" قطع"
							]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
					onClick: () => setOpen(item),
					children: "التفاصيل"
				})]
			}, item.id);
		}),
		open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EquipmentDetail, {
			equipment: open,
			user,
			onClose: () => setOpen(null),
			onEdit: () => {
				setEdit(open);
				setOpen(null);
			},
			onDelete: () => {
				setRemoveId(open.id);
				setOpen(null);
			}
		}) : null,
		edit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditEquipment, {
			equipment: edit,
			onClose: () => setEdit(null)
		}) : null,
		removeId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
			title: "إزالة المعدة",
			onClose: () => setRemoveId(null),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 text-sm",
				children: "ستُحذف المعدة من السجل ويُفك ارتباطها بقطع الغيار. سجل الأعطال يبقى محفوظًا."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
				danger: true,
				onClick: () => {
					const message = data.deleteEquipment(removeId);
					if (message) toast.error(message);
					else toast.success("تمت إزالة المعدة");
					setRemoveId(null);
				},
				children: "تأكيد الإزالة"
			})]
		}) : null
	] });
}
function EquipmentDetail({ equipment, user, onClose, onEdit, onDelete }) {
	const data = useCmms();
	const parts = data.parts.filter((part) => part.equipmentIds.includes(equipment.id));
	const faults = data.breakdowns.filter((item) => item.equipmentId === equipment.id);
	const plans = data.pmPlans.filter((plan) => plan.equipmentId === equipment.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		title: "تفاصيل المعدة",
		onClose,
		wide: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-[180px_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thumb, {
					equipment,
					large: true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "text-xl font-extrabold",
						children: equipment.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"الكود: ",
							equipment.code || "—",
							" · ",
							equipment.model || "—"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [canManageAssets(user) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
							onClick: onEdit,
							children: "تعديل"
						}) : null, user.role === "admin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
							danger: true,
							onClick: onDelete,
							children: "إزالة"
						}) : null]
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "my-4 grid grid-cols-2 gap-2 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat$1, {
						label: "الأعطال",
						value: faults.length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat$1, {
						label: "مفتوحة",
						value: faults.filter((item) => item.status === "open").length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat$1, {
						label: "خطط PM",
						value: plans.length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat$1, {
						label: "قطع مرتبطة",
						value: parts.length
					})
				]
			}),
			equipment.pdfData ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				className: "mb-3 inline-flex font-bold text-accent",
				href: equipment.pdfData,
				download: equipment.pdfName || "catalog.pdf",
				children: "تنزيل كتالوج PDF"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm text-muted",
				children: "لا يوجد كتالوج"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
				className: "mb-2 font-extrabold",
				children: "قطع الغيار"
			}),
			canManageAssets(user) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartLinker, { equipmentId: equipment.id }) : parts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "لا توجد قطع مرتبطة" }) : null,
			!canManageAssets(user) && parts.map((part) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "border-b border-line py-2 text-sm",
				children: [
					part.name,
					" · في الماكينة ",
					part.machineQty[equipment.id] ?? 0,
					" · المخزن ",
					part.qty
				]
			}, part.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
				className: "mb-2 mt-4 font-extrabold",
				children: "آخر الأعطال"
			}),
			faults.slice(0, 5).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between gap-2 rounded-lg bg-soft p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm",
					children: item.description
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: item.status })]
			}, item.id)),
			faults.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "لا توجد أعطال لهذه المعدة" }) : null
		]
	});
}
function PartLinker({ equipmentId }) {
	const data = useCmms();
	if (data.parts.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "أضف قطع غيار أولًا ثم اربطها من هنا" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-2",
		children: data.parts.map((part) => {
			const linked = part.equipmentIds.includes(equipmentId);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2 rounded-lg border border-line p-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1 text-sm font-bold",
						children: [part.name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", {
							className: "block font-normal text-muted",
							children: ["مخزن ", part.qty]
						})]
					}),
					linked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field h-11 w-24 rounded-lg border border-line bg-soft px-2",
						type: "number",
						min: 0,
						value: part.machineQty[equipmentId] ?? 0,
						onChange: (event) => data.setMachineQty(part.id, equipmentId, Number(event.target.value)),
						"aria-label": "عددها في الماكينة"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
						onClick: () => data.togglePartLink(part.id, equipmentId),
						children: linked ? "فك الربط" : "ربط"
					})
				]
			}, part.id);
		})
	});
}
function EditEquipment({ equipment, onClose }) {
	const update = useCmms((state) => state.updateEquipment);
	const [name, setName] = (0, import_react.useState)(equipment.name);
	const [code, setCode] = (0, import_react.useState)(equipment.code);
	const [model, setModel] = (0, import_react.useState)(equipment.model);
	const [imageFile, setImageFile] = (0, import_react.useState)(null);
	const [pdfFile, setPdfFile] = (0, import_react.useState)(null);
	const [pending, setPending] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		title: "تعديل المعدة",
		onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: (event) => {
				event.preventDefault();
				setPending(true);
				(async () => {
					try {
						const files = await readFiles(imageFile, pdfFile);
						if (files.error) return toast.error(files.error);
						const message = update(equipment.id, {
							name,
							code,
							model,
							image: files.image || void 0,
							pdfName: files.pdfName || void 0,
							pdfData: files.pdfData || void 0
						});
						if (message) return toast.error(message);
						toast.success("تم حفظ التعديل");
						onClose();
					} finally {
						setPending(false);
					}
				})();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "اسم المعدة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: name,
						onChange: (event) => setName(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الكود",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: code,
						onChange: (event) => setCode(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الموديل والقسم",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: model,
						onChange: (event) => setModel(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "صورة جديدة (اختياري)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: "image/*",
						onChange: (event) => setImageFile(event.target.files?.[0] ?? null)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "كتالوج جديد (اختياري)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: "application/pdf",
						onChange: (event) => setPdfFile(event.target.files?.[0] ?? null)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					type: "submit",
					disabled: pending,
					children: "حفظ التعديل"
				})
			]
		})
	});
}
function Thumb({ equipment, large }) {
	const className = large ? "h-40 w-full overflow-hidden rounded-xl bg-soft" : "grid size-14 shrink-0 place-items-center overflow-hidden rounded-lg bg-soft text-muted";
	if (!equipment.image) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cog, { className: "size-5" })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: equipment.image,
			alt: "",
			className: "size-full object-cover"
		})
	});
}
function Stat$1({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-soft p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
			className: "block text-xl",
			children: value
		})]
	});
}
async function readFiles(imageFile, pdfFile) {
	if (imageFile && imageFile.size > 10485760) return {
		error: "حجم الصورة الأصلية أكبر من 10 ميغابايت",
		image: "",
		pdfName: "",
		pdfData: ""
	};
	if (pdfFile && pdfFile.size > 12e5) return {
		error: "ملف PDF أكبر من 1.2 ميغابايت حتى لا تمتلئ ذاكرة الجهاز",
		image: "",
		pdfName: "",
		pdfData: ""
	};
	try {
		const image = imageFile ? await compressImage(imageFile) : "";
		const pdfData = pdfFile ? await readDataUrl(pdfFile) : "";
		return {
			error: "",
			image,
			pdfName: pdfFile?.name ?? "",
			pdfData
		};
	} catch {
		return {
			error: "تعذر تجهيز الملفات",
			image: "",
			pdfName: "",
			pdfData: ""
		};
	}
}
function HomePage({ user }) {
	const data = useCmms();
	const open = data.breakdowns.filter((item) => item.status === "open");
	const metrics = lifetimeMetrics(data.breakdowns);
	const critical = data.parts.filter(isCritical).length;
	const due = pmDueCount(data.pmPlans);
	const recent = [...data.breakdowns].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 4);
	const kpis = [
		{
			label: "أعطال مفتوحة",
			value: open.length,
			note: "تحتاج متابعة الآن",
			tone: "danger",
			section: "breakdowns"
		},
		{
			label: "صيانة مستحقة",
			value: due,
			note: "اليوم والمتأخرة",
			tone: "warn",
			section: "pm"
		},
		{
			label: "الأصول والمعدات",
			value: data.equipment.length,
			note: "معدات مسجلة",
			tone: "accent",
			section: "equipment"
		},
		{
			label: "قطع حرجة",
			value: critical,
			note: "عند حد إعادة الطلب أو أقل",
			tone: "teal",
			section: "parts"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			title: "مركز التشغيل",
			text: "حالة المعدات والأعطال والصيانة في وردية واحدة.",
			children: canLogBreakdown(user) && canSee(user, data.permissions, "breakdowns") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
				onClick: () => data.setSection("breakdowns"),
				children: "تسجيل عطل"
			}) : null
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "hero",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hero-copy",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-bold tracking-widest text-navy-muted",
						children: "MAINTENANCE OPERATIONS"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-1 text-2xl font-extrabold",
						children: greeting(user.name)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 max-w-xl text-sm text-navy-muted",
						children: "تابع العطل المفتوح قبل أن يتحول التحذير إلى توقف."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "chip",
								children: "النظام يعمل"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "chip",
								children: "البيانات على هذا الجهاز"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "chip",
								children: [open.length, " عطل مفتوح"]
							})
						]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 grid grid-cols-2 gap-3 lg:grid-cols-4",
			children: kpis.map((kpi) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => data.setSection(kpi.section),
				"data-tone": kpi.tone,
				className: "kpi rounded-xl border border-line bg-panel p-4 text-start shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-bold text-muted",
						children: kpi.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "mt-2 block text-3xl font-extrabold text-ink",
						children: kpi.value
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
						className: "text-xs text-muted",
						children: kpi.note
					})
				]
			}, kpi.label))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "أعطال تحتاج تدخل",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-xs font-extrabold text-accent",
						onClick: () => data.setSection("breakdowns"),
						children: "عرض الكل"
					}),
					children: open.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "لا توجد أعطال مفتوحة" }) : open.slice(0, 5).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex w-full items-center gap-3 border-b border-line py-3 text-start last:border-0",
						onClick: () => {
							data.setFocus({
								kind: "breakdown",
								id: item.id
							});
							data.setSection("breakdowns");
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: `size-2.5 rounded-full ${item.priority === "urgent" ? "bg-danger" : "bg-warn"}` }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									className: "block truncate text-sm",
									children: equipmentName(data.equipment, item.equipmentId)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", {
									className: "block truncate text-xs text-muted",
									children: [
										item.description,
										" · ",
										item.technician
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriorityPill, { priority: item.priority })
						]
					}, item.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "مؤشرات الأعطال المغلقة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
								label: "MTTR",
								value: `${metrics.mttr} د`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
								label: "MTBF",
								value: `${metrics.mtbf} س`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
								label: "التوقف",
								value: formatMinutes(metrics.down)
							})
						]
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "إجراءات سريعة",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							label: "تسجيل عطل",
							onClick: () => data.setSection("breakdowns")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							label: "أمر شغل",
							onClick: () => data.setSection("workorders")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							label: "تنفيذ PM",
							onClick: () => data.setSection("pm")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							label: "المعدات",
							onClick: () => data.setSection("equipment")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							label: "المخزون",
							onClick: () => data.setSection("parts")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							label: "التقارير",
							onClick: () => data.setSection("reports")
						})
					]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "آخر النشاط",
				children: recent.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "لا توجد نشاطات بعد" }) : recent.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 border-b border-line py-3 last:border-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: `size-2.5 rounded-full ${item.status === "open" ? "bg-danger" : "bg-good"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "block truncate text-sm",
							children: equipmentName(data.equipment, item.equipmentId)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", {
							className: "text-xs text-muted",
							children: [
								item.status === "open" ? "مفتوح" : "مغلق",
								" · ",
								item.start.slice(0, 10)
							]
						})]
					})]
				}, item.id))
			})] })]
		})
	] });
}
function Metric({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-line bg-soft p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
			className: "text-xs font-bold text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
			className: "mt-1 block text-xl font-extrabold",
			children: value
		})]
	});
}
function Quick({ label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: "min-h-11 rounded-lg border border-line bg-soft px-3 text-start text-xs font-extrabold text-ink",
		children: label
	});
}
var DEMOS = [
	{
		username: "admin",
		label: "مسؤول",
		hint: "كل الصلاحيات"
	},
	{
		username: "super",
		label: "مشرف صيانة",
		hint: "أصول وخطط وتقارير"
	},
	{
		username: "tech",
		label: "فني صيانة",
		hint: "تسجيل الأعطال والتنفيذ"
	}
];
function LoginScreen() {
	const login = useCmms((state) => state.login);
	const [username, setUsername] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	async function submit(nextUser = username, nextPass = password) {
		setPending(true);
		const message = await login(nextUser, nextPass);
		setPending(false);
		if (message) {
			setError(message);
			toast.error(message);
			return;
		}
		setError("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center bg-navy px-4 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "w-full max-w-md rounded-2xl bg-panel p-7 shadow-xl",
			onSubmit: (event) => {
				event.preventDefault();
				submit();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-6 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mx-auto mb-3 grid size-12 place-items-center rounded-xl bg-navy text-on-navy",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-2xl font-extrabold text-ink",
							children: "مركز تشغيل الصيانة"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "متابعة الأصول والأعطال والصيانة الوقائية"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "اسم المستخدم",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: username,
						onChange: (event) => setUsername(event.target.value),
						autoComplete: "username"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "كلمة المرور",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: password,
						onChange: (event) => setPassword(event.target.value),
						type: "password",
						autoComplete: "current-password"
					})
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-center text-sm font-bold text-danger",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					type: "submit",
					disabled: pending,
					className: "w-full",
					children: pending ? "جاري الدخول" : "تسجيل الدخول"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 border-t border-line pt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-2 text-xs font-bold text-muted",
						children: ["حسابات تجريبية — كلمة المرور ", DEMO_PASSWORD]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-2",
						children: DEMOS.map((demo) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex min-h-11 items-center justify-between rounded-lg border border-line bg-soft px-3 text-start",
							onClick: () => {
								setUsername(demo.username);
								setPassword(DEMO_PASSWORD);
								submit(demo.username, DEMO_PASSWORD);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-extrabold text-ink",
								children: demo.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted",
								children: demo.hint
							})]
						}, demo.username))
					})]
				})
			]
		})
	});
}
var PERM_LABELS = [
	{
		key: "equipment",
		label: "المعدات"
	},
	{
		key: "breakdowns",
		label: "الأعطال"
	},
	{
		key: "pm",
		label: "الصيانة الوقائية"
	},
	{
		key: "parts",
		label: "قطع الغيار"
	},
	{
		key: "reports",
		label: "التقارير"
	}
];
function NotificationsPage() {
	const data = useCmms();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
		title: "مركز التنبيهات",
		text: "تنبيهات الأعطال الجديدة داخل النظام.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
			onClick: () => data.markAllRead(),
			children: "تحديد الكل كمقروء"
		})
	}), data.notifications.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "لا توجد تنبيهات" }) : data.notifications.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => {
			data.markRead(item.id);
			if (item.breakdownId) {
				data.setFocus({
					kind: "breakdown",
					id: item.breakdownId
				});
				data.setSection("breakdowns");
			}
		},
		className: `mb-2 w-full rounded-xl border p-4 text-start ${item.read ? "border-line bg-panel" : "border-accent bg-accent/5"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
				className: "block",
				children: item.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: item.body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
				className: "text-xs text-muted",
				children: formatWhen(item.createdAt)
			})
		]
	}, item.id))] });
}
function UsersPage({ user }) {
	const data = useCmms();
	const [name, setName] = (0, import_react.useState)("");
	const [username, setUsername] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [role, setRole] = (0, import_react.useState)("technician");
	if (user.role !== "admin") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: "المستخدمون",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "هذه الصفحة للمسؤول فقط." })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			title: "المستخدمون والصلاحيات",
			text: "كلمات المرور تُحفظ مشفرة على هذا الجهاز، ولا تُعرض مرة أخرى."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			title: "مستخدم جديد",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: (event) => {
					event.preventDefault();
					data.addUser({
						name,
						username,
						password,
						role
					}).then((message) => {
						if (message) toast.error(message);
						else {
							setName("");
							setUsername("");
							setPassword("");
							toast.success("تمت إضافة المستخدم");
						}
					});
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "الاسم",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: name,
								onChange: (event) => setName(event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "اسم المستخدم",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: username,
								onChange: (event) => setUsername(event.target.value),
								autoComplete: "off"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "كلمة المرور",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: password,
								onChange: (event) => setPassword(event.target.value),
								type: "password",
								autoComplete: "new-password"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "الدور",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: role,
								onChange: (event) => setRole(event.target.value),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "technician",
										children: "فني صيانة"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "supervisor",
										children: "مشرف صيانة"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "admin",
										children: "مسؤول"
									})
								]
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					type: "submit",
					children: "إضافة المستخدم"
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			title: "صلاحيات الأدوار",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermBlock, {
					title: "فني صيانة",
					role: "technician"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermBlock, {
					title: "مشرف صيانة",
					role: "supervisor"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "المسؤول يرى كل الأقسام دائمًا. إخفاء قسم يخفيه من القائمة ولا يسبب خطأ في بقية الشاشات."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			title: "الحسابات",
			children: data.users.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "mb-2 flex items-center justify-between gap-2 rounded-lg border border-line p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: item.name }),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", {
						className: "text-muted",
						children: [
							ROLE_LABEL[item.role],
							" · ",
							item.username
						]
					})
				] }), item.username !== "admin" && item.id !== user.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
					danger: true,
					onClick: () => {
						const message = data.deleteUser(item.id);
						if (message) toast.error(message);
						else toast.success("تم حذف المستخدم");
					},
					children: "حذف"
				}) : null]
			}, item.id))
		})
	] });
}
function PermBlock({ title, role }) {
	const permissions = useCmms((state) => state.permissions);
	const setPerm = useCmms((state) => state.setPerm);
	const set = permissions[role];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
			className: "mb-2 text-sm font-extrabold",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-3",
			children: PERM_LABELS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex min-h-11 items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					className: "size-4",
					checked: !!set?.[item.key],
					onChange: (event) => {
						const message = setPerm(role, item.key, event.target.checked);
						if (message) toast.error(message);
					}
				}), item.label]
			}, item.key))
		})]
	});
}
function SettingsPage({ user }) {
	const data = useCmms();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
		title: "إعدادات النظام",
		text: "النسخة تعمل على هذا الجهاز. لا توجد مزامنة سحابية وهمية."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			title: "هوية النظام",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
					label: "النظام",
					value: "مركز تشغيل الصيانة"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
					label: "المطور",
					value: "ElawadyEssam"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
					label: "البريد",
					value: "ElawadyEssam8@gmail.com"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
					label: "التواصل",
					value: "01112429073"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
					label: "التخزين",
					value: "على هذا المتصفح فقط"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			title: "نسخة احتياطية",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm text-muted",
				children: "صدّر ملفًا يمكنك فتحه لاحقًا على نفس الجهاز أو جهاز آخر. الاستيراد واستعادة التجربة للمسؤول."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
						onClick: () => downloadText("maintenance-backup.json", data.exportBackup(), "application/json"),
						children: "تصدير النسخة"
					}),
					user.role === "admin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "inline-flex h-11 cursor-pointer items-center rounded-lg border border-line bg-soft px-4 text-sm font-bold",
						children: ["استيراد", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "application/json",
							className: "hidden",
							onChange: (event) => {
								const file = event.target.files?.[0];
								event.target.value = "";
								if (!file) return;
								file.text().then((json) => {
									try {
										const message = data.importBackup(JSON.parse(json));
										if (message) toast.error(message);
										else toast.success("تم استيراد النسخة");
									} catch {
										toast.error("تعذر قراءة الملف");
									}
								});
							}
						})]
					}) : null,
					user.role === "admin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
						danger: true,
						onClick: () => {
							if (!window.confirm("ستُستبدل البيانات الحالية بالبيانات التجريبية. هل تريد المتابعة؟")) return;
							const message = data.resetDemo();
							if (message) toast.error(message);
							else toast.success("تمت استعادة البيانات التجريبية");
						},
						children: "استعادة التجربة"
					}) : null
				]
			})]
		})]
	})] });
}
function Info({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-2 rounded-lg bg-soft p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
			className: "block text-sm",
			children: value
		})]
	});
}
function PartsPage({ user }) {
	const data = useCmms();
	const [name, setName] = (0, import_react.useState)("");
	const [storeNo, setStoreNo] = (0, import_react.useState)("");
	const [qty, setQty] = (0, import_react.useState)(5);
	const [minQty, setMinQty] = (0, import_react.useState)(2);
	const [picked, setPicked] = (0, import_react.useState)([]);
	const [query, setQuery] = (0, import_react.useState)("");
	const manage = canManageParts(user);
	const rows = data.parts.filter((part) => {
		return `${part.name} ${part.storeNo} ${part.equipmentIds.map((id) => equipmentName(data.equipment, id)).join(" ")}`.toLowerCase().includes(query.trim().toLowerCase());
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			title: "المخزون وقطع الغيار",
			text: "القطع الحرجة هي التي وصل رصيدها إلى حد إعادة الطلب أو أقل."
		}),
		manage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			title: "إضافة قطعة",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: (event) => {
					event.preventDefault();
					const message = data.addPart({
						name,
						storeNo,
						qty,
						minQty,
						equipmentIds: picked
					});
					if (message) return toast.error(message);
					setName("");
					setStoreNo("");
					setPicked([]);
					toast.success("تمت إضافة القطعة");
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "اسم القطعة",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: name,
									onChange: (event) => setName(event.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "رقم المخزن",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: storeNo,
									onChange: (event) => setStoreNo(event.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "الرصيد",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									min: 0,
									value: qty,
									onChange: (event) => setQty(Number(event.target.value))
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "حد إعادة الطلب",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									min: 0,
									value: minQty,
									onChange: (event) => setMinQty(Number(event.target.value))
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "المعدات المرتبطة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-2 sm:grid-cols-2",
							children: data.equipment.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex min-h-11 items-center gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									className: "size-4",
									checked: picked.includes(item.id),
									onChange: (event) => setPicked(event.target.checked ? [...picked, item.id] : picked.filter((id) => id !== item.id))
								}), item.name]
							}, item.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						type: "submit",
						children: "إضافة القطعة"
					})
				]
			})
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			title: "البحث",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "h-11 w-full rounded-lg border border-line bg-soft px-3",
				value: query,
				onChange: (event) => setQuery(event.target.value),
				placeholder: "اسم القطعة أو رقم المخزن"
			})
		}),
		rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "لا توجد نتائج" }) : rows.map((part) => {
			const names = part.equipmentIds.length ? part.equipmentIds.map((id) => equipmentName(data.equipment, id)).join("، ") : "عامة / غير مرتبطة";
			const critical = isCritical(part);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "mb-3 flex items-center gap-3 rounded-xl border border-line bg-panel p-3 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "block",
							children: part.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								"رقم المخزن ",
								part.storeNo,
								" · الرصيد ",
								part.qty,
								" · الحد ",
								part.minQty
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: names
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `rounded-full px-2.5 py-1 text-xs font-extrabold ${critical ? "bg-danger/10 text-danger" : "bg-good/10 text-good"}`,
					children: critical ? "حرجة" : `الرصيد ${part.qty}`
				})]
			}, part.id);
		})
	] });
}
function PmPage({ user }) {
	const data = useCmms();
	const [tab, setTab] = (0, import_react.useState)("overview");
	const [query, setQuery] = (0, import_react.useState)("");
	const [bucket, setBucket] = (0, import_react.useState)("all");
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [executeId, setExecuteId] = (0, import_react.useState)(null);
	const [day, setDay] = (0, import_react.useState)(null);
	const active = data.pmPlans.filter((plan) => plan.active);
	const filtered = active.filter((plan) => {
		const text = `${plan.title} ${equipmentName(data.equipment, plan.equipmentId)} ${plan.assignedTo}`.toLowerCase();
		const diff = daysUntil(plan.nextDate);
		const bucketOk = bucket === "all" || bucket === "overdue" && diff < 0 || bucket === "today" && diff === 0 || bucket === "week" && diff >= 0 && diff <= 7 || bucket === "later" && diff > 7;
		return text.includes(query.trim().toLowerCase()) && bucketOk;
	});
	const counts = {
		total: active.length,
		today: active.filter((plan) => daysUntil(plan.nextDate) === 0).length,
		overdue: active.filter((plan) => daysUntil(plan.nextDate) < 0).length,
		week: active.filter((plan) => {
			const diff = daysUntil(plan.nextDate);
			return diff >= 0 && diff <= 7;
		}).length,
		compliance: complianceRate(data.pmPlans, data.pmHistory)
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			title: "الصيانة الوقائية",
			text: "خطة واحدة لكل معدة: موعد، قائمة فحص، وتنفيذ يحرّك الاستحقاق.",
			children: canManagePlans(user) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
				onClick: () => setEditing("new"),
				children: "إنشاء خطة"
			}) : null
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid grid-cols-2 gap-2 lg:grid-cols-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
					label: "الخطط",
					value: String(counts.total),
					onClick: () => setBucket("all")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
					label: "اليوم",
					value: String(counts.today),
					onClick: () => setBucket("today")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
					label: "متأخرة",
					value: String(counts.overdue),
					onClick: () => setBucket("overdue")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
					label: "خلال 7 أيام",
					value: String(counts.week),
					onClick: () => setBucket("week")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
					label: "الالتزام",
					value: `${counts.compliance}%`,
					onClick: () => setTab("history")
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-3 flex flex-wrap gap-2",
			children: [
				"overview",
				"calendar",
				"history"
			].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setTab(item),
				className: `h-11 rounded-lg px-3 text-sm font-extrabold ${tab === item ? "bg-accent text-on-accent" : "border border-line bg-panel text-ink"}`,
				children: item === "overview" ? "نظرة عامة" : item === "calendar" ? "التقويم" : "سجل التنفيذ"
			}, item))
		}),
		tab === "overview" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "أقرب الاستحقاقات",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "h-11 rounded-lg border border-line bg-soft px-2 text-sm",
					value: bucket,
					onChange: (event) => setBucket(event.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "الكل"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "overdue",
							children: "متأخرة"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "today",
							children: "اليوم"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "week",
							children: "7 أيام"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "later",
							children: "قادمة"
						})
					]
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "mb-3 h-11 w-full rounded-lg border border-line bg-soft px-3",
					value: query,
					onChange: (event) => setQuery(event.target.value),
					placeholder: "بحث في الخطط أو المعدات"
				}), filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "لا توجد خطط في هذا التصنيف" }) : filtered.slice().sort((a, b) => daysUntil(a.nextDate) - daysUntil(b.nextDate)).map((plan) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanRow, {
					plan,
					onOpen: () => setExecuteId(plan.id),
					onEdit: canManagePlans(user) ? () => setEditing(plan) : void 0
				}, plan.id))]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "كل الخطط",
				children: active.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "أنشئ أول خطة للبدء" }) : active.map((plan) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanRow, {
					plan,
					onOpen: () => setExecuteId(plan.id),
					onEdit: canManagePlans(user) ? () => setEditing(plan) : void 0
				}, plan.id))
			})]
		}) : null,
		tab === "calendar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, {
			plans: active,
			selected: day,
			onSelect: setDay,
			onExecute: setExecuteId
		}) : null,
		tab === "history" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			title: "سجل التنفيذ",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-3 text-sm text-muted",
				children: [
					"الالتزام = التنفيذ في الموعد ÷ (كل التنفيذات + الخطط المتأخرة الآن). الحالي ",
					counts.compliance,
					"%."
				]
			}), data.pmHistory.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "لا يوجد تنفيذ بعد" }) : data.pmHistory.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "mb-2 border-s-4 border-accent bg-soft p-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: item.title }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-muted",
						children: [
							equipmentName(data.equipment, item.equipmentId),
							" · ",
							item.date,
							" · ",
							item.technician,
							" · ",
							item.onTime ? "في الموعد" : "بعد الموعد"
						]
					}),
					item.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: item.note }) : null
				]
			}, item.id))]
		}) : null,
		editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanForm, {
			plan: editing === "new" ? null : editing,
			onClose: () => setEditing(null)
		}) : null,
		executeId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExecutePlan, {
			id: executeId,
			onClose: () => setExecuteId(null)
		}) : null
	] });
}
function Kpi({ label, value, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "rounded-xl border border-line bg-panel p-3 text-start shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
			className: "text-xs font-bold text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
			className: "mt-1 block text-2xl",
			children: value
		})]
	});
}
function PlanRow({ plan, onOpen, onEdit }) {
	const equipment = useCmms((state) => state.equipment);
	const diff = daysUntil(plan.nextDate);
	const label = diff < 0 ? "متأخرة" : diff === 0 ? "اليوم" : diff <= 7 ? "خلال أسبوع" : "مجدولة";
	const tone = diff < 0 || diff === 0 ? "bg-danger/10 text-danger" : diff <= 7 ? "bg-warn/15 text-warn" : "bg-good/10 text-good";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-2 flex flex-wrap items-center gap-2 rounded-lg border border-line p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
					className: "block text-sm",
					children: plan.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", {
					className: "text-xs text-muted",
					children: [
						equipmentName(equipment, plan.equipmentId),
						" · ",
						plan.nextDate,
						" · ",
						FREQUENCY_LABEL[plan.frequency]
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `rounded-full px-2 py-1 text-xs font-extrabold ${tone}`,
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
				onClick: onOpen,
				children: "تنفيذ"
			}),
			onEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
				onClick: onEdit,
				children: "تعديل"
			}) : null
		]
	});
}
function Calendar({ plans, selected, onSelect, onExecute }) {
	const equipment = useCmms((state) => state.equipment);
	const now = /* @__PURE__ */ new Date();
	const year = now.getFullYear();
	const month = now.getMonth();
	const first = new Date(year, month, 1);
	const count = new Date(year, month + 1, 0).getDate();
	const offset = (first.getDay() + 1) % 7;
	const names = [
		"السبت",
		"الأحد",
		"الإثنين",
		"الثلاثاء",
		"الأربعاء",
		"الخميس",
		"الجمعة"
	];
	const cells = [...Array(offset).fill(null), ...Array.from({ length: count }, (_, index) => index + 1)];
	const selectedPlans = plans.filter((plan) => plan.nextDate === selected);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		title: `تقويم ${now.toLocaleDateString("ar-EG-u-nu-latn", {
			month: "long",
			year: "numeric"
		})}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-7 gap-1",
			children: [names.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-1 text-center text-xs font-extrabold text-muted",
				children: name
			}, name)), cells.map((value, index) => {
				if (!value) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {}, `e-${index}`);
				const iso = `${year}-${String(month + 1).padStart(2, "0")}-${String(value).padStart(2, "0")}`;
				const hits = plans.filter((plan) => plan.nextDate === iso);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onSelect(iso),
					className: `min-h-16 rounded-lg border p-1 text-start ${selected === iso ? "border-accent bg-accent/10" : "border-line bg-panel"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "text-xs",
						children: value
					}), hits.slice(0, 2).map((plan) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block truncate rounded bg-soft px-1 text-xs text-accent",
						children: plan.title
					}, plan.id))]
				}, iso);
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4",
			children: !selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "اختر يومًا لعرض خططه"
			}) : selectedPlans.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "لا توجد صيانة في هذا اليوم" }) : selectedPlans.map((plan) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-sm",
					children: [
						plan.title,
						" · ",
						equipmentName(equipment, plan.equipmentId)
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
					onClick: () => onExecute(plan.id),
					children: "تنفيذ"
				})]
			}, plan.id))
		})]
	});
}
function PlanForm({ plan, onClose }) {
	const data = useCmms();
	const [equipmentId, setEquipmentId] = (0, import_react.useState)(plan?.equipmentId ?? data.equipment[0]?.id ?? "");
	const [title, setTitle] = (0, import_react.useState)(plan?.title ?? "");
	const [frequency, setFrequency] = (0, import_react.useState)(plan?.frequency ?? "monthly");
	const [intervalDays, setIntervalDays] = (0, import_react.useState)(plan?.intervalDays ?? 30);
	const [nextDate, setNextDate] = (0, import_react.useState)(plan?.nextDate ?? today());
	const [assignedTo, setAssignedTo] = (0, import_react.useState)(plan?.assignedTo ?? "");
	const [tasks, setTasks] = (0, import_react.useState)(plan?.tasks ?? ["فحص بصري"]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		title: plan ? "تعديل خطة" : "إنشاء خطة",
		onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: (event) => {
				event.preventDefault();
				const message = data.savePlan({
					id: plan?.id,
					equipmentId,
					title,
					frequency,
					intervalDays,
					nextDate,
					assignedTo,
					tasks
				});
				if (message) return toast.error(message);
				toast.success("تم حفظ الخطة");
				onClose();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "المعدة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: equipmentId,
						onChange: (event) => setEquipmentId(event.target.value),
						children: data.equipment.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item.id,
							children: item.name
						}, item.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "اسم الخطة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: title,
						onChange: (event) => setTitle(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "التكرار",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: frequency,
								onChange: (event) => {
									const next = event.target.value;
									setFrequency(next);
									setIntervalDays(FREQUENCY_DAYS[next]);
								},
								children: Object.keys(FREQUENCY_LABEL).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item,
									children: FREQUENCY_LABEL[item]
								}, item))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "كل (يوم)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								min: 1,
								value: intervalDays,
								onChange: (event) => setIntervalDays(Number(event.target.value))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "الاستحقاق",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "date",
								value: nextDate,
								onChange: (event) => setNextDate(event.target.value)
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "المسؤول",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: assignedTo,
						onChange: (event) => setAssignedTo(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "text-xs",
							children: "قائمة الفحص"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-xs font-extrabold text-accent",
							onClick: () => setTasks([...tasks, ""]),
							children: "إضافة بند"
						})]
					}), tasks.map((task, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "h-11 flex-1 rounded-lg border border-line bg-soft px-3",
							value: task,
							onChange: (event) => setTasks(tasks.map((item, itemIndex) => itemIndex === index ? event.target.value : item))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
							onClick: () => setTasks(tasks.filter((_, itemIndex) => itemIndex !== index)),
							children: "حذف"
						})]
					}, index))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					type: "submit",
					children: "حفظ الخطة"
				})
			]
		})
	});
}
function ExecutePlan({ id, onClose }) {
	const data = useCmms();
	const plan = data.pmPlans.find((item) => item.id === id);
	const [checked, setChecked] = (0, import_react.useState)({});
	const [note, setNote] = (0, import_react.useState)("");
	const tasks = plan?.tasks ?? [];
	const ready = (0, import_react.useMemo)(() => tasks.every((_, index) => checked[index]), [tasks, checked]);
	if (!plan) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		title: "تنفيذ الخطة",
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-3 text-sm",
				children: [
					plan.title,
					" · ",
					equipmentName(data.equipment, plan.equipmentId),
					" · الاستحقاق ",
					plan.nextDate
				]
			}),
			tasks.map((task, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mb-2 flex min-h-11 items-center gap-2 rounded-lg border border-line px-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					className: "size-4",
					checked: !!checked[index],
					onChange: (event) => setChecked({
						...checked,
						[index]: event.target.checked
					})
				}), task]
			}, index)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "ملاحظة",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: note,
					onChange: (event) => setNote(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
				disabled: !ready,
				onClick: () => {
					const message = data.executePlan(plan.id, note);
					if (message) return toast.error(message);
					toast.success("تم تسجيل التنفيذ وتحريك الموعد");
					onClose();
				},
				children: "تأكيد التنفيذ"
			})
		]
	});
}
function ReportsPage({ user }) {
	const data = useCmms();
	const allowed = canSee(user, data.permissions, "reports");
	const [from, setFrom] = (0, import_react.useState)(data.reportFrom);
	const [to, setTo] = (0, import_react.useState)(data.reportTo);
	const [dailyDate, setDailyDate] = (0, import_react.useState)(today());
	const [dailyEq, setDailyEq] = (0, import_react.useState)("");
	const [equipmentId, setEquipmentId] = (0, import_react.useState)(data.equipment[0]?.id ?? "");
	if (!allowed) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
		title: "التقارير",
		text: "مؤشرات الفترة المحددة."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: "غير متاح",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-bold text-danger",
			children: "ليس لديك صلاحية التقارير. يمكن للمسؤول تفعيلها من المستخدمين."
		})
	})] });
	const summary = summarize(data.breakdowns, data.reportFrom, data.reportTo);
	const chart = data.equipment.map((item) => ({
		name: item.name,
		count: summary.rows.filter((row) => row.equipmentId === item.id).length
	})).filter((item) => item.count > 0);
	const one = summarize(data.breakdowns.filter((item) => item.equipmentId === equipmentId), data.reportFrom, data.reportTo);
	const daily = data.breakdowns.filter((item) => item.start.slice(0, 10) === dailyDate && (!dailyEq || item.equipmentId === dailyEq));
	const dailyDown = daily.filter((item) => item.status === "closed").reduce((sum, item) => sum + minutesBetween(item.start, item.end), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			title: "مؤشرات الأداء والتقارير",
			text: "MTTR وMTBF والتوقف محسوبان على الفترة التي تحددها، وليس على أرقام ثابتة."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			title: "فترة التقرير",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "من",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "date",
						value: from,
						onChange: (event) => setFrom(event.target.value)
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "إلى",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "date",
						value: to,
						onChange: (event) => setTo(event.target.value)
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					onClick: () => {
						const message = data.setReportRange(from, to);
						if (message) toast.error(message);
						else toast.success("تم تطبيق الفترة");
					},
					children: "تطبيق الفترة"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
					onClick: () => exportSummary(data.equipment, data.breakdowns, data.reportFrom, data.reportTo),
					children: "تصدير Excel"
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid grid-cols-2 gap-3 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "الأعطال",
					value: String(summary.failures)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "مفتوحة / مغلقة",
					value: `${summary.open} / ${summary.closed.length}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "التوقف",
					value: formatMinutes(summary.down)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "MTTR / MTBF",
					value: `${summary.mttr} د · ${summary.mtbf} س`
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			title: "الأعطال حسب المعدة",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaultChart, { data: chart })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			title: "تقرير معدة",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "المعدة",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					value: equipmentId,
					onChange: (event) => setEquipmentId(event.target.value),
					children: data.equipment.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: item.id,
						children: item.name
					}, item.id))
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					"الأعطال ",
					one.failures,
					" · المفتوحة ",
					one.open,
					" · التوقف ",
					formatMinutes(one.down),
					" · MTTR ",
					one.mttr,
					" د · MTBF ",
					one.mtbf,
					" س"
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			title: "تقرير الأعطال اليومية",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
				onClick: () => window.print(),
				children: "طباعة"
			}),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				id: "daily-report",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "التاريخ",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "date",
								value: dailyDate,
								onChange: (event) => setDailyDate(event.target.value)
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "المعدة",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: dailyEq,
								onChange: (event) => setDailyEq(event.target.value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "كل المعدات"
								}), data.equipment.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item.id,
									children: item.name
								}, item.id))]
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 grid grid-cols-3 gap-2 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "البلاغات",
								value: String(daily.length)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "مفتوحة",
								value: String(daily.filter((item) => item.status === "open").length)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "التوقف",
								value: formatMinutes(dailyDown)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full border-collapse text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
								className: "bg-soft text-start",
								children: [
									"المعدة",
									"الوصف",
									"الفني",
									"البداية",
									"الإغلاق",
									"الحالة",
									"التوقف",
									"القطع"
								].map((head) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "border border-line p-2 text-start",
									children: head
								}, head))
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: daily.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 8,
								className: "border border-line p-4 text-center text-muted",
								children: "لا توجد أعطال في هذا اليوم"
							}) }) : daily.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "border border-line p-2",
									children: equipmentName(data.equipment, item.equipmentId)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "border border-line p-2",
									children: item.description
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "border border-line p-2",
									children: item.technician
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "border border-line p-2",
									children: formatWhen(item.start)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "border border-line p-2",
									children: formatWhen(item.end, "—")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "border border-line p-2",
									children: item.status === "open" ? "مفتوح" : "مغلق"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "border border-line p-2",
									children: item.end ? formatMinutes(minutesBetween(item.start, item.end)) : "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "border border-line p-2",
									children: item.usedParts.map((part) => `${part.name} (${part.qty})`).join("، ") || "—"
								})
							] }, item.id)) })]
						})
					})
				]
			})
		})
	] });
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-line bg-panel p-3 shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
			className: "text-xs font-bold text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
			className: "mt-1 block text-xl",
			children: value
		})]
	});
}
function FaultChart({ data }) {
	const [lib, setLib] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		import("../_libs/recharts+[...].mjs").then((n) => n.t).then((module) => {
			if (live) setLib(module);
		});
		return () => {
			live = false;
		};
	}, []);
	if (data.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "لا توجد أعطال داخل الفترة" });
	if (!lib) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-60 rounded-lg bg-soft" });
	const { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } = lib;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-60",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
				data,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "name",
						tick: {
							fill: "var(--color-muted)",
							fontSize: 11
						},
						interval: 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						allowDecimals: false,
						tick: {
							fill: "var(--color-muted)",
							fontSize: 11
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
						dataKey: "count",
						name: "الأعطال",
						fill: "var(--color-accent)",
						radius: [
							4,
							4,
							0,
							0
						]
					})
				]
			})
		})
	});
}
function exportSummary(equipment, breakdowns, from, to) {
	const rows = [[
		"المعدة",
		"عدد الأعطال",
		"مفتوحة",
		"التوقف بالدقائق",
		"MTTR",
		"MTBF"
	]];
	equipment.forEach((item) => {
		const summary = summarize(breakdowns.filter((row) => row.equipmentId === item.id), from, to);
		rows.push([
			item.name,
			String(summary.failures),
			String(summary.open),
			String(summary.down),
			String(summary.mttr),
			String(summary.mtbf)
		]);
	});
	const csv = `\uFEFF${rows.map((row) => row.map((value) => `"${value.replaceAll("\"", "\"\"")}"`).join(",")).join("\n")}`;
	downloadText(`maintenance-${from}-${to}.csv`, csv, "text/csv;charset=utf-8");
}
var MAIN = [
	{
		id: "home",
		label: "لوحة التشغيل",
		icon: LayoutDashboard
	},
	{
		id: "equipment",
		label: "الأصول والمعدات",
		icon: Cog
	},
	{
		id: "breakdowns",
		label: "بلاغات الأعطال",
		icon: Wrench
	},
	{
		id: "workorders",
		label: "أوامر الصيانة",
		icon: ClipboardList
	},
	{
		id: "pm",
		label: "الصيانة الوقائية",
		icon: CalendarClock
	},
	{
		id: "parts",
		label: "المخزون وقطع الغيار",
		icon: Package
	},
	{
		id: "reports",
		label: "مؤشرات الأداء",
		icon: ChartColumn
	},
	{
		id: "notifications",
		label: "مركز التنبيهات",
		icon: Bell
	}
];
var FOOT = [{
	id: "users",
	label: "المستخدمون والصلاحيات",
	icon: Users
}, {
	id: "settings",
	label: "إعدادات النظام",
	icon: Settings
}];
function MaintenanceApp() {
	const user = useCmms((state) => state.users.find((item) => item.id === state.sessionUserId) ?? null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		dir: "rtl",
		position: "top-center"
	}), user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { user }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginScreen, {})] });
}
function Shell({ user }) {
	const section = useCmms((state) => state.section);
	const setSection = useCmms((state) => state.setSection);
	const permissions = useCmms((state) => state.permissions);
	const unread = useCmms((state) => state.notifications.filter((item) => !item.read).length);
	const logout = useCmms((state) => state.logout);
	const [open, setOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!canSee(user, permissions, section)) setSection("home");
	}, [
		user,
		permissions,
		section,
		setSection
	]);
	function go(id) {
		setSection(id);
		setOpen(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-canvas",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "topbar no-print",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "menu-btn",
						"aria-expanded": open,
						"aria-label": "فتح قائمة الأقسام",
						onClick: () => setOpen(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-4" }), "الأقسام"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "me-auto truncate text-base font-extrabold",
						children: "مركز تشغيل الصيانة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "hidden max-w-48 truncate text-xs text-navy-muted sm:block",
						children: [
							user.name,
							" — ",
							ROLE_LABEL[user.role]
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "icon-btn relative",
						"aria-label": "التنبيهات",
						onClick: () => go("notifications"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-4" }), unread > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute -top-1 -start-1 grid min-w-5 place-items-center rounded-full bg-danger px-1 text-xs text-on-accent",
							children: unread
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "icon-btn",
						"aria-label": "خروج",
						onClick: logout,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" })
					})
				]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "scrim",
				"aria-label": "إغلاق القائمة",
				onClick: () => setOpen(false)
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "app-body",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: `sidebar no-print ${open ? "is-open" : ""}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "side-brand",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "مركز التشغيل" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "Maintenance Control Center" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							"aria-label": "أقسام النظام",
							children: MAIN.filter((item) => canSee(user, permissions, item.id)).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
								item,
								active: section === item.id,
								badge: item.id === "notifications" ? unread : 0,
								onClick: () => go(item.id)
							}, item.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "side-foot",
							children: FOOT.filter((item) => canSee(user, permissions, item.id)).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
								item,
								active: section === item.id,
								badge: 0,
								onClick: () => go(item.id)
							}, item.id))
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "main-pane",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "page",
						children: [
							section === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomePage, { user }) : null,
							section === "equipment" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EquipmentPage, { user }) : null,
							section === "breakdowns" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BreakdownsPage, { user }) : null,
							section === "workorders" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkOrdersPage, {}) : null,
							section === "pm" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PmPage, { user }) : null,
							section === "parts" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartsPage, { user }) : null,
							section === "reports" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportsPage, { user }) : null,
							section === "notifications" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotificationsPage, {}) : null,
							section === "users" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsersPage, { user }) : null,
							section === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPage, { user }) : null
						]
					})
				})]
			})
		]
	});
}
function NavButton({ item, active, badge, onClick }) {
	const Icon = item.icon;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: `side-link ${active ? "is-active" : ""}`,
		"aria-current": active ? "page" : void 0,
		onClick,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "side-ico",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "truncate",
				children: item.label
			}),
			badge > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ms-auto rounded-full bg-danger px-2 text-xs text-on-accent",
				children: badge
			}) : null
		]
	});
}
function Home() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		Promise.resolve(useCmms.persist.rehydrate()).finally(() => setReady(true));
	}, []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center bg-navy text-on-navy",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-lg font-extrabold",
				children: "مركز تشغيل الصيانة"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-navy-muted",
				children: "جاري تحميل البيانات"
			})]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MaintenanceApp, {});
}
//#endregion
export { Home as component };
