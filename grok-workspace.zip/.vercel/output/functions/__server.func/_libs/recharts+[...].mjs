import { i as __toESM, n as __exportAll } from "../_runtime.mjs";
import { q as require_react } from "./@tanstack/react-router+[...].mjs";
import { t as clsx } from "./clsx.mjs";
import { C as require_isNumber, D as require_memoize, E as require_get, O as require_isFunction, S as require_isNaN, T as require_isNil, _ as require_max, a as require_mapValues, b as require_uniqBy, c as require_first, d as require_minBy, f as require_maxBy, g as require_min, h as require_flatMap, i as require_every, k as require_isObject, l as require_isBoolean, m as require_isEqual, n as require_omit, o as require_some, p as require_last, r as require_find, s as require_range, t as require_sumBy, u as require_isPlainObject, v as require_throttle, w as require_isString, x as require_upperFirst, y as require_sortBy } from "./lodash.mjs";
import { t as require_react_is } from "./react-is.mjs";
import { C as cross_default, D as area_default, E as bumpY, O as line_default, S as diamond_default, T as bumpX, _ as Symbol$1, a as none_default$1, b as star_default, c as stepBefore, d as monotoneX, f as monotoneY, g as basis_default, h as basisClosed_default, i as stack_default, k as linear_default, l as step_default, m as basisOpen_default, n as silhouette_default, o as none_default, p as linearClosed_default, r as expand_default, s as stepAfter, t as wiggle_default, u as natural_default, v as wye_default, w as circle_default, x as square_default, y as triangle_default } from "./d3-shape.mjs";
import { C as linear, D as implicit, E as point, O as ordinal, S as identity$1, T as band, _ as radial, a as divergingSymlog, b as symlog, c as sequentialLog, d as sequentialSymlog, f as utcTime, g as quantile, h as quantize, i as divergingSqrt, l as sequentialPow, m as threshold, n as divergingLog, o as sequentialQuantile, p as time, r as divergingPow, s as sequential, t as diverging, u as sequentialSqrt, v as pow, w as tickFormat, x as log, y as sqrt } from "./d3-scale+[...].mjs";
import { t as decimal_default } from "./decimal.js-light.mjs";
import { t as es6_default } from "./react-smooth.mjs";
import { t as require_eventemitter3 } from "./eventemitter3.mjs";
//#region node_modules/recharts/es6/util/DataUtils.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_isObject = /* @__PURE__ */ __toESM(require_isObject());
var import_isFunction = /* @__PURE__ */ __toESM(require_isFunction());
var import_react_is = require_react_is();
var import_isString = /* @__PURE__ */ __toESM(require_isString());
var import_isNaN = /* @__PURE__ */ __toESM(require_isNaN());
var import_get = /* @__PURE__ */ __toESM(require_get());
var import_isNumber = /* @__PURE__ */ __toESM(require_isNumber());
var import_isNil = /* @__PURE__ */ __toESM(require_isNil());
var mathSign = function mathSign(value) {
	if (value === 0) return 0;
	if (value > 0) return 1;
	return -1;
};
var isPercent = function isPercent(value) {
	return (0, import_isString.default)(value) && value.indexOf("%") === value.length - 1;
};
var isNumber$1 = function isNumber(value) {
	return (0, import_isNumber.default)(value) && !(0, import_isNaN.default)(value);
};
var isNullish = function isNullish(value) {
	return (0, import_isNil.default)(value);
};
var isNumOrStr = function isNumOrStr(value) {
	return isNumber$1(value) || (0, import_isString.default)(value);
};
var idCounter = 0;
var uniqueId = function uniqueId(prefix) {
	var id = ++idCounter;
	return "".concat(prefix || "").concat(id);
};
/**
* Get percent value of a total value
* @param {number|string} percent A percent
* @param {number} totalValue     Total value
* @param {number} defaultValue   The value returned when percent is undefined or invalid
* @param {boolean} validate      If set to be true, the result will be validated
* @return {number} value
*/
var getPercentValue = function getPercentValue(percent, totalValue) {
	var defaultValue = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 0;
	var validate = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : false;
	if (!isNumber$1(percent) && !(0, import_isString.default)(percent)) return defaultValue;
	var value;
	if (isPercent(percent)) {
		var index = percent.indexOf("%");
		value = totalValue * parseFloat(percent.slice(0, index)) / 100;
	} else value = +percent;
	if ((0, import_isNaN.default)(value)) value = defaultValue;
	if (validate && value > totalValue) value = totalValue;
	return value;
};
var getAnyElementOfObject = function getAnyElementOfObject(obj) {
	if (!obj) return null;
	var keys = Object.keys(obj);
	if (keys && keys.length) return obj[keys[0]];
	return null;
};
var hasDuplicate = function hasDuplicate(ary) {
	if (!Array.isArray(ary)) return false;
	var len = ary.length;
	var cache = {};
	for (var i = 0; i < len; i++) if (!cache[ary[i]]) cache[ary[i]] = true;
	else return true;
	return false;
};
var interpolateNumber$1 = function interpolateNumber(numberA, numberB) {
	if (isNumber$1(numberA) && isNumber$1(numberB)) return function(t) {
		return numberA + t * (numberB - numberA);
	};
	return function() {
		return numberB;
	};
};
function findEntryInArray(ary, specifiedKey, specifiedValue) {
	if (!ary || !ary.length) return null;
	return ary.find(function(entry) {
		return entry && (typeof specifiedKey === "function" ? specifiedKey(entry) : (0, import_get.default)(entry, specifiedKey)) === specifiedValue;
	});
}
/**
* The least square linear regression
* @param {Array} data The array of points
* @returns {Object} The domain of x, and the parameter of linear function
*/
var getLinearRegression = function getLinearRegression(data) {
	if (!data || !data.length) return null;
	var len = data.length;
	var xsum = 0;
	var ysum = 0;
	var xysum = 0;
	var xxsum = 0;
	var xmin = Infinity;
	var xmax = -Infinity;
	var xcurrent = 0;
	var ycurrent = 0;
	for (var i = 0; i < len; i++) {
		xcurrent = data[i].cx || 0;
		ycurrent = data[i].cy || 0;
		xsum += xcurrent;
		ysum += ycurrent;
		xysum += xcurrent * ycurrent;
		xxsum += xcurrent * xcurrent;
		xmin = Math.min(xmin, xcurrent);
		xmax = Math.max(xmax, xcurrent);
	}
	var a = len * xxsum !== xsum * xsum ? (len * xysum - xsum * ysum) / (len * xxsum - xsum * xsum) : 0;
	return {
		xmin,
		xmax,
		a,
		b: (ysum - a * xsum) / len
	};
};
/**
* Compare values.
*
* This function is intended to be passed to `Array.prototype.sort()`. It properly compares generic homogeneous arrays that are either `string[]`,
* `number[]`, or `Date[]`. When comparing heterogeneous arrays or homogeneous arrays of other types, it will attempt to compare items properly but
* will fall back to string comparison for mismatched or unsupported types.
*
* For some background, `Array.prototype.sort()`'s default comparator coerces each of the array's items into a string and compares the strings. This
* often leads to undesirable behavior, especially with numerical items.
*
* @param {unknown} a The first item to compare
* @param {unknown} b The second item to compare
* @return {number} A negative number if a < b, a positive number if a > b, 0 if equal
*/
var compareValues = function compareValues(a, b) {
	if (isNumber$1(a) && isNumber$1(b)) return a - b;
	if ((0, import_isString.default)(a) && (0, import_isString.default)(b)) return a.localeCompare(b);
	if (a instanceof Date && b instanceof Date) return a.getTime() - b.getTime();
	return String(a).localeCompare(String(b));
};
//#endregion
//#region node_modules/recharts/es6/util/ShallowEqual.js
function shallowEqual(a, b) {
	for (var key in a) if ({}.hasOwnProperty.call(a, key) && (!{}.hasOwnProperty.call(b, key) || a[key] !== b[key])) return false;
	for (var _key in b) if ({}.hasOwnProperty.call(b, _key) && !{}.hasOwnProperty.call(a, _key)) return false;
	return true;
}
//#endregion
//#region node_modules/recharts/es6/util/types.js
function _typeof$55(o) {
	"@babel/helpers - typeof";
	return _typeof$55 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$55(o);
}
/**
* Determines how values are stacked:
*
* - `none` is the default, it adds values on top of each other. No smarts. Negative values will overlap.
* - `expand` make it so that the values always add up to 1 - so the chart will look like a rectangle.
* - `wiggle` and `silhouette` tries to keep the chart centered.
* - `sign` stacks positive values above zero and negative values below zero. Similar to `none` but handles negatives.
* - `positive` ignores all negative values, and then behaves like \`none\`.
*
* Also see https://d3js.org/d3-shape/stack#stack-offsets
* (note that the `diverging` offset in d3 is named `sign` in recharts)
*/
var SVGContainerPropKeys = ["viewBox", "children"];
var SVGElementPropKeys = [
	"aria-activedescendant",
	"aria-atomic",
	"aria-autocomplete",
	"aria-busy",
	"aria-checked",
	"aria-colcount",
	"aria-colindex",
	"aria-colspan",
	"aria-controls",
	"aria-current",
	"aria-describedby",
	"aria-details",
	"aria-disabled",
	"aria-errormessage",
	"aria-expanded",
	"aria-flowto",
	"aria-haspopup",
	"aria-hidden",
	"aria-invalid",
	"aria-keyshortcuts",
	"aria-label",
	"aria-labelledby",
	"aria-level",
	"aria-live",
	"aria-modal",
	"aria-multiline",
	"aria-multiselectable",
	"aria-orientation",
	"aria-owns",
	"aria-placeholder",
	"aria-posinset",
	"aria-pressed",
	"aria-readonly",
	"aria-relevant",
	"aria-required",
	"aria-roledescription",
	"aria-rowcount",
	"aria-rowindex",
	"aria-rowspan",
	"aria-selected",
	"aria-setsize",
	"aria-sort",
	"aria-valuemax",
	"aria-valuemin",
	"aria-valuenow",
	"aria-valuetext",
	"className",
	"color",
	"height",
	"id",
	"lang",
	"max",
	"media",
	"method",
	"min",
	"name",
	"style",
	"target",
	"width",
	"role",
	"tabIndex",
	"accentHeight",
	"accumulate",
	"additive",
	"alignmentBaseline",
	"allowReorder",
	"alphabetic",
	"amplitude",
	"arabicForm",
	"ascent",
	"attributeName",
	"attributeType",
	"autoReverse",
	"azimuth",
	"baseFrequency",
	"baselineShift",
	"baseProfile",
	"bbox",
	"begin",
	"bias",
	"by",
	"calcMode",
	"capHeight",
	"clip",
	"clipPath",
	"clipPathUnits",
	"clipRule",
	"colorInterpolation",
	"colorInterpolationFilters",
	"colorProfile",
	"colorRendering",
	"contentScriptType",
	"contentStyleType",
	"cursor",
	"cx",
	"cy",
	"d",
	"decelerate",
	"descent",
	"diffuseConstant",
	"direction",
	"display",
	"divisor",
	"dominantBaseline",
	"dur",
	"dx",
	"dy",
	"edgeMode",
	"elevation",
	"enableBackground",
	"end",
	"exponent",
	"externalResourcesRequired",
	"fill",
	"fillOpacity",
	"fillRule",
	"filter",
	"filterRes",
	"filterUnits",
	"floodColor",
	"floodOpacity",
	"focusable",
	"fontFamily",
	"fontSize",
	"fontSizeAdjust",
	"fontStretch",
	"fontStyle",
	"fontVariant",
	"fontWeight",
	"format",
	"from",
	"fx",
	"fy",
	"g1",
	"g2",
	"glyphName",
	"glyphOrientationHorizontal",
	"glyphOrientationVertical",
	"glyphRef",
	"gradientTransform",
	"gradientUnits",
	"hanging",
	"horizAdvX",
	"horizOriginX",
	"href",
	"ideographic",
	"imageRendering",
	"in2",
	"in",
	"intercept",
	"k1",
	"k2",
	"k3",
	"k4",
	"k",
	"kernelMatrix",
	"kernelUnitLength",
	"kerning",
	"keyPoints",
	"keySplines",
	"keyTimes",
	"lengthAdjust",
	"letterSpacing",
	"lightingColor",
	"limitingConeAngle",
	"local",
	"markerEnd",
	"markerHeight",
	"markerMid",
	"markerStart",
	"markerUnits",
	"markerWidth",
	"mask",
	"maskContentUnits",
	"maskUnits",
	"mathematical",
	"mode",
	"numOctaves",
	"offset",
	"opacity",
	"operator",
	"order",
	"orient",
	"orientation",
	"origin",
	"overflow",
	"overlinePosition",
	"overlineThickness",
	"paintOrder",
	"panose1",
	"pathLength",
	"patternContentUnits",
	"patternTransform",
	"patternUnits",
	"pointerEvents",
	"pointsAtX",
	"pointsAtY",
	"pointsAtZ",
	"preserveAlpha",
	"preserveAspectRatio",
	"primitiveUnits",
	"r",
	"radius",
	"refX",
	"refY",
	"renderingIntent",
	"repeatCount",
	"repeatDur",
	"requiredExtensions",
	"requiredFeatures",
	"restart",
	"result",
	"rotate",
	"rx",
	"ry",
	"seed",
	"shapeRendering",
	"slope",
	"spacing",
	"specularConstant",
	"specularExponent",
	"speed",
	"spreadMethod",
	"startOffset",
	"stdDeviation",
	"stemh",
	"stemv",
	"stitchTiles",
	"stopColor",
	"stopOpacity",
	"strikethroughPosition",
	"strikethroughThickness",
	"string",
	"stroke",
	"strokeDasharray",
	"strokeDashoffset",
	"strokeLinecap",
	"strokeLinejoin",
	"strokeMiterlimit",
	"strokeOpacity",
	"strokeWidth",
	"surfaceScale",
	"systemLanguage",
	"tableValues",
	"targetX",
	"targetY",
	"textAnchor",
	"textDecoration",
	"textLength",
	"textRendering",
	"to",
	"transform",
	"u1",
	"u2",
	"underlinePosition",
	"underlineThickness",
	"unicode",
	"unicodeBidi",
	"unicodeRange",
	"unitsPerEm",
	"vAlphabetic",
	"values",
	"vectorEffect",
	"version",
	"vertAdvY",
	"vertOriginX",
	"vertOriginY",
	"vHanging",
	"vIdeographic",
	"viewTarget",
	"visibility",
	"vMathematical",
	"widths",
	"wordSpacing",
	"writingMode",
	"x1",
	"x2",
	"x",
	"xChannelSelector",
	"xHeight",
	"xlinkActuate",
	"xlinkArcrole",
	"xlinkHref",
	"xlinkRole",
	"xlinkShow",
	"xlinkTitle",
	"xlinkType",
	"xmlBase",
	"xmlLang",
	"xmlns",
	"xmlnsXlink",
	"xmlSpace",
	"y1",
	"y2",
	"y",
	"yChannelSelector",
	"z",
	"zoomAndPan",
	"ref",
	"key",
	"angle"
];
var PolyElementKeys = ["points", "pathLength"];
/** svg element types that have specific attribute filtration requirements */
/** map of svg element types to unique svg attributes that belong to that element */
var FilteredElementKeyMap = {
	svg: SVGContainerPropKeys,
	polygon: PolyElementKeys,
	polyline: PolyElementKeys
};
var EventKeys = [
	"dangerouslySetInnerHTML",
	"onCopy",
	"onCopyCapture",
	"onCut",
	"onCutCapture",
	"onPaste",
	"onPasteCapture",
	"onCompositionEnd",
	"onCompositionEndCapture",
	"onCompositionStart",
	"onCompositionStartCapture",
	"onCompositionUpdate",
	"onCompositionUpdateCapture",
	"onFocus",
	"onFocusCapture",
	"onBlur",
	"onBlurCapture",
	"onChange",
	"onChangeCapture",
	"onBeforeInput",
	"onBeforeInputCapture",
	"onInput",
	"onInputCapture",
	"onReset",
	"onResetCapture",
	"onSubmit",
	"onSubmitCapture",
	"onInvalid",
	"onInvalidCapture",
	"onLoad",
	"onLoadCapture",
	"onError",
	"onErrorCapture",
	"onKeyDown",
	"onKeyDownCapture",
	"onKeyPress",
	"onKeyPressCapture",
	"onKeyUp",
	"onKeyUpCapture",
	"onAbort",
	"onAbortCapture",
	"onCanPlay",
	"onCanPlayCapture",
	"onCanPlayThrough",
	"onCanPlayThroughCapture",
	"onDurationChange",
	"onDurationChangeCapture",
	"onEmptied",
	"onEmptiedCapture",
	"onEncrypted",
	"onEncryptedCapture",
	"onEnded",
	"onEndedCapture",
	"onLoadedData",
	"onLoadedDataCapture",
	"onLoadedMetadata",
	"onLoadedMetadataCapture",
	"onLoadStart",
	"onLoadStartCapture",
	"onPause",
	"onPauseCapture",
	"onPlay",
	"onPlayCapture",
	"onPlaying",
	"onPlayingCapture",
	"onProgress",
	"onProgressCapture",
	"onRateChange",
	"onRateChangeCapture",
	"onSeeked",
	"onSeekedCapture",
	"onSeeking",
	"onSeekingCapture",
	"onStalled",
	"onStalledCapture",
	"onSuspend",
	"onSuspendCapture",
	"onTimeUpdate",
	"onTimeUpdateCapture",
	"onVolumeChange",
	"onVolumeChangeCapture",
	"onWaiting",
	"onWaitingCapture",
	"onAuxClick",
	"onAuxClickCapture",
	"onClick",
	"onClickCapture",
	"onContextMenu",
	"onContextMenuCapture",
	"onDoubleClick",
	"onDoubleClickCapture",
	"onDrag",
	"onDragCapture",
	"onDragEnd",
	"onDragEndCapture",
	"onDragEnter",
	"onDragEnterCapture",
	"onDragExit",
	"onDragExitCapture",
	"onDragLeave",
	"onDragLeaveCapture",
	"onDragOver",
	"onDragOverCapture",
	"onDragStart",
	"onDragStartCapture",
	"onDrop",
	"onDropCapture",
	"onMouseDown",
	"onMouseDownCapture",
	"onMouseEnter",
	"onMouseLeave",
	"onMouseMove",
	"onMouseMoveCapture",
	"onMouseOut",
	"onMouseOutCapture",
	"onMouseOver",
	"onMouseOverCapture",
	"onMouseUp",
	"onMouseUpCapture",
	"onSelect",
	"onSelectCapture",
	"onTouchCancel",
	"onTouchCancelCapture",
	"onTouchEnd",
	"onTouchEndCapture",
	"onTouchMove",
	"onTouchMoveCapture",
	"onTouchStart",
	"onTouchStartCapture",
	"onPointerDown",
	"onPointerDownCapture",
	"onPointerMove",
	"onPointerMoveCapture",
	"onPointerUp",
	"onPointerUpCapture",
	"onPointerCancel",
	"onPointerCancelCapture",
	"onPointerEnter",
	"onPointerEnterCapture",
	"onPointerLeave",
	"onPointerLeaveCapture",
	"onPointerOver",
	"onPointerOverCapture",
	"onPointerOut",
	"onPointerOutCapture",
	"onGotPointerCapture",
	"onGotPointerCaptureCapture",
	"onLostPointerCapture",
	"onLostPointerCaptureCapture",
	"onScroll",
	"onScrollCapture",
	"onWheel",
	"onWheelCapture",
	"onAnimationStart",
	"onAnimationStartCapture",
	"onAnimationEnd",
	"onAnimationEndCapture",
	"onAnimationIteration",
	"onAnimationIterationCapture",
	"onTransitionEnd",
	"onTransitionEndCapture"
];
/** The type of easing function to use for animations */
/** Specifies the duration of animation, the unit of this option is ms. */
/** the offset of a chart, which define the blank space all around */
/**
* The domain of axis.
* This is the definition
*
* Numeric domain is always defined by an array of exactly two values, for the min and the max of the axis.
* Categorical domain is defined as array of all possible values.
*
* Can be specified in many ways:
* - array of numbers
* - with special strings like 'dataMin' and 'dataMax'
* - with special string math like 'dataMin - 100'
* - with keyword 'auto'
* - or a function
* - array of functions
* - or a combination of the above
*/
/**
* NumberDomain is an evaluated {@link AxisDomain}.
* Unlike {@link AxisDomain}, it has no variety - it's a tuple of two number.
* This is after all the keywords and functions were evaluated and what is left is [min, max].
*
* Know that the min, max values are not guaranteed to be nice numbers - values like -Infinity or NaN are possible.
*
* There are also `category` axes that have different things than numbers in their domain.
*/
/** The props definition of base axis */
/** Defines how ticks are placed and whether / how tick collisions are handled.
* 'preserveStart' keeps the left tick on collision and ensures that the first tick is always shown.
* 'preserveEnd' keeps the right tick on collision and ensures that the last tick is always shown.
* 'preserveStartEnd' keeps the left tick on collision and ensures that the first and last ticks are always shown.
* 'equidistantPreserveStart' selects a number N such that every nTh tick will be shown without collision.
*/
var adaptEventHandlers = function adaptEventHandlers(props, newHandler) {
	if (!props || typeof props === "function" || typeof props === "boolean") return null;
	var inputProps = props;
	if (/*#__PURE__*/ (0, import_react.isValidElement)(props)) inputProps = props.props;
	if (!(0, import_isObject.default)(inputProps)) return null;
	var out = {};
	Object.keys(inputProps).forEach(function(key) {
		if (EventKeys.includes(key)) out[key] = newHandler || function(e) {
			return inputProps[key](inputProps, e);
		};
	});
	return out;
};
var getEventHandlerOfChild = function getEventHandlerOfChild(originalHandler, data, index) {
	return function(e) {
		originalHandler(data, index, e);
		return null;
	};
};
var adaptEventsOfChild = function adaptEventsOfChild(props, data, index) {
	if (!(0, import_isObject.default)(props) || _typeof$55(props) !== "object") return null;
	var out = null;
	Object.keys(props).forEach(function(key) {
		var item = props[key];
		if (EventKeys.includes(key) && typeof item === "function") {
			if (!out) out = {};
			out[key] = getEventHandlerOfChild(item, data, index);
		}
	});
	return out;
};
//#endregion
//#region node_modules/recharts/es6/util/ReactUtils.js
var _excluded$26 = ["children"];
var _excluded2$10 = ["children"];
function _objectWithoutProperties$26(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$26(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$26(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
function _typeof$54(o) {
	"@babel/helpers - typeof";
	return _typeof$54 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$54(o);
}
var REACT_BROWSER_EVENT_MAP = {
	click: "onClick",
	mousedown: "onMouseDown",
	mouseup: "onMouseUp",
	mouseover: "onMouseOver",
	mousemove: "onMouseMove",
	mouseout: "onMouseOut",
	mouseenter: "onMouseEnter",
	mouseleave: "onMouseLeave",
	touchcancel: "onTouchCancel",
	touchend: "onTouchEnd",
	touchmove: "onTouchMove",
	touchstart: "onTouchStart",
	contextmenu: "onContextMenu",
	dblclick: "onDoubleClick"
};
/**
* Get the display name of a component
* @param  {Object} Comp Specified Component
* @return {String}      Display name of Component
*/
var getDisplayName = function getDisplayName(Comp) {
	if (typeof Comp === "string") return Comp;
	if (!Comp) return "";
	return Comp.displayName || Comp.name || "Component";
};
var lastChildren = null;
var lastResult = null;
var toArray = function toArray(children) {
	if (children === lastChildren && Array.isArray(lastResult)) return lastResult;
	var result = [];
	import_react.Children.forEach(children, function(child) {
		if ((0, import_isNil.default)(child)) return;
		if ((0, import_react_is.isFragment)(child)) result = result.concat(toArray(child.props.children));
		else result.push(child);
	});
	lastResult = result;
	lastChildren = children;
	return result;
};
function findAllByType(children, type) {
	var result = [];
	var types = [];
	if (Array.isArray(type)) types = type.map(function(t) {
		return getDisplayName(t);
	});
	else types = [getDisplayName(type)];
	toArray(children).forEach(function(child) {
		var childType = (0, import_get.default)(child, "type.displayName") || (0, import_get.default)(child, "type.name");
		if (types.indexOf(childType) !== -1) result.push(child);
	});
	return result;
}
function findChildByType(children, type) {
	var result = findAllByType(children, type);
	return result && result[0];
}
/**
* validate the width and height props of a chart element
* @param  {Object} el A chart element
* @return {Boolean}   true If the props width and height are number, and greater than 0
*/
var validateWidthHeight = function validateWidthHeight(el) {
	if (!el || !el.props) return false;
	var _el$props = el.props, width = _el$props.width, height = _el$props.height;
	if (!isNumber$1(width) || width <= 0 || !isNumber$1(height) || height <= 0) return false;
	return true;
};
var SVG_TAGS = [
	"a",
	"altGlyph",
	"altGlyphDef",
	"altGlyphItem",
	"animate",
	"animateColor",
	"animateMotion",
	"animateTransform",
	"circle",
	"clipPath",
	"color-profile",
	"cursor",
	"defs",
	"desc",
	"ellipse",
	"feBlend",
	"feColormatrix",
	"feComponentTransfer",
	"feComposite",
	"feConvolveMatrix",
	"feDiffuseLighting",
	"feDisplacementMap",
	"feDistantLight",
	"feFlood",
	"feFuncA",
	"feFuncB",
	"feFuncG",
	"feFuncR",
	"feGaussianBlur",
	"feImage",
	"feMerge",
	"feMergeNode",
	"feMorphology",
	"feOffset",
	"fePointLight",
	"feSpecularLighting",
	"feSpotLight",
	"feTile",
	"feTurbulence",
	"filter",
	"font",
	"font-face",
	"font-face-format",
	"font-face-name",
	"font-face-url",
	"foreignObject",
	"g",
	"glyph",
	"glyphRef",
	"hkern",
	"image",
	"line",
	"lineGradient",
	"marker",
	"mask",
	"metadata",
	"missing-glyph",
	"mpath",
	"path",
	"pattern",
	"polygon",
	"polyline",
	"radialGradient",
	"rect",
	"script",
	"set",
	"stop",
	"style",
	"svg",
	"switch",
	"symbol",
	"text",
	"textPath",
	"title",
	"tref",
	"tspan",
	"use",
	"view",
	"vkern"
];
var isSvgElement = function isSvgElement(child) {
	return child && child.type && (0, import_isString.default)(child.type) && SVG_TAGS.indexOf(child.type) >= 0;
};
var hasClipDot = function hasClipDot(dot) {
	return dot && _typeof$54(dot) === "object" && "clipDot" in dot;
};
/**
* Checks if the property is valid to spread onto an SVG element or onto a specific component
* @param {unknown} property property value currently being compared
* @param {string} key property key currently being compared
* @param {boolean} includeEvents if events are included in spreadable props
* @param {boolean} svgElementType checks against map of SVG element types to attributes
* @returns {boolean} is prop valid
*/
var isValidSpreadableProp = function isValidSpreadableProp(property, key, includeEvents, svgElementType) {
	var _FilteredElementKeyMa;
	/**
	* If the svg element type is explicitly included, check against the filtered element key map
	* to determine if there are attributes that should only exist on that element type.
	* @todo Add an internal cjs version of https://github.com/wooorm/svg-element-attributes for full coverage.
	*/
	var matchingElementTypeKeys = (_FilteredElementKeyMa = FilteredElementKeyMap === null || FilteredElementKeyMap === void 0 ? void 0 : FilteredElementKeyMap[svgElementType]) !== null && _FilteredElementKeyMa !== void 0 ? _FilteredElementKeyMa : [];
	return key.startsWith("data-") || !(0, import_isFunction.default)(property) && (svgElementType && matchingElementTypeKeys.includes(key) || SVGElementPropKeys.includes(key)) || includeEvents && EventKeys.includes(key);
};
/**
* Filter all the svg elements of children
* @param  {Array} children The children of a react element
* @return {Array}          All the svg elements
*/
var filterSvgElements = function filterSvgElements(children) {
	var svgElements = [];
	toArray(children).forEach(function(entry) {
		if (isSvgElement(entry)) svgElements.push(entry);
	});
	return svgElements;
};
var filterProps = function filterProps(props, includeEvents, svgElementType) {
	if (!props || typeof props === "function" || typeof props === "boolean") return null;
	var inputProps = props;
	if (/*#__PURE__*/ (0, import_react.isValidElement)(props)) inputProps = props.props;
	if (!(0, import_isObject.default)(inputProps)) return null;
	var out = {};
	/**
	* Props are blindly spread onto SVG elements. This loop filters out properties that we don't want to spread.
	* Items filtered out are as follows:
	*   - functions in properties that are SVG attributes (functions are included when includeEvents is true)
	*   - props that are SVG attributes but don't matched the passed svgElementType
	*   - any prop that is not in SVGElementPropKeys (or in EventKeys if includeEvents is true)
	*/
	Object.keys(inputProps).forEach(function(key) {
		var _inputProps;
		if (isValidSpreadableProp((_inputProps = inputProps) === null || _inputProps === void 0 ? void 0 : _inputProps[key], key, includeEvents, svgElementType)) out[key] = inputProps[key];
	});
	return out;
};
/**
* Wether props of children changed
* @param  {Object} nextChildren The latest children
* @param  {Object} prevChildren The prev children
* @return {Boolean}             equal or not
*/
var isChildrenEqual = function isChildrenEqual(nextChildren, prevChildren) {
	if (nextChildren === prevChildren) return true;
	var count = import_react.Children.count(nextChildren);
	if (count !== import_react.Children.count(prevChildren)) return false;
	if (count === 0) return true;
	if (count === 1) return isSingleChildEqual(Array.isArray(nextChildren) ? nextChildren[0] : nextChildren, Array.isArray(prevChildren) ? prevChildren[0] : prevChildren);
	for (var i = 0; i < count; i++) {
		var nextChild = nextChildren[i];
		var prevChild = prevChildren[i];
		if (Array.isArray(nextChild) || Array.isArray(prevChild)) {
			if (!isChildrenEqual(nextChild, prevChild)) return false;
		} else if (!isSingleChildEqual(nextChild, prevChild)) return false;
	}
	return true;
};
var isSingleChildEqual = function isSingleChildEqual(nextChild, prevChild) {
	if ((0, import_isNil.default)(nextChild) && (0, import_isNil.default)(prevChild)) return true;
	if (!(0, import_isNil.default)(nextChild) && !(0, import_isNil.default)(prevChild)) {
		var _ref = nextChild.props || {}, nextChildren = _ref.children, nextProps = _objectWithoutProperties$26(_ref, _excluded$26);
		var _ref2 = prevChild.props || {}, prevChildren = _ref2.children, prevProps = _objectWithoutProperties$26(_ref2, _excluded2$10);
		if (nextChildren && prevChildren) return shallowEqual(nextProps, prevProps) && isChildrenEqual(nextChildren, prevChildren);
		if (!nextChildren && !prevChildren) return shallowEqual(nextProps, prevProps);
		return false;
	}
	return false;
};
var renderByOrder = function renderByOrder(children, renderMap) {
	var elements = [];
	var record = {};
	toArray(children).forEach(function(child, index) {
		if (isSvgElement(child)) elements.push(child);
		else if (child) {
			var displayName = getDisplayName(child.type);
			var _ref3 = renderMap[displayName] || {}, handler = _ref3.handler, once = _ref3.once;
			if (handler && (!once || !record[displayName])) {
				var results = handler(child, displayName, index);
				elements.push(results);
				record[displayName] = true;
			}
		}
	});
	return elements;
};
var getReactEventByType = function getReactEventByType(e) {
	var type = e && e.type;
	if (type && REACT_BROWSER_EVENT_MAP[type]) return REACT_BROWSER_EVENT_MAP[type];
	return null;
};
var parseChildIndex = function parseChildIndex(child, children) {
	return toArray(children).indexOf(child);
};
//#endregion
//#region node_modules/recharts/es6/container/Surface.js
/**
* @fileOverview Surface
*/
var _excluded$25 = [
	"children",
	"width",
	"height",
	"viewBox",
	"className",
	"style",
	"title",
	"desc"
];
function _extends$42() {
	_extends$42 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$42.apply(this, arguments);
}
function _objectWithoutProperties$25(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$25(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$25(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
function Surface(props) {
	var children = props.children, width = props.width, height = props.height, viewBox = props.viewBox, className = props.className, style = props.style, title = props.title, desc = props.desc, others = _objectWithoutProperties$25(props, _excluded$25);
	var svgView = viewBox || {
		width,
		height,
		x: 0,
		y: 0
	};
	var layerClass = clsx("recharts-surface", className);
	return /*#__PURE__*/ import_react.createElement("svg", _extends$42({}, filterProps(others, true, "svg"), {
		className: layerClass,
		width,
		height,
		style,
		viewBox: "".concat(svgView.x, " ").concat(svgView.y, " ").concat(svgView.width, " ").concat(svgView.height)
	}), /*#__PURE__*/ import_react.createElement("title", null, title), /*#__PURE__*/ import_react.createElement("desc", null, desc), children);
}
//#endregion
//#region node_modules/recharts/es6/container/Layer.js
var _excluded$24 = ["children", "className"];
function _extends$41() {
	_extends$41 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$41.apply(this, arguments);
}
function _objectWithoutProperties$24(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$24(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$24(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
var Layer = /*#__PURE__*/ import_react.forwardRef(function(props, ref) {
	var children = props.children, className = props.className, others = _objectWithoutProperties$24(props, _excluded$24);
	var layerClass = clsx("recharts-layer", className);
	return /*#__PURE__*/ import_react.createElement("g", _extends$41({ className: layerClass }, filterProps(others, true), { ref }), children);
});
//#endregion
//#region node_modules/recharts/es6/util/LogUtils.js
var warn = function warn(condition, format) {
	for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) args[_key - 2] = arguments[_key];
};
//#endregion
//#region node_modules/recharts/es6/shape/Symbols.js
/**
* @fileOverview Curve
*/
var import_upperFirst = /* @__PURE__ */ __toESM(require_upperFirst());
function _typeof$53(o) {
	"@babel/helpers - typeof";
	return _typeof$53 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$53(o);
}
var _excluded$23 = [
	"type",
	"size",
	"sizeType"
];
function _extends$40() {
	_extends$40 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$40.apply(this, arguments);
}
function ownKeys$45(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$45(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$45(Object(t), !0).forEach(function(r) {
			_defineProperty$51(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$45(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$51(obj, key, value) {
	key = _toPropertyKey$52(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$52(t) {
	var i = _toPrimitive$52(t, "string");
	return "symbol" == _typeof$53(i) ? i : i + "";
}
function _toPrimitive$52(t, r) {
	if ("object" != _typeof$53(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$53(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _objectWithoutProperties$23(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$23(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$23(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
var symbolFactories = {
	symbolCircle: circle_default,
	symbolCross: cross_default,
	symbolDiamond: diamond_default,
	symbolSquare: square_default,
	symbolStar: star_default,
	symbolTriangle: triangle_default,
	symbolWye: wye_default
};
var RADIAN$2 = Math.PI / 180;
var getSymbolFactory = function getSymbolFactory(type) {
	return symbolFactories["symbol".concat((0, import_upperFirst.default)(type))] || circle_default;
};
var calculateAreaSize = function calculateAreaSize(size, sizeType, type) {
	if (sizeType === "area") return size;
	switch (type) {
		case "cross": return 5 * size * size / 9;
		case "diamond": return .5 * size * size / Math.sqrt(3);
		case "square": return size * size;
		case "star":
			var angle = 18 * RADIAN$2;
			return 1.25 * size * size * (Math.tan(angle) - Math.tan(angle * 2) * Math.pow(Math.tan(angle), 2));
		case "triangle": return Math.sqrt(3) * size * size / 4;
		case "wye": return (21 - 10 * Math.sqrt(3)) * size * size / 8;
		default: return Math.PI * size * size / 4;
	}
};
var registerSymbol = function registerSymbol(key, factory) {
	symbolFactories["symbol".concat((0, import_upperFirst.default)(key))] = factory;
};
var Symbols = function Symbols(_ref) {
	var _ref$type = _ref.type, type = _ref$type === void 0 ? "circle" : _ref$type, _ref$size = _ref.size, size = _ref$size === void 0 ? 64 : _ref$size, _ref$sizeType = _ref.sizeType, sizeType = _ref$sizeType === void 0 ? "area" : _ref$sizeType;
	var props = _objectSpread$45(_objectSpread$45({}, _objectWithoutProperties$23(_ref, _excluded$23)), {}, {
		type,
		size,
		sizeType
	});
	/**
	* Calculate the path of curve
	* @return {String} path
	*/
	var getPath = function getPath() {
		var symbolFactory = getSymbolFactory(type);
		return Symbol$1().type(symbolFactory).size(calculateAreaSize(size, sizeType, type))();
	};
	var className = props.className, cx = props.cx, cy = props.cy;
	var filteredProps = filterProps(props, true);
	if (cx === +cx && cy === +cy && size === +size) return /*#__PURE__*/ import_react.createElement("path", _extends$40({}, filteredProps, {
		className: clsx("recharts-symbols", className),
		transform: "translate(".concat(cx, ", ").concat(cy, ")"),
		d: getPath()
	}));
	return null;
};
Symbols.registerSymbol = registerSymbol;
//#endregion
//#region node_modules/recharts/es6/component/DefaultLegendContent.js
/**
* @fileOverview Default Legend Content
*/
function _typeof$52(o) {
	"@babel/helpers - typeof";
	return _typeof$52 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$52(o);
}
function _extends$39() {
	_extends$39 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$39.apply(this, arguments);
}
function ownKeys$44(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$44(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$44(Object(t), !0).forEach(function(r) {
			_defineProperty$50(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$44(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _classCallCheck$28(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$28(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$51(descriptor.key), descriptor);
	}
}
function _createClass$28(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$28(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$28(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$25(t, o, e) {
	return o = _getPrototypeOf$25(o), _possibleConstructorReturn$25(t, _isNativeReflectConstruct$25() ? Reflect.construct(o, e || [], _getPrototypeOf$25(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$25(self, call) {
	if (call && (_typeof$52(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$25(self);
}
function _assertThisInitialized$25(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$25() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$25 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$25(o) {
	_getPrototypeOf$25 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$25(o);
}
function _inherits$25(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$25(subClass, superClass);
}
function _setPrototypeOf$25(o, p) {
	_setPrototypeOf$25 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$25(o, p);
}
function _defineProperty$50(obj, key, value) {
	key = _toPropertyKey$51(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$51(t) {
	var i = _toPrimitive$51(t, "string");
	return "symbol" == _typeof$52(i) ? i : i + "";
}
function _toPrimitive$51(t, r) {
	if ("object" != _typeof$52(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$52(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var SIZE = 32;
var DefaultLegendContent = /*#__PURE__*/ function(_PureComponent) {
	function DefaultLegendContent() {
		_classCallCheck$28(this, DefaultLegendContent);
		return _callSuper$25(this, DefaultLegendContent, arguments);
	}
	_inherits$25(DefaultLegendContent, _PureComponent);
	return _createClass$28(DefaultLegendContent, [
		{
			key: "renderIcon",
			value: 
			/**
			* Render the path of icon
			* @param {Object} data Data of each legend item
			* @return {String} Path element
			*/
			function renderIcon(data) {
				var inactiveColor = this.props.inactiveColor;
				var halfSize = SIZE / 2;
				var sixthSize = SIZE / 6;
				var thirdSize = SIZE / 3;
				var color = data.inactive ? inactiveColor : data.color;
				if (data.type === "plainline") return /*#__PURE__*/ import_react.createElement("line", {
					strokeWidth: 4,
					fill: "none",
					stroke: color,
					strokeDasharray: data.payload.strokeDasharray,
					x1: 0,
					y1: halfSize,
					x2: SIZE,
					y2: halfSize,
					className: "recharts-legend-icon"
				});
				if (data.type === "line") return /*#__PURE__*/ import_react.createElement("path", {
					strokeWidth: 4,
					fill: "none",
					stroke: color,
					d: "M0,".concat(halfSize, "h").concat(thirdSize, "\n            A").concat(sixthSize, ",").concat(sixthSize, ",0,1,1,").concat(2 * thirdSize, ",").concat(halfSize, "\n            H").concat(SIZE, "M").concat(2 * thirdSize, ",").concat(halfSize, "\n            A").concat(sixthSize, ",").concat(sixthSize, ",0,1,1,").concat(thirdSize, ",").concat(halfSize),
					className: "recharts-legend-icon"
				});
				if (data.type === "rect") return /*#__PURE__*/ import_react.createElement("path", {
					stroke: "none",
					fill: color,
					d: "M0,".concat(SIZE / 8, "h").concat(SIZE, "v").concat(SIZE * 3 / 4, "h").concat(-SIZE, "z"),
					className: "recharts-legend-icon"
				});
				if (/*#__PURE__*/ import_react.isValidElement(data.legendIcon)) {
					var iconProps = _objectSpread$44({}, data);
					delete iconProps.legendIcon;
					return /*#__PURE__*/ import_react.cloneElement(data.legendIcon, iconProps);
				}
				return /*#__PURE__*/ import_react.createElement(Symbols, {
					fill: color,
					cx: halfSize,
					cy: halfSize,
					size: SIZE,
					sizeType: "diameter",
					type: data.type
				});
			}
		},
		{
			key: "renderItems",
			value: function renderItems() {
				var _this = this;
				var _this$props = this.props, payload = _this$props.payload, iconSize = _this$props.iconSize, layout = _this$props.layout, formatter = _this$props.formatter, inactiveColor = _this$props.inactiveColor;
				var viewBox = {
					x: 0,
					y: 0,
					width: SIZE,
					height: SIZE
				};
				var itemStyle = {
					display: layout === "horizontal" ? "inline-block" : "block",
					marginRight: 10
				};
				var svgStyle = {
					display: "inline-block",
					verticalAlign: "middle",
					marginRight: 4
				};
				return payload.map(function(entry, i) {
					var finalFormatter = entry.formatter || formatter;
					var className = clsx(_defineProperty$50(_defineProperty$50({ "recharts-legend-item": true }, "legend-item-".concat(i), true), "inactive", entry.inactive));
					if (entry.type === "none") return null;
					var entryValue = !(0, import_isFunction.default)(entry.value) ? entry.value : null;
					warn(!(0, import_isFunction.default)(entry.value), "The name property is also required when using a function for the dataKey of a chart's cartesian components. Ex: <Bar name=\"Name of my Data\"/>");
					var color = entry.inactive ? inactiveColor : entry.color;
					return /*#__PURE__*/ import_react.createElement("li", _extends$39({
						className,
						style: itemStyle,
						key: "legend-item-".concat(i)
					}, adaptEventsOfChild(_this.props, entry, i)), /*#__PURE__*/ import_react.createElement(Surface, {
						width: iconSize,
						height: iconSize,
						viewBox,
						style: svgStyle
					}, _this.renderIcon(entry)), /*#__PURE__*/ import_react.createElement("span", {
						className: "recharts-legend-item-text",
						style: { color }
					}, finalFormatter ? finalFormatter(entryValue, entry, i) : entryValue));
				});
			}
		},
		{
			key: "render",
			value: function render() {
				var _this$props2 = this.props, payload = _this$props2.payload, layout = _this$props2.layout, align = _this$props2.align;
				if (!payload || !payload.length) return null;
				var finalStyle = {
					padding: 0,
					margin: 0,
					textAlign: layout === "horizontal" ? align : "left"
				};
				return /*#__PURE__*/ import_react.createElement("ul", {
					className: "recharts-default-legend",
					style: finalStyle
				}, this.renderItems());
			}
		}
	]);
}(import_react.PureComponent);
_defineProperty$50(DefaultLegendContent, "displayName", "Legend");
_defineProperty$50(DefaultLegendContent, "defaultProps", {
	iconSize: 14,
	layout: "horizontal",
	align: "center",
	verticalAlign: "middle",
	inactiveColor: "#ccc"
});
//#endregion
//#region node_modules/recharts/es6/util/payload/getUniqPayload.js
var import_uniqBy = /* @__PURE__ */ __toESM(require_uniqBy());
/**
* This is configuration option that decides how to filter for unique values only:
*
* - `false` means "no filter"
* - `true` means "use recharts default filter"
* - function means "use return of this function as the default key"
*/
function getUniqPayload(payload, option, defaultUniqBy) {
	if (option === true) return (0, import_uniqBy.default)(payload, defaultUniqBy);
	if ((0, import_isFunction.default)(option)) return (0, import_uniqBy.default)(payload, option);
	return payload;
}
//#endregion
//#region node_modules/recharts/es6/component/Legend.js
/**
* @fileOverview Legend
*/
function _typeof$51(o) {
	"@babel/helpers - typeof";
	return _typeof$51 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$51(o);
}
var _excluded$22 = ["ref"];
function ownKeys$43(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$43(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$43(Object(t), !0).forEach(function(r) {
			_defineProperty$49(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$43(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _classCallCheck$27(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$27(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$50(descriptor.key), descriptor);
	}
}
function _createClass$27(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$27(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$27(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$24(t, o, e) {
	return o = _getPrototypeOf$24(o), _possibleConstructorReturn$24(t, _isNativeReflectConstruct$24() ? Reflect.construct(o, e || [], _getPrototypeOf$24(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$24(self, call) {
	if (call && (_typeof$51(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$24(self);
}
function _assertThisInitialized$24(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$24() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$24 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$24(o) {
	_getPrototypeOf$24 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$24(o);
}
function _inherits$24(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$24(subClass, superClass);
}
function _setPrototypeOf$24(o, p) {
	_setPrototypeOf$24 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$24(o, p);
}
function _defineProperty$49(obj, key, value) {
	key = _toPropertyKey$50(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$50(t) {
	var i = _toPrimitive$50(t, "string");
	return "symbol" == _typeof$51(i) ? i : i + "";
}
function _toPrimitive$50(t, r) {
	if ("object" != _typeof$51(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$51(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _objectWithoutProperties$22(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$22(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$22(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
function defaultUniqBy$1(entry) {
	return entry.value;
}
function renderContent$1(content, props) {
	if (/*#__PURE__*/ import_react.isValidElement(content)) return /*#__PURE__*/ import_react.cloneElement(content, props);
	if (typeof content === "function") return /*#__PURE__*/ import_react.createElement(content, props);
	props.ref;
	var otherProps = _objectWithoutProperties$22(props, _excluded$22);
	return /*#__PURE__*/ import_react.createElement(DefaultLegendContent, otherProps);
}
var EPS$1 = 1;
var Legend = /*#__PURE__*/ function(_PureComponent) {
	function Legend() {
		var _this;
		_classCallCheck$27(this, Legend);
		for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
		_this = _callSuper$24(this, Legend, [].concat(args));
		_defineProperty$49(_this, "lastBoundingBox", {
			width: -1,
			height: -1
		});
		return _this;
	}
	_inherits$24(Legend, _PureComponent);
	return _createClass$27(Legend, [
		{
			key: "componentDidMount",
			value: function componentDidMount() {
				this.updateBBox();
			}
		},
		{
			key: "componentDidUpdate",
			value: function componentDidUpdate() {
				this.updateBBox();
			}
		},
		{
			key: "getBBox",
			value: function getBBox() {
				if (this.wrapperNode && this.wrapperNode.getBoundingClientRect) {
					var box = this.wrapperNode.getBoundingClientRect();
					box.height = this.wrapperNode.offsetHeight;
					box.width = this.wrapperNode.offsetWidth;
					return box;
				}
				return null;
			}
		},
		{
			key: "updateBBox",
			value: function updateBBox() {
				var onBBoxUpdate = this.props.onBBoxUpdate;
				var box = this.getBBox();
				if (box) {
					if (Math.abs(box.width - this.lastBoundingBox.width) > EPS$1 || Math.abs(box.height - this.lastBoundingBox.height) > EPS$1) {
						this.lastBoundingBox.width = box.width;
						this.lastBoundingBox.height = box.height;
						if (onBBoxUpdate) onBBoxUpdate(box);
					}
				} else if (this.lastBoundingBox.width !== -1 || this.lastBoundingBox.height !== -1) {
					this.lastBoundingBox.width = -1;
					this.lastBoundingBox.height = -1;
					if (onBBoxUpdate) onBBoxUpdate(null);
				}
			}
		},
		{
			key: "getBBoxSnapshot",
			value: function getBBoxSnapshot() {
				if (this.lastBoundingBox.width >= 0 && this.lastBoundingBox.height >= 0) return _objectSpread$43({}, this.lastBoundingBox);
				return {
					width: 0,
					height: 0
				};
			}
		},
		{
			key: "getDefaultPosition",
			value: function getDefaultPosition(style) {
				var _this$props = this.props, layout = _this$props.layout, align = _this$props.align, verticalAlign = _this$props.verticalAlign, margin = _this$props.margin, chartWidth = _this$props.chartWidth, chartHeight = _this$props.chartHeight;
				var hPos, vPos;
				if (!style || (style.left === void 0 || style.left === null) && (style.right === void 0 || style.right === null)) {
					if (align === "center" && layout === "vertical") {
						var box = this.getBBoxSnapshot();
						hPos = { left: ((chartWidth || 0) - box.width) / 2 };
					} else hPos = align === "right" ? { right: margin && margin.right || 0 } : { left: margin && margin.left || 0 };
				}
				if (!style || (style.top === void 0 || style.top === null) && (style.bottom === void 0 || style.bottom === null)) {
					if (verticalAlign === "middle") {
						var _box = this.getBBoxSnapshot();
						vPos = { top: ((chartHeight || 0) - _box.height) / 2 };
					} else vPos = verticalAlign === "bottom" ? { bottom: margin && margin.bottom || 0 } : { top: margin && margin.top || 0 };
				}
				return _objectSpread$43(_objectSpread$43({}, hPos), vPos);
			}
		},
		{
			key: "render",
			value: function render() {
				var _this2 = this;
				var _this$props2 = this.props, content = _this$props2.content, width = _this$props2.width, height = _this$props2.height, wrapperStyle = _this$props2.wrapperStyle, payloadUniqBy = _this$props2.payloadUniqBy, payload = _this$props2.payload;
				var outerStyle = _objectSpread$43(_objectSpread$43({
					position: "absolute",
					width: width || "auto",
					height: height || "auto"
				}, this.getDefaultPosition(wrapperStyle)), wrapperStyle);
				return /*#__PURE__*/ import_react.createElement("div", {
					className: "recharts-legend-wrapper",
					style: outerStyle,
					ref: function ref(node) {
						_this2.wrapperNode = node;
					}
				}, renderContent$1(content, _objectSpread$43(_objectSpread$43({}, this.props), {}, { payload: getUniqPayload(payload, payloadUniqBy, defaultUniqBy$1) })));
			}
		}
	], [{
		key: "getWithHeight",
		value: function getWithHeight(item, chartWidth) {
			var layout = _objectSpread$43(_objectSpread$43({}, this.defaultProps), item.props).layout;
			if (layout === "vertical" && isNumber$1(item.props.height)) return { height: item.props.height };
			if (layout === "horizontal") return { width: item.props.width || chartWidth };
			return null;
		}
	}]);
}(import_react.PureComponent);
_defineProperty$49(Legend, "displayName", "Legend");
_defineProperty$49(Legend, "defaultProps", {
	iconSize: 14,
	layout: "horizontal",
	align: "center",
	verticalAlign: "bottom"
});
//#endregion
//#region node_modules/recharts/es6/component/DefaultTooltipContent.js
/**
* @fileOverview Default Tooltip Content
*/
var import_sortBy = /* @__PURE__ */ __toESM(require_sortBy());
function _typeof$50(o) {
	"@babel/helpers - typeof";
	return _typeof$50 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$50(o);
}
function _extends$38() {
	_extends$38 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$38.apply(this, arguments);
}
function _slicedToArray$12(arr, i) {
	return _arrayWithHoles$12(arr) || _iterableToArrayLimit$12(arr, i) || _unsupportedIterableToArray$19(arr, i) || _nonIterableRest$12();
}
function _nonIterableRest$12() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$19(o, minLen) {
	if (!o) return;
	if (typeof o === "string") return _arrayLikeToArray$19(o, minLen);
	var n = Object.prototype.toString.call(o).slice(8, -1);
	if (n === "Object" && o.constructor) n = o.constructor.name;
	if (n === "Map" || n === "Set") return Array.from(o);
	if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$19(o, minLen);
}
function _arrayLikeToArray$19(arr, len) {
	if (len == null || len > arr.length) len = arr.length;
	for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
	return arr2;
}
function _iterableToArrayLimit$12(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = !0, o = !1;
		try {
			if (i = (t = t.call(r)).next, 0 === l) {
				if (Object(t) !== t) return;
				f = !1;
			} else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = !0, n = r;
		} finally {
			try {
				if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
function _arrayWithHoles$12(arr) {
	if (Array.isArray(arr)) return arr;
}
function ownKeys$42(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$42(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$42(Object(t), !0).forEach(function(r) {
			_defineProperty$48(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$42(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$48(obj, key, value) {
	key = _toPropertyKey$49(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$49(t) {
	var i = _toPrimitive$49(t, "string");
	return "symbol" == _typeof$50(i) ? i : i + "";
}
function _toPrimitive$49(t, r) {
	if ("object" != _typeof$50(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$50(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function defaultFormatter(value) {
	return Array.isArray(value) && isNumOrStr(value[0]) && isNumOrStr(value[1]) ? value.join(" ~ ") : value;
}
var DefaultTooltipContent = function DefaultTooltipContent(props) {
	var _props$separator = props.separator, separator = _props$separator === void 0 ? " : " : _props$separator, _props$contentStyle = props.contentStyle, contentStyle = _props$contentStyle === void 0 ? {} : _props$contentStyle, _props$itemStyle = props.itemStyle, itemStyle = _props$itemStyle === void 0 ? {} : _props$itemStyle, _props$labelStyle = props.labelStyle, labelStyle = _props$labelStyle === void 0 ? {} : _props$labelStyle, payload = props.payload, formatter = props.formatter, itemSorter = props.itemSorter, wrapperClassName = props.wrapperClassName, labelClassName = props.labelClassName, label = props.label, labelFormatter = props.labelFormatter, _props$accessibilityL = props.accessibilityLayer, accessibilityLayer = _props$accessibilityL === void 0 ? false : _props$accessibilityL;
	var renderContent = function renderContent() {
		if (payload && payload.length) {
			var listStyle = {
				padding: 0,
				margin: 0
			};
			var items = (itemSorter ? (0, import_sortBy.default)(payload, itemSorter) : payload).map(function(entry, i) {
				if (entry.type === "none") return null;
				var finalItemStyle = _objectSpread$42({
					display: "block",
					paddingTop: 4,
					paddingBottom: 4,
					color: entry.color || "#000"
				}, itemStyle);
				var finalFormatter = entry.formatter || formatter || defaultFormatter;
				var value = entry.value, name = entry.name;
				var finalValue = value;
				var finalName = name;
				if (finalFormatter && finalValue != null && finalName != null) {
					var formatted = finalFormatter(value, name, entry, i, payload);
					if (Array.isArray(formatted)) {
						var _formatted = _slicedToArray$12(formatted, 2);
						finalValue = _formatted[0];
						finalName = _formatted[1];
					} else finalValue = formatted;
				}
				return /*#__PURE__*/ import_react.createElement("li", {
					className: "recharts-tooltip-item",
					key: "tooltip-item-".concat(i),
					style: finalItemStyle
				}, isNumOrStr(finalName) ? /*#__PURE__*/ import_react.createElement("span", { className: "recharts-tooltip-item-name" }, finalName) : null, isNumOrStr(finalName) ? /*#__PURE__*/ import_react.createElement("span", { className: "recharts-tooltip-item-separator" }, separator) : null, /*#__PURE__*/ import_react.createElement("span", { className: "recharts-tooltip-item-value" }, finalValue), /*#__PURE__*/ import_react.createElement("span", { className: "recharts-tooltip-item-unit" }, entry.unit || ""));
			});
			return /*#__PURE__*/ import_react.createElement("ul", {
				className: "recharts-tooltip-item-list",
				style: listStyle
			}, items);
		}
		return null;
	};
	var finalStyle = _objectSpread$42({
		margin: 0,
		padding: 10,
		backgroundColor: "#fff",
		border: "1px solid #ccc",
		whiteSpace: "nowrap"
	}, contentStyle);
	var finalLabelStyle = _objectSpread$42({ margin: 0 }, labelStyle);
	var hasLabel = !(0, import_isNil.default)(label);
	var finalLabel = hasLabel ? label : "";
	var wrapperCN = clsx("recharts-default-tooltip", wrapperClassName);
	var labelCN = clsx("recharts-tooltip-label", labelClassName);
	if (hasLabel && labelFormatter && payload !== void 0 && payload !== null) finalLabel = labelFormatter(label, payload);
	var accessibilityAttributes = accessibilityLayer ? {
		role: "status",
		"aria-live": "assertive"
	} : {};
	return /*#__PURE__*/ import_react.createElement("div", _extends$38({
		className: wrapperCN,
		style: finalStyle
	}, accessibilityAttributes), /*#__PURE__*/ import_react.createElement("p", {
		className: labelCN,
		style: finalLabelStyle
	}, /*#__PURE__*/ import_react.isValidElement(finalLabel) ? finalLabel : "".concat(finalLabel)), renderContent());
};
//#endregion
//#region node_modules/recharts/es6/util/tooltip/translate.js
function _typeof$49(o) {
	"@babel/helpers - typeof";
	return _typeof$49 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$49(o);
}
function _defineProperty$47(obj, key, value) {
	key = _toPropertyKey$48(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$48(t) {
	var i = _toPrimitive$48(t, "string");
	return "symbol" == _typeof$49(i) ? i : i + "";
}
function _toPrimitive$48(t, r) {
	if ("object" != _typeof$49(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$49(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var CSS_CLASS_PREFIX = "recharts-tooltip-wrapper";
var TOOLTIP_HIDDEN = { visibility: "hidden" };
function getTooltipCSSClassName(_ref) {
	var coordinate = _ref.coordinate, translateX = _ref.translateX, translateY = _ref.translateY;
	return clsx(CSS_CLASS_PREFIX, _defineProperty$47(_defineProperty$47(_defineProperty$47(_defineProperty$47({}, "".concat(CSS_CLASS_PREFIX, "-right"), isNumber$1(translateX) && coordinate && isNumber$1(coordinate.x) && translateX >= coordinate.x), "".concat(CSS_CLASS_PREFIX, "-left"), isNumber$1(translateX) && coordinate && isNumber$1(coordinate.x) && translateX < coordinate.x), "".concat(CSS_CLASS_PREFIX, "-bottom"), isNumber$1(translateY) && coordinate && isNumber$1(coordinate.y) && translateY >= coordinate.y), "".concat(CSS_CLASS_PREFIX, "-top"), isNumber$1(translateY) && coordinate && isNumber$1(coordinate.y) && translateY < coordinate.y));
}
function getTooltipTranslateXY(_ref2) {
	var allowEscapeViewBox = _ref2.allowEscapeViewBox, coordinate = _ref2.coordinate, key = _ref2.key, offsetTopLeft = _ref2.offsetTopLeft, position = _ref2.position, reverseDirection = _ref2.reverseDirection, tooltipDimension = _ref2.tooltipDimension, viewBox = _ref2.viewBox, viewBoxDimension = _ref2.viewBoxDimension;
	if (position && isNumber$1(position[key])) return position[key];
	var negative = coordinate[key] - tooltipDimension - offsetTopLeft;
	var positive = coordinate[key] + offsetTopLeft;
	if (allowEscapeViewBox[key]) return reverseDirection[key] ? negative : positive;
	if (reverseDirection[key]) {
		if (negative < viewBox[key]) return Math.max(positive, viewBox[key]);
		return Math.max(negative, viewBox[key]);
	}
	if (positive + tooltipDimension > viewBox[key] + viewBoxDimension) return Math.max(negative, viewBox[key]);
	return Math.max(positive, viewBox[key]);
}
function getTransformStyle(_ref3) {
	var translateX = _ref3.translateX, translateY = _ref3.translateY;
	return { transform: _ref3.useTranslate3d ? "translate3d(".concat(translateX, "px, ").concat(translateY, "px, 0)") : "translate(".concat(translateX, "px, ").concat(translateY, "px)") };
}
function getTooltipTranslate(_ref4) {
	var allowEscapeViewBox = _ref4.allowEscapeViewBox, coordinate = _ref4.coordinate, offsetTopLeft = _ref4.offsetTopLeft, position = _ref4.position, reverseDirection = _ref4.reverseDirection, tooltipBox = _ref4.tooltipBox, useTranslate3d = _ref4.useTranslate3d, viewBox = _ref4.viewBox;
	var cssProperties, translateX, translateY;
	if (tooltipBox.height > 0 && tooltipBox.width > 0 && coordinate) {
		translateX = getTooltipTranslateXY({
			allowEscapeViewBox,
			coordinate,
			key: "x",
			offsetTopLeft,
			position,
			reverseDirection,
			tooltipDimension: tooltipBox.width,
			viewBox,
			viewBoxDimension: viewBox.width
		});
		translateY = getTooltipTranslateXY({
			allowEscapeViewBox,
			coordinate,
			key: "y",
			offsetTopLeft,
			position,
			reverseDirection,
			tooltipDimension: tooltipBox.height,
			viewBox,
			viewBoxDimension: viewBox.height
		});
		cssProperties = getTransformStyle({
			translateX,
			translateY,
			useTranslate3d
		});
	} else cssProperties = TOOLTIP_HIDDEN;
	return {
		cssProperties,
		cssClasses: getTooltipCSSClassName({
			translateX,
			translateY,
			coordinate
		})
	};
}
//#endregion
//#region node_modules/recharts/es6/component/TooltipBoundingBox.js
function _typeof$48(o) {
	"@babel/helpers - typeof";
	return _typeof$48 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$48(o);
}
function ownKeys$41(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$41(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$41(Object(t), !0).forEach(function(r) {
			_defineProperty$46(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$41(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _classCallCheck$26(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$26(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$47(descriptor.key), descriptor);
	}
}
function _createClass$26(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$26(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$26(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$23(t, o, e) {
	return o = _getPrototypeOf$23(o), _possibleConstructorReturn$23(t, _isNativeReflectConstruct$23() ? Reflect.construct(o, e || [], _getPrototypeOf$23(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$23(self, call) {
	if (call && (_typeof$48(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$23(self);
}
function _assertThisInitialized$23(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$23() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$23 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$23(o) {
	_getPrototypeOf$23 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$23(o);
}
function _inherits$23(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$23(subClass, superClass);
}
function _setPrototypeOf$23(o, p) {
	_setPrototypeOf$23 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$23(o, p);
}
function _defineProperty$46(obj, key, value) {
	key = _toPropertyKey$47(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$47(t) {
	var i = _toPrimitive$47(t, "string");
	return "symbol" == _typeof$48(i) ? i : i + "";
}
function _toPrimitive$47(t, r) {
	if ("object" != _typeof$48(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$48(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var EPSILON = 1;
var TooltipBoundingBox = /*#__PURE__*/ function(_PureComponent) {
	function TooltipBoundingBox() {
		var _this;
		_classCallCheck$26(this, TooltipBoundingBox);
		for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
		_this = _callSuper$23(this, TooltipBoundingBox, [].concat(args));
		_defineProperty$46(_this, "state", {
			dismissed: false,
			dismissedAtCoordinate: {
				x: 0,
				y: 0
			},
			lastBoundingBox: {
				width: -1,
				height: -1
			}
		});
		_defineProperty$46(_this, "handleKeyDown", function(event) {
			if (event.key === "Escape") {
				var _this$props$coordinat, _this$props$coordinat2, _this$props$coordinat3, _this$props$coordinat4;
				_this.setState({
					dismissed: true,
					dismissedAtCoordinate: {
						x: (_this$props$coordinat = (_this$props$coordinat2 = _this.props.coordinate) === null || _this$props$coordinat2 === void 0 ? void 0 : _this$props$coordinat2.x) !== null && _this$props$coordinat !== void 0 ? _this$props$coordinat : 0,
						y: (_this$props$coordinat3 = (_this$props$coordinat4 = _this.props.coordinate) === null || _this$props$coordinat4 === void 0 ? void 0 : _this$props$coordinat4.y) !== null && _this$props$coordinat3 !== void 0 ? _this$props$coordinat3 : 0
					}
				});
			}
		});
		return _this;
	}
	_inherits$23(TooltipBoundingBox, _PureComponent);
	return _createClass$26(TooltipBoundingBox, [
		{
			key: "updateBBox",
			value: function updateBBox() {
				if (this.wrapperNode && this.wrapperNode.getBoundingClientRect) {
					var box = this.wrapperNode.getBoundingClientRect();
					if (Math.abs(box.width - this.state.lastBoundingBox.width) > EPSILON || Math.abs(box.height - this.state.lastBoundingBox.height) > EPSILON) this.setState({ lastBoundingBox: {
						width: box.width,
						height: box.height
					} });
				} else if (this.state.lastBoundingBox.width !== -1 || this.state.lastBoundingBox.height !== -1) this.setState({ lastBoundingBox: {
					width: -1,
					height: -1
				} });
			}
		},
		{
			key: "componentDidMount",
			value: function componentDidMount() {
				document.addEventListener("keydown", this.handleKeyDown);
				this.updateBBox();
			}
		},
		{
			key: "componentWillUnmount",
			value: function componentWillUnmount() {
				document.removeEventListener("keydown", this.handleKeyDown);
			}
		},
		{
			key: "componentDidUpdate",
			value: function componentDidUpdate() {
				var _this$props$coordinat5, _this$props$coordinat6;
				if (this.props.active) this.updateBBox();
				if (!this.state.dismissed) return;
				if (((_this$props$coordinat5 = this.props.coordinate) === null || _this$props$coordinat5 === void 0 ? void 0 : _this$props$coordinat5.x) !== this.state.dismissedAtCoordinate.x || ((_this$props$coordinat6 = this.props.coordinate) === null || _this$props$coordinat6 === void 0 ? void 0 : _this$props$coordinat6.y) !== this.state.dismissedAtCoordinate.y) this.state.dismissed = false;
			}
		},
		{
			key: "render",
			value: function render() {
				var _this2 = this;
				var _this$props = this.props, active = _this$props.active, allowEscapeViewBox = _this$props.allowEscapeViewBox, animationDuration = _this$props.animationDuration, animationEasing = _this$props.animationEasing, children = _this$props.children, coordinate = _this$props.coordinate, hasPayload = _this$props.hasPayload, isAnimationActive = _this$props.isAnimationActive, offset = _this$props.offset, position = _this$props.position, reverseDirection = _this$props.reverseDirection, useTranslate3d = _this$props.useTranslate3d, viewBox = _this$props.viewBox, wrapperStyle = _this$props.wrapperStyle;
				var _getTooltipTranslate = getTooltipTranslate({
					allowEscapeViewBox,
					coordinate,
					offsetTopLeft: offset,
					position,
					reverseDirection,
					tooltipBox: this.state.lastBoundingBox,
					useTranslate3d,
					viewBox
				}), cssClasses = _getTooltipTranslate.cssClasses, cssProperties = _getTooltipTranslate.cssProperties;
				var outerStyle = _objectSpread$41(_objectSpread$41({ transition: isAnimationActive && active ? "transform ".concat(animationDuration, "ms ").concat(animationEasing) : void 0 }, cssProperties), {}, {
					pointerEvents: "none",
					visibility: !this.state.dismissed && active && hasPayload ? "visible" : "hidden",
					position: "absolute",
					top: 0,
					left: 0
				}, wrapperStyle);
				return /*#__PURE__*/ import_react.createElement("div", {
					tabIndex: -1,
					className: cssClasses,
					style: outerStyle,
					ref: function ref(node) {
						_this2.wrapperNode = node;
					}
				}, children);
			}
		}
	]);
}(import_react.PureComponent);
var Global = {
	isSsr: function parseIsSsrByDefault() {
		return !(typeof window !== "undefined" && window.document && window.document.createElement && window.setTimeout);
	}(),
	get: function get(key) {
		return Global[key];
	},
	set: function set(key, value) {
		if (typeof key === "string") Global[key] = value;
		else {
			var keys = Object.keys(key);
			if (keys && keys.length) keys.forEach(function(k) {
				Global[k] = key[k];
			});
		}
	}
};
//#endregion
//#region node_modules/recharts/es6/component/Tooltip.js
/**
* @fileOverview Tooltip
*/
function _typeof$47(o) {
	"@babel/helpers - typeof";
	return _typeof$47 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$47(o);
}
function ownKeys$40(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$40(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$40(Object(t), !0).forEach(function(r) {
			_defineProperty$45(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$40(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _classCallCheck$25(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$25(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$46(descriptor.key), descriptor);
	}
}
function _createClass$25(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$25(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$25(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$22(t, o, e) {
	return o = _getPrototypeOf$22(o), _possibleConstructorReturn$22(t, _isNativeReflectConstruct$22() ? Reflect.construct(o, e || [], _getPrototypeOf$22(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$22(self, call) {
	if (call && (_typeof$47(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$22(self);
}
function _assertThisInitialized$22(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$22() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$22 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$22(o) {
	_getPrototypeOf$22 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$22(o);
}
function _inherits$22(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$22(subClass, superClass);
}
function _setPrototypeOf$22(o, p) {
	_setPrototypeOf$22 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$22(o, p);
}
function _defineProperty$45(obj, key, value) {
	key = _toPropertyKey$46(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$46(t) {
	var i = _toPrimitive$46(t, "string");
	return "symbol" == _typeof$47(i) ? i : i + "";
}
function _toPrimitive$46(t, r) {
	if ("object" != _typeof$47(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$47(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function defaultUniqBy(entry) {
	return entry.dataKey;
}
function renderContent(content, props) {
	if (/*#__PURE__*/ import_react.isValidElement(content)) return /*#__PURE__*/ import_react.cloneElement(content, props);
	if (typeof content === "function") return /*#__PURE__*/ import_react.createElement(content, props);
	return /*#__PURE__*/ import_react.createElement(DefaultTooltipContent, props);
}
var Tooltip = /*#__PURE__*/ function(_PureComponent) {
	function Tooltip() {
		_classCallCheck$25(this, Tooltip);
		return _callSuper$22(this, Tooltip, arguments);
	}
	_inherits$22(Tooltip, _PureComponent);
	return _createClass$25(Tooltip, [{
		key: "render",
		value: function render() {
			var _this = this;
			var _this$props = this.props, active = _this$props.active, allowEscapeViewBox = _this$props.allowEscapeViewBox, animationDuration = _this$props.animationDuration, animationEasing = _this$props.animationEasing, content = _this$props.content, coordinate = _this$props.coordinate, filterNull = _this$props.filterNull, isAnimationActive = _this$props.isAnimationActive, offset = _this$props.offset, payload = _this$props.payload, payloadUniqBy = _this$props.payloadUniqBy, position = _this$props.position, reverseDirection = _this$props.reverseDirection, useTranslate3d = _this$props.useTranslate3d, viewBox = _this$props.viewBox, wrapperStyle = _this$props.wrapperStyle;
			var finalPayload = payload !== null && payload !== void 0 ? payload : [];
			if (filterNull && finalPayload.length) finalPayload = getUniqPayload(payload.filter(function(entry) {
				return entry.value != null && (entry.hide !== true || _this.props.includeHidden);
			}), payloadUniqBy, defaultUniqBy);
			var hasPayload = finalPayload.length > 0;
			return /*#__PURE__*/ import_react.createElement(TooltipBoundingBox, {
				allowEscapeViewBox,
				animationDuration,
				animationEasing,
				isAnimationActive,
				active,
				coordinate,
				hasPayload,
				offset,
				position,
				reverseDirection,
				useTranslate3d,
				viewBox,
				wrapperStyle
			}, renderContent(content, _objectSpread$40(_objectSpread$40({}, this.props), {}, { payload: finalPayload })));
		}
	}]);
}(import_react.PureComponent);
_defineProperty$45(Tooltip, "displayName", "Tooltip");
_defineProperty$45(Tooltip, "defaultProps", {
	accessibilityLayer: false,
	allowEscapeViewBox: {
		x: false,
		y: false
	},
	animationDuration: 400,
	animationEasing: "ease",
	contentStyle: {},
	coordinate: {
		x: 0,
		y: 0
	},
	cursor: true,
	cursorStyle: {},
	filterNull: true,
	isAnimationActive: !Global.isSsr,
	itemStyle: {},
	labelStyle: {},
	offset: 10,
	reverseDirection: {
		x: false,
		y: false
	},
	separator: " : ",
	trigger: "hover",
	useTranslate3d: false,
	viewBox: {
		x: 0,
		y: 0,
		height: 0,
		width: 0
	},
	wrapperStyle: {}
});
//#endregion
//#region node_modules/recharts/es6/component/ResponsiveContainer.js
/**
* @fileOverview Wrapper component to make charts adapt to the size of parent * DOM
*/
var import_throttle = /* @__PURE__ */ __toESM(require_throttle());
function _typeof$46(o) {
	"@babel/helpers - typeof";
	return _typeof$46 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$46(o);
}
function ownKeys$39(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$39(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$39(Object(t), !0).forEach(function(r) {
			_defineProperty$44(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$39(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$44(obj, key, value) {
	key = _toPropertyKey$45(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$45(t) {
	var i = _toPrimitive$45(t, "string");
	return "symbol" == _typeof$46(i) ? i : i + "";
}
function _toPrimitive$45(t, r) {
	if ("object" != _typeof$46(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$46(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _slicedToArray$11(arr, i) {
	return _arrayWithHoles$11(arr) || _iterableToArrayLimit$11(arr, i) || _unsupportedIterableToArray$18(arr, i) || _nonIterableRest$11();
}
function _nonIterableRest$11() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$18(o, minLen) {
	if (!o) return;
	if (typeof o === "string") return _arrayLikeToArray$18(o, minLen);
	var n = Object.prototype.toString.call(o).slice(8, -1);
	if (n === "Object" && o.constructor) n = o.constructor.name;
	if (n === "Map" || n === "Set") return Array.from(o);
	if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$18(o, minLen);
}
function _arrayLikeToArray$18(arr, len) {
	if (len == null || len > arr.length) len = arr.length;
	for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
	return arr2;
}
function _iterableToArrayLimit$11(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = !0, o = !1;
		try {
			if (i = (t = t.call(r)).next, 0 === l) {
				if (Object(t) !== t) return;
				f = !1;
			} else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = !0, n = r;
		} finally {
			try {
				if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
function _arrayWithHoles$11(arr) {
	if (Array.isArray(arr)) return arr;
}
var ResponsiveContainer = /*#__PURE__*/ (0, import_react.forwardRef)(function(_ref, ref) {
	var aspect = _ref.aspect, _ref$initialDimension = _ref.initialDimension, initialDimension = _ref$initialDimension === void 0 ? {
		width: -1,
		height: -1
	} : _ref$initialDimension, _ref$width = _ref.width, width = _ref$width === void 0 ? "100%" : _ref$width, _ref$height = _ref.height, height = _ref$height === void 0 ? "100%" : _ref$height, _ref$minWidth = _ref.minWidth, minWidth = _ref$minWidth === void 0 ? 0 : _ref$minWidth, minHeight = _ref.minHeight, maxHeight = _ref.maxHeight, children = _ref.children, _ref$debounce = _ref.debounce, debounce = _ref$debounce === void 0 ? 0 : _ref$debounce, id = _ref.id, className = _ref.className, onResize = _ref.onResize, _ref$style = _ref.style, style = _ref$style === void 0 ? {} : _ref$style;
	var containerRef = (0, import_react.useRef)(null);
	var onResizeRef = (0, import_react.useRef)();
	onResizeRef.current = onResize;
	(0, import_react.useImperativeHandle)(ref, function() {
		return Object.defineProperty(containerRef.current, "current", {
			get: function get() {
				console.warn("The usage of ref.current.current is deprecated and will no longer be supported.");
				return containerRef.current;
			},
			configurable: true
		});
	});
	var _useState2 = _slicedToArray$11((0, import_react.useState)({
		containerWidth: initialDimension.width,
		containerHeight: initialDimension.height
	}), 2), sizes = _useState2[0], setSizes = _useState2[1];
	var setContainerSize = (0, import_react.useCallback)(function(newWidth, newHeight) {
		setSizes(function(prevState) {
			var roundedWidth = Math.round(newWidth);
			var roundedHeight = Math.round(newHeight);
			if (prevState.containerWidth === roundedWidth && prevState.containerHeight === roundedHeight) return prevState;
			return {
				containerWidth: roundedWidth,
				containerHeight: roundedHeight
			};
		});
	}, []);
	(0, import_react.useEffect)(function() {
		var callback = function callback(entries) {
			var _onResizeRef$current;
			var _entries$0$contentRec = entries[0].contentRect, containerWidth = _entries$0$contentRec.width, containerHeight = _entries$0$contentRec.height;
			setContainerSize(containerWidth, containerHeight);
			(_onResizeRef$current = onResizeRef.current) === null || _onResizeRef$current === void 0 || _onResizeRef$current.call(onResizeRef, containerWidth, containerHeight);
		};
		if (debounce > 0) callback = (0, import_throttle.default)(callback, debounce, {
			trailing: true,
			leading: false
		});
		var observer = new ResizeObserver(callback);
		var _containerRef$current = containerRef.current.getBoundingClientRect(), containerWidth = _containerRef$current.width, containerHeight = _containerRef$current.height;
		setContainerSize(containerWidth, containerHeight);
		observer.observe(containerRef.current);
		return function() {
			observer.disconnect();
		};
	}, [setContainerSize, debounce]);
	var chartContent = (0, import_react.useMemo)(function() {
		var containerWidth = sizes.containerWidth, containerHeight = sizes.containerHeight;
		if (containerWidth < 0 || containerHeight < 0) return null;
		warn(isPercent(width) || isPercent(height), "The width(%s) and height(%s) are both fixed numbers,\n       maybe you don't need to use a ResponsiveContainer.", width, height);
		warn(!aspect || aspect > 0, "The aspect(%s) must be greater than zero.", aspect);
		var calculatedWidth = isPercent(width) ? containerWidth : width;
		var calculatedHeight = isPercent(height) ? containerHeight : height;
		if (aspect && aspect > 0) {
			if (calculatedWidth) calculatedHeight = calculatedWidth / aspect;
			else if (calculatedHeight) calculatedWidth = calculatedHeight * aspect;
			if (maxHeight && calculatedHeight > maxHeight) calculatedHeight = maxHeight;
		}
		warn(calculatedWidth > 0 || calculatedHeight > 0, "The width(%s) and height(%s) of chart should be greater than 0,\n       please check the style of container, or the props width(%s) and height(%s),\n       or add a minWidth(%s) or minHeight(%s) or use aspect(%s) to control the\n       height and width.", calculatedWidth, calculatedHeight, width, height, minWidth, minHeight, aspect);
		var isCharts = !Array.isArray(children) && getDisplayName(children.type).endsWith("Chart");
		return import_react.Children.map(children, function(child) {
			if (/*#__PURE__*/ import_react.isValidElement(child)) return /*#__PURE__*/ (0, import_react.cloneElement)(child, _objectSpread$39({
				width: calculatedWidth,
				height: calculatedHeight
			}, isCharts ? { style: _objectSpread$39({
				height: "100%",
				width: "100%",
				maxHeight: calculatedHeight,
				maxWidth: calculatedWidth
			}, child.props.style) } : {}));
			return child;
		});
	}, [
		aspect,
		children,
		height,
		maxHeight,
		minHeight,
		minWidth,
		sizes,
		width
	]);
	return /*#__PURE__*/ import_react.createElement("div", {
		id: id ? "".concat(id) : void 0,
		className: clsx("recharts-responsive-container", className),
		style: _objectSpread$39(_objectSpread$39({}, style), {}, {
			width,
			height,
			minWidth,
			minHeight,
			maxHeight
		}),
		ref: containerRef
	}, chartContent);
});
//#endregion
//#region node_modules/recharts/es6/component/Cell.js
/**
* @fileOverview Cross
*/
var Cell = function Cell(_props) {
	return null;
};
Cell.displayName = "Cell";
//#endregion
//#region node_modules/recharts/es6/util/DOMUtils.js
function _typeof$45(o) {
	"@babel/helpers - typeof";
	return _typeof$45 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$45(o);
}
function ownKeys$38(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$38(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$38(Object(t), !0).forEach(function(r) {
			_defineProperty$43(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$38(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$43(obj, key, value) {
	key = _toPropertyKey$44(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$44(t) {
	var i = _toPrimitive$44(t, "string");
	return "symbol" == _typeof$45(i) ? i : i + "";
}
function _toPrimitive$44(t, r) {
	if ("object" != _typeof$45(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$45(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var stringCache = {
	widthCache: {},
	cacheCount: 0
};
var MAX_CACHE_NUM = 2e3;
var SPAN_STYLE = {
	position: "absolute",
	top: "-20000px",
	left: 0,
	padding: 0,
	margin: 0,
	border: "none",
	whiteSpace: "pre"
};
var MEASUREMENT_SPAN_ID = "recharts_measurement_span";
function removeInvalidKeys(obj) {
	var copyObj = _objectSpread$38({}, obj);
	Object.keys(copyObj).forEach(function(key) {
		if (!copyObj[key]) delete copyObj[key];
	});
	return copyObj;
}
var getStringSize = function getStringSize(text) {
	var style = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
	if (text === void 0 || text === null || Global.isSsr) return {
		width: 0,
		height: 0
	};
	var copyStyle = removeInvalidKeys(style);
	var cacheKey = JSON.stringify({
		text,
		copyStyle
	});
	if (stringCache.widthCache[cacheKey]) return stringCache.widthCache[cacheKey];
	try {
		var measurementSpan = document.getElementById(MEASUREMENT_SPAN_ID);
		if (!measurementSpan) {
			measurementSpan = document.createElement("span");
			measurementSpan.setAttribute("id", MEASUREMENT_SPAN_ID);
			measurementSpan.setAttribute("aria-hidden", "true");
			document.body.appendChild(measurementSpan);
		}
		var measurementSpanStyle = _objectSpread$38(_objectSpread$38({}, SPAN_STYLE), copyStyle);
		Object.assign(measurementSpan.style, measurementSpanStyle);
		measurementSpan.textContent = "".concat(text);
		var rect = measurementSpan.getBoundingClientRect();
		var result = {
			width: rect.width,
			height: rect.height
		};
		stringCache.widthCache[cacheKey] = result;
		if (++stringCache.cacheCount > MAX_CACHE_NUM) {
			stringCache.cacheCount = 0;
			stringCache.widthCache = {};
		}
		return result;
	} catch (e) {
		return {
			width: 0,
			height: 0
		};
	}
};
var getOffset = function getOffset(rect) {
	return {
		top: rect.top + window.scrollY - document.documentElement.clientTop,
		left: rect.left + window.scrollX - document.documentElement.clientLeft
	};
};
//#endregion
//#region node_modules/recharts/es6/util/ReduceCSSCalc.js
function _typeof$44(o) {
	"@babel/helpers - typeof";
	return _typeof$44 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$44(o);
}
function _slicedToArray$10(arr, i) {
	return _arrayWithHoles$10(arr) || _iterableToArrayLimit$10(arr, i) || _unsupportedIterableToArray$17(arr, i) || _nonIterableRest$10();
}
function _nonIterableRest$10() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$17(o, minLen) {
	if (!o) return;
	if (typeof o === "string") return _arrayLikeToArray$17(o, minLen);
	var n = Object.prototype.toString.call(o).slice(8, -1);
	if (n === "Object" && o.constructor) n = o.constructor.name;
	if (n === "Map" || n === "Set") return Array.from(o);
	if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$17(o, minLen);
}
function _arrayLikeToArray$17(arr, len) {
	if (len == null || len > arr.length) len = arr.length;
	for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
	return arr2;
}
function _iterableToArrayLimit$10(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = !0, o = !1;
		try {
			if (i = (t = t.call(r)).next, 0 === l) {
				if (Object(t) !== t) return;
				f = !1;
			} else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = !0, n = r;
		} finally {
			try {
				if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
function _arrayWithHoles$10(arr) {
	if (Array.isArray(arr)) return arr;
}
function _classCallCheck$24(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$24(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$43(descriptor.key), descriptor);
	}
}
function _createClass$24(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$24(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$24(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _toPropertyKey$43(t) {
	var i = _toPrimitive$43(t, "string");
	return "symbol" == _typeof$44(i) ? i : i + "";
}
function _toPrimitive$43(t, r) {
	if ("object" != _typeof$44(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$44(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var MULTIPLY_OR_DIVIDE_REGEX = /(-?\d+(?:\.\d+)?[a-zA-Z%]*)([*/])(-?\d+(?:\.\d+)?[a-zA-Z%]*)/;
var ADD_OR_SUBTRACT_REGEX = /(-?\d+(?:\.\d+)?[a-zA-Z%]*)([+-])(-?\d+(?:\.\d+)?[a-zA-Z%]*)/;
var CSS_LENGTH_UNIT_REGEX = /^px|cm|vh|vw|em|rem|%|mm|in|pt|pc|ex|ch|vmin|vmax|Q$/;
var NUM_SPLIT_REGEX = /(-?\d+(?:\.\d+)?)([a-zA-Z%]+)?/;
var CONVERSION_RATES = {
	cm: 96 / 2.54,
	mm: 96 / 25.4,
	pt: 96 / 72,
	pc: 16,
	"in": 96,
	Q: 96 / 101.6,
	px: 1
};
var FIXED_CSS_LENGTH_UNITS = Object.keys(CONVERSION_RATES);
var STR_NAN = "NaN";
function convertToPx(value, unit) {
	return value * CONVERSION_RATES[unit];
}
var DecimalCSS = /*#__PURE__*/ function() {
	function DecimalCSS(num, unit) {
		_classCallCheck$24(this, DecimalCSS);
		this.num = num;
		this.unit = unit;
		this.num = num;
		this.unit = unit;
		if (Number.isNaN(num)) this.unit = "";
		if (unit !== "" && !CSS_LENGTH_UNIT_REGEX.test(unit)) {
			this.num = NaN;
			this.unit = "";
		}
		if (FIXED_CSS_LENGTH_UNITS.includes(unit)) {
			this.num = convertToPx(num, unit);
			this.unit = "px";
		}
	}
	return _createClass$24(DecimalCSS, [
		{
			key: "add",
			value: function add(other) {
				if (this.unit !== other.unit) return new DecimalCSS(NaN, "");
				return new DecimalCSS(this.num + other.num, this.unit);
			}
		},
		{
			key: "subtract",
			value: function subtract(other) {
				if (this.unit !== other.unit) return new DecimalCSS(NaN, "");
				return new DecimalCSS(this.num - other.num, this.unit);
			}
		},
		{
			key: "multiply",
			value: function multiply(other) {
				if (this.unit !== "" && other.unit !== "" && this.unit !== other.unit) return new DecimalCSS(NaN, "");
				return new DecimalCSS(this.num * other.num, this.unit || other.unit);
			}
		},
		{
			key: "divide",
			value: function divide(other) {
				if (this.unit !== "" && other.unit !== "" && this.unit !== other.unit) return new DecimalCSS(NaN, "");
				return new DecimalCSS(this.num / other.num, this.unit || other.unit);
			}
		},
		{
			key: "toString",
			value: function toString() {
				return "".concat(this.num).concat(this.unit);
			}
		},
		{
			key: "isNaN",
			value: function isNaN() {
				return Number.isNaN(this.num);
			}
		}
	], [{
		key: "parse",
		value: function parse(str) {
			var _NUM_SPLIT_REGEX$exec;
			var _ref2 = _slicedToArray$10((_NUM_SPLIT_REGEX$exec = NUM_SPLIT_REGEX.exec(str)) !== null && _NUM_SPLIT_REGEX$exec !== void 0 ? _NUM_SPLIT_REGEX$exec : [], 3), numStr = _ref2[1], unit = _ref2[2];
			return new DecimalCSS(parseFloat(numStr), unit !== null && unit !== void 0 ? unit : "");
		}
	}]);
}();
function calculateArithmetic(expr) {
	if (expr.includes(STR_NAN)) return STR_NAN;
	var newExpr = expr;
	while (newExpr.includes("*") || newExpr.includes("/")) {
		var _MULTIPLY_OR_DIVIDE_R;
		var _ref4 = _slicedToArray$10((_MULTIPLY_OR_DIVIDE_R = MULTIPLY_OR_DIVIDE_REGEX.exec(newExpr)) !== null && _MULTIPLY_OR_DIVIDE_R !== void 0 ? _MULTIPLY_OR_DIVIDE_R : [], 4), leftOperand = _ref4[1], operator = _ref4[2], rightOperand = _ref4[3];
		var lTs = DecimalCSS.parse(leftOperand !== null && leftOperand !== void 0 ? leftOperand : "");
		var rTs = DecimalCSS.parse(rightOperand !== null && rightOperand !== void 0 ? rightOperand : "");
		var result = operator === "*" ? lTs.multiply(rTs) : lTs.divide(rTs);
		if (result.isNaN()) return STR_NAN;
		newExpr = newExpr.replace(MULTIPLY_OR_DIVIDE_REGEX, result.toString());
	}
	while (newExpr.includes("+") || /.-\d+(?:\.\d+)?/.test(newExpr)) {
		var _ADD_OR_SUBTRACT_REGE;
		var _ref6 = _slicedToArray$10((_ADD_OR_SUBTRACT_REGE = ADD_OR_SUBTRACT_REGEX.exec(newExpr)) !== null && _ADD_OR_SUBTRACT_REGE !== void 0 ? _ADD_OR_SUBTRACT_REGE : [], 4), _leftOperand = _ref6[1], _operator = _ref6[2], _rightOperand = _ref6[3];
		var _lTs = DecimalCSS.parse(_leftOperand !== null && _leftOperand !== void 0 ? _leftOperand : "");
		var _rTs = DecimalCSS.parse(_rightOperand !== null && _rightOperand !== void 0 ? _rightOperand : "");
		var _result = _operator === "+" ? _lTs.add(_rTs) : _lTs.subtract(_rTs);
		if (_result.isNaN()) return STR_NAN;
		newExpr = newExpr.replace(ADD_OR_SUBTRACT_REGEX, _result.toString());
	}
	return newExpr;
}
var PARENTHESES_REGEX = /\(([^()]*)\)/;
function calculateParentheses(expr) {
	var newExpr = expr;
	while (newExpr.includes("(")) {
		var parentheticalExpression = _slicedToArray$10(PARENTHESES_REGEX.exec(newExpr), 2)[1];
		newExpr = newExpr.replace(PARENTHESES_REGEX, calculateArithmetic(parentheticalExpression));
	}
	return newExpr;
}
function evaluateExpression(expression) {
	var newExpr = expression.replace(/\s+/g, "");
	newExpr = calculateParentheses(newExpr);
	newExpr = calculateArithmetic(newExpr);
	return newExpr;
}
function safeEvaluateExpression(expression) {
	try {
		return evaluateExpression(expression);
	} catch (e) {
		/* istanbul ignore next */
		return STR_NAN;
	}
}
function reduceCSSCalc(expression) {
	var result = safeEvaluateExpression(expression.slice(5, -1));
	if (result === STR_NAN) return "";
	return result;
}
//#endregion
//#region node_modules/recharts/es6/component/Text.js
var _excluded$21 = [
	"x",
	"y",
	"lineHeight",
	"capHeight",
	"scaleToFit",
	"textAnchor",
	"verticalAnchor",
	"fill"
];
var _excluded2$9 = [
	"dx",
	"dy",
	"angle",
	"className",
	"breakAll"
];
function _extends$37() {
	_extends$37 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$37.apply(this, arguments);
}
function _objectWithoutProperties$21(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$21(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$21(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
function _slicedToArray$9(arr, i) {
	return _arrayWithHoles$9(arr) || _iterableToArrayLimit$9(arr, i) || _unsupportedIterableToArray$16(arr, i) || _nonIterableRest$9();
}
function _nonIterableRest$9() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$16(o, minLen) {
	if (!o) return;
	if (typeof o === "string") return _arrayLikeToArray$16(o, minLen);
	var n = Object.prototype.toString.call(o).slice(8, -1);
	if (n === "Object" && o.constructor) n = o.constructor.name;
	if (n === "Map" || n === "Set") return Array.from(o);
	if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$16(o, minLen);
}
function _arrayLikeToArray$16(arr, len) {
	if (len == null || len > arr.length) len = arr.length;
	for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
	return arr2;
}
function _iterableToArrayLimit$9(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = !0, o = !1;
		try {
			if (i = (t = t.call(r)).next, 0 === l) {
				if (Object(t) !== t) return;
				f = !1;
			} else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = !0, n = r;
		} finally {
			try {
				if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
function _arrayWithHoles$9(arr) {
	if (Array.isArray(arr)) return arr;
}
var BREAKING_SPACES = /[ \f\n\r\t\v\u2028\u2029]+/;
var calculateWordWidths = function calculateWordWidths(_ref) {
	var children = _ref.children, breakAll = _ref.breakAll, style = _ref.style;
	try {
		var words = [];
		if (!(0, import_isNil.default)(children)) {
			if (breakAll) words = children.toString().split("");
			else words = children.toString().split(BREAKING_SPACES);
		}
		return {
			wordsWithComputedWidth: words.map(function(word) {
				return {
					word,
					width: getStringSize(word, style).width
				};
			}),
			spaceWidth: breakAll ? 0 : getStringSize("\xA0", style).width
		};
	} catch (e) {
		return null;
	}
};
var calculateWordsByLines = function calculateWordsByLines(_ref2, initialWordsWithComputedWith, spaceWidth, lineWidth, scaleToFit) {
	var maxLines = _ref2.maxLines, children = _ref2.children, style = _ref2.style, breakAll = _ref2.breakAll;
	var shouldLimitLines = isNumber$1(maxLines);
	var text = children;
	var calculate = function calculate() {
		return (arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : []).reduce(function(result, _ref3) {
			var word = _ref3.word, width = _ref3.width;
			var currentLine = result[result.length - 1];
			if (currentLine && (lineWidth == null || scaleToFit || currentLine.width + width + spaceWidth < Number(lineWidth))) {
				currentLine.words.push(word);
				currentLine.width += width + spaceWidth;
			} else {
				var newLine = {
					words: [word],
					width
				};
				result.push(newLine);
			}
			return result;
		}, []);
	};
	var originalResult = calculate(initialWordsWithComputedWith);
	var findLongestLine = function findLongestLine(words) {
		return words.reduce(function(a, b) {
			return a.width > b.width ? a : b;
		});
	};
	if (!shouldLimitLines) return originalResult;
	var suffix = "…";
	var checkOverflow = function checkOverflow(index) {
		var words = calculateWordWidths({
			breakAll,
			style,
			children: text.slice(0, index) + suffix
		}).wordsWithComputedWidth;
		var result = calculate(words);
		return [result.length > maxLines || findLongestLine(result).width > Number(lineWidth), result];
	};
	var start = 0;
	var end = text.length - 1;
	var iterations = 0;
	var trimmedResult;
	while (start <= end && iterations <= text.length - 1) {
		var middle = Math.floor((start + end) / 2);
		var _checkOverflow2 = _slicedToArray$9(checkOverflow(middle - 1), 2), doesPrevOverflow = _checkOverflow2[0], result = _checkOverflow2[1];
		var doesMiddleOverflow = _slicedToArray$9(checkOverflow(middle), 1)[0];
		if (!doesPrevOverflow && !doesMiddleOverflow) start = middle + 1;
		if (doesPrevOverflow && doesMiddleOverflow) end = middle - 1;
		if (!doesPrevOverflow && doesMiddleOverflow) {
			trimmedResult = result;
			break;
		}
		iterations++;
	}
	return trimmedResult || originalResult;
};
var getWordsWithoutCalculate = function getWordsWithoutCalculate(children) {
	return [{ words: !(0, import_isNil.default)(children) ? children.toString().split(BREAKING_SPACES) : [] }];
};
var getWordsByLines = function getWordsByLines(_ref4) {
	var width = _ref4.width, scaleToFit = _ref4.scaleToFit, children = _ref4.children, style = _ref4.style, breakAll = _ref4.breakAll, maxLines = _ref4.maxLines;
	if ((width || scaleToFit) && !Global.isSsr) {
		var wordsWithComputedWidth, spaceWidth;
		var wordWidths = calculateWordWidths({
			breakAll,
			children,
			style
		});
		if (wordWidths) {
			var wcw = wordWidths.wordsWithComputedWidth, sw = wordWidths.spaceWidth;
			wordsWithComputedWidth = wcw;
			spaceWidth = sw;
		} else return getWordsWithoutCalculate(children);
		return calculateWordsByLines({
			breakAll,
			children,
			maxLines,
			style
		}, wordsWithComputedWidth, spaceWidth, width, scaleToFit);
	}
	return getWordsWithoutCalculate(children);
};
var DEFAULT_FILL = "#808080";
var Text = function Text(_ref5) {
	var _ref5$x = _ref5.x, propsX = _ref5$x === void 0 ? 0 : _ref5$x, _ref5$y = _ref5.y, propsY = _ref5$y === void 0 ? 0 : _ref5$y, _ref5$lineHeight = _ref5.lineHeight, lineHeight = _ref5$lineHeight === void 0 ? "1em" : _ref5$lineHeight, _ref5$capHeight = _ref5.capHeight, capHeight = _ref5$capHeight === void 0 ? "0.71em" : _ref5$capHeight, _ref5$scaleToFit = _ref5.scaleToFit, scaleToFit = _ref5$scaleToFit === void 0 ? false : _ref5$scaleToFit, _ref5$textAnchor = _ref5.textAnchor, textAnchor = _ref5$textAnchor === void 0 ? "start" : _ref5$textAnchor, _ref5$verticalAnchor = _ref5.verticalAnchor, verticalAnchor = _ref5$verticalAnchor === void 0 ? "end" : _ref5$verticalAnchor, _ref5$fill = _ref5.fill, fill = _ref5$fill === void 0 ? DEFAULT_FILL : _ref5$fill, props = _objectWithoutProperties$21(_ref5, _excluded$21);
	var wordsByLines = (0, import_react.useMemo)(function() {
		return getWordsByLines({
			breakAll: props.breakAll,
			children: props.children,
			maxLines: props.maxLines,
			scaleToFit,
			style: props.style,
			width: props.width
		});
	}, [
		props.breakAll,
		props.children,
		props.maxLines,
		scaleToFit,
		props.style,
		props.width
	]);
	var dx = props.dx, dy = props.dy, angle = props.angle, className = props.className, breakAll = props.breakAll, textProps = _objectWithoutProperties$21(props, _excluded2$9);
	if (!isNumOrStr(propsX) || !isNumOrStr(propsY)) return null;
	var x = propsX + (isNumber$1(dx) ? dx : 0);
	var y = propsY + (isNumber$1(dy) ? dy : 0);
	var startDy;
	switch (verticalAnchor) {
		case "start":
			startDy = reduceCSSCalc("calc(".concat(capHeight, ")"));
			break;
		case "middle":
			startDy = reduceCSSCalc("calc(".concat((wordsByLines.length - 1) / 2, " * -").concat(lineHeight, " + (").concat(capHeight, " / 2))"));
			break;
		default: startDy = reduceCSSCalc("calc(".concat(wordsByLines.length - 1, " * -").concat(lineHeight, ")"));
	}
	var transforms = [];
	if (scaleToFit) {
		var lineWidth = wordsByLines[0].width;
		var width = props.width;
		transforms.push("scale(".concat((isNumber$1(width) ? width / lineWidth : 1) / lineWidth, ")"));
	}
	if (angle) transforms.push("rotate(".concat(angle, ", ").concat(x, ", ").concat(y, ")"));
	if (transforms.length) textProps.transform = transforms.join(" ");
	return /*#__PURE__*/ import_react.createElement("text", _extends$37({}, filterProps(textProps, true), {
		x,
		y,
		className: clsx("recharts-text", className),
		textAnchor,
		fill: fill.includes("url") ? DEFAULT_FILL : fill
	}), wordsByLines.map(function(line, index) {
		var words = line.words.join(breakAll ? "" : " ");
		return /*#__PURE__*/ import_react.createElement("tspan", {
			x,
			dy: index === 0 ? startDy : lineHeight,
			key: "".concat(words, "-").concat(index)
		}, words);
	}));
};
//#endregion
//#region node_modules/victory-vendor/es/d3-scale.js
var d3_scale_exports = /* @__PURE__ */ __exportAll({
	scaleBand: () => band,
	scaleDiverging: () => diverging,
	scaleDivergingLog: () => divergingLog,
	scaleDivergingPow: () => divergingPow,
	scaleDivergingSqrt: () => divergingSqrt,
	scaleDivergingSymlog: () => divergingSymlog,
	scaleIdentity: () => identity$1,
	scaleImplicit: () => implicit,
	scaleLinear: () => linear,
	scaleLog: () => log,
	scaleOrdinal: () => ordinal,
	scalePoint: () => point,
	scalePow: () => pow,
	scaleQuantile: () => quantile,
	scaleQuantize: () => quantize,
	scaleRadial: () => radial,
	scaleSequential: () => sequential,
	scaleSequentialLog: () => sequentialLog,
	scaleSequentialPow: () => sequentialPow,
	scaleSequentialQuantile: () => sequentialQuantile,
	scaleSequentialSqrt: () => sequentialSqrt,
	scaleSequentialSymlog: () => sequentialSymlog,
	scaleSqrt: () => sqrt,
	scaleSymlog: () => symlog,
	scaleThreshold: () => threshold,
	scaleTime: () => time,
	scaleUtc: () => utcTime,
	tickFormat: () => tickFormat
});
//#endregion
//#region node_modules/recharts-scale/es6/util/utils.js
var import_max = /* @__PURE__ */ __toESM(require_max());
var import_min = /* @__PURE__ */ __toESM(require_min());
var import_flatMap = /* @__PURE__ */ __toESM(require_flatMap());
var import_isEqual = /* @__PURE__ */ __toESM(require_isEqual());
function _toConsumableArray$9(arr) {
	return _arrayWithoutHoles$9(arr) || _iterableToArray$9(arr) || _unsupportedIterableToArray$15(arr) || _nonIterableSpread$9();
}
function _nonIterableSpread$9() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$15(o, minLen) {
	if (!o) return;
	if (typeof o === "string") return _arrayLikeToArray$15(o, minLen);
	var n = Object.prototype.toString.call(o).slice(8, -1);
	if (n === "Object" && o.constructor) n = o.constructor.name;
	if (n === "Map" || n === "Set") return Array.from(o);
	if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$15(o, minLen);
}
function _iterableToArray$9(iter) {
	if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
}
function _arrayWithoutHoles$9(arr) {
	if (Array.isArray(arr)) return _arrayLikeToArray$15(arr);
}
function _arrayLikeToArray$15(arr, len) {
	if (len == null || len > arr.length) len = arr.length;
	for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
	return arr2;
}
var identity = function identity(i) {
	return i;
};
var PLACE_HOLDER = { "@@functional/placeholder": true };
var isPlaceHolder = function isPlaceHolder(val) {
	return val === PLACE_HOLDER;
};
var curry0 = function curry0(fn) {
	return function _curried() {
		if (arguments.length === 0 || arguments.length === 1 && isPlaceHolder(arguments.length <= 0 ? void 0 : arguments[0])) return _curried;
		return fn.apply(void 0, arguments);
	};
};
var curryN = function curryN(n, fn) {
	if (n === 1) return fn;
	return curry0(function() {
		for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
		var argsLength = args.filter(function(arg) {
			return arg !== PLACE_HOLDER;
		}).length;
		if (argsLength >= n) return fn.apply(void 0, args);
		return curryN(n - argsLength, curry0(function() {
			for (var _len2 = arguments.length, restArgs = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) restArgs[_key2] = arguments[_key2];
			var newArgs = args.map(function(arg) {
				return isPlaceHolder(arg) ? restArgs.shift() : arg;
			});
			return fn.apply(void 0, _toConsumableArray$9(newArgs).concat(restArgs));
		}));
	});
};
var curry = function curry(fn) {
	return curryN(fn.length, fn);
};
var range$2 = function range(begin, end) {
	var arr = [];
	for (var i = begin; i < end; ++i) arr[i - begin] = i;
	return arr;
};
var map = curry(function(fn, arr) {
	if (Array.isArray(arr)) return arr.map(fn);
	return Object.keys(arr).map(function(key) {
		return arr[key];
	}).map(fn);
});
var compose = function compose() {
	for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) args[_key3] = arguments[_key3];
	if (!args.length) return identity;
	var fns = args.reverse();
	var firstFn = fns[0];
	var tailsFn = fns.slice(1);
	return function() {
		return tailsFn.reduce(function(res, fn) {
			return fn(res);
		}, firstFn.apply(void 0, arguments));
	};
};
var reverse = function reverse(arr) {
	if (Array.isArray(arr)) return arr.reverse();
	return arr.split("").reverse.join("");
};
var memoize$1 = function memoize(fn) {
	var lastArgs = null;
	var lastResult = null;
	return function() {
		for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) args[_key4] = arguments[_key4];
		if (lastArgs && args.every(function(val, i) {
			return val === lastArgs[i];
		})) return lastResult;
		lastArgs = args;
		lastResult = fn.apply(void 0, args);
		return lastResult;
	};
};
//#endregion
//#region node_modules/recharts-scale/es6/util/arithmetic.js
/**
* @fileOverview 一些公用的运算方法
* @author xile611
* @date 2015-09-17
*/
/**
* 获取数值的位数
* 其中绝对值属于区间[0.1, 1)， 得到的值为0
* 绝对值属于区间[0.01, 0.1)，得到的位数为 -1
* 绝对值属于区间[0.001, 0.01)，得到的位数为 -2
*
* @param  {Number} value 数值
* @return {Integer} 位数
*/
function getDigitCount(value) {
	var result;
	if (value === 0) result = 1;
	else result = Math.floor(new decimal_default(value).abs().log(10).toNumber()) + 1;
	return result;
}
/**
* 按照固定的步长获取[start, end)这个区间的数据
* 并且需要处理js计算精度的问题
*
* @param  {Decimal} start 起点
* @param  {Decimal} end   终点，不包含该值
* @param  {Decimal} step  步长
* @return {Array}         若干数值
*/
function rangeStep(start, end, step) {
	var num = new decimal_default(start);
	var i = 0;
	var result = [];
	while (num.lt(end) && i < 1e5) {
		result.push(num.toNumber());
		num = num.add(step);
		i++;
	}
	return result;
}
var arithmetic_default = {
	rangeStep,
	getDigitCount,
	interpolateNumber: curry(function(a, b, t) {
		var newA = +a;
		return newA + t * (+b - newA);
	}),
	uninterpolateNumber: curry(function(a, b, x) {
		var diff = b - +a;
		diff = diff || Infinity;
		return (x - a) / diff;
	}),
	uninterpolateTruncation: curry(function(a, b, x) {
		var diff = b - +a;
		diff = diff || Infinity;
		return Math.max(0, Math.min(1, (x - a) / diff));
	})
};
//#endregion
//#region node_modules/recharts-scale/es6/getNiceTickValues.js
/**
* @fileOverview calculate tick values of scale
* @author xile611, arcthur
* @date 2015-09-17
*/
function _toConsumableArray$8(arr) {
	return _arrayWithoutHoles$8(arr) || _iterableToArray$8(arr) || _unsupportedIterableToArray$14(arr) || _nonIterableSpread$8();
}
function _nonIterableSpread$8() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _iterableToArray$8(iter) {
	if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
}
function _arrayWithoutHoles$8(arr) {
	if (Array.isArray(arr)) return _arrayLikeToArray$14(arr);
}
function _slicedToArray$8(arr, i) {
	return _arrayWithHoles$8(arr) || _iterableToArrayLimit$8(arr, i) || _unsupportedIterableToArray$14(arr, i) || _nonIterableRest$8();
}
function _nonIterableRest$8() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$14(o, minLen) {
	if (!o) return;
	if (typeof o === "string") return _arrayLikeToArray$14(o, minLen);
	var n = Object.prototype.toString.call(o).slice(8, -1);
	if (n === "Object" && o.constructor) n = o.constructor.name;
	if (n === "Map" || n === "Set") return Array.from(o);
	if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$14(o, minLen);
}
function _arrayLikeToArray$14(arr, len) {
	if (len == null || len > arr.length) len = arr.length;
	for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
	return arr2;
}
function _iterableToArrayLimit$8(arr, i) {
	if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return;
	var _arr = [];
	var _n = true;
	var _d = false;
	var _e = void 0;
	try {
		for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
			_arr.push(_s.value);
			if (i && _arr.length === i) break;
		}
	} catch (err) {
		_d = true;
		_e = err;
	} finally {
		try {
			if (!_n && _i["return"] != null) _i["return"]();
		} finally {
			if (_d) throw _e;
		}
	}
	return _arr;
}
function _arrayWithHoles$8(arr) {
	if (Array.isArray(arr)) return arr;
}
/**
* Calculate a interval of a minimum value and a maximum value
*
* @param  {Number} min       The minimum value
* @param  {Number} max       The maximum value
* @return {Array} An interval
*/
function getValidInterval(_ref) {
	var _ref2 = _slicedToArray$8(_ref, 2), min = _ref2[0], max = _ref2[1];
	var validMin = min, validMax = max;
	if (min > max) {
		validMin = max;
		validMax = min;
	}
	return [validMin, validMax];
}
/**
* Calculate the step which is easy to understand between ticks, like 10, 20, 25
*
* @param  {Decimal} roughStep        The rough step calculated by deviding the
* difference by the tickCount
* @param  {Boolean} allowDecimals    Allow the ticks to be decimals or not
* @param  {Integer} correctionFactor A correction factor
* @return {Decimal} The step which is easy to understand between two ticks
*/
function getFormatStep(roughStep, allowDecimals, correctionFactor) {
	if (roughStep.lte(0)) return new decimal_default(0);
	var digitCount = arithmetic_default.getDigitCount(roughStep.toNumber());
	var digitCountValue = new decimal_default(10).pow(digitCount);
	var stepRatio = roughStep.div(digitCountValue);
	var stepRatioScale = digitCount !== 1 ? .05 : .1;
	var formatStep = new decimal_default(Math.ceil(stepRatio.div(stepRatioScale).toNumber())).add(correctionFactor).mul(stepRatioScale).mul(digitCountValue);
	return allowDecimals ? formatStep : new decimal_default(Math.ceil(formatStep));
}
/**
* calculate the ticks when the minimum value equals to the maximum value
*
* @param  {Number}  value         The minimum valuue which is also the maximum value
* @param  {Integer} tickCount     The count of ticks
* @param  {Boolean} allowDecimals Allow the ticks to be decimals or not
* @return {Array}                 ticks
*/
function getTickOfSingleValue(value, tickCount, allowDecimals) {
	var step = 1;
	var middle = new decimal_default(value);
	if (!middle.isint() && allowDecimals) {
		var absVal = Math.abs(value);
		if (absVal < 1) {
			step = new decimal_default(10).pow(arithmetic_default.getDigitCount(value) - 1);
			middle = new decimal_default(Math.floor(middle.div(step).toNumber())).mul(step);
		} else if (absVal > 1) middle = new decimal_default(Math.floor(value));
	} else if (value === 0) middle = new decimal_default(Math.floor((tickCount - 1) / 2));
	else if (!allowDecimals) middle = new decimal_default(Math.floor(value));
	var middleIndex = Math.floor((tickCount - 1) / 2);
	return compose(map(function(n) {
		return middle.add(new decimal_default(n - middleIndex).mul(step)).toNumber();
	}), range$2)(0, tickCount);
}
/**
* Calculate the step
*
* @param  {Number}  min              The minimum value of an interval
* @param  {Number}  max              The maximum value of an interval
* @param  {Integer} tickCount        The count of ticks
* @param  {Boolean} allowDecimals    Allow the ticks to be decimals or not
* @param  {Number}  correctionFactor A correction factor
* @return {Object}  The step, minimum value of ticks, maximum value of ticks
*/
function calculateStep(min, max, tickCount, allowDecimals) {
	var correctionFactor = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : 0;
	if (!Number.isFinite((max - min) / (tickCount - 1))) return {
		step: new decimal_default(0),
		tickMin: new decimal_default(0),
		tickMax: new decimal_default(0)
	};
	var step = getFormatStep(new decimal_default(max).sub(min).div(tickCount - 1), allowDecimals, correctionFactor);
	var middle;
	if (min <= 0 && max >= 0) middle = new decimal_default(0);
	else {
		middle = new decimal_default(min).add(max).div(2);
		middle = middle.sub(new decimal_default(middle).mod(step));
	}
	var belowCount = Math.ceil(middle.sub(min).div(step).toNumber());
	var upCount = Math.ceil(new decimal_default(max).sub(middle).div(step).toNumber());
	var scaleCount = belowCount + upCount + 1;
	if (scaleCount > tickCount) return calculateStep(min, max, tickCount, allowDecimals, correctionFactor + 1);
	if (scaleCount < tickCount) {
		upCount = max > 0 ? upCount + (tickCount - scaleCount) : upCount;
		belowCount = max > 0 ? belowCount : belowCount + (tickCount - scaleCount);
	}
	return {
		step,
		tickMin: middle.sub(new decimal_default(belowCount).mul(step)),
		tickMax: middle.add(new decimal_default(upCount).mul(step))
	};
}
/**
* Calculate the ticks of an interval, the count of ticks will be guraranteed
*
* @param  {Number}  min, max      min: The minimum value, max: The maximum value
* @param  {Integer} tickCount     The count of ticks
* @param  {Boolean} allowDecimals Allow the ticks to be decimals or not
* @return {Array}   ticks
*/
function getNiceTickValuesFn(_ref3) {
	var _ref4 = _slicedToArray$8(_ref3, 2), min = _ref4[0], max = _ref4[1];
	var tickCount = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 6;
	var allowDecimals = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : true;
	var count = Math.max(tickCount, 2);
	var _getValidInterval2 = _slicedToArray$8(getValidInterval([min, max]), 2), cormin = _getValidInterval2[0], cormax = _getValidInterval2[1];
	if (cormin === -Infinity || cormax === Infinity) {
		var _values = cormax === Infinity ? [cormin].concat(_toConsumableArray$8(range$2(0, tickCount - 1).map(function() {
			return Infinity;
		}))) : [].concat(_toConsumableArray$8(range$2(0, tickCount - 1).map(function() {
			return -Infinity;
		})), [cormax]);
		return min > max ? reverse(_values) : _values;
	}
	if (cormin === cormax) return getTickOfSingleValue(cormin, tickCount, allowDecimals);
	var _calculateStep = calculateStep(cormin, cormax, count, allowDecimals), step = _calculateStep.step, tickMin = _calculateStep.tickMin, tickMax = _calculateStep.tickMax;
	var values = arithmetic_default.rangeStep(tickMin, tickMax.add(new decimal_default(.1).mul(step)), step);
	return min > max ? reverse(values) : values;
}
/**
* Calculate the ticks of an interval, the count of ticks won't be guraranteed,
* but the domain will be guaranteed
*
* @param  {Number}  min, max      min: The minimum value, max: The maximum value
* @param  {Integer} tickCount     The count of ticks
* @param  {Boolean} allowDecimals Allow the ticks to be decimals or not
* @return {Array}   ticks
*/
function getTickValuesFixedDomainFn(_ref7, tickCount) {
	var _ref8 = _slicedToArray$8(_ref7, 2), min = _ref8[0], max = _ref8[1];
	var allowDecimals = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : true;
	var _getValidInterval6 = _slicedToArray$8(getValidInterval([min, max]), 2), cormin = _getValidInterval6[0], cormax = _getValidInterval6[1];
	if (cormin === -Infinity || cormax === Infinity) return [min, max];
	if (cormin === cormax) return [cormin];
	var count = Math.max(tickCount, 2);
	var step = getFormatStep(new decimal_default(cormax).sub(cormin).div(count - 1), allowDecimals, 0);
	var values = [].concat(_toConsumableArray$8(arithmetic_default.rangeStep(new decimal_default(cormin), new decimal_default(cormax).sub(new decimal_default(.99).mul(step)), step)), [cormax]);
	return min > max ? reverse(values) : values;
}
var getNiceTickValues = memoize$1(getNiceTickValuesFn);
var getTickValuesFixedDomain = memoize$1(getTickValuesFixedDomainFn);
//#endregion
//#region node_modules/tiny-invariant/dist/esm/tiny-invariant.js
var prefix = "Invariant failed";
function invariant(condition, message) {
	if (condition) return;
	throw new Error(prefix);
}
//#endregion
//#region node_modules/recharts/es6/cartesian/ErrorBar.js
/**
* @fileOverview Render a group of error bar
*/
var _excluded$20 = [
	"offset",
	"layout",
	"width",
	"dataKey",
	"data",
	"dataPointFormatter",
	"xAxis",
	"yAxis"
];
function _typeof$43(o) {
	"@babel/helpers - typeof";
	return _typeof$43 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$43(o);
}
function _extends$36() {
	_extends$36 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$36.apply(this, arguments);
}
function _slicedToArray$7(arr, i) {
	return _arrayWithHoles$7(arr) || _iterableToArrayLimit$7(arr, i) || _unsupportedIterableToArray$13(arr, i) || _nonIterableRest$7();
}
function _nonIterableRest$7() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$13(o, minLen) {
	if (!o) return;
	if (typeof o === "string") return _arrayLikeToArray$13(o, minLen);
	var n = Object.prototype.toString.call(o).slice(8, -1);
	if (n === "Object" && o.constructor) n = o.constructor.name;
	if (n === "Map" || n === "Set") return Array.from(o);
	if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$13(o, minLen);
}
function _arrayLikeToArray$13(arr, len) {
	if (len == null || len > arr.length) len = arr.length;
	for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
	return arr2;
}
function _iterableToArrayLimit$7(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = !0, o = !1;
		try {
			if (i = (t = t.call(r)).next, 0 === l) {
				if (Object(t) !== t) return;
				f = !1;
			} else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = !0, n = r;
		} finally {
			try {
				if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
function _arrayWithHoles$7(arr) {
	if (Array.isArray(arr)) return arr;
}
function _objectWithoutProperties$20(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$20(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$20(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
function _classCallCheck$23(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$23(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$42(descriptor.key), descriptor);
	}
}
function _createClass$23(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$23(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$23(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$21(t, o, e) {
	return o = _getPrototypeOf$21(o), _possibleConstructorReturn$21(t, _isNativeReflectConstruct$21() ? Reflect.construct(o, e || [], _getPrototypeOf$21(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$21(self, call) {
	if (call && (_typeof$43(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$21(self);
}
function _assertThisInitialized$21(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$21() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$21 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$21(o) {
	_getPrototypeOf$21 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$21(o);
}
function _inherits$21(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$21(subClass, superClass);
}
function _setPrototypeOf$21(o, p) {
	_setPrototypeOf$21 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$21(o, p);
}
function _defineProperty$42(obj, key, value) {
	key = _toPropertyKey$42(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$42(t) {
	var i = _toPrimitive$42(t, "string");
	return "symbol" == _typeof$43(i) ? i : i + "";
}
function _toPrimitive$42(t, r) {
	if ("object" != _typeof$43(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$43(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var ErrorBar = /*#__PURE__*/ function(_React$Component) {
	function ErrorBar() {
		_classCallCheck$23(this, ErrorBar);
		return _callSuper$21(this, ErrorBar, arguments);
	}
	_inherits$21(ErrorBar, _React$Component);
	return _createClass$23(ErrorBar, [{
		key: "render",
		value: function render() {
			var _this$props = this.props, offset = _this$props.offset, layout = _this$props.layout, width = _this$props.width, dataKey = _this$props.dataKey, data = _this$props.data, dataPointFormatter = _this$props.dataPointFormatter, xAxis = _this$props.xAxis, yAxis = _this$props.yAxis;
			var svgProps = filterProps(_objectWithoutProperties$20(_this$props, _excluded$20), false);
			this.props.direction === "x" && xAxis.type !== "number" && invariant(false);
			var errorBars = data.map(function(entry) {
				var _dataPointFormatter = dataPointFormatter(entry, dataKey), x = _dataPointFormatter.x, y = _dataPointFormatter.y, value = _dataPointFormatter.value, errorVal = _dataPointFormatter.errorVal;
				if (!errorVal) return null;
				var lineCoordinates = [];
				var lowBound, highBound;
				if (Array.isArray(errorVal)) {
					var _errorVal = _slicedToArray$7(errorVal, 2);
					lowBound = _errorVal[0];
					highBound = _errorVal[1];
				} else lowBound = highBound = errorVal;
				if (layout === "vertical") {
					var scale = xAxis.scale;
					var yMid = y + offset;
					var yMin = yMid + width;
					var yMax = yMid - width;
					var xMin = scale(value - lowBound);
					var xMax = scale(value + highBound);
					lineCoordinates.push({
						x1: xMax,
						y1: yMin,
						x2: xMax,
						y2: yMax
					});
					lineCoordinates.push({
						x1: xMin,
						y1: yMid,
						x2: xMax,
						y2: yMid
					});
					lineCoordinates.push({
						x1: xMin,
						y1: yMin,
						x2: xMin,
						y2: yMax
					});
				} else if (layout === "horizontal") {
					var _scale = yAxis.scale;
					var xMid = x + offset;
					var _xMin = xMid - width;
					var _xMax = xMid + width;
					var _yMin = _scale(value - lowBound);
					var _yMax = _scale(value + highBound);
					lineCoordinates.push({
						x1: _xMin,
						y1: _yMax,
						x2: _xMax,
						y2: _yMax
					});
					lineCoordinates.push({
						x1: xMid,
						y1: _yMin,
						x2: xMid,
						y2: _yMax
					});
					lineCoordinates.push({
						x1: _xMin,
						y1: _yMin,
						x2: _xMax,
						y2: _yMin
					});
				}
				return /*#__PURE__*/ import_react.createElement(Layer, _extends$36({
					className: "recharts-errorBar",
					key: "bar-".concat(lineCoordinates.map(function(c) {
						return "".concat(c.x1, "-").concat(c.x2, "-").concat(c.y1, "-").concat(c.y2);
					}))
				}, svgProps), lineCoordinates.map(function(coordinates) {
					return /*#__PURE__*/ import_react.createElement("line", _extends$36({}, coordinates, { key: "line-".concat(coordinates.x1, "-").concat(coordinates.x2, "-").concat(coordinates.y1, "-").concat(coordinates.y2) }));
				}));
			});
			return /*#__PURE__*/ import_react.createElement(Layer, { className: "recharts-errorBars" }, errorBars);
		}
	}]);
}(import_react.Component);
_defineProperty$42(ErrorBar, "defaultProps", {
	stroke: "black",
	strokeWidth: 1.5,
	width: 5,
	offset: 0,
	layout: "horizontal"
});
_defineProperty$42(ErrorBar, "displayName", "ErrorBar");
//#endregion
//#region node_modules/recharts/es6/util/getLegendProps.js
function _typeof$42(o) {
	"@babel/helpers - typeof";
	return _typeof$42 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$42(o);
}
function ownKeys$37(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$37(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$37(Object(t), !0).forEach(function(r) {
			_defineProperty$41(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$37(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$41(obj, key, value) {
	key = _toPropertyKey$41(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$41(t) {
	var i = _toPrimitive$41(t, "string");
	return "symbol" == _typeof$42(i) ? i : i + "";
}
function _toPrimitive$41(t, r) {
	if ("object" != _typeof$42(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$42(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var getLegendProps = function getLegendProps(_ref) {
	var children = _ref.children, formattedGraphicalItems = _ref.formattedGraphicalItems, legendWidth = _ref.legendWidth, legendContent = _ref.legendContent;
	var legendItem = findChildByType(children, Legend);
	if (!legendItem) return null;
	var legendDefaultProps = Legend.defaultProps;
	var legendProps = legendDefaultProps !== void 0 ? _objectSpread$37(_objectSpread$37({}, legendDefaultProps), legendItem.props) : {};
	var legendData;
	if (legendItem.props && legendItem.props.payload) legendData = legendItem.props && legendItem.props.payload;
	else if (legendContent === "children") legendData = (formattedGraphicalItems || []).reduce(function(result, _ref2) {
		var item = _ref2.item, props = _ref2.props;
		var data = props.sectors || props.data || [];
		return result.concat(data.map(function(entry) {
			return {
				type: legendItem.props.iconType || item.props.legendType,
				value: entry.name,
				color: entry.fill,
				payload: entry
			};
		}));
	}, []);
	else legendData = (formattedGraphicalItems || []).map(function(_ref3) {
		var item = _ref3.item;
		var itemDefaultProps = item.type.defaultProps;
		var itemProps = itemDefaultProps !== void 0 ? _objectSpread$37(_objectSpread$37({}, itemDefaultProps), item.props) : {};
		var dataKey = itemProps.dataKey, name = itemProps.name, legendType = itemProps.legendType;
		return {
			inactive: itemProps.hide,
			dataKey,
			type: legendProps.iconType || legendType || "square",
			color: getMainColorOfGraphicItem(item),
			value: name || dataKey,
			payload: itemProps
		};
	});
	return _objectSpread$37(_objectSpread$37(_objectSpread$37({}, legendProps), Legend.getWithHeight(legendItem, legendWidth)), {}, {
		payload: legendData,
		item: legendItem
	});
};
//#endregion
//#region node_modules/recharts/es6/util/ChartUtils.js
function _typeof$41(o) {
	"@babel/helpers - typeof";
	return _typeof$41 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$41(o);
}
function _toConsumableArray$7(arr) {
	return _arrayWithoutHoles$7(arr) || _iterableToArray$7(arr) || _unsupportedIterableToArray$12(arr) || _nonIterableSpread$7();
}
function _nonIterableSpread$7() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$12(o, minLen) {
	if (!o) return;
	if (typeof o === "string") return _arrayLikeToArray$12(o, minLen);
	var n = Object.prototype.toString.call(o).slice(8, -1);
	if (n === "Object" && o.constructor) n = o.constructor.name;
	if (n === "Map" || n === "Set") return Array.from(o);
	if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$12(o, minLen);
}
function _iterableToArray$7(iter) {
	if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _arrayWithoutHoles$7(arr) {
	if (Array.isArray(arr)) return _arrayLikeToArray$12(arr);
}
function _arrayLikeToArray$12(arr, len) {
	if (len == null || len > arr.length) len = arr.length;
	for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
	return arr2;
}
function ownKeys$36(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$36(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$36(Object(t), !0).forEach(function(r) {
			_defineProperty$40(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$36(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$40(obj, key, value) {
	key = _toPropertyKey$40(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$40(t) {
	var i = _toPrimitive$40(t, "string");
	return "symbol" == _typeof$41(i) ? i : i + "";
}
function _toPrimitive$40(t, r) {
	if ("object" != _typeof$41(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$41(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function getValueByDataKey(obj, dataKey, defaultValue) {
	if ((0, import_isNil.default)(obj) || (0, import_isNil.default)(dataKey)) return defaultValue;
	if (isNumOrStr(dataKey)) return (0, import_get.default)(obj, dataKey, defaultValue);
	if ((0, import_isFunction.default)(dataKey)) return dataKey(obj);
	return defaultValue;
}
/**
* Get domain of data by key.
* @param  {Array}   data      The data displayed in the chart
* @param  {String}  key       The unique key of a group of data
* @param  {String}  type      The type of axis
* @param  {Boolean} filterNil Whether or not filter nil values
* @return {Array} Domain of data
*/
function getDomainOfDataByKey(data, key, type, filterNil) {
	var flattenData = (0, import_flatMap.default)(data, function(entry) {
		return getValueByDataKey(entry, key);
	});
	if (type === "number") {
		var domain = flattenData.filter(function(entry) {
			return isNumber$1(entry) || parseFloat(entry);
		});
		return domain.length ? [(0, import_min.default)(domain), (0, import_max.default)(domain)] : [Infinity, -Infinity];
	}
	return (filterNil ? flattenData.filter(function(entry) {
		return !(0, import_isNil.default)(entry);
	}) : flattenData).map(function(entry) {
		return isNumOrStr(entry) || entry instanceof Date ? entry : "";
	});
}
var calculateActiveTickIndex = function calculateActiveTickIndex(coordinate) {
	var _ticks$length;
	var ticks = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [];
	var unsortedTicks = arguments.length > 2 ? arguments[2] : void 0;
	var axis = arguments.length > 3 ? arguments[3] : void 0;
	var index = -1;
	var len = (_ticks$length = ticks === null || ticks === void 0 ? void 0 : ticks.length) !== null && _ticks$length !== void 0 ? _ticks$length : 0;
	if (len <= 1) return 0;
	if (axis && axis.axisType === "angleAxis" && Math.abs(Math.abs(axis.range[1] - axis.range[0]) - 360) <= 1e-6) {
		var range = axis.range;
		for (var i = 0; i < len; i++) {
			var before = i > 0 ? unsortedTicks[i - 1].coordinate : unsortedTicks[len - 1].coordinate;
			var cur = unsortedTicks[i].coordinate;
			var after = i >= len - 1 ? unsortedTicks[0].coordinate : unsortedTicks[i + 1].coordinate;
			var sameDirectionCoord = void 0;
			if (mathSign(cur - before) !== mathSign(after - cur)) {
				var diffInterval = [];
				if (mathSign(after - cur) === mathSign(range[1] - range[0])) {
					sameDirectionCoord = after;
					var curInRange = cur + range[1] - range[0];
					diffInterval[0] = Math.min(curInRange, (curInRange + before) / 2);
					diffInterval[1] = Math.max(curInRange, (curInRange + before) / 2);
				} else {
					sameDirectionCoord = before;
					var afterInRange = after + range[1] - range[0];
					diffInterval[0] = Math.min(cur, (afterInRange + cur) / 2);
					diffInterval[1] = Math.max(cur, (afterInRange + cur) / 2);
				}
				var sameInterval = [Math.min(cur, (sameDirectionCoord + cur) / 2), Math.max(cur, (sameDirectionCoord + cur) / 2)];
				if (coordinate > sameInterval[0] && coordinate <= sameInterval[1] || coordinate >= diffInterval[0] && coordinate <= diffInterval[1]) {
					index = unsortedTicks[i].index;
					break;
				}
			} else {
				var minValue = Math.min(before, after);
				var maxValue = Math.max(before, after);
				if (coordinate > (minValue + cur) / 2 && coordinate <= (maxValue + cur) / 2) {
					index = unsortedTicks[i].index;
					break;
				}
			}
		}
	} else for (var _i = 0; _i < len; _i++) if (_i === 0 && coordinate <= (ticks[_i].coordinate + ticks[_i + 1].coordinate) / 2 || _i > 0 && _i < len - 1 && coordinate > (ticks[_i].coordinate + ticks[_i - 1].coordinate) / 2 && coordinate <= (ticks[_i].coordinate + ticks[_i + 1].coordinate) / 2 || _i === len - 1 && coordinate > (ticks[_i].coordinate + ticks[_i - 1].coordinate) / 2) {
		index = ticks[_i].index;
		break;
	}
	return index;
};
/**
* Get the main color of each graphic item
* @param  {ReactElement} item A graphic item
* @return {String}            Color
*/
var getMainColorOfGraphicItem = function getMainColorOfGraphicItem(item) {
	var _item$type;
	var displayName = item.type.displayName;
	var defaultedProps = (_item$type = item.type) !== null && _item$type !== void 0 && _item$type.defaultProps ? _objectSpread$36(_objectSpread$36({}, item.type.defaultProps), item.props) : item.props;
	var stroke = defaultedProps.stroke, fill = defaultedProps.fill;
	var result;
	switch (displayName) {
		case "Line":
			result = stroke;
			break;
		case "Area":
		case "Radar":
			result = stroke && stroke !== "none" ? stroke : fill;
			break;
		default: result = fill;
	}
	return result;
};
/**
* Calculate the size of all groups for stacked bar graph
* @param  {Object} stackGroups The items grouped by axisId and stackId
* @return {Object} The size of all groups
*/
var getBarSizeList = function getBarSizeList(_ref2) {
	var globalSize = _ref2.barSize, totalSize = _ref2.totalSize, _ref2$stackGroups = _ref2.stackGroups, stackGroups = _ref2$stackGroups === void 0 ? {} : _ref2$stackGroups;
	if (!stackGroups) return {};
	var result = {};
	var numericAxisIds = Object.keys(stackGroups);
	for (var i = 0, len = numericAxisIds.length; i < len; i++) {
		var sgs = stackGroups[numericAxisIds[i]].stackGroups;
		var stackIds = Object.keys(sgs);
		for (var j = 0, sLen = stackIds.length; j < sLen; j++) {
			var _sgs$stackIds$j = sgs[stackIds[j]], items = _sgs$stackIds$j.items, cateAxisId = _sgs$stackIds$j.cateAxisId;
			var barItems = items.filter(function(item) {
				return getDisplayName(item.type).indexOf("Bar") >= 0;
			});
			if (barItems && barItems.length) {
				var barItemDefaultProps = barItems[0].type.defaultProps;
				var barItemProps = barItemDefaultProps !== void 0 ? _objectSpread$36(_objectSpread$36({}, barItemDefaultProps), barItems[0].props) : barItems[0].props;
				var selfSize = barItemProps.barSize;
				var cateId = barItemProps[cateAxisId];
				if (!result[cateId]) result[cateId] = [];
				var barSize = (0, import_isNil.default)(selfSize) ? globalSize : selfSize;
				result[cateId].push({
					item: barItems[0],
					stackList: barItems.slice(1),
					barSize: (0, import_isNil.default)(barSize) ? void 0 : getPercentValue(barSize, totalSize, 0)
				});
			}
		}
	}
	return result;
};
/**
* Calculate the size of each bar and offset between start of band and the bar
*
* @param  {number} bandSize is the size of area where bars can render
* @param  {number | string} barGap is the gap size, as a percentage of `bandSize`.
*                                  Can be defined as number or percent string
* @param  {number | string} barCategoryGap is the gap size, as a percentage of `bandSize`.
*                                  Can be defined as number or percent string
* @param  {Array<object>} sizeList Sizes of all groups
* @param  {number} maxBarSize The maximum size of each bar
* @return {Array<object>} The size and offset of each bar
*/
var getBarPosition = function getBarPosition(_ref3) {
	var barGap = _ref3.barGap, barCategoryGap = _ref3.barCategoryGap, bandSize = _ref3.bandSize, _ref3$sizeList = _ref3.sizeList, sizeList = _ref3$sizeList === void 0 ? [] : _ref3$sizeList, maxBarSize = _ref3.maxBarSize;
	var len = sizeList.length;
	if (len < 1) return null;
	var realBarGap = getPercentValue(barGap, bandSize, 0, true);
	var result;
	var initialValue = [];
	if (sizeList[0].barSize === +sizeList[0].barSize) {
		var useFull = false;
		var fullBarSize = bandSize / len;
		var sum = sizeList.reduce(function(res, entry) {
			return res + entry.barSize || 0;
		}, 0);
		sum += (len - 1) * realBarGap;
		if (sum >= bandSize) {
			sum -= (len - 1) * realBarGap;
			realBarGap = 0;
		}
		if (sum >= bandSize && fullBarSize > 0) {
			useFull = true;
			fullBarSize *= .9;
			sum = len * fullBarSize;
		}
		var prev = {
			offset: ((bandSize - sum) / 2 >> 0) - realBarGap,
			size: 0
		};
		result = sizeList.reduce(function(res, entry) {
			var newPosition = {
				item: entry.item,
				position: {
					offset: prev.offset + prev.size + realBarGap,
					size: useFull ? fullBarSize : entry.barSize
				}
			};
			var newRes = [].concat(_toConsumableArray$7(res), [newPosition]);
			prev = newRes[newRes.length - 1].position;
			if (entry.stackList && entry.stackList.length) entry.stackList.forEach(function(item) {
				newRes.push({
					item,
					position: prev
				});
			});
			return newRes;
		}, initialValue);
	} else {
		var _offset = getPercentValue(barCategoryGap, bandSize, 0, true);
		if (bandSize - 2 * _offset - (len - 1) * realBarGap <= 0) realBarGap = 0;
		var originalSize = (bandSize - 2 * _offset - (len - 1) * realBarGap) / len;
		if (originalSize > 1) originalSize >>= 0;
		var size = maxBarSize === +maxBarSize ? Math.min(originalSize, maxBarSize) : originalSize;
		result = sizeList.reduce(function(res, entry, i) {
			var newRes = [].concat(_toConsumableArray$7(res), [{
				item: entry.item,
				position: {
					offset: _offset + (originalSize + realBarGap) * i + (originalSize - size) / 2,
					size
				}
			}]);
			if (entry.stackList && entry.stackList.length) entry.stackList.forEach(function(item) {
				newRes.push({
					item,
					position: newRes[newRes.length - 1].position
				});
			});
			return newRes;
		}, initialValue);
	}
	return result;
};
var appendOffsetOfLegend = function appendOffsetOfLegend(offset, _unused, props, legendBox) {
	var children = props.children, width = props.width, margin = props.margin;
	var legendProps = getLegendProps({
		children,
		legendWidth: width - (margin.left || 0) - (margin.right || 0)
	});
	if (legendProps) {
		var _ref4 = legendBox || {}, boxWidth = _ref4.width, boxHeight = _ref4.height;
		var align = legendProps.align, verticalAlign = legendProps.verticalAlign, layout = legendProps.layout;
		if ((layout === "vertical" || layout === "horizontal" && verticalAlign === "middle") && align !== "center" && isNumber$1(offset[align])) return _objectSpread$36(_objectSpread$36({}, offset), {}, _defineProperty$40({}, align, offset[align] + (boxWidth || 0)));
		if ((layout === "horizontal" || layout === "vertical" && align === "center") && verticalAlign !== "middle" && isNumber$1(offset[verticalAlign])) return _objectSpread$36(_objectSpread$36({}, offset), {}, _defineProperty$40({}, verticalAlign, offset[verticalAlign] + (boxHeight || 0)));
	}
	return offset;
};
var isErrorBarRelevantForAxis = function isErrorBarRelevantForAxis(layout, axisType, direction) {
	if ((0, import_isNil.default)(axisType)) return true;
	if (layout === "horizontal") return axisType === "yAxis";
	if (layout === "vertical") return axisType === "xAxis";
	if (direction === "x") return axisType === "xAxis";
	if (direction === "y") return axisType === "yAxis";
	return true;
};
var getDomainOfErrorBars = function getDomainOfErrorBars(data, item, dataKey, layout, axisType) {
	var children = item.props.children;
	var errorBars = findAllByType(children, ErrorBar).filter(function(errorBarChild) {
		return isErrorBarRelevantForAxis(layout, axisType, errorBarChild.props.direction);
	});
	if (errorBars && errorBars.length) {
		var keys = errorBars.map(function(errorBarChild) {
			return errorBarChild.props.dataKey;
		});
		return data.reduce(function(result, entry) {
			var entryValue = getValueByDataKey(entry, dataKey);
			if ((0, import_isNil.default)(entryValue)) return result;
			var mainValue = Array.isArray(entryValue) ? [(0, import_min.default)(entryValue), (0, import_max.default)(entryValue)] : [entryValue, entryValue];
			var errorDomain = keys.reduce(function(prevErrorArr, k) {
				var errorValue = getValueByDataKey(entry, k, 0);
				var lowerValue = mainValue[0] - Math.abs(Array.isArray(errorValue) ? errorValue[0] : errorValue);
				var upperValue = mainValue[1] + Math.abs(Array.isArray(errorValue) ? errorValue[1] : errorValue);
				return [Math.min(lowerValue, prevErrorArr[0]), Math.max(upperValue, prevErrorArr[1])];
			}, [Infinity, -Infinity]);
			return [Math.min(errorDomain[0], result[0]), Math.max(errorDomain[1], result[1])];
		}, [Infinity, -Infinity]);
	}
	return null;
};
var parseErrorBarsOfAxis = function parseErrorBarsOfAxis(data, items, dataKey, axisType, layout) {
	var domains = items.map(function(item) {
		return getDomainOfErrorBars(data, item, dataKey, layout, axisType);
	}).filter(function(entry) {
		return !(0, import_isNil.default)(entry);
	});
	if (domains && domains.length) return domains.reduce(function(result, entry) {
		return [Math.min(result[0], entry[0]), Math.max(result[1], entry[1])];
	}, [Infinity, -Infinity]);
	return null;
};
/**
* Get domain of data by the configuration of item element
* @param  {Array}   data      The data displayed in the chart
* @param  {Array}   items     The instances of item
* @param  {String}  type      The type of axis, number - Number Axis, category - Category Axis
* @param  {LayoutType} layout The type of layout
* @param  {Boolean} filterNil Whether or not filter nil values
* @return {Array}        Domain
*/
var getDomainOfItemsWithSameAxis = function getDomainOfItemsWithSameAxis(data, items, type, layout, filterNil) {
	var domains = items.map(function(item) {
		var dataKey = item.props.dataKey;
		if (type === "number" && dataKey) return getDomainOfErrorBars(data, item, dataKey, layout) || getDomainOfDataByKey(data, dataKey, type, filterNil);
		return getDomainOfDataByKey(data, dataKey, type, filterNil);
	});
	if (type === "number") return domains.reduce(function(result, entry) {
		return [Math.min(result[0], entry[0]), Math.max(result[1], entry[1])];
	}, [Infinity, -Infinity]);
	var tag = {};
	return domains.reduce(function(result, entry) {
		for (var i = 0, len = entry.length; i < len; i++) if (!tag[entry[i]]) {
			tag[entry[i]] = true;
			result.push(entry[i]);
		}
		return result;
	}, []);
};
var isCategoricalAxis = function isCategoricalAxis(layout, axisType) {
	return layout === "horizontal" && axisType === "xAxis" || layout === "vertical" && axisType === "yAxis" || layout === "centric" && axisType === "angleAxis" || layout === "radial" && axisType === "radiusAxis";
};
/**
* Calculate the Coordinates of grid
* @param  {Array} ticks           The ticks in axis
* @param {Number} minValue        The minimun value of axis
* @param {Number} maxValue        The maximun value of axis
* @param {boolean} syncWithTicks  Synchronize grid lines with ticks or not
* @return {Array}                 Coordinates
*/
var getCoordinatesOfGrid = function getCoordinatesOfGrid(ticks, minValue, maxValue, syncWithTicks) {
	if (syncWithTicks) return ticks.map(function(entry) {
		return entry.coordinate;
	});
	var hasMin, hasMax;
	var values = ticks.map(function(entry) {
		if (entry.coordinate === minValue) hasMin = true;
		if (entry.coordinate === maxValue) hasMax = true;
		return entry.coordinate;
	});
	if (!hasMin) values.push(minValue);
	if (!hasMax) values.push(maxValue);
	return values;
};
/**
* Get the ticks of an axis
* @param  {Object}  axis The configuration of an axis
* @param {Boolean} isGrid Whether or not are the ticks in grid
* @param {Boolean} isAll Return the ticks of all the points or not
* @return {Array}  Ticks
*/
var getTicksOfAxis = function getTicksOfAxis(axis, isGrid, isAll) {
	if (!axis) return null;
	var scale = axis.scale;
	var duplicateDomain = axis.duplicateDomain, type = axis.type, range = axis.range;
	var offsetForBand = axis.realScaleType === "scaleBand" ? scale.bandwidth() / 2 : 2;
	var offset = (isGrid || isAll) && type === "category" && scale.bandwidth ? scale.bandwidth() / offsetForBand : 0;
	offset = axis.axisType === "angleAxis" && (range === null || range === void 0 ? void 0 : range.length) >= 2 ? mathSign(range[0] - range[1]) * 2 * offset : offset;
	if (isGrid && (axis.ticks || axis.niceTicks)) return (axis.ticks || axis.niceTicks).map(function(entry) {
		return {
			coordinate: scale(duplicateDomain ? duplicateDomain.indexOf(entry) : entry) + offset,
			value: entry,
			offset
		};
	}).filter(function(row) {
		return !(0, import_isNaN.default)(row.coordinate);
	});
	if (axis.isCategorical && axis.categoricalDomain) return axis.categoricalDomain.map(function(entry, index) {
		return {
			coordinate: scale(entry) + offset,
			value: entry,
			index,
			offset
		};
	});
	if (scale.ticks && !isAll) return scale.ticks(axis.tickCount).map(function(entry) {
		return {
			coordinate: scale(entry) + offset,
			value: entry,
			offset
		};
	});
	return scale.domain().map(function(entry, index) {
		return {
			coordinate: scale(entry) + offset,
			value: duplicateDomain ? duplicateDomain[entry] : entry,
			index,
			offset
		};
	});
};
/**
* combine the handlers
* @param  {Function} defaultHandler Internal private handler
* @param  {Function} childHandler Handler function specified in child component
* @return {Function}                The combined handler
*/
var handlerWeakMap = /* @__PURE__ */ new WeakMap();
var combineEventHandlers = function combineEventHandlers(defaultHandler, childHandler) {
	if (typeof childHandler !== "function") return defaultHandler;
	if (!handlerWeakMap.has(defaultHandler)) handlerWeakMap.set(defaultHandler, /* @__PURE__ */ new WeakMap());
	var childWeakMap = handlerWeakMap.get(defaultHandler);
	if (childWeakMap.has(childHandler)) return childWeakMap.get(childHandler);
	var combineHandler = function combineHandler() {
		defaultHandler.apply(void 0, arguments);
		childHandler.apply(void 0, arguments);
	};
	childWeakMap.set(childHandler, combineHandler);
	return combineHandler;
};
/**
* Parse the scale function of axis
* @param  {Object}   axis          The option of axis
* @param  {String}   chartType     The displayName of chart
* @param  {Boolean}  hasBar        if it has a bar
* @return {object}               The scale function and resolved name
*/
var parseScale = function parseScale(axis, chartType, hasBar) {
	var scale = axis.scale, type = axis.type, layout = axis.layout, axisType = axis.axisType;
	if (scale === "auto") {
		if (layout === "radial" && axisType === "radiusAxis") return {
			scale: band(),
			realScaleType: "band"
		};
		if (layout === "radial" && axisType === "angleAxis") return {
			scale: linear(),
			realScaleType: "linear"
		};
		if (type === "category" && chartType && (chartType.indexOf("LineChart") >= 0 || chartType.indexOf("AreaChart") >= 0 || chartType.indexOf("ComposedChart") >= 0 && !hasBar)) return {
			scale: point(),
			realScaleType: "point"
		};
		if (type === "category") return {
			scale: band(),
			realScaleType: "band"
		};
		return {
			scale: linear(),
			realScaleType: "linear"
		};
	}
	if ((0, import_isString.default)(scale)) {
		var name = "scale".concat((0, import_upperFirst.default)(scale));
		return {
			scale: (d3_scale_exports[name] || point)(),
			realScaleType: d3_scale_exports[name] ? name : "point"
		};
	}
	return (0, import_isFunction.default)(scale) ? { scale } : {
		scale: point(),
		realScaleType: "point"
	};
};
var EPS = 1e-4;
var checkDomainOfScale = function checkDomainOfScale(scale) {
	var domain = scale.domain();
	if (!domain || domain.length <= 2) return;
	var len = domain.length;
	var range = scale.range();
	var minValue = Math.min(range[0], range[1]) - EPS;
	var maxValue = Math.max(range[0], range[1]) + EPS;
	var first = scale(domain[0]);
	var last = scale(domain[len - 1]);
	if (first < minValue || first > maxValue || last < minValue || last > maxValue) scale.domain([domain[0], domain[len - 1]]);
};
var findPositionOfBar = function findPositionOfBar(barPosition, child) {
	if (!barPosition) return null;
	for (var i = 0, len = barPosition.length; i < len; i++) if (barPosition[i].item === child) return barPosition[i].position;
	return null;
};
/**
* Both value and domain are tuples of two numbers
* - but the type stays as array of numbers until we have better support in rest of the app
* @param {Array} value input that will be truncated
* @param {Array} domain boundaries
* @returns {Array} tuple of two numbers
*/
var truncateByDomain = function truncateByDomain(value, domain) {
	if (!domain || domain.length !== 2 || !isNumber$1(domain[0]) || !isNumber$1(domain[1])) return value;
	var minValue = Math.min(domain[0], domain[1]);
	var maxValue = Math.max(domain[0], domain[1]);
	var result = [value[0], value[1]];
	if (!isNumber$1(value[0]) || value[0] < minValue) result[0] = minValue;
	if (!isNumber$1(value[1]) || value[1] > maxValue) result[1] = maxValue;
	if (result[0] > maxValue) result[0] = maxValue;
	if (result[1] < minValue) result[1] = minValue;
	return result;
};
/**
* Function type to compute offset for stacked data.
*
* d3-shape has something fishy going on with its types.
* In @definitelytyped/d3-shape, this function (the offset accessor) is typed as Series<> => void.
* However! When I actually open the storybook I can see that the offset accessor actually receives Array<Series<>>.
* The same I can see in the source code itself:
* https://github.com/DefinitelyTyped/DefinitelyTyped/discussions/66042
* That one unfortunately has no types but we can tell it passes three-dimensional array.
*
* Which leads me to believe that definitelytyped is wrong on this one.
* There's open discussion on this topic without much attention:
* https://github.com/DefinitelyTyped/DefinitelyTyped/discussions/66042
*/
var STACK_OFFSET_MAP = {
	sign: function offsetSign(series) {
		var n = series.length;
		if (n <= 0) return;
		for (var j = 0, m = series[0].length; j < m; ++j) {
			var positive = 0;
			var negative = 0;
			for (var i = 0; i < n; ++i) {
				var value = (0, import_isNaN.default)(series[i][j][1]) ? series[i][j][0] : series[i][j][1];
				if (value >= 0) {
					series[i][j][0] = positive;
					series[i][j][1] = positive + value;
					positive = series[i][j][1];
				} else {
					series[i][j][0] = negative;
					series[i][j][1] = negative + value;
					negative = series[i][j][1];
				}
			}
		}
	},
	expand: expand_default,
	none: none_default,
	silhouette: silhouette_default,
	wiggle: wiggle_default,
	positive: function offsetPositive(series) {
		var n = series.length;
		if (n <= 0) return;
		for (var j = 0, m = series[0].length; j < m; ++j) {
			var positive = 0;
			for (var i = 0; i < n; ++i) {
				var value = (0, import_isNaN.default)(series[i][j][1]) ? series[i][j][0] : series[i][j][1];
				if (value >= 0) {
					series[i][j][0] = positive;
					series[i][j][1] = positive + value;
					positive = series[i][j][1];
				} else {
					series[i][j][0] = 0;
					series[i][j][1] = 0;
				}
			}
		}
	}
};
var getStackedData = function getStackedData(data, stackItems, offsetType) {
	var dataKeys = stackItems.map(function(item) {
		return item.props.dataKey;
	});
	var offsetAccessor = STACK_OFFSET_MAP[offsetType];
	return stack_default().keys(dataKeys).value(function(d, key) {
		return +getValueByDataKey(d, key, 0);
	}).order(none_default$1).offset(offsetAccessor)(data);
};
var getStackGroupsByAxisId = function getStackGroupsByAxisId(data, _items, numericAxisId, cateAxisId, offsetType, reverseStackOrder) {
	if (!data) return null;
	var stackGroups = (reverseStackOrder ? _items.reverse() : _items).reduce(function(result, item) {
		var _item$type2;
		var defaultedProps = (_item$type2 = item.type) !== null && _item$type2 !== void 0 && _item$type2.defaultProps ? _objectSpread$36(_objectSpread$36({}, item.type.defaultProps), item.props) : item.props;
		var stackId = defaultedProps.stackId;
		if (defaultedProps.hide) return result;
		var axisId = defaultedProps[numericAxisId];
		var parentGroup = result[axisId] || {
			hasStack: false,
			stackGroups: {}
		};
		if (isNumOrStr(stackId)) {
			var childGroup = parentGroup.stackGroups[stackId] || {
				numericAxisId,
				cateAxisId,
				items: []
			};
			childGroup.items.push(item);
			parentGroup.hasStack = true;
			parentGroup.stackGroups[stackId] = childGroup;
		} else parentGroup.stackGroups[uniqueId("_stackId_")] = {
			numericAxisId,
			cateAxisId,
			items: [item]
		};
		return _objectSpread$36(_objectSpread$36({}, result), {}, _defineProperty$40({}, axisId, parentGroup));
	}, {});
	return Object.keys(stackGroups).reduce(function(result, axisId) {
		var group = stackGroups[axisId];
		if (group.hasStack) group.stackGroups = Object.keys(group.stackGroups).reduce(function(res, stackId) {
			var g = group.stackGroups[stackId];
			return _objectSpread$36(_objectSpread$36({}, res), {}, _defineProperty$40({}, stackId, {
				numericAxisId,
				cateAxisId,
				items: g.items,
				stackedData: getStackedData(data, g.items, offsetType)
			}));
		}, {});
		return _objectSpread$36(_objectSpread$36({}, result), {}, _defineProperty$40({}, axisId, group));
	}, {});
};
/**
* Configure the scale function of axis
* @param {Object} scale The scale function
* @param {Object} opts  The configuration of axis
* @return {Object}      null
*/
var getTicksOfScale = function getTicksOfScale(scale, opts) {
	var realScaleType = opts.realScaleType, type = opts.type, tickCount = opts.tickCount, originalDomain = opts.originalDomain, allowDecimals = opts.allowDecimals;
	var scaleType = realScaleType || opts.scale;
	if (scaleType !== "auto" && scaleType !== "linear") return null;
	if (tickCount && type === "number" && originalDomain && (originalDomain[0] === "auto" || originalDomain[1] === "auto")) {
		var domain = scale.domain();
		if (!domain.length) return null;
		var tickValues = getNiceTickValues(domain, tickCount, allowDecimals);
		scale.domain([(0, import_min.default)(tickValues), (0, import_max.default)(tickValues)]);
		return { niceTicks: tickValues };
	}
	if (tickCount && type === "number") return { niceTicks: getTickValuesFixedDomain(scale.domain(), tickCount, allowDecimals) };
	return null;
};
function getCateCoordinateOfLine(_ref5) {
	var axis = _ref5.axis, ticks = _ref5.ticks, bandSize = _ref5.bandSize, entry = _ref5.entry, index = _ref5.index, dataKey = _ref5.dataKey;
	if (axis.type === "category") {
		if (!axis.allowDuplicatedCategory && axis.dataKey && !(0, import_isNil.default)(entry[axis.dataKey])) {
			var matchedTick = findEntryInArray(ticks, "value", entry[axis.dataKey]);
			if (matchedTick) return matchedTick.coordinate + bandSize / 2;
		}
		return ticks[index] ? ticks[index].coordinate + bandSize / 2 : null;
	}
	var value = getValueByDataKey(entry, !(0, import_isNil.default)(dataKey) ? dataKey : axis.dataKey);
	return !(0, import_isNil.default)(value) ? axis.scale(value) : null;
}
var getCateCoordinateOfBar = function getCateCoordinateOfBar(_ref6) {
	var axis = _ref6.axis, ticks = _ref6.ticks, offset = _ref6.offset, bandSize = _ref6.bandSize, entry = _ref6.entry, index = _ref6.index;
	if (axis.type === "category") return ticks[index] ? ticks[index].coordinate + offset : null;
	var value = getValueByDataKey(entry, axis.dataKey, axis.domain[index]);
	return !(0, import_isNil.default)(value) ? axis.scale(value) - bandSize / 2 + offset : null;
};
var getBaseValueOfBar = function getBaseValueOfBar(_ref7) {
	var numericAxis = _ref7.numericAxis;
	var domain = numericAxis.scale.domain();
	if (numericAxis.type === "number") {
		var minValue = Math.min(domain[0], domain[1]);
		var maxValue = Math.max(domain[0], domain[1]);
		if (minValue <= 0 && maxValue >= 0) return 0;
		if (maxValue < 0) return maxValue;
		return minValue;
	}
	return domain[0];
};
var getStackedDataOfItem = function getStackedDataOfItem(item, stackGroups) {
	var _item$type3;
	var stackId = ((_item$type3 = item.type) !== null && _item$type3 !== void 0 && _item$type3.defaultProps ? _objectSpread$36(_objectSpread$36({}, item.type.defaultProps), item.props) : item.props).stackId;
	if (isNumOrStr(stackId)) {
		var group = stackGroups[stackId];
		if (group) {
			var itemIndex = group.items.indexOf(item);
			return itemIndex >= 0 ? group.stackedData[itemIndex] : null;
		}
	}
	return null;
};
var getDomainOfSingle = function getDomainOfSingle(data) {
	return data.reduce(function(result, entry) {
		return [(0, import_min.default)(entry.concat([result[0]]).filter(isNumber$1)), (0, import_max.default)(entry.concat([result[1]]).filter(isNumber$1))];
	}, [Infinity, -Infinity]);
};
var getDomainOfStackGroups = function getDomainOfStackGroups(stackGroups, startIndex, endIndex) {
	return Object.keys(stackGroups).reduce(function(result, stackId) {
		var domain = stackGroups[stackId].stackedData.reduce(function(res, entry) {
			var s = getDomainOfSingle(entry.slice(startIndex, endIndex + 1));
			return [Math.min(res[0], s[0]), Math.max(res[1], s[1])];
		}, [Infinity, -Infinity]);
		return [Math.min(domain[0], result[0]), Math.max(domain[1], result[1])];
	}, [Infinity, -Infinity]).map(function(result) {
		return result === Infinity || result === -Infinity ? 0 : result;
	});
};
var MIN_VALUE_REG = /^dataMin[\s]*-[\s]*([0-9]+([.]{1}[0-9]+){0,1})$/;
var MAX_VALUE_REG = /^dataMax[\s]*\+[\s]*([0-9]+([.]{1}[0-9]+){0,1})$/;
var parseSpecifiedDomain = function parseSpecifiedDomain(specifiedDomain, dataDomain, allowDataOverflow) {
	if ((0, import_isFunction.default)(specifiedDomain)) return specifiedDomain(dataDomain, allowDataOverflow);
	if (!Array.isArray(specifiedDomain)) return dataDomain;
	var domain = [];
	if (isNumber$1(specifiedDomain[0])) domain[0] = allowDataOverflow ? specifiedDomain[0] : Math.min(specifiedDomain[0], dataDomain[0]);
	else if (MIN_VALUE_REG.test(specifiedDomain[0])) {
		var value = +MIN_VALUE_REG.exec(specifiedDomain[0])[1];
		domain[0] = dataDomain[0] - value;
	} else if ((0, import_isFunction.default)(specifiedDomain[0])) domain[0] = specifiedDomain[0](dataDomain[0]);
	else domain[0] = dataDomain[0];
	if (isNumber$1(specifiedDomain[1])) domain[1] = allowDataOverflow ? specifiedDomain[1] : Math.max(specifiedDomain[1], dataDomain[1]);
	else if (MAX_VALUE_REG.test(specifiedDomain[1])) {
		var _value = +MAX_VALUE_REG.exec(specifiedDomain[1])[1];
		domain[1] = dataDomain[1] + _value;
	} else if ((0, import_isFunction.default)(specifiedDomain[1])) domain[1] = specifiedDomain[1](dataDomain[1]);
	else domain[1] = dataDomain[1];
	return domain;
};
/**
* Calculate the size between two category
* @param  {Object} axis  The options of axis
* @param  {Array}  ticks The ticks of axis
* @param  {Boolean} isBar if items in axis are bars
* @return {Number} Size
*/
var getBandSizeOfAxis = function getBandSizeOfAxis(axis, ticks, isBar) {
	if (axis && axis.scale && axis.scale.bandwidth) {
		var bandWidth = axis.scale.bandwidth();
		if (!isBar || bandWidth > 0) return bandWidth;
	}
	if (axis && ticks && ticks.length >= 2) {
		var orderedTicks = (0, import_sortBy.default)(ticks, function(o) {
			return o.coordinate;
		});
		var bandSize = Infinity;
		for (var i = 1, len = orderedTicks.length; i < len; i++) {
			var cur = orderedTicks[i];
			var prev = orderedTicks[i - 1];
			bandSize = Math.min((cur.coordinate || 0) - (prev.coordinate || 0), bandSize);
		}
		return bandSize === Infinity ? 0 : bandSize;
	}
	return isBar ? void 0 : 0;
};
/**
* parse the domain of a category axis when a domain is specified
* @param   {Array}        specifiedDomain  The domain specified by users
* @param   {Array}        calculatedDomain The domain calculated by dateKey
* @param   {ReactElement} axisChild        The axis ReactElement
* @returns {Array}        domains
*/
var parseDomainOfCategoryAxis = function parseDomainOfCategoryAxis(specifiedDomain, calculatedDomain, axisChild) {
	if (!specifiedDomain || !specifiedDomain.length) return calculatedDomain;
	if ((0, import_isEqual.default)(specifiedDomain, (0, import_get.default)(axisChild, "type.defaultProps.domain"))) return calculatedDomain;
	return specifiedDomain;
};
var getTooltipItem = function getTooltipItem(graphicalItem, payload) {
	var defaultedProps = graphicalItem.type.defaultProps ? _objectSpread$36(_objectSpread$36({}, graphicalItem.type.defaultProps), graphicalItem.props) : graphicalItem.props;
	var dataKey = defaultedProps.dataKey, name = defaultedProps.name, unit = defaultedProps.unit, formatter = defaultedProps.formatter, tooltipType = defaultedProps.tooltipType, chartType = defaultedProps.chartType, hide = defaultedProps.hide;
	return _objectSpread$36(_objectSpread$36({}, filterProps(graphicalItem, false)), {}, {
		dataKey,
		unit,
		formatter,
		name: name || dataKey,
		color: getMainColorOfGraphicItem(graphicalItem),
		value: getValueByDataKey(payload, dataKey),
		type: tooltipType,
		payload,
		chartType,
		hide
	});
};
//#endregion
//#region node_modules/recharts/es6/util/PolarUtils.js
function _typeof$40(o) {
	"@babel/helpers - typeof";
	return _typeof$40 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$40(o);
}
function ownKeys$35(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$35(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$35(Object(t), !0).forEach(function(r) {
			_defineProperty$39(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$35(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$39(obj, key, value) {
	key = _toPropertyKey$39(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$39(t) {
	var i = _toPrimitive$39(t, "string");
	return "symbol" == _typeof$40(i) ? i : i + "";
}
function _toPrimitive$39(t, r) {
	if ("object" != _typeof$40(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$40(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _slicedToArray$6(arr, i) {
	return _arrayWithHoles$6(arr) || _iterableToArrayLimit$6(arr, i) || _unsupportedIterableToArray$11(arr, i) || _nonIterableRest$6();
}
function _nonIterableRest$6() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$11(o, minLen) {
	if (!o) return;
	if (typeof o === "string") return _arrayLikeToArray$11(o, minLen);
	var n = Object.prototype.toString.call(o).slice(8, -1);
	if (n === "Object" && o.constructor) n = o.constructor.name;
	if (n === "Map" || n === "Set") return Array.from(o);
	if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$11(o, minLen);
}
function _arrayLikeToArray$11(arr, len) {
	if (len == null || len > arr.length) len = arr.length;
	for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
	return arr2;
}
function _iterableToArrayLimit$6(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = !0, o = !1;
		try {
			if (i = (t = t.call(r)).next, 0 === l) {
				if (Object(t) !== t) return;
				f = !1;
			} else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = !0, n = r;
		} finally {
			try {
				if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
function _arrayWithHoles$6(arr) {
	if (Array.isArray(arr)) return arr;
}
var RADIAN$1 = Math.PI / 180;
var radianToDegree = function radianToDegree(angleInRadian) {
	return angleInRadian * 180 / Math.PI;
};
var polarToCartesian = function polarToCartesian(cx, cy, radius, angle) {
	return {
		x: cx + Math.cos(-RADIAN$1 * angle) * radius,
		y: cy + Math.sin(-RADIAN$1 * angle) * radius
	};
};
var getMaxRadius = function getMaxRadius(width, height) {
	var offset = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {
		top: 0,
		right: 0,
		bottom: 0,
		left: 0
	};
	return Math.min(Math.abs(width - (offset.left || 0) - (offset.right || 0)), Math.abs(height - (offset.top || 0) - (offset.bottom || 0))) / 2;
};
/**
* Calculate the scale function, position, width, height of axes
* @param  {Object} props     Latest props
* @param  {Object} axisMap   The configuration of axes
* @param  {Object} offset    The offset of main part in the svg element
* @param  {Object} axisType  The type of axes, radius-axis or angle-axis
* @param  {String} chartName The name of chart
* @return {Object} Configuration
*/
var formatAxisMap$1 = function formatAxisMap(props, axisMap, offset, axisType, chartName) {
	var width = props.width, height = props.height;
	var startAngle = props.startAngle, endAngle = props.endAngle;
	var cx = getPercentValue(props.cx, width, width / 2);
	var cy = getPercentValue(props.cy, height, height / 2);
	var maxRadius = getMaxRadius(width, height, offset);
	var innerRadius = getPercentValue(props.innerRadius, maxRadius, 0);
	var outerRadius = getPercentValue(props.outerRadius, maxRadius, maxRadius * .8);
	return Object.keys(axisMap).reduce(function(result, id) {
		var axis = axisMap[id];
		var domain = axis.domain, reversed = axis.reversed;
		var range;
		if ((0, import_isNil.default)(axis.range)) {
			if (axisType === "angleAxis") range = [startAngle, endAngle];
			else if (axisType === "radiusAxis") range = [innerRadius, outerRadius];
			if (reversed) range = [range[1], range[0]];
		} else {
			range = axis.range;
			var _range2 = _slicedToArray$6(range, 2);
			startAngle = _range2[0];
			endAngle = _range2[1];
		}
		var _parseScale = parseScale(axis, chartName), realScaleType = _parseScale.realScaleType, scale = _parseScale.scale;
		scale.domain(domain).range(range);
		checkDomainOfScale(scale);
		var ticks = getTicksOfScale(scale, _objectSpread$35(_objectSpread$35({}, axis), {}, { realScaleType }));
		var finalAxis = _objectSpread$35(_objectSpread$35(_objectSpread$35({}, axis), ticks), {}, {
			range,
			radius: outerRadius,
			realScaleType,
			scale,
			cx,
			cy,
			innerRadius,
			outerRadius,
			startAngle,
			endAngle
		});
		return _objectSpread$35(_objectSpread$35({}, result), {}, _defineProperty$39({}, id, finalAxis));
	}, {});
};
var distanceBetweenPoints = function distanceBetweenPoints(point, anotherPoint) {
	var x1 = point.x, y1 = point.y;
	var x2 = anotherPoint.x, y2 = anotherPoint.y;
	return Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
};
var getAngleOfPoint = function getAngleOfPoint(_ref, _ref2) {
	var x = _ref.x, y = _ref.y;
	var cx = _ref2.cx, cy = _ref2.cy;
	var radius = distanceBetweenPoints({
		x,
		y
	}, {
		x: cx,
		y: cy
	});
	if (radius <= 0) return { radius };
	var cos = (x - cx) / radius;
	var angleInRadian = Math.acos(cos);
	if (y > cy) angleInRadian = 2 * Math.PI - angleInRadian;
	return {
		radius,
		angle: radianToDegree(angleInRadian),
		angleInRadian
	};
};
var formatAngleOfSector = function formatAngleOfSector(_ref3) {
	var startAngle = _ref3.startAngle, endAngle = _ref3.endAngle;
	var startCnt = Math.floor(startAngle / 360);
	var endCnt = Math.floor(endAngle / 360);
	var min = Math.min(startCnt, endCnt);
	return {
		startAngle: startAngle - min * 360,
		endAngle: endAngle - min * 360
	};
};
var reverseFormatAngleOfSetor = function reverseFormatAngleOfSetor(angle, _ref4) {
	var startAngle = _ref4.startAngle, endAngle = _ref4.endAngle;
	var startCnt = Math.floor(startAngle / 360);
	var endCnt = Math.floor(endAngle / 360);
	return angle + Math.min(startCnt, endCnt) * 360;
};
var inRangeOfSector = function inRangeOfSector(_ref5, sector) {
	var x = _ref5.x, y = _ref5.y;
	var _getAngleOfPoint = getAngleOfPoint({
		x,
		y
	}, sector), radius = _getAngleOfPoint.radius, angle = _getAngleOfPoint.angle;
	var innerRadius = sector.innerRadius, outerRadius = sector.outerRadius;
	if (radius < innerRadius || radius > outerRadius) return false;
	if (radius === 0) return true;
	var _formatAngleOfSector = formatAngleOfSector(sector), startAngle = _formatAngleOfSector.startAngle, endAngle = _formatAngleOfSector.endAngle;
	var formatAngle = angle;
	var inRange;
	if (startAngle <= endAngle) {
		while (formatAngle > endAngle) formatAngle -= 360;
		while (formatAngle < startAngle) formatAngle += 360;
		inRange = formatAngle >= startAngle && formatAngle <= endAngle;
	} else {
		while (formatAngle > startAngle) formatAngle -= 360;
		while (formatAngle < endAngle) formatAngle += 360;
		inRange = formatAngle >= endAngle && formatAngle <= startAngle;
	}
	if (inRange) return _objectSpread$35(_objectSpread$35({}, sector), {}, {
		radius,
		angle: reverseFormatAngleOfSetor(formatAngle, sector)
	});
	return null;
};
var getTickClassName = function getTickClassName(tick) {
	return !/*#__PURE__*/ (0, import_react.isValidElement)(tick) && !(0, import_isFunction.default)(tick) && typeof tick !== "boolean" ? tick.className : "";
};
//#endregion
//#region node_modules/recharts/es6/component/Label.js
function _typeof$39(o) {
	"@babel/helpers - typeof";
	return _typeof$39 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$39(o);
}
var _excluded$19 = ["offset"];
function _toConsumableArray$6(arr) {
	return _arrayWithoutHoles$6(arr) || _iterableToArray$6(arr) || _unsupportedIterableToArray$10(arr) || _nonIterableSpread$6();
}
function _nonIterableSpread$6() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$10(o, minLen) {
	if (!o) return;
	if (typeof o === "string") return _arrayLikeToArray$10(o, minLen);
	var n = Object.prototype.toString.call(o).slice(8, -1);
	if (n === "Object" && o.constructor) n = o.constructor.name;
	if (n === "Map" || n === "Set") return Array.from(o);
	if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$10(o, minLen);
}
function _iterableToArray$6(iter) {
	if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _arrayWithoutHoles$6(arr) {
	if (Array.isArray(arr)) return _arrayLikeToArray$10(arr);
}
function _arrayLikeToArray$10(arr, len) {
	if (len == null || len > arr.length) len = arr.length;
	for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
	return arr2;
}
function _objectWithoutProperties$19(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$19(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$19(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
function ownKeys$34(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$34(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$34(Object(t), !0).forEach(function(r) {
			_defineProperty$38(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$34(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$38(obj, key, value) {
	key = _toPropertyKey$38(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$38(t) {
	var i = _toPrimitive$38(t, "string");
	return "symbol" == _typeof$39(i) ? i : i + "";
}
function _toPrimitive$38(t, r) {
	if ("object" != _typeof$39(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$39(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _extends$35() {
	_extends$35 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$35.apply(this, arguments);
}
var getLabel = function getLabel(props) {
	var value = props.value, formatter = props.formatter;
	var label = (0, import_isNil.default)(props.children) ? value : props.children;
	if ((0, import_isFunction.default)(formatter)) return formatter(label);
	return label;
};
var getDeltaAngle$1 = function getDeltaAngle(startAngle, endAngle) {
	return mathSign(endAngle - startAngle) * Math.min(Math.abs(endAngle - startAngle), 360);
};
var renderRadialLabel = function renderRadialLabel(labelProps, label, attrs) {
	var position = labelProps.position, viewBox = labelProps.viewBox, offset = labelProps.offset, className = labelProps.className;
	var _ref = viewBox, cx = _ref.cx, cy = _ref.cy, innerRadius = _ref.innerRadius, outerRadius = _ref.outerRadius, startAngle = _ref.startAngle, endAngle = _ref.endAngle, clockWise = _ref.clockWise;
	var radius = (innerRadius + outerRadius) / 2;
	var deltaAngle = getDeltaAngle$1(startAngle, endAngle);
	var sign = deltaAngle >= 0 ? 1 : -1;
	var labelAngle, direction;
	if (position === "insideStart") {
		labelAngle = startAngle + sign * offset;
		direction = clockWise;
	} else if (position === "insideEnd") {
		labelAngle = endAngle - sign * offset;
		direction = !clockWise;
	} else if (position === "end") {
		labelAngle = endAngle + sign * offset;
		direction = clockWise;
	}
	direction = deltaAngle <= 0 ? direction : !direction;
	var startPoint = polarToCartesian(cx, cy, radius, labelAngle);
	var endPoint = polarToCartesian(cx, cy, radius, labelAngle + (direction ? 1 : -1) * 359);
	var path = "M".concat(startPoint.x, ",").concat(startPoint.y, "\n    A").concat(radius, ",").concat(radius, ",0,1,").concat(direction ? 0 : 1, ",\n    ").concat(endPoint.x, ",").concat(endPoint.y);
	var id = (0, import_isNil.default)(labelProps.id) ? uniqueId("recharts-radial-line-") : labelProps.id;
	return /*#__PURE__*/ import_react.createElement("text", _extends$35({}, attrs, {
		dominantBaseline: "central",
		className: clsx("recharts-radial-bar-label", className)
	}), /*#__PURE__*/ import_react.createElement("defs", null, /*#__PURE__*/ import_react.createElement("path", {
		id,
		d: path
	})), /*#__PURE__*/ import_react.createElement("textPath", { xlinkHref: "#".concat(id) }, label));
};
var getAttrsOfPolarLabel = function getAttrsOfPolarLabel(props) {
	var viewBox = props.viewBox, offset = props.offset, position = props.position;
	var _ref2 = viewBox, cx = _ref2.cx, cy = _ref2.cy, innerRadius = _ref2.innerRadius, outerRadius = _ref2.outerRadius;
	var midAngle = (_ref2.startAngle + _ref2.endAngle) / 2;
	if (position === "outside") {
		var _polarToCartesian = polarToCartesian(cx, cy, outerRadius + offset, midAngle), _x = _polarToCartesian.x;
		return {
			x: _x,
			y: _polarToCartesian.y,
			textAnchor: _x >= cx ? "start" : "end",
			verticalAnchor: "middle"
		};
	}
	if (position === "center") return {
		x: cx,
		y: cy,
		textAnchor: "middle",
		verticalAnchor: "middle"
	};
	if (position === "centerTop") return {
		x: cx,
		y: cy,
		textAnchor: "middle",
		verticalAnchor: "start"
	};
	if (position === "centerBottom") return {
		x: cx,
		y: cy,
		textAnchor: "middle",
		verticalAnchor: "end"
	};
	var _polarToCartesian2 = polarToCartesian(cx, cy, (innerRadius + outerRadius) / 2, midAngle);
	return {
		x: _polarToCartesian2.x,
		y: _polarToCartesian2.y,
		textAnchor: "middle",
		verticalAnchor: "middle"
	};
};
var getAttrsOfCartesianLabel = function getAttrsOfCartesianLabel(props) {
	var viewBox = props.viewBox, parentViewBox = props.parentViewBox, offset = props.offset, position = props.position;
	var _ref3 = viewBox, x = _ref3.x, y = _ref3.y, width = _ref3.width, height = _ref3.height;
	var verticalSign = height >= 0 ? 1 : -1;
	var verticalOffset = verticalSign * offset;
	var verticalEnd = verticalSign > 0 ? "end" : "start";
	var verticalStart = verticalSign > 0 ? "start" : "end";
	var horizontalSign = width >= 0 ? 1 : -1;
	var horizontalOffset = horizontalSign * offset;
	var horizontalEnd = horizontalSign > 0 ? "end" : "start";
	var horizontalStart = horizontalSign > 0 ? "start" : "end";
	if (position === "top") return _objectSpread$34(_objectSpread$34({}, {
		x: x + width / 2,
		y: y - verticalSign * offset,
		textAnchor: "middle",
		verticalAnchor: verticalEnd
	}), parentViewBox ? {
		height: Math.max(y - parentViewBox.y, 0),
		width
	} : {});
	if (position === "bottom") return _objectSpread$34(_objectSpread$34({}, {
		x: x + width / 2,
		y: y + height + verticalOffset,
		textAnchor: "middle",
		verticalAnchor: verticalStart
	}), parentViewBox ? {
		height: Math.max(parentViewBox.y + parentViewBox.height - (y + height), 0),
		width
	} : {});
	if (position === "left") {
		var _attrs2 = {
			x: x - horizontalOffset,
			y: y + height / 2,
			textAnchor: horizontalEnd,
			verticalAnchor: "middle"
		};
		return _objectSpread$34(_objectSpread$34({}, _attrs2), parentViewBox ? {
			width: Math.max(_attrs2.x - parentViewBox.x, 0),
			height
		} : {});
	}
	if (position === "right") {
		var _attrs3 = {
			x: x + width + horizontalOffset,
			y: y + height / 2,
			textAnchor: horizontalStart,
			verticalAnchor: "middle"
		};
		return _objectSpread$34(_objectSpread$34({}, _attrs3), parentViewBox ? {
			width: Math.max(parentViewBox.x + parentViewBox.width - _attrs3.x, 0),
			height
		} : {});
	}
	var sizeAttrs = parentViewBox ? {
		width,
		height
	} : {};
	if (position === "insideLeft") return _objectSpread$34({
		x: x + horizontalOffset,
		y: y + height / 2,
		textAnchor: horizontalStart,
		verticalAnchor: "middle"
	}, sizeAttrs);
	if (position === "insideRight") return _objectSpread$34({
		x: x + width - horizontalOffset,
		y: y + height / 2,
		textAnchor: horizontalEnd,
		verticalAnchor: "middle"
	}, sizeAttrs);
	if (position === "insideTop") return _objectSpread$34({
		x: x + width / 2,
		y: y + verticalOffset,
		textAnchor: "middle",
		verticalAnchor: verticalStart
	}, sizeAttrs);
	if (position === "insideBottom") return _objectSpread$34({
		x: x + width / 2,
		y: y + height - verticalOffset,
		textAnchor: "middle",
		verticalAnchor: verticalEnd
	}, sizeAttrs);
	if (position === "insideTopLeft") return _objectSpread$34({
		x: x + horizontalOffset,
		y: y + verticalOffset,
		textAnchor: horizontalStart,
		verticalAnchor: verticalStart
	}, sizeAttrs);
	if (position === "insideTopRight") return _objectSpread$34({
		x: x + width - horizontalOffset,
		y: y + verticalOffset,
		textAnchor: horizontalEnd,
		verticalAnchor: verticalStart
	}, sizeAttrs);
	if (position === "insideBottomLeft") return _objectSpread$34({
		x: x + horizontalOffset,
		y: y + height - verticalOffset,
		textAnchor: horizontalStart,
		verticalAnchor: verticalEnd
	}, sizeAttrs);
	if (position === "insideBottomRight") return _objectSpread$34({
		x: x + width - horizontalOffset,
		y: y + height - verticalOffset,
		textAnchor: horizontalEnd,
		verticalAnchor: verticalEnd
	}, sizeAttrs);
	if ((0, import_isObject.default)(position) && (isNumber$1(position.x) || isPercent(position.x)) && (isNumber$1(position.y) || isPercent(position.y))) return _objectSpread$34({
		x: x + getPercentValue(position.x, width),
		y: y + getPercentValue(position.y, height),
		textAnchor: "end",
		verticalAnchor: "end"
	}, sizeAttrs);
	return _objectSpread$34({
		x: x + width / 2,
		y: y + height / 2,
		textAnchor: "middle",
		verticalAnchor: "middle"
	}, sizeAttrs);
};
var isPolar = function isPolar(viewBox) {
	return "cx" in viewBox && isNumber$1(viewBox.cx);
};
function Label(_ref4) {
	var _ref4$offset = _ref4.offset, offset = _ref4$offset === void 0 ? 5 : _ref4$offset, restProps = _objectWithoutProperties$19(_ref4, _excluded$19);
	var props = _objectSpread$34({ offset }, restProps);
	var viewBox = props.viewBox, position = props.position, value = props.value, children = props.children, content = props.content, _props$className = props.className, className = _props$className === void 0 ? "" : _props$className, textBreakAll = props.textBreakAll;
	if (!viewBox || (0, import_isNil.default)(value) && (0, import_isNil.default)(children) && !/*#__PURE__*/ (0, import_react.isValidElement)(content) && !(0, import_isFunction.default)(content)) return null;
	if (/*#__PURE__*/ (0, import_react.isValidElement)(content)) return /*#__PURE__*/ (0, import_react.cloneElement)(content, props);
	var label;
	if ((0, import_isFunction.default)(content)) {
		label = /*#__PURE__*/ (0, import_react.createElement)(content, props);
		if (/*#__PURE__*/ (0, import_react.isValidElement)(label)) return label;
	} else label = getLabel(props);
	var isPolarLabel = isPolar(viewBox);
	var attrs = filterProps(props, true);
	if (isPolarLabel && (position === "insideStart" || position === "insideEnd" || position === "end")) return renderRadialLabel(props, label, attrs);
	var positionAttrs = isPolarLabel ? getAttrsOfPolarLabel(props) : getAttrsOfCartesianLabel(props);
	return /*#__PURE__*/ import_react.createElement(Text, _extends$35({ className: clsx("recharts-label", className) }, attrs, positionAttrs, { breakAll: textBreakAll }), label);
}
Label.displayName = "Label";
var parseViewBox = function parseViewBox(props) {
	var cx = props.cx, cy = props.cy, angle = props.angle, startAngle = props.startAngle, endAngle = props.endAngle, r = props.r, radius = props.radius, innerRadius = props.innerRadius, outerRadius = props.outerRadius, x = props.x, y = props.y, top = props.top, left = props.left, width = props.width, height = props.height, clockWise = props.clockWise, labelViewBox = props.labelViewBox;
	if (labelViewBox) return labelViewBox;
	if (isNumber$1(width) && isNumber$1(height)) {
		if (isNumber$1(x) && isNumber$1(y)) return {
			x,
			y,
			width,
			height
		};
		if (isNumber$1(top) && isNumber$1(left)) return {
			x: top,
			y: left,
			width,
			height
		};
	}
	if (isNumber$1(x) && isNumber$1(y)) return {
		x,
		y,
		width: 0,
		height: 0
	};
	if (isNumber$1(cx) && isNumber$1(cy)) return {
		cx,
		cy,
		startAngle: startAngle || angle || 0,
		endAngle: endAngle || angle || 0,
		innerRadius: innerRadius || 0,
		outerRadius: outerRadius || radius || r || 0,
		clockWise
	};
	if (props.viewBox) return props.viewBox;
	return {};
};
var parseLabel = function parseLabel(label, viewBox) {
	if (!label) return null;
	if (label === true) return /*#__PURE__*/ import_react.createElement(Label, {
		key: "label-implicit",
		viewBox
	});
	if (isNumOrStr(label)) return /*#__PURE__*/ import_react.createElement(Label, {
		key: "label-implicit",
		viewBox,
		value: label
	});
	if (/*#__PURE__*/ (0, import_react.isValidElement)(label)) {
		if (label.type === Label) return /*#__PURE__*/ (0, import_react.cloneElement)(label, {
			key: "label-implicit",
			viewBox
		});
		return /*#__PURE__*/ import_react.createElement(Label, {
			key: "label-implicit",
			content: label,
			viewBox
		});
	}
	if ((0, import_isFunction.default)(label)) return /*#__PURE__*/ import_react.createElement(Label, {
		key: "label-implicit",
		content: label,
		viewBox
	});
	if ((0, import_isObject.default)(label)) return /*#__PURE__*/ import_react.createElement(Label, _extends$35({ viewBox }, label, { key: "label-implicit" }));
	return null;
};
var renderCallByParent$1 = function renderCallByParent(parentProps, viewBox) {
	var checkPropsLabel = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : true;
	if (!parentProps || !parentProps.children && checkPropsLabel && !parentProps.label) return null;
	var children = parentProps.children;
	var parentViewBox = parseViewBox(parentProps);
	var explicitChildren = findAllByType(children, Label).map(function(child, index) {
		return /*#__PURE__*/ (0, import_react.cloneElement)(child, {
			viewBox: viewBox || parentViewBox,
			key: "label-".concat(index)
		});
	});
	if (!checkPropsLabel) return explicitChildren;
	return [parseLabel(parentProps.label, viewBox || parentViewBox)].concat(_toConsumableArray$6(explicitChildren));
};
Label.parseViewBox = parseViewBox;
Label.renderCallByParent = renderCallByParent$1;
//#endregion
//#region node_modules/recharts/es6/component/LabelList.js
var import_last = /* @__PURE__ */ __toESM(require_last());
function _typeof$38(o) {
	"@babel/helpers - typeof";
	return _typeof$38 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$38(o);
}
var _excluded$18 = ["valueAccessor"];
var _excluded2$8 = [
	"data",
	"dataKey",
	"clockWise",
	"id",
	"textBreakAll"
];
function _toConsumableArray$5(arr) {
	return _arrayWithoutHoles$5(arr) || _iterableToArray$5(arr) || _unsupportedIterableToArray$9(arr) || _nonIterableSpread$5();
}
function _nonIterableSpread$5() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$9(o, minLen) {
	if (!o) return;
	if (typeof o === "string") return _arrayLikeToArray$9(o, minLen);
	var n = Object.prototype.toString.call(o).slice(8, -1);
	if (n === "Object" && o.constructor) n = o.constructor.name;
	if (n === "Map" || n === "Set") return Array.from(o);
	if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$9(o, minLen);
}
function _iterableToArray$5(iter) {
	if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _arrayWithoutHoles$5(arr) {
	if (Array.isArray(arr)) return _arrayLikeToArray$9(arr);
}
function _arrayLikeToArray$9(arr, len) {
	if (len == null || len > arr.length) len = arr.length;
	for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
	return arr2;
}
function _extends$34() {
	_extends$34 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$34.apply(this, arguments);
}
function ownKeys$33(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$33(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$33(Object(t), !0).forEach(function(r) {
			_defineProperty$37(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$33(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$37(obj, key, value) {
	key = _toPropertyKey$37(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$37(t) {
	var i = _toPrimitive$37(t, "string");
	return "symbol" == _typeof$38(i) ? i : i + "";
}
function _toPrimitive$37(t, r) {
	if ("object" != _typeof$38(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$38(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _objectWithoutProperties$18(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$18(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$18(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
var defaultAccessor = function defaultAccessor(entry) {
	return Array.isArray(entry.value) ? (0, import_last.default)(entry.value) : entry.value;
};
function LabelList(_ref) {
	var _ref$valueAccessor = _ref.valueAccessor, valueAccessor = _ref$valueAccessor === void 0 ? defaultAccessor : _ref$valueAccessor, restProps = _objectWithoutProperties$18(_ref, _excluded$18);
	var data = restProps.data, dataKey = restProps.dataKey, clockWise = restProps.clockWise, id = restProps.id, textBreakAll = restProps.textBreakAll, others = _objectWithoutProperties$18(restProps, _excluded2$8);
	if (!data || !data.length) return null;
	return /*#__PURE__*/ import_react.createElement(Layer, { className: "recharts-label-list" }, data.map(function(entry, index) {
		var value = (0, import_isNil.default)(dataKey) ? valueAccessor(entry, index) : getValueByDataKey(entry && entry.payload, dataKey);
		var idProps = (0, import_isNil.default)(id) ? {} : { id: "".concat(id, "-").concat(index) };
		return /*#__PURE__*/ import_react.createElement(Label, _extends$34({}, filterProps(entry, true), others, idProps, {
			parentViewBox: entry.parentViewBox,
			value,
			textBreakAll,
			viewBox: Label.parseViewBox((0, import_isNil.default)(clockWise) ? entry : _objectSpread$33(_objectSpread$33({}, entry), {}, { clockWise })),
			key: "label-".concat(index),
			index
		}));
	}));
}
LabelList.displayName = "LabelList";
function parseLabelList(label, data) {
	if (!label) return null;
	if (label === true) return /*#__PURE__*/ import_react.createElement(LabelList, {
		key: "labelList-implicit",
		data
	});
	if (/*#__PURE__*/ import_react.isValidElement(label) || (0, import_isFunction.default)(label)) return /*#__PURE__*/ import_react.createElement(LabelList, {
		key: "labelList-implicit",
		data,
		content: label
	});
	if ((0, import_isObject.default)(label)) return /*#__PURE__*/ import_react.createElement(LabelList, _extends$34({ data }, label, { key: "labelList-implicit" }));
	return null;
}
function renderCallByParent(parentProps, data) {
	var checkPropsLabel = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : true;
	if (!parentProps || !parentProps.children && checkPropsLabel && !parentProps.label) return null;
	var children = parentProps.children;
	var explicitChildren = findAllByType(children, LabelList).map(function(child, index) {
		return /*#__PURE__*/ (0, import_react.cloneElement)(child, {
			data,
			key: "labelList-".concat(index)
		});
	});
	if (!checkPropsLabel) return explicitChildren;
	return [parseLabelList(parentProps.label, data)].concat(_toConsumableArray$5(explicitChildren));
}
LabelList.renderCallByParent = renderCallByParent;
//#endregion
//#region node_modules/recharts/es6/component/Customized.js
/**
* @fileOverview Customized
*/
var _excluded$17 = ["component"];
function _typeof$37(o) {
	"@babel/helpers - typeof";
	return _typeof$37 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$37(o);
}
function _objectWithoutProperties$17(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$17(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$17(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
/**
* custom svg elements by rechart instance props and state.
* @returns {Object}   svg elements
*/
function Customized(_ref) {
	var component = _ref.component, props = _objectWithoutProperties$17(_ref, _excluded$17);
	var child;
	if (/*#__PURE__*/ (0, import_react.isValidElement)(component)) child = /*#__PURE__*/ (0, import_react.cloneElement)(component, props);
	else if ((0, import_isFunction.default)(component)) child = /*#__PURE__*/ (0, import_react.createElement)(component, props);
	else warn(false, "Customized's props `component` must be React.element or Function, but got %s.", _typeof$37(component));
	return /*#__PURE__*/ import_react.createElement(Layer, { className: "recharts-customized-wrapper" }, child);
}
Customized.displayName = "Customized";
//#endregion
//#region node_modules/recharts/es6/shape/Sector.js
/**
* @fileOverview Sector
*/
function _typeof$36(o) {
	"@babel/helpers - typeof";
	return _typeof$36 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$36(o);
}
function _extends$33() {
	_extends$33 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$33.apply(this, arguments);
}
function ownKeys$32(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$32(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$32(Object(t), !0).forEach(function(r) {
			_defineProperty$36(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$32(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$36(obj, key, value) {
	key = _toPropertyKey$36(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$36(t) {
	var i = _toPrimitive$36(t, "string");
	return "symbol" == _typeof$36(i) ? i : i + "";
}
function _toPrimitive$36(t, r) {
	if ("object" != _typeof$36(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$36(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var getDeltaAngle = function getDeltaAngle(startAngle, endAngle) {
	return mathSign(endAngle - startAngle) * Math.min(Math.abs(endAngle - startAngle), 359.999);
};
var getTangentCircle = function getTangentCircle(_ref) {
	var cx = _ref.cx, cy = _ref.cy, radius = _ref.radius, angle = _ref.angle, sign = _ref.sign, isExternal = _ref.isExternal, cornerRadius = _ref.cornerRadius, cornerIsExternal = _ref.cornerIsExternal;
	var centerRadius = cornerRadius * (isExternal ? 1 : -1) + radius;
	var theta = Math.asin(cornerRadius / centerRadius) / RADIAN$1;
	var centerAngle = cornerIsExternal ? angle : angle + sign * theta;
	var center = polarToCartesian(cx, cy, centerRadius, centerAngle);
	var circleTangency = polarToCartesian(cx, cy, radius, centerAngle);
	var lineTangencyAngle = cornerIsExternal ? angle - sign * theta : angle;
	return {
		center,
		circleTangency,
		lineTangency: polarToCartesian(cx, cy, centerRadius * Math.cos(theta * RADIAN$1), lineTangencyAngle),
		theta
	};
};
var getSectorPath = function getSectorPath(_ref2) {
	var cx = _ref2.cx, cy = _ref2.cy, innerRadius = _ref2.innerRadius, outerRadius = _ref2.outerRadius, startAngle = _ref2.startAngle, endAngle = _ref2.endAngle;
	var angle = getDeltaAngle(startAngle, endAngle);
	var tempEndAngle = startAngle + angle;
	var outerStartPoint = polarToCartesian(cx, cy, outerRadius, startAngle);
	var outerEndPoint = polarToCartesian(cx, cy, outerRadius, tempEndAngle);
	var path = "M ".concat(outerStartPoint.x, ",").concat(outerStartPoint.y, "\n    A ").concat(outerRadius, ",").concat(outerRadius, ",0,\n    ").concat(+(Math.abs(angle) > 180), ",").concat(+(startAngle > tempEndAngle), ",\n    ").concat(outerEndPoint.x, ",").concat(outerEndPoint.y, "\n  ");
	if (innerRadius > 0) {
		var innerStartPoint = polarToCartesian(cx, cy, innerRadius, startAngle);
		var innerEndPoint = polarToCartesian(cx, cy, innerRadius, tempEndAngle);
		path += "L ".concat(innerEndPoint.x, ",").concat(innerEndPoint.y, "\n            A ").concat(innerRadius, ",").concat(innerRadius, ",0,\n            ").concat(+(Math.abs(angle) > 180), ",").concat(+(startAngle <= tempEndAngle), ",\n            ").concat(innerStartPoint.x, ",").concat(innerStartPoint.y, " Z");
	} else path += "L ".concat(cx, ",").concat(cy, " Z");
	return path;
};
var getSectorWithCorner = function getSectorWithCorner(_ref3) {
	var cx = _ref3.cx, cy = _ref3.cy, innerRadius = _ref3.innerRadius, outerRadius = _ref3.outerRadius, cornerRadius = _ref3.cornerRadius, forceCornerRadius = _ref3.forceCornerRadius, cornerIsExternal = _ref3.cornerIsExternal, startAngle = _ref3.startAngle, endAngle = _ref3.endAngle;
	var sign = mathSign(endAngle - startAngle);
	var _getTangentCircle = getTangentCircle({
		cx,
		cy,
		radius: outerRadius,
		angle: startAngle,
		sign,
		cornerRadius,
		cornerIsExternal
	}), soct = _getTangentCircle.circleTangency, solt = _getTangentCircle.lineTangency, sot = _getTangentCircle.theta;
	var _getTangentCircle2 = getTangentCircle({
		cx,
		cy,
		radius: outerRadius,
		angle: endAngle,
		sign: -sign,
		cornerRadius,
		cornerIsExternal
	}), eoct = _getTangentCircle2.circleTangency, eolt = _getTangentCircle2.lineTangency, eot = _getTangentCircle2.theta;
	var outerArcAngle = cornerIsExternal ? Math.abs(startAngle - endAngle) : Math.abs(startAngle - endAngle) - sot - eot;
	if (outerArcAngle < 0) {
		if (forceCornerRadius) return "M ".concat(solt.x, ",").concat(solt.y, "\n        a").concat(cornerRadius, ",").concat(cornerRadius, ",0,0,1,").concat(cornerRadius * 2, ",0\n        a").concat(cornerRadius, ",").concat(cornerRadius, ",0,0,1,").concat(-cornerRadius * 2, ",0\n      ");
		return getSectorPath({
			cx,
			cy,
			innerRadius,
			outerRadius,
			startAngle,
			endAngle
		});
	}
	var path = "M ".concat(solt.x, ",").concat(solt.y, "\n    A").concat(cornerRadius, ",").concat(cornerRadius, ",0,0,").concat(+(sign < 0), ",").concat(soct.x, ",").concat(soct.y, "\n    A").concat(outerRadius, ",").concat(outerRadius, ",0,").concat(+(outerArcAngle > 180), ",").concat(+(sign < 0), ",").concat(eoct.x, ",").concat(eoct.y, "\n    A").concat(cornerRadius, ",").concat(cornerRadius, ",0,0,").concat(+(sign < 0), ",").concat(eolt.x, ",").concat(eolt.y, "\n  ");
	if (innerRadius > 0) {
		var _getTangentCircle3 = getTangentCircle({
			cx,
			cy,
			radius: innerRadius,
			angle: startAngle,
			sign,
			isExternal: true,
			cornerRadius,
			cornerIsExternal
		}), sict = _getTangentCircle3.circleTangency, silt = _getTangentCircle3.lineTangency, sit = _getTangentCircle3.theta;
		var _getTangentCircle4 = getTangentCircle({
			cx,
			cy,
			radius: innerRadius,
			angle: endAngle,
			sign: -sign,
			isExternal: true,
			cornerRadius,
			cornerIsExternal
		}), eict = _getTangentCircle4.circleTangency, eilt = _getTangentCircle4.lineTangency, eit = _getTangentCircle4.theta;
		var innerArcAngle = cornerIsExternal ? Math.abs(startAngle - endAngle) : Math.abs(startAngle - endAngle) - sit - eit;
		if (innerArcAngle < 0 && cornerRadius === 0) return "".concat(path, "L").concat(cx, ",").concat(cy, "Z");
		path += "L".concat(eilt.x, ",").concat(eilt.y, "\n      A").concat(cornerRadius, ",").concat(cornerRadius, ",0,0,").concat(+(sign < 0), ",").concat(eict.x, ",").concat(eict.y, "\n      A").concat(innerRadius, ",").concat(innerRadius, ",0,").concat(+(innerArcAngle > 180), ",").concat(+(sign > 0), ",").concat(sict.x, ",").concat(sict.y, "\n      A").concat(cornerRadius, ",").concat(cornerRadius, ",0,0,").concat(+(sign < 0), ",").concat(silt.x, ",").concat(silt.y, "Z");
	} else path += "L".concat(cx, ",").concat(cy, "Z");
	return path;
};
var defaultProps$3 = {
	cx: 0,
	cy: 0,
	innerRadius: 0,
	outerRadius: 0,
	startAngle: 0,
	endAngle: 0,
	cornerRadius: 0,
	forceCornerRadius: false,
	cornerIsExternal: false
};
var Sector = function Sector(sectorProps) {
	var props = _objectSpread$32(_objectSpread$32({}, defaultProps$3), sectorProps);
	var cx = props.cx, cy = props.cy, innerRadius = props.innerRadius, outerRadius = props.outerRadius, cornerRadius = props.cornerRadius, forceCornerRadius = props.forceCornerRadius, cornerIsExternal = props.cornerIsExternal, startAngle = props.startAngle, endAngle = props.endAngle, className = props.className;
	if (outerRadius < innerRadius || startAngle === endAngle) return null;
	var layerClass = clsx("recharts-sector", className);
	var deltaRadius = outerRadius - innerRadius;
	var cr = getPercentValue(cornerRadius, deltaRadius, 0, true);
	var path;
	if (cr > 0 && Math.abs(startAngle - endAngle) < 360) path = getSectorWithCorner({
		cx,
		cy,
		innerRadius,
		outerRadius,
		cornerRadius: Math.min(cr, deltaRadius / 2),
		forceCornerRadius,
		cornerIsExternal,
		startAngle,
		endAngle
	});
	else path = getSectorPath({
		cx,
		cy,
		innerRadius,
		outerRadius,
		startAngle,
		endAngle
	});
	return /*#__PURE__*/ import_react.createElement("path", _extends$33({}, filterProps(props, true), {
		className: layerClass,
		d: path,
		role: "img"
	}));
};
//#endregion
//#region node_modules/recharts/es6/shape/Curve.js
/**
* @fileOverview Curve
*/
function _typeof$35(o) {
	"@babel/helpers - typeof";
	return _typeof$35 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$35(o);
}
function _extends$32() {
	_extends$32 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$32.apply(this, arguments);
}
function ownKeys$31(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$31(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$31(Object(t), !0).forEach(function(r) {
			_defineProperty$35(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$31(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$35(obj, key, value) {
	key = _toPropertyKey$35(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$35(t) {
	var i = _toPrimitive$35(t, "string");
	return "symbol" == _typeof$35(i) ? i : i + "";
}
function _toPrimitive$35(t, r) {
	if ("object" != _typeof$35(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$35(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var CURVE_FACTORIES = {
	curveBasisClosed: basisClosed_default,
	curveBasisOpen: basisOpen_default,
	curveBasis: basis_default,
	curveBumpX: bumpX,
	curveBumpY: bumpY,
	curveLinearClosed: linearClosed_default,
	curveLinear: linear_default,
	curveMonotoneX: monotoneX,
	curveMonotoneY: monotoneY,
	curveNatural: natural_default,
	curveStep: step_default,
	curveStepAfter: stepAfter,
	curveStepBefore: stepBefore
};
var defined = function defined(p) {
	return p.x === +p.x && p.y === +p.y;
};
var getX = function getX(p) {
	return p.x;
};
var getY = function getY(p) {
	return p.y;
};
var getCurveFactory = function getCurveFactory(type, layout) {
	if ((0, import_isFunction.default)(type)) return type;
	var name = "curve".concat((0, import_upperFirst.default)(type));
	if ((name === "curveMonotone" || name === "curveBump") && layout) return CURVE_FACTORIES["".concat(name).concat(layout === "vertical" ? "Y" : "X")];
	return CURVE_FACTORIES[name] || linear_default;
};
/**
* Calculate the path of curve. Returns null if points is an empty array.
* @return path or null
*/
var getPath$1 = function getPath(_ref) {
	var _ref$type = _ref.type, type = _ref$type === void 0 ? "linear" : _ref$type, _ref$points = _ref.points, points = _ref$points === void 0 ? [] : _ref$points, baseLine = _ref.baseLine, layout = _ref.layout, _ref$connectNulls = _ref.connectNulls, connectNulls = _ref$connectNulls === void 0 ? false : _ref$connectNulls;
	var curveFactory = getCurveFactory(type, layout);
	var formatPoints = connectNulls ? points.filter(function(entry) {
		return defined(entry);
	}) : points;
	var lineFunction;
	if (Array.isArray(baseLine)) {
		var formatBaseLine = connectNulls ? baseLine.filter(function(base) {
			return defined(base);
		}) : baseLine;
		var areaPoints = formatPoints.map(function(entry, index) {
			return _objectSpread$31(_objectSpread$31({}, entry), {}, { base: formatBaseLine[index] });
		});
		if (layout === "vertical") lineFunction = area_default().y(getY).x1(getX).x0(function(d) {
			return d.base.x;
		});
		else lineFunction = area_default().x(getX).y1(getY).y0(function(d) {
			return d.base.y;
		});
		lineFunction.defined(defined).curve(curveFactory);
		return lineFunction(areaPoints);
	}
	if (layout === "vertical" && isNumber$1(baseLine)) lineFunction = area_default().y(getY).x1(getX).x0(baseLine);
	else if (isNumber$1(baseLine)) lineFunction = area_default().x(getX).y1(getY).y0(baseLine);
	else lineFunction = line_default().x(getX).y(getY);
	lineFunction.defined(defined).curve(curveFactory);
	return lineFunction(formatPoints);
};
var Curve = function Curve(props) {
	var className = props.className, points = props.points, path = props.path, pathRef = props.pathRef;
	if ((!points || !points.length) && !path) return null;
	var realPath = points && points.length ? getPath$1(props) : path;
	return /*#__PURE__*/ import_react.createElement("path", _extends$32({}, filterProps(props, false), adaptEventHandlers(props), {
		className: clsx("recharts-curve", className),
		d: realPath,
		ref: pathRef
	}));
};
//#endregion
//#region node_modules/recharts/es6/shape/Rectangle.js
/**
* @fileOverview Rectangle
*/
function _typeof$34(o) {
	"@babel/helpers - typeof";
	return _typeof$34 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$34(o);
}
function _extends$31() {
	_extends$31 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$31.apply(this, arguments);
}
function _slicedToArray$5(arr, i) {
	return _arrayWithHoles$5(arr) || _iterableToArrayLimit$5(arr, i) || _unsupportedIterableToArray$8(arr, i) || _nonIterableRest$5();
}
function _nonIterableRest$5() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$8(o, minLen) {
	if (!o) return;
	if (typeof o === "string") return _arrayLikeToArray$8(o, minLen);
	var n = Object.prototype.toString.call(o).slice(8, -1);
	if (n === "Object" && o.constructor) n = o.constructor.name;
	if (n === "Map" || n === "Set") return Array.from(o);
	if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$8(o, minLen);
}
function _arrayLikeToArray$8(arr, len) {
	if (len == null || len > arr.length) len = arr.length;
	for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
	return arr2;
}
function _iterableToArrayLimit$5(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = !0, o = !1;
		try {
			if (i = (t = t.call(r)).next, 0 === l) {
				if (Object(t) !== t) return;
				f = !1;
			} else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = !0, n = r;
		} finally {
			try {
				if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
function _arrayWithHoles$5(arr) {
	if (Array.isArray(arr)) return arr;
}
function ownKeys$30(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$30(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$30(Object(t), !0).forEach(function(r) {
			_defineProperty$34(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$30(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$34(obj, key, value) {
	key = _toPropertyKey$34(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$34(t) {
	var i = _toPrimitive$34(t, "string");
	return "symbol" == _typeof$34(i) ? i : i + "";
}
function _toPrimitive$34(t, r) {
	if ("object" != _typeof$34(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$34(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var getRectanglePath = function getRectanglePath(x, y, width, height, radius) {
	var maxRadius = Math.min(Math.abs(width) / 2, Math.abs(height) / 2);
	var ySign = height >= 0 ? 1 : -1;
	var xSign = width >= 0 ? 1 : -1;
	var clockWise = height >= 0 && width >= 0 || height < 0 && width < 0 ? 1 : 0;
	var path;
	if (maxRadius > 0 && radius instanceof Array) {
		var newRadius = [
			0,
			0,
			0,
			0
		];
		for (var i = 0, len = 4; i < len; i++) newRadius[i] = radius[i] > maxRadius ? maxRadius : radius[i];
		path = "M".concat(x, ",").concat(y + ySign * newRadius[0]);
		if (newRadius[0] > 0) path += "A ".concat(newRadius[0], ",").concat(newRadius[0], ",0,0,").concat(clockWise, ",").concat(x + xSign * newRadius[0], ",").concat(y);
		path += "L ".concat(x + width - xSign * newRadius[1], ",").concat(y);
		if (newRadius[1] > 0) path += "A ".concat(newRadius[1], ",").concat(newRadius[1], ",0,0,").concat(clockWise, ",\n        ").concat(x + width, ",").concat(y + ySign * newRadius[1]);
		path += "L ".concat(x + width, ",").concat(y + height - ySign * newRadius[2]);
		if (newRadius[2] > 0) path += "A ".concat(newRadius[2], ",").concat(newRadius[2], ",0,0,").concat(clockWise, ",\n        ").concat(x + width - xSign * newRadius[2], ",").concat(y + height);
		path += "L ".concat(x + xSign * newRadius[3], ",").concat(y + height);
		if (newRadius[3] > 0) path += "A ".concat(newRadius[3], ",").concat(newRadius[3], ",0,0,").concat(clockWise, ",\n        ").concat(x, ",").concat(y + height - ySign * newRadius[3]);
		path += "Z";
	} else if (maxRadius > 0 && radius === +radius && radius > 0) {
		var _newRadius = Math.min(maxRadius, radius);
		path = "M ".concat(x, ",").concat(y + ySign * _newRadius, "\n            A ").concat(_newRadius, ",").concat(_newRadius, ",0,0,").concat(clockWise, ",").concat(x + xSign * _newRadius, ",").concat(y, "\n            L ").concat(x + width - xSign * _newRadius, ",").concat(y, "\n            A ").concat(_newRadius, ",").concat(_newRadius, ",0,0,").concat(clockWise, ",").concat(x + width, ",").concat(y + ySign * _newRadius, "\n            L ").concat(x + width, ",").concat(y + height - ySign * _newRadius, "\n            A ").concat(_newRadius, ",").concat(_newRadius, ",0,0,").concat(clockWise, ",").concat(x + width - xSign * _newRadius, ",").concat(y + height, "\n            L ").concat(x + xSign * _newRadius, ",").concat(y + height, "\n            A ").concat(_newRadius, ",").concat(_newRadius, ",0,0,").concat(clockWise, ",").concat(x, ",").concat(y + height - ySign * _newRadius, " Z");
	} else path = "M ".concat(x, ",").concat(y, " h ").concat(width, " v ").concat(height, " h ").concat(-width, " Z");
	return path;
};
var isInRectangle = function isInRectangle(point, rect) {
	if (!point || !rect) return false;
	var px = point.x, py = point.y;
	var x = rect.x, y = rect.y, width = rect.width, height = rect.height;
	if (Math.abs(width) > 0 && Math.abs(height) > 0) {
		var minX = Math.min(x, x + width);
		var maxX = Math.max(x, x + width);
		var minY = Math.min(y, y + height);
		var maxY = Math.max(y, y + height);
		return px >= minX && px <= maxX && py >= minY && py <= maxY;
	}
	return false;
};
var defaultProps$2 = {
	x: 0,
	y: 0,
	width: 0,
	height: 0,
	radius: 0,
	isAnimationActive: false,
	isUpdateAnimationActive: false,
	animationBegin: 0,
	animationDuration: 1500,
	animationEasing: "ease"
};
var Rectangle = function Rectangle(rectangleProps) {
	var props = _objectSpread$30(_objectSpread$30({}, defaultProps$2), rectangleProps);
	var pathRef = (0, import_react.useRef)();
	var _useState2 = _slicedToArray$5((0, import_react.useState)(-1), 2), totalLength = _useState2[0], setTotalLength = _useState2[1];
	(0, import_react.useEffect)(function() {
		if (pathRef.current && pathRef.current.getTotalLength) try {
			var pathTotalLength = pathRef.current.getTotalLength();
			if (pathTotalLength) setTotalLength(pathTotalLength);
		} catch (err) {}
	}, []);
	var x = props.x, y = props.y, width = props.width, height = props.height, radius = props.radius, className = props.className;
	var animationEasing = props.animationEasing, animationDuration = props.animationDuration, animationBegin = props.animationBegin, isAnimationActive = props.isAnimationActive, isUpdateAnimationActive = props.isUpdateAnimationActive;
	if (x !== +x || y !== +y || width !== +width || height !== +height || width === 0 || height === 0) return null;
	var layerClass = clsx("recharts-rectangle", className);
	if (!isUpdateAnimationActive) return /*#__PURE__*/ import_react.createElement("path", _extends$31({}, filterProps(props, true), {
		className: layerClass,
		d: getRectanglePath(x, y, width, height, radius)
	}));
	return /*#__PURE__*/ import_react.createElement(es6_default, {
		canBegin: totalLength > 0,
		from: {
			width,
			height,
			x,
			y
		},
		to: {
			width,
			height,
			x,
			y
		},
		duration: animationDuration,
		animationEasing,
		isActive: isUpdateAnimationActive
	}, function(_ref) {
		var currWidth = _ref.width, currHeight = _ref.height, currX = _ref.x, currY = _ref.y;
		return /*#__PURE__*/ import_react.createElement(es6_default, {
			canBegin: totalLength > 0,
			from: "0px ".concat(totalLength === -1 ? 1 : totalLength, "px"),
			to: "".concat(totalLength, "px 0px"),
			attributeName: "strokeDasharray",
			begin: animationBegin,
			duration: animationDuration,
			isActive: isAnimationActive,
			easing: animationEasing
		}, /*#__PURE__*/ import_react.createElement("path", _extends$31({}, filterProps(props, true), {
			className: layerClass,
			d: getRectanglePath(currX, currY, currWidth, currHeight, radius),
			ref: pathRef
		})));
	});
};
//#endregion
//#region node_modules/recharts/es6/shape/Polygon.js
/**
* @fileOverview Polygon
*/
var _excluded$16 = [
	"points",
	"className",
	"baseLinePoints",
	"connectNulls"
];
function _extends$30() {
	_extends$30 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$30.apply(this, arguments);
}
function _objectWithoutProperties$16(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$16(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$16(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
function _toConsumableArray$4(arr) {
	return _arrayWithoutHoles$4(arr) || _iterableToArray$4(arr) || _unsupportedIterableToArray$7(arr) || _nonIterableSpread$4();
}
function _nonIterableSpread$4() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$7(o, minLen) {
	if (!o) return;
	if (typeof o === "string") return _arrayLikeToArray$7(o, minLen);
	var n = Object.prototype.toString.call(o).slice(8, -1);
	if (n === "Object" && o.constructor) n = o.constructor.name;
	if (n === "Map" || n === "Set") return Array.from(o);
	if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$7(o, minLen);
}
function _iterableToArray$4(iter) {
	if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _arrayWithoutHoles$4(arr) {
	if (Array.isArray(arr)) return _arrayLikeToArray$7(arr);
}
function _arrayLikeToArray$7(arr, len) {
	if (len == null || len > arr.length) len = arr.length;
	for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
	return arr2;
}
var isValidatePoint = function isValidatePoint(point) {
	return point && point.x === +point.x && point.y === +point.y;
};
var getParsedPoints = function getParsedPoints() {
	var points = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [];
	var segmentPoints = [[]];
	points.forEach(function(entry) {
		if (isValidatePoint(entry)) segmentPoints[segmentPoints.length - 1].push(entry);
		else if (segmentPoints[segmentPoints.length - 1].length > 0) segmentPoints.push([]);
	});
	if (isValidatePoint(points[0])) segmentPoints[segmentPoints.length - 1].push(points[0]);
	if (segmentPoints[segmentPoints.length - 1].length <= 0) segmentPoints = segmentPoints.slice(0, -1);
	return segmentPoints;
};
var getSinglePolygonPath = function getSinglePolygonPath(points, connectNulls) {
	var segmentPoints = getParsedPoints(points);
	if (connectNulls) segmentPoints = [segmentPoints.reduce(function(res, segPoints) {
		return [].concat(_toConsumableArray$4(res), _toConsumableArray$4(segPoints));
	}, [])];
	var polygonPath = segmentPoints.map(function(segPoints) {
		return segPoints.reduce(function(path, point, index) {
			return "".concat(path).concat(index === 0 ? "M" : "L").concat(point.x, ",").concat(point.y);
		}, "");
	}).join("");
	return segmentPoints.length === 1 ? "".concat(polygonPath, "Z") : polygonPath;
};
var getRanglePath = function getRanglePath(points, baseLinePoints, connectNulls) {
	var outerPath = getSinglePolygonPath(points, connectNulls);
	return "".concat(outerPath.slice(-1) === "Z" ? outerPath.slice(0, -1) : outerPath, "L").concat(getSinglePolygonPath(baseLinePoints.reverse(), connectNulls).slice(1));
};
var Polygon = function Polygon(props) {
	var points = props.points, className = props.className, baseLinePoints = props.baseLinePoints, connectNulls = props.connectNulls, others = _objectWithoutProperties$16(props, _excluded$16);
	if (!points || !points.length) return null;
	var layerClass = clsx("recharts-polygon", className);
	if (baseLinePoints && baseLinePoints.length) {
		var hasStroke = others.stroke && others.stroke !== "none";
		var rangePath = getRanglePath(points, baseLinePoints, connectNulls);
		return /*#__PURE__*/ import_react.createElement("g", { className: layerClass }, /*#__PURE__*/ import_react.createElement("path", _extends$30({}, filterProps(others, true), {
			fill: rangePath.slice(-1) === "Z" ? others.fill : "none",
			stroke: "none",
			d: rangePath
		})), hasStroke ? /*#__PURE__*/ import_react.createElement("path", _extends$30({}, filterProps(others, true), {
			fill: "none",
			d: getSinglePolygonPath(points, connectNulls)
		})) : null, hasStroke ? /*#__PURE__*/ import_react.createElement("path", _extends$30({}, filterProps(others, true), {
			fill: "none",
			d: getSinglePolygonPath(baseLinePoints, connectNulls)
		})) : null);
	}
	var singlePath = getSinglePolygonPath(points, connectNulls);
	return /*#__PURE__*/ import_react.createElement("path", _extends$30({}, filterProps(others, true), {
		fill: singlePath.slice(-1) === "Z" ? others.fill : "none",
		className: layerClass,
		d: singlePath
	}));
};
//#endregion
//#region node_modules/recharts/es6/shape/Dot.js
/**
* @fileOverview Dot
*/
function _extends$29() {
	_extends$29 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$29.apply(this, arguments);
}
var Dot = function Dot(props) {
	var cx = props.cx, cy = props.cy, r = props.r, className = props.className;
	var layerClass = clsx("recharts-dot", className);
	if (cx === +cx && cy === +cy && r === +r) return /*#__PURE__*/ import_react.createElement("circle", _extends$29({}, filterProps(props, false), adaptEventHandlers(props), {
		className: layerClass,
		cx,
		cy,
		r
	}));
	return null;
};
//#endregion
//#region node_modules/recharts/es6/shape/Cross.js
/**
* @fileOverview Cross
*/
function _typeof$33(o) {
	"@babel/helpers - typeof";
	return _typeof$33 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$33(o);
}
var _excluded$15 = [
	"x",
	"y",
	"top",
	"left",
	"width",
	"height",
	"className"
];
function _extends$28() {
	_extends$28 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$28.apply(this, arguments);
}
function ownKeys$29(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$29(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$29(Object(t), !0).forEach(function(r) {
			_defineProperty$33(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$29(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$33(obj, key, value) {
	key = _toPropertyKey$33(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$33(t) {
	var i = _toPrimitive$33(t, "string");
	return "symbol" == _typeof$33(i) ? i : i + "";
}
function _toPrimitive$33(t, r) {
	if ("object" != _typeof$33(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$33(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _objectWithoutProperties$15(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$15(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$15(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
var getPath = function getPath(x, y, width, height, top, left) {
	return "M".concat(x, ",").concat(top, "v").concat(height, "M").concat(left, ",").concat(y, "h").concat(width);
};
var Cross = function Cross(_ref) {
	var _ref$x = _ref.x, x = _ref$x === void 0 ? 0 : _ref$x, _ref$y = _ref.y, y = _ref$y === void 0 ? 0 : _ref$y, _ref$top = _ref.top, top = _ref$top === void 0 ? 0 : _ref$top, _ref$left = _ref.left, left = _ref$left === void 0 ? 0 : _ref$left, _ref$width = _ref.width, width = _ref$width === void 0 ? 0 : _ref$width, _ref$height = _ref.height, height = _ref$height === void 0 ? 0 : _ref$height, className = _ref.className, rest = _objectWithoutProperties$15(_ref, _excluded$15);
	var props = _objectSpread$29({
		x,
		y,
		top,
		left,
		width,
		height
	}, rest);
	if (!isNumber$1(x) || !isNumber$1(y) || !isNumber$1(width) || !isNumber$1(height) || !isNumber$1(top) || !isNumber$1(left)) return null;
	return /*#__PURE__*/ import_react.createElement("path", _extends$28({}, filterProps(props, true), {
		className: clsx("recharts-cross", className),
		d: getPath(x, y, width, height, top, left)
	}));
};
//#endregion
//#region node_modules/recharts/es6/polar/PolarGrid.js
/**
* @fileOverview Polar Grid
*/
var _excluded$14 = [
	"cx",
	"cy",
	"innerRadius",
	"outerRadius",
	"gridType",
	"radialLines"
];
function _typeof$32(o) {
	"@babel/helpers - typeof";
	return _typeof$32 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$32(o);
}
function _objectWithoutProperties$14(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$14(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$14(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
function _extends$27() {
	_extends$27 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$27.apply(this, arguments);
}
function ownKeys$28(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$28(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$28(Object(t), !0).forEach(function(r) {
			_defineProperty$32(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$28(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$32(obj, key, value) {
	key = _toPropertyKey$32(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$32(t) {
	var i = _toPrimitive$32(t, "string");
	return "symbol" == _typeof$32(i) ? i : i + "";
}
function _toPrimitive$32(t, r) {
	if ("object" != _typeof$32(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$32(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var getPolygonPath = function getPolygonPath(radius, cx, cy, polarAngles) {
	var path = "";
	polarAngles.forEach(function(angle, i) {
		var point = polarToCartesian(cx, cy, radius, angle);
		if (i) path += "L ".concat(point.x, ",").concat(point.y);
		else path += "M ".concat(point.x, ",").concat(point.y);
	});
	path += "Z";
	return path;
};
var PolarAngles = function PolarAngles(props) {
	var cx = props.cx, cy = props.cy, innerRadius = props.innerRadius, outerRadius = props.outerRadius, polarAngles = props.polarAngles, radialLines = props.radialLines;
	if (!polarAngles || !polarAngles.length || !radialLines) return null;
	var polarAnglesProps = _objectSpread$28({ stroke: "#ccc" }, filterProps(props, false));
	return /*#__PURE__*/ import_react.createElement("g", { className: "recharts-polar-grid-angle" }, polarAngles.map(function(entry) {
		var start = polarToCartesian(cx, cy, innerRadius, entry);
		var end = polarToCartesian(cx, cy, outerRadius, entry);
		return /*#__PURE__*/ import_react.createElement("line", _extends$27({}, polarAnglesProps, {
			key: "line-".concat(entry),
			x1: start.x,
			y1: start.y,
			x2: end.x,
			y2: end.y
		}));
	}));
};
var ConcentricCircle = function ConcentricCircle(props) {
	var cx = props.cx, cy = props.cy, radius = props.radius, index = props.index;
	var concentricCircleProps = _objectSpread$28(_objectSpread$28({ stroke: "#ccc" }, filterProps(props, false)), {}, { fill: "none" });
	return /*#__PURE__*/ import_react.createElement("circle", _extends$27({}, concentricCircleProps, {
		className: clsx("recharts-polar-grid-concentric-circle", props.className),
		key: "circle-".concat(index),
		cx,
		cy,
		r: radius
	}));
};
var ConcentricPolygon = function ConcentricPolygon(props) {
	var radius = props.radius, index = props.index;
	var concentricPolygonProps = _objectSpread$28(_objectSpread$28({ stroke: "#ccc" }, filterProps(props, false)), {}, { fill: "none" });
	return /*#__PURE__*/ import_react.createElement("path", _extends$27({}, concentricPolygonProps, {
		className: clsx("recharts-polar-grid-concentric-polygon", props.className),
		key: "path-".concat(index),
		d: getPolygonPath(radius, props.cx, props.cy, props.polarAngles)
	}));
};
var ConcentricPath = function ConcentricPath(props) {
	var polarRadius = props.polarRadius, gridType = props.gridType;
	if (!polarRadius || !polarRadius.length) return null;
	return /*#__PURE__*/ import_react.createElement("g", { className: "recharts-polar-grid-concentric" }, polarRadius.map(function(entry, i) {
		var key = i;
		if (gridType === "circle") return /*#__PURE__*/ import_react.createElement(ConcentricCircle, _extends$27({ key }, props, {
			radius: entry,
			index: i
		}));
		return /*#__PURE__*/ import_react.createElement(ConcentricPolygon, _extends$27({ key }, props, {
			radius: entry,
			index: i
		}));
	}));
};
var PolarGrid = function PolarGrid(_ref) {
	var _ref$cx = _ref.cx, cx = _ref$cx === void 0 ? 0 : _ref$cx, _ref$cy = _ref.cy, cy = _ref$cy === void 0 ? 0 : _ref$cy, _ref$innerRadius = _ref.innerRadius, innerRadius = _ref$innerRadius === void 0 ? 0 : _ref$innerRadius, _ref$outerRadius = _ref.outerRadius, outerRadius = _ref$outerRadius === void 0 ? 0 : _ref$outerRadius, _ref$gridType = _ref.gridType, gridType = _ref$gridType === void 0 ? "polygon" : _ref$gridType, _ref$radialLines = _ref.radialLines, radialLines = _ref$radialLines === void 0 ? true : _ref$radialLines, props = _objectWithoutProperties$14(_ref, _excluded$14);
	if (outerRadius <= 0) return null;
	return /*#__PURE__*/ import_react.createElement("g", { className: "recharts-polar-grid" }, /*#__PURE__*/ import_react.createElement(PolarAngles, _extends$27({
		cx,
		cy,
		innerRadius,
		outerRadius,
		gridType,
		radialLines
	}, props)), /*#__PURE__*/ import_react.createElement(ConcentricPath, _extends$27({
		cx,
		cy,
		innerRadius,
		outerRadius,
		gridType,
		radialLines
	}, props)));
};
PolarGrid.displayName = "PolarGrid";
//#endregion
//#region node_modules/recharts/es6/polar/PolarRadiusAxis.js
/**
* @fileOverview The axis of polar coordinate system
*/
var import_maxBy = /* @__PURE__ */ __toESM(require_maxBy());
var import_minBy = /* @__PURE__ */ __toESM(require_minBy());
var _excluded$13 = [
	"cx",
	"cy",
	"angle",
	"ticks",
	"axisLine"
];
var _excluded2$7 = [
	"ticks",
	"tick",
	"angle",
	"tickFormatter",
	"stroke"
];
function _typeof$31(o) {
	"@babel/helpers - typeof";
	return _typeof$31 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$31(o);
}
function _extends$26() {
	_extends$26 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$26.apply(this, arguments);
}
function ownKeys$27(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$27(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$27(Object(t), !0).forEach(function(r) {
			_defineProperty$31(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$27(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _objectWithoutProperties$13(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$13(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$13(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
function _classCallCheck$22(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$22(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$31(descriptor.key), descriptor);
	}
}
function _createClass$22(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$22(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$22(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$20(t, o, e) {
	return o = _getPrototypeOf$20(o), _possibleConstructorReturn$20(t, _isNativeReflectConstruct$20() ? Reflect.construct(o, e || [], _getPrototypeOf$20(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$20(self, call) {
	if (call && (_typeof$31(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$20(self);
}
function _assertThisInitialized$20(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$20() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$20 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$20(o) {
	_getPrototypeOf$20 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$20(o);
}
function _inherits$20(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$20(subClass, superClass);
}
function _setPrototypeOf$20(o, p) {
	_setPrototypeOf$20 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$20(o, p);
}
function _defineProperty$31(obj, key, value) {
	key = _toPropertyKey$31(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$31(t) {
	var i = _toPrimitive$31(t, "string");
	return "symbol" == _typeof$31(i) ? i : i + "";
}
function _toPrimitive$31(t, r) {
	if ("object" != _typeof$31(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$31(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var PolarRadiusAxis = /*#__PURE__*/ function(_PureComponent) {
	function PolarRadiusAxis() {
		_classCallCheck$22(this, PolarRadiusAxis);
		return _callSuper$20(this, PolarRadiusAxis, arguments);
	}
	_inherits$20(PolarRadiusAxis, _PureComponent);
	return _createClass$22(PolarRadiusAxis, [
		{
			key: "getTickValueCoord",
			value: 
			/**
			* Calculate the coordinate of tick
			* @param  {Number} coordinate The radius of tick
			* @return {Object} (x, y)
			*/
			function getTickValueCoord(_ref) {
				var coordinate = _ref.coordinate;
				var _this$props = this.props, angle = _this$props.angle, cx = _this$props.cx, cy = _this$props.cy;
				return polarToCartesian(cx, cy, coordinate, angle);
			}
		},
		{
			key: "getTickTextAnchor",
			value: function getTickTextAnchor() {
				var orientation = this.props.orientation;
				var textAnchor;
				switch (orientation) {
					case "left":
						textAnchor = "end";
						break;
					case "right":
						textAnchor = "start";
						break;
					default: textAnchor = "middle";
				}
				return textAnchor;
			}
		},
		{
			key: "getViewBox",
			value: function getViewBox() {
				var _this$props2 = this.props, cx = _this$props2.cx, cy = _this$props2.cy, angle = _this$props2.angle, ticks = _this$props2.ticks;
				var maxRadiusTick = (0, import_maxBy.default)(ticks, function(entry) {
					return entry.coordinate || 0;
				});
				return {
					cx,
					cy,
					startAngle: angle,
					endAngle: angle,
					innerRadius: (0, import_minBy.default)(ticks, function(entry) {
						return entry.coordinate || 0;
					}).coordinate || 0,
					outerRadius: maxRadiusTick.coordinate || 0
				};
			}
		},
		{
			key: "renderAxisLine",
			value: function renderAxisLine() {
				var _this$props3 = this.props, cx = _this$props3.cx, cy = _this$props3.cy, angle = _this$props3.angle, ticks = _this$props3.ticks, axisLine = _this$props3.axisLine, others = _objectWithoutProperties$13(_this$props3, _excluded$13);
				var extent = ticks.reduce(function(result, entry) {
					return [Math.min(result[0], entry.coordinate), Math.max(result[1], entry.coordinate)];
				}, [Infinity, -Infinity]);
				var point0 = polarToCartesian(cx, cy, extent[0], angle);
				var point1 = polarToCartesian(cx, cy, extent[1], angle);
				var props = _objectSpread$27(_objectSpread$27(_objectSpread$27({}, filterProps(others, false)), {}, { fill: "none" }, filterProps(axisLine, false)), {}, {
					x1: point0.x,
					y1: point0.y,
					x2: point1.x,
					y2: point1.y
				});
				return /*#__PURE__*/ import_react.createElement("line", _extends$26({ className: "recharts-polar-radius-axis-line" }, props));
			}
		},
		{
			key: "renderTicks",
			value: function renderTicks() {
				var _this = this;
				var _this$props4 = this.props, ticks = _this$props4.ticks, tick = _this$props4.tick, angle = _this$props4.angle, tickFormatter = _this$props4.tickFormatter, stroke = _this$props4.stroke, others = _objectWithoutProperties$13(_this$props4, _excluded2$7);
				var textAnchor = this.getTickTextAnchor();
				var axisProps = filterProps(others, false);
				var customTickProps = filterProps(tick, false);
				var items = ticks.map(function(entry, i) {
					var coord = _this.getTickValueCoord(entry);
					var tickProps = _objectSpread$27(_objectSpread$27(_objectSpread$27(_objectSpread$27({
						textAnchor,
						transform: "rotate(".concat(90 - angle, ", ").concat(coord.x, ", ").concat(coord.y, ")")
					}, axisProps), {}, {
						stroke: "none",
						fill: stroke
					}, customTickProps), {}, { index: i }, coord), {}, { payload: entry });
					return /*#__PURE__*/ import_react.createElement(Layer, _extends$26({
						className: clsx("recharts-polar-radius-axis-tick", getTickClassName(tick)),
						key: "tick-".concat(entry.coordinate)
					}, adaptEventsOfChild(_this.props, entry, i)), PolarRadiusAxis.renderTickItem(tick, tickProps, tickFormatter ? tickFormatter(entry.value, i) : entry.value));
				});
				return /*#__PURE__*/ import_react.createElement(Layer, { className: "recharts-polar-radius-axis-ticks" }, items);
			}
		},
		{
			key: "render",
			value: function render() {
				var _this$props5 = this.props, ticks = _this$props5.ticks, axisLine = _this$props5.axisLine, tick = _this$props5.tick;
				if (!ticks || !ticks.length) return null;
				return /*#__PURE__*/ import_react.createElement(Layer, { className: clsx("recharts-polar-radius-axis", this.props.className) }, axisLine && this.renderAxisLine(), tick && this.renderTicks(), Label.renderCallByParent(this.props, this.getViewBox()));
			}
		}
	], [{
		key: "renderTickItem",
		value: function renderTickItem(option, props, value) {
			var tickItem;
			if (/*#__PURE__*/ import_react.isValidElement(option)) tickItem = /*#__PURE__*/ import_react.cloneElement(option, props);
			else if ((0, import_isFunction.default)(option)) tickItem = option(props);
			else tickItem = /*#__PURE__*/ import_react.createElement(Text, _extends$26({}, props, { className: "recharts-polar-radius-axis-tick-value" }), value);
			return tickItem;
		}
	}]);
}(import_react.PureComponent);
_defineProperty$31(PolarRadiusAxis, "displayName", "PolarRadiusAxis");
_defineProperty$31(PolarRadiusAxis, "axisType", "radiusAxis");
_defineProperty$31(PolarRadiusAxis, "defaultProps", {
	type: "number",
	radiusAxisId: 0,
	cx: 0,
	cy: 0,
	angle: 0,
	orientation: "right",
	stroke: "#ccc",
	axisLine: true,
	tick: true,
	tickCount: 5,
	allowDataOverflow: false,
	scale: "auto",
	allowDuplicatedCategory: true
});
//#endregion
//#region node_modules/recharts/es6/polar/PolarAngleAxis.js
/**
* @fileOverview Axis of radial direction
*/
function _typeof$30(o) {
	"@babel/helpers - typeof";
	return _typeof$30 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$30(o);
}
function _extends$25() {
	_extends$25 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$25.apply(this, arguments);
}
function ownKeys$26(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$26(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$26(Object(t), !0).forEach(function(r) {
			_defineProperty$30(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$26(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _classCallCheck$21(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$21(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$30(descriptor.key), descriptor);
	}
}
function _createClass$21(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$21(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$21(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$19(t, o, e) {
	return o = _getPrototypeOf$19(o), _possibleConstructorReturn$19(t, _isNativeReflectConstruct$19() ? Reflect.construct(o, e || [], _getPrototypeOf$19(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$19(self, call) {
	if (call && (_typeof$30(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$19(self);
}
function _assertThisInitialized$19(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$19() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$19 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$19(o) {
	_getPrototypeOf$19 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$19(o);
}
function _inherits$19(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$19(subClass, superClass);
}
function _setPrototypeOf$19(o, p) {
	_setPrototypeOf$19 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$19(o, p);
}
function _defineProperty$30(obj, key, value) {
	key = _toPropertyKey$30(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$30(t) {
	var i = _toPrimitive$30(t, "string");
	return "symbol" == _typeof$30(i) ? i : i + "";
}
function _toPrimitive$30(t, r) {
	if ("object" != _typeof$30(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$30(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var RADIAN = Math.PI / 180;
var eps = 1e-5;
var PolarAngleAxis = /*#__PURE__*/ function(_PureComponent) {
	function PolarAngleAxis() {
		_classCallCheck$21(this, PolarAngleAxis);
		return _callSuper$19(this, PolarAngleAxis, arguments);
	}
	_inherits$19(PolarAngleAxis, _PureComponent);
	return _createClass$21(PolarAngleAxis, [
		{
			key: "getTickLineCoord",
			value: 
			/**
			* Calculate the coordinate of line endpoint
			* @param  {Object} data The Data if ticks
			* @return {Object} (x0, y0): The start point of text,
			*                  (x1, y1): The end point close to text,
			*                  (x2, y2): The end point close to axis
			*/
			function getTickLineCoord(data) {
				var _this$props = this.props, cx = _this$props.cx, cy = _this$props.cy, radius = _this$props.radius, orientation = _this$props.orientation;
				var tickLineSize = _this$props.tickSize || 8;
				var p1 = polarToCartesian(cx, cy, radius, data.coordinate);
				var p2 = polarToCartesian(cx, cy, radius + (orientation === "inner" ? -1 : 1) * tickLineSize, data.coordinate);
				return {
					x1: p1.x,
					y1: p1.y,
					x2: p2.x,
					y2: p2.y
				};
			}
		},
		{
			key: "getTickTextAnchor",
			value: function getTickTextAnchor(data) {
				var orientation = this.props.orientation;
				var cos = Math.cos(-data.coordinate * RADIAN);
				var textAnchor;
				if (cos > eps) textAnchor = orientation === "outer" ? "start" : "end";
				else if (cos < -eps) textAnchor = orientation === "outer" ? "end" : "start";
				else textAnchor = "middle";
				return textAnchor;
			}
		},
		{
			key: "renderAxisLine",
			value: function renderAxisLine() {
				var _this$props2 = this.props, cx = _this$props2.cx, cy = _this$props2.cy, radius = _this$props2.radius, axisLine = _this$props2.axisLine, axisLineType = _this$props2.axisLineType;
				var props = _objectSpread$26(_objectSpread$26({}, filterProps(this.props, false)), {}, { fill: "none" }, filterProps(axisLine, false));
				if (axisLineType === "circle") return /*#__PURE__*/ import_react.createElement(Dot, _extends$25({ className: "recharts-polar-angle-axis-line" }, props, {
					cx,
					cy,
					r: radius
				}));
				var points = this.props.ticks.map(function(entry) {
					return polarToCartesian(cx, cy, radius, entry.coordinate);
				});
				return /*#__PURE__*/ import_react.createElement(Polygon, _extends$25({ className: "recharts-polar-angle-axis-line" }, props, { points }));
			}
		},
		{
			key: "renderTicks",
			value: function renderTicks() {
				var _this = this;
				var _this$props3 = this.props, ticks = _this$props3.ticks, tick = _this$props3.tick, tickLine = _this$props3.tickLine, tickFormatter = _this$props3.tickFormatter, stroke = _this$props3.stroke;
				var axisProps = filterProps(this.props, false);
				var customTickProps = filterProps(tick, false);
				var tickLineProps = _objectSpread$26(_objectSpread$26({}, axisProps), {}, { fill: "none" }, filterProps(tickLine, false));
				var items = ticks.map(function(entry, i) {
					var lineCoord = _this.getTickLineCoord(entry);
					var tickProps = _objectSpread$26(_objectSpread$26(_objectSpread$26({ textAnchor: _this.getTickTextAnchor(entry) }, axisProps), {}, {
						stroke: "none",
						fill: stroke
					}, customTickProps), {}, {
						index: i,
						payload: entry,
						x: lineCoord.x2,
						y: lineCoord.y2
					});
					return /*#__PURE__*/ import_react.createElement(Layer, _extends$25({
						className: clsx("recharts-polar-angle-axis-tick", getTickClassName(tick)),
						key: "tick-".concat(entry.coordinate)
					}, adaptEventsOfChild(_this.props, entry, i)), tickLine && /*#__PURE__*/ import_react.createElement("line", _extends$25({ className: "recharts-polar-angle-axis-tick-line" }, tickLineProps, lineCoord)), tick && PolarAngleAxis.renderTickItem(tick, tickProps, tickFormatter ? tickFormatter(entry.value, i) : entry.value));
				});
				return /*#__PURE__*/ import_react.createElement(Layer, { className: "recharts-polar-angle-axis-ticks" }, items);
			}
		},
		{
			key: "render",
			value: function render() {
				var _this$props4 = this.props, ticks = _this$props4.ticks, radius = _this$props4.radius, axisLine = _this$props4.axisLine;
				if (radius <= 0 || !ticks || !ticks.length) return null;
				return /*#__PURE__*/ import_react.createElement(Layer, { className: clsx("recharts-polar-angle-axis", this.props.className) }, axisLine && this.renderAxisLine(), this.renderTicks());
			}
		}
	], [{
		key: "renderTickItem",
		value: function renderTickItem(option, props, value) {
			var tickItem;
			if (/*#__PURE__*/ import_react.isValidElement(option)) tickItem = /*#__PURE__*/ import_react.cloneElement(option, props);
			else if ((0, import_isFunction.default)(option)) tickItem = option(props);
			else tickItem = /*#__PURE__*/ import_react.createElement(Text, _extends$25({}, props, { className: "recharts-polar-angle-axis-tick-value" }), value);
			return tickItem;
		}
	}]);
}(import_react.PureComponent);
_defineProperty$30(PolarAngleAxis, "displayName", "PolarAngleAxis");
_defineProperty$30(PolarAngleAxis, "axisType", "angleAxis");
_defineProperty$30(PolarAngleAxis, "defaultProps", {
	type: "category",
	angleAxisId: 0,
	scale: "auto",
	cx: 0,
	cy: 0,
	orientation: "outer",
	axisLine: true,
	tickLine: true,
	tickSize: 8,
	tick: true,
	hide: false,
	allowDuplicatedCategory: true
});
//#endregion
//#region node_modules/recharts/es6/shape/Trapezoid.js
var import_isPlainObject = /* @__PURE__ */ __toESM(require_isPlainObject());
var import_isBoolean = /* @__PURE__ */ __toESM(require_isBoolean());
/**
* @fileOverview Rectangle
*/
function _typeof$29(o) {
	"@babel/helpers - typeof";
	return _typeof$29 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$29(o);
}
function _extends$24() {
	_extends$24 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$24.apply(this, arguments);
}
function _slicedToArray$4(arr, i) {
	return _arrayWithHoles$4(arr) || _iterableToArrayLimit$4(arr, i) || _unsupportedIterableToArray$6(arr, i) || _nonIterableRest$4();
}
function _nonIterableRest$4() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$6(o, minLen) {
	if (!o) return;
	if (typeof o === "string") return _arrayLikeToArray$6(o, minLen);
	var n = Object.prototype.toString.call(o).slice(8, -1);
	if (n === "Object" && o.constructor) n = o.constructor.name;
	if (n === "Map" || n === "Set") return Array.from(o);
	if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$6(o, minLen);
}
function _arrayLikeToArray$6(arr, len) {
	if (len == null || len > arr.length) len = arr.length;
	for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
	return arr2;
}
function _iterableToArrayLimit$4(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = !0, o = !1;
		try {
			if (i = (t = t.call(r)).next, 0 === l) {
				if (Object(t) !== t) return;
				f = !1;
			} else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = !0, n = r;
		} finally {
			try {
				if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
function _arrayWithHoles$4(arr) {
	if (Array.isArray(arr)) return arr;
}
function ownKeys$25(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$25(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$25(Object(t), !0).forEach(function(r) {
			_defineProperty$29(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$25(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$29(obj, key, value) {
	key = _toPropertyKey$29(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$29(t) {
	var i = _toPrimitive$29(t, "string");
	return "symbol" == _typeof$29(i) ? i : i + "";
}
function _toPrimitive$29(t, r) {
	if ("object" != _typeof$29(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$29(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var getTrapezoidPath = function getTrapezoidPath(x, y, upperWidth, lowerWidth, height) {
	var widthGap = upperWidth - lowerWidth;
	var path = "M ".concat(x, ",").concat(y);
	path += "L ".concat(x + upperWidth, ",").concat(y);
	path += "L ".concat(x + upperWidth - widthGap / 2, ",").concat(y + height);
	path += "L ".concat(x + upperWidth - widthGap / 2 - lowerWidth, ",").concat(y + height);
	path += "L ".concat(x, ",").concat(y, " Z");
	return path;
};
var defaultProps$1 = {
	x: 0,
	y: 0,
	upperWidth: 0,
	lowerWidth: 0,
	height: 0,
	isUpdateAnimationActive: false,
	animationBegin: 0,
	animationDuration: 1500,
	animationEasing: "ease"
};
var Trapezoid = function Trapezoid(props) {
	var trapezoidProps = _objectSpread$25(_objectSpread$25({}, defaultProps$1), props);
	var pathRef = (0, import_react.useRef)();
	var _useState2 = _slicedToArray$4((0, import_react.useState)(-1), 2), totalLength = _useState2[0], setTotalLength = _useState2[1];
	(0, import_react.useEffect)(function() {
		if (pathRef.current && pathRef.current.getTotalLength) try {
			var pathTotalLength = pathRef.current.getTotalLength();
			if (pathTotalLength) setTotalLength(pathTotalLength);
		} catch (err) {}
	}, []);
	var x = trapezoidProps.x, y = trapezoidProps.y, upperWidth = trapezoidProps.upperWidth, lowerWidth = trapezoidProps.lowerWidth, height = trapezoidProps.height, className = trapezoidProps.className;
	var animationEasing = trapezoidProps.animationEasing, animationDuration = trapezoidProps.animationDuration, animationBegin = trapezoidProps.animationBegin, isUpdateAnimationActive = trapezoidProps.isUpdateAnimationActive;
	if (x !== +x || y !== +y || upperWidth !== +upperWidth || lowerWidth !== +lowerWidth || height !== +height || upperWidth === 0 && lowerWidth === 0 || height === 0) return null;
	var layerClass = clsx("recharts-trapezoid", className);
	if (!isUpdateAnimationActive) return /*#__PURE__*/ import_react.createElement("g", null, /*#__PURE__*/ import_react.createElement("path", _extends$24({}, filterProps(trapezoidProps, true), {
		className: layerClass,
		d: getTrapezoidPath(x, y, upperWidth, lowerWidth, height)
	})));
	return /*#__PURE__*/ import_react.createElement(es6_default, {
		canBegin: totalLength > 0,
		from: {
			upperWidth: 0,
			lowerWidth: 0,
			height,
			x,
			y
		},
		to: {
			upperWidth,
			lowerWidth,
			height,
			x,
			y
		},
		duration: animationDuration,
		animationEasing,
		isActive: isUpdateAnimationActive
	}, function(_ref) {
		var currUpperWidth = _ref.upperWidth, currLowerWidth = _ref.lowerWidth, currHeight = _ref.height, currX = _ref.x, currY = _ref.y;
		return /*#__PURE__*/ import_react.createElement(es6_default, {
			canBegin: totalLength > 0,
			from: "0px ".concat(totalLength === -1 ? 1 : totalLength, "px"),
			to: "".concat(totalLength, "px 0px"),
			attributeName: "strokeDasharray",
			begin: animationBegin,
			duration: animationDuration,
			easing: animationEasing
		}, /*#__PURE__*/ import_react.createElement("path", _extends$24({}, filterProps(trapezoidProps, true), {
			className: layerClass,
			d: getTrapezoidPath(currX, currY, currUpperWidth, currLowerWidth, currHeight),
			ref: pathRef
		})));
	});
};
//#endregion
//#region node_modules/recharts/es6/util/ActiveShapeUtils.js
var _excluded$12 = [
	"option",
	"shapeType",
	"propTransformer",
	"activeClassName",
	"isActive"
];
function _typeof$28(o) {
	"@babel/helpers - typeof";
	return _typeof$28 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$28(o);
}
function _objectWithoutProperties$12(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$12(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$12(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
function ownKeys$24(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$24(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$24(Object(t), !0).forEach(function(r) {
			_defineProperty$28(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$24(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$28(obj, key, value) {
	key = _toPropertyKey$28(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$28(t) {
	var i = _toPrimitive$28(t, "string");
	return "symbol" == _typeof$28(i) ? i : i + "";
}
function _toPrimitive$28(t, r) {
	if ("object" != _typeof$28(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$28(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
/**
* This is an abstraction for rendering a user defined prop for a customized shape in several forms.
*
* <Shape /> is the root and will handle taking in:
*  - an object of svg properties
*  - a boolean
*  - a render prop(inline function that returns jsx)
*  - a react element
*
* <ShapeSelector /> is a subcomponent of <Shape /> and used to match a component
* to the value of props.shapeType that is passed to the root.
*
*/
function defaultPropTransformer(option, props) {
	return _objectSpread$24(_objectSpread$24({}, props), option);
}
function isSymbolsProps(shapeType, _elementProps) {
	return shapeType === "symbols";
}
function ShapeSelector(_ref) {
	var shapeType = _ref.shapeType, elementProps = _ref.elementProps;
	switch (shapeType) {
		case "rectangle": return /*#__PURE__*/ import_react.createElement(Rectangle, elementProps);
		case "trapezoid": return /*#__PURE__*/ import_react.createElement(Trapezoid, elementProps);
		case "sector": return /*#__PURE__*/ import_react.createElement(Sector, elementProps);
		case "symbols":
			if (isSymbolsProps(shapeType, elementProps)) return /*#__PURE__*/ import_react.createElement(Symbols, elementProps);
			break;
		default: return null;
	}
}
function getPropsFromShapeOption(option) {
	if (/*#__PURE__*/ (0, import_react.isValidElement)(option)) return option.props;
	return option;
}
function Shape(_ref2) {
	var option = _ref2.option, shapeType = _ref2.shapeType, _ref2$propTransformer = _ref2.propTransformer, propTransformer = _ref2$propTransformer === void 0 ? defaultPropTransformer : _ref2$propTransformer, _ref2$activeClassName = _ref2.activeClassName, activeClassName = _ref2$activeClassName === void 0 ? "recharts-active-shape" : _ref2$activeClassName, isActive = _ref2.isActive, props = _objectWithoutProperties$12(_ref2, _excluded$12);
	var shape;
	if (/*#__PURE__*/ (0, import_react.isValidElement)(option)) shape = /*#__PURE__*/ (0, import_react.cloneElement)(option, _objectSpread$24(_objectSpread$24({}, props), getPropsFromShapeOption(option)));
	else if ((0, import_isFunction.default)(option)) shape = option(props);
	else if ((0, import_isPlainObject.default)(option) && !(0, import_isBoolean.default)(option)) {
		var nextProps = propTransformer(option, props);
		shape = /*#__PURE__*/ import_react.createElement(ShapeSelector, {
			shapeType,
			elementProps: nextProps
		});
	} else {
		var elementProps = props;
		shape = /*#__PURE__*/ import_react.createElement(ShapeSelector, {
			shapeType,
			elementProps
		});
	}
	if (isActive) return /*#__PURE__*/ import_react.createElement(Layer, { className: activeClassName }, shape);
	return shape;
}
/**
* This is an abstraction to handle identifying the active index from a tooltip mouse interaction
*/
function isFunnel(graphicalItem, _item) {
	return _item != null && "trapezoids" in graphicalItem.props;
}
function isPie(graphicalItem, _item) {
	return _item != null && "sectors" in graphicalItem.props;
}
function isScatter(graphicalItem, _item) {
	return _item != null && "points" in graphicalItem.props;
}
function compareFunnel(shapeData, activeTooltipItem) {
	var _activeTooltipItem$la, _activeTooltipItem$la2;
	var xMatches = shapeData.x === (activeTooltipItem === null || activeTooltipItem === void 0 || (_activeTooltipItem$la = activeTooltipItem.labelViewBox) === null || _activeTooltipItem$la === void 0 ? void 0 : _activeTooltipItem$la.x) || shapeData.x === activeTooltipItem.x;
	var yMatches = shapeData.y === (activeTooltipItem === null || activeTooltipItem === void 0 || (_activeTooltipItem$la2 = activeTooltipItem.labelViewBox) === null || _activeTooltipItem$la2 === void 0 ? void 0 : _activeTooltipItem$la2.y) || shapeData.y === activeTooltipItem.y;
	return xMatches && yMatches;
}
function comparePie(shapeData, activeTooltipItem) {
	var startAngleMatches = shapeData.endAngle === activeTooltipItem.endAngle;
	var endAngleMatches = shapeData.startAngle === activeTooltipItem.startAngle;
	return startAngleMatches && endAngleMatches;
}
function compareScatter(shapeData, activeTooltipItem) {
	var xMatches = shapeData.x === activeTooltipItem.x;
	var yMatches = shapeData.y === activeTooltipItem.y;
	var zMatches = shapeData.z === activeTooltipItem.z;
	return xMatches && yMatches && zMatches;
}
function getComparisonFn(graphicalItem, activeItem) {
	var comparison;
	if (isFunnel(graphicalItem, activeItem)) comparison = compareFunnel;
	else if (isPie(graphicalItem, activeItem)) comparison = comparePie;
	else if (isScatter(graphicalItem, activeItem)) comparison = compareScatter;
	return comparison;
}
function getShapeDataKey(graphicalItem, activeItem) {
	var shapeKey;
	if (isFunnel(graphicalItem, activeItem)) shapeKey = "trapezoids";
	else if (isPie(graphicalItem, activeItem)) shapeKey = "sectors";
	else if (isScatter(graphicalItem, activeItem)) shapeKey = "points";
	return shapeKey;
}
function getActiveShapeTooltipPayload(graphicalItem, activeItem) {
	if (isFunnel(graphicalItem, activeItem)) {
		var _activeItem$tooltipPa;
		return (_activeItem$tooltipPa = activeItem.tooltipPayload) === null || _activeItem$tooltipPa === void 0 || (_activeItem$tooltipPa = _activeItem$tooltipPa[0]) === null || _activeItem$tooltipPa === void 0 || (_activeItem$tooltipPa = _activeItem$tooltipPa.payload) === null || _activeItem$tooltipPa === void 0 ? void 0 : _activeItem$tooltipPa.payload;
	}
	if (isPie(graphicalItem, activeItem)) {
		var _activeItem$tooltipPa2;
		return (_activeItem$tooltipPa2 = activeItem.tooltipPayload) === null || _activeItem$tooltipPa2 === void 0 || (_activeItem$tooltipPa2 = _activeItem$tooltipPa2[0]) === null || _activeItem$tooltipPa2 === void 0 || (_activeItem$tooltipPa2 = _activeItem$tooltipPa2.payload) === null || _activeItem$tooltipPa2 === void 0 ? void 0 : _activeItem$tooltipPa2.payload;
	}
	if (isScatter(graphicalItem, activeItem)) return activeItem.payload;
	return {};
}
/**
*
* @param {GetActiveShapeIndexForTooltip} arg an object of incoming attributes from Tooltip
* @returns {number}
*
* To handle possible duplicates in the data set,
* match both the data value of the active item to a data value on a graph item,
* and match the mouse coordinates of the active item to the coordinates of in a particular components shape data.
* This assumes equal lengths of shape objects to data items.
*/
function getActiveShapeIndexForTooltip(_ref3) {
	var activeTooltipItem = _ref3.activeTooltipItem, graphicalItem = _ref3.graphicalItem, itemData = _ref3.itemData;
	var shapeKey = getShapeDataKey(graphicalItem, activeTooltipItem);
	var tooltipPayload = getActiveShapeTooltipPayload(graphicalItem, activeTooltipItem);
	var activeItemMatches = itemData.filter(function(datum, dataIndex) {
		var valuesMatch = (0, import_isEqual.default)(tooltipPayload, datum);
		var mouseCoordinateMatches = graphicalItem.props[shapeKey].filter(function(shapeData) {
			return getComparisonFn(graphicalItem, activeTooltipItem)(shapeData, activeTooltipItem);
		});
		var coordinatesMatch = dataIndex === graphicalItem.props[shapeKey].indexOf(mouseCoordinateMatches[mouseCoordinateMatches.length - 1]);
		return valuesMatch && coordinatesMatch;
	});
	return itemData.indexOf(activeItemMatches[activeItemMatches.length - 1]);
}
//#endregion
//#region node_modules/recharts/es6/polar/Pie.js
/**
* @fileOverview Render sectors of a pie
*/
var _Pie;
function _typeof$27(o) {
	"@babel/helpers - typeof";
	return _typeof$27 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$27(o);
}
function _extends$23() {
	_extends$23 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$23.apply(this, arguments);
}
function ownKeys$23(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$23(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$23(Object(t), !0).forEach(function(r) {
			_defineProperty$27(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$23(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _classCallCheck$20(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$20(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$27(descriptor.key), descriptor);
	}
}
function _createClass$20(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$20(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$20(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$18(t, o, e) {
	return o = _getPrototypeOf$18(o), _possibleConstructorReturn$18(t, _isNativeReflectConstruct$18() ? Reflect.construct(o, e || [], _getPrototypeOf$18(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$18(self, call) {
	if (call && (_typeof$27(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$18(self);
}
function _assertThisInitialized$18(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$18() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$18 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$18(o) {
	_getPrototypeOf$18 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$18(o);
}
function _inherits$18(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$18(subClass, superClass);
}
function _setPrototypeOf$18(o, p) {
	_setPrototypeOf$18 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$18(o, p);
}
function _defineProperty$27(obj, key, value) {
	key = _toPropertyKey$27(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$27(t) {
	var i = _toPrimitive$27(t, "string");
	return "symbol" == _typeof$27(i) ? i : i + "";
}
function _toPrimitive$27(t, r) {
	if ("object" != _typeof$27(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$27(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var Pie = /*#__PURE__*/ function(_PureComponent) {
	function Pie(props) {
		var _this;
		_classCallCheck$20(this, Pie);
		_this = _callSuper$18(this, Pie, [props]);
		_defineProperty$27(_this, "pieRef", null);
		_defineProperty$27(_this, "sectorRefs", []);
		_defineProperty$27(_this, "id", uniqueId("recharts-pie-"));
		_defineProperty$27(_this, "handleAnimationEnd", function() {
			var onAnimationEnd = _this.props.onAnimationEnd;
			_this.setState({ isAnimationFinished: true });
			if ((0, import_isFunction.default)(onAnimationEnd)) onAnimationEnd();
		});
		_defineProperty$27(_this, "handleAnimationStart", function() {
			var onAnimationStart = _this.props.onAnimationStart;
			_this.setState({ isAnimationFinished: false });
			if ((0, import_isFunction.default)(onAnimationStart)) onAnimationStart();
		});
		_this.state = {
			isAnimationFinished: !props.isAnimationActive,
			prevIsAnimationActive: props.isAnimationActive,
			prevAnimationId: props.animationId,
			sectorToFocus: 0
		};
		return _this;
	}
	_inherits$18(Pie, _PureComponent);
	return _createClass$20(Pie, [
		{
			key: "isActiveIndex",
			value: function isActiveIndex(i) {
				var activeIndex = this.props.activeIndex;
				if (Array.isArray(activeIndex)) return activeIndex.indexOf(i) !== -1;
				return i === activeIndex;
			}
		},
		{
			key: "hasActiveIndex",
			value: function hasActiveIndex() {
				var activeIndex = this.props.activeIndex;
				return Array.isArray(activeIndex) ? activeIndex.length !== 0 : activeIndex || activeIndex === 0;
			}
		},
		{
			key: "renderLabels",
			value: function renderLabels(sectors) {
				if (this.props.isAnimationActive && !this.state.isAnimationFinished) return null;
				var _this$props = this.props, label = _this$props.label, labelLine = _this$props.labelLine, dataKey = _this$props.dataKey, valueKey = _this$props.valueKey;
				var pieProps = filterProps(this.props, false);
				var customLabelProps = filterProps(label, false);
				var customLabelLineProps = filterProps(labelLine, false);
				var offsetRadius = label && label.offsetRadius || 20;
				var labels = sectors.map(function(entry, i) {
					var midAngle = (entry.startAngle + entry.endAngle) / 2;
					var endPoint = polarToCartesian(entry.cx, entry.cy, entry.outerRadius + offsetRadius, midAngle);
					var labelProps = _objectSpread$23(_objectSpread$23(_objectSpread$23(_objectSpread$23({}, pieProps), entry), {}, { stroke: "none" }, customLabelProps), {}, {
						index: i,
						textAnchor: Pie.getTextAnchor(endPoint.x, entry.cx)
					}, endPoint);
					var lineProps = _objectSpread$23(_objectSpread$23(_objectSpread$23(_objectSpread$23({}, pieProps), entry), {}, {
						fill: "none",
						stroke: entry.fill
					}, customLabelLineProps), {}, {
						index: i,
						points: [polarToCartesian(entry.cx, entry.cy, entry.outerRadius, midAngle), endPoint]
					});
					var realDataKey = dataKey;
					if ((0, import_isNil.default)(dataKey) && (0, import_isNil.default)(valueKey)) realDataKey = "value";
					else if ((0, import_isNil.default)(dataKey)) realDataKey = valueKey;
					return /*#__PURE__*/ import_react.createElement(Layer, { key: "label-".concat(entry.startAngle, "-").concat(entry.endAngle, "-").concat(entry.midAngle, "-").concat(i) }, labelLine && Pie.renderLabelLineItem(labelLine, lineProps, "line"), Pie.renderLabelItem(label, labelProps, getValueByDataKey(entry, realDataKey)));
				});
				return /*#__PURE__*/ import_react.createElement(Layer, { className: "recharts-pie-labels" }, labels);
			}
		},
		{
			key: "renderSectorsStatically",
			value: function renderSectorsStatically(sectors) {
				var _this2 = this;
				var _this$props2 = this.props, activeShape = _this$props2.activeShape, blendStroke = _this$props2.blendStroke, inactiveShapeProp = _this$props2.inactiveShape;
				return sectors.map(function(entry, i) {
					if ((entry === null || entry === void 0 ? void 0 : entry.startAngle) === 0 && (entry === null || entry === void 0 ? void 0 : entry.endAngle) === 0 && sectors.length !== 1) return null;
					var isActive = _this2.isActiveIndex(i);
					var inactiveShape = inactiveShapeProp && _this2.hasActiveIndex() ? inactiveShapeProp : null;
					var sectorOptions = isActive ? activeShape : inactiveShape;
					var sectorProps = _objectSpread$23(_objectSpread$23({}, entry), {}, {
						stroke: blendStroke ? entry.fill : entry.stroke,
						tabIndex: -1
					});
					return /*#__PURE__*/ import_react.createElement(Layer, _extends$23({
						ref: function ref(_ref) {
							if (_ref && !_this2.sectorRefs.includes(_ref)) _this2.sectorRefs.push(_ref);
						},
						tabIndex: -1,
						className: "recharts-pie-sector"
					}, adaptEventsOfChild(_this2.props, entry, i), { key: "sector-".concat(entry === null || entry === void 0 ? void 0 : entry.startAngle, "-").concat(entry === null || entry === void 0 ? void 0 : entry.endAngle, "-").concat(entry.midAngle, "-").concat(i) }), /*#__PURE__*/ import_react.createElement(Shape, _extends$23({
						option: sectorOptions,
						isActive,
						shapeType: "sector"
					}, sectorProps)));
				});
			}
		},
		{
			key: "renderSectorsWithAnimation",
			value: function renderSectorsWithAnimation() {
				var _this3 = this;
				var _this$props3 = this.props, sectors = _this$props3.sectors, isAnimationActive = _this$props3.isAnimationActive, animationBegin = _this$props3.animationBegin, animationDuration = _this$props3.animationDuration, animationEasing = _this$props3.animationEasing, animationId = _this$props3.animationId;
				var _this$state = this.state, prevSectors = _this$state.prevSectors, prevIsAnimationActive = _this$state.prevIsAnimationActive;
				return /*#__PURE__*/ import_react.createElement(es6_default, {
					begin: animationBegin,
					duration: animationDuration,
					isActive: isAnimationActive,
					easing: animationEasing,
					from: { t: 0 },
					to: { t: 1 },
					key: "pie-".concat(animationId, "-").concat(prevIsAnimationActive),
					onAnimationStart: this.handleAnimationStart,
					onAnimationEnd: this.handleAnimationEnd
				}, function(_ref2) {
					var t = _ref2.t;
					var stepData = [];
					var curAngle = (sectors && sectors[0]).startAngle;
					sectors.forEach(function(entry, index) {
						var prev = prevSectors && prevSectors[index];
						var paddingAngle = index > 0 ? (0, import_get.default)(entry, "paddingAngle", 0) : 0;
						if (prev) {
							var angleIp = interpolateNumber$1(prev.endAngle - prev.startAngle, entry.endAngle - entry.startAngle);
							var latest = _objectSpread$23(_objectSpread$23({}, entry), {}, {
								startAngle: curAngle + paddingAngle,
								endAngle: curAngle + angleIp(t) + paddingAngle
							});
							stepData.push(latest);
							curAngle = latest.endAngle;
						} else {
							var endAngle = entry.endAngle, startAngle = entry.startAngle;
							var deltaAngle = interpolateNumber$1(0, endAngle - startAngle)(t);
							var _latest = _objectSpread$23(_objectSpread$23({}, entry), {}, {
								startAngle: curAngle + paddingAngle,
								endAngle: curAngle + deltaAngle + paddingAngle
							});
							stepData.push(_latest);
							curAngle = _latest.endAngle;
						}
					});
					return /*#__PURE__*/ import_react.createElement(Layer, null, _this3.renderSectorsStatically(stepData));
				});
			}
		},
		{
			key: "attachKeyboardHandlers",
			value: function attachKeyboardHandlers(pieRef) {
				var _this4 = this;
				pieRef.onkeydown = function(e) {
					if (!e.altKey) switch (e.key) {
						case "ArrowLeft":
							var next = ++_this4.state.sectorToFocus % _this4.sectorRefs.length;
							_this4.sectorRefs[next].focus();
							_this4.setState({ sectorToFocus: next });
							break;
						case "ArrowRight":
							var _next = --_this4.state.sectorToFocus < 0 ? _this4.sectorRefs.length - 1 : _this4.state.sectorToFocus % _this4.sectorRefs.length;
							_this4.sectorRefs[_next].focus();
							_this4.setState({ sectorToFocus: _next });
							break;
						case "Escape":
							_this4.sectorRefs[_this4.state.sectorToFocus].blur();
							_this4.setState({ sectorToFocus: 0 });
					}
				};
			}
		},
		{
			key: "renderSectors",
			value: function renderSectors() {
				var _this$props4 = this.props, sectors = _this$props4.sectors, isAnimationActive = _this$props4.isAnimationActive;
				var prevSectors = this.state.prevSectors;
				if (isAnimationActive && sectors && sectors.length && (!prevSectors || !(0, import_isEqual.default)(prevSectors, sectors))) return this.renderSectorsWithAnimation();
				return this.renderSectorsStatically(sectors);
			}
		},
		{
			key: "componentDidMount",
			value: function componentDidMount() {
				if (this.pieRef) this.attachKeyboardHandlers(this.pieRef);
			}
		},
		{
			key: "render",
			value: function render() {
				var _this5 = this;
				var _this$props5 = this.props, hide = _this$props5.hide, sectors = _this$props5.sectors, className = _this$props5.className, label = _this$props5.label, cx = _this$props5.cx, cy = _this$props5.cy, innerRadius = _this$props5.innerRadius, outerRadius = _this$props5.outerRadius, isAnimationActive = _this$props5.isAnimationActive;
				var isAnimationFinished = this.state.isAnimationFinished;
				if (hide || !sectors || !sectors.length || !isNumber$1(cx) || !isNumber$1(cy) || !isNumber$1(innerRadius) || !isNumber$1(outerRadius)) return null;
				var layerClass = clsx("recharts-pie", className);
				return /*#__PURE__*/ import_react.createElement(Layer, {
					tabIndex: this.props.rootTabIndex,
					className: layerClass,
					ref: function ref(_ref3) {
						_this5.pieRef = _ref3;
					}
				}, this.renderSectors(), label && this.renderLabels(sectors), Label.renderCallByParent(this.props, null, false), (!isAnimationActive || isAnimationFinished) && LabelList.renderCallByParent(this.props, sectors, false));
			}
		}
	], [
		{
			key: "getDerivedStateFromProps",
			value: function getDerivedStateFromProps(nextProps, prevState) {
				if (prevState.prevIsAnimationActive !== nextProps.isAnimationActive) return {
					prevIsAnimationActive: nextProps.isAnimationActive,
					prevAnimationId: nextProps.animationId,
					curSectors: nextProps.sectors,
					prevSectors: [],
					isAnimationFinished: true
				};
				if (nextProps.isAnimationActive && nextProps.animationId !== prevState.prevAnimationId) return {
					prevAnimationId: nextProps.animationId,
					curSectors: nextProps.sectors,
					prevSectors: prevState.curSectors,
					isAnimationFinished: true
				};
				if (nextProps.sectors !== prevState.curSectors) return {
					curSectors: nextProps.sectors,
					isAnimationFinished: true
				};
				return null;
			}
		},
		{
			key: "getTextAnchor",
			value: function getTextAnchor(x, cx) {
				if (x > cx) return "start";
				if (x < cx) return "end";
				return "middle";
			}
		},
		{
			key: "renderLabelLineItem",
			value: function renderLabelLineItem(option, props, key) {
				if (/*#__PURE__*/ import_react.isValidElement(option)) return /*#__PURE__*/ import_react.cloneElement(option, props);
				if ((0, import_isFunction.default)(option)) return option(props);
				var className = clsx("recharts-pie-label-line", typeof option !== "boolean" ? option.className : "");
				return /*#__PURE__*/ import_react.createElement(Curve, _extends$23({}, props, {
					key,
					type: "linear",
					className
				}));
			}
		},
		{
			key: "renderLabelItem",
			value: function renderLabelItem(option, props, value) {
				if (/*#__PURE__*/ import_react.isValidElement(option)) return /*#__PURE__*/ import_react.cloneElement(option, props);
				var label = value;
				if ((0, import_isFunction.default)(option)) {
					label = option(props);
					if (/*#__PURE__*/ import_react.isValidElement(label)) return label;
				}
				var className = clsx("recharts-pie-label-text", typeof option !== "boolean" && !(0, import_isFunction.default)(option) ? option.className : "");
				return /*#__PURE__*/ import_react.createElement(Text, _extends$23({}, props, {
					alignmentBaseline: "middle",
					className
				}), label);
			}
		}
	]);
}(import_react.PureComponent);
_Pie = Pie;
_defineProperty$27(Pie, "displayName", "Pie");
_defineProperty$27(Pie, "defaultProps", {
	stroke: "#fff",
	fill: "#808080",
	legendType: "rect",
	cx: "50%",
	cy: "50%",
	startAngle: 0,
	endAngle: 360,
	innerRadius: 0,
	outerRadius: "80%",
	paddingAngle: 0,
	labelLine: true,
	hide: false,
	minAngle: 0,
	isAnimationActive: !Global.isSsr,
	animationBegin: 400,
	animationDuration: 1500,
	animationEasing: "ease",
	nameKey: "name",
	blendStroke: false,
	rootTabIndex: 0
});
_defineProperty$27(Pie, "parseDeltaAngle", function(startAngle, endAngle) {
	return mathSign(endAngle - startAngle) * Math.min(Math.abs(endAngle - startAngle), 360);
});
_defineProperty$27(Pie, "getRealPieData", function(itemProps) {
	var data = itemProps.data, children = itemProps.children;
	var presentationProps = filterProps(itemProps, false);
	var cells = findAllByType(children, Cell);
	if (data && data.length) return data.map(function(entry, index) {
		return _objectSpread$23(_objectSpread$23(_objectSpread$23({ payload: entry }, presentationProps), entry), cells && cells[index] && cells[index].props);
	});
	if (cells && cells.length) return cells.map(function(cell) {
		return _objectSpread$23(_objectSpread$23({}, presentationProps), cell.props);
	});
	return [];
});
_defineProperty$27(Pie, "parseCoordinateOfPie", function(itemProps, offset) {
	var top = offset.top, left = offset.left, width = offset.width, height = offset.height;
	var maxPieRadius = getMaxRadius(width, height);
	return {
		cx: left + getPercentValue(itemProps.cx, width, width / 2),
		cy: top + getPercentValue(itemProps.cy, height, height / 2),
		innerRadius: getPercentValue(itemProps.innerRadius, maxPieRadius, 0),
		outerRadius: getPercentValue(itemProps.outerRadius, maxPieRadius, maxPieRadius * .8),
		maxRadius: itemProps.maxRadius || Math.sqrt(width * width + height * height) / 2
	};
});
_defineProperty$27(Pie, "getComposedData", function(_ref4) {
	var item = _ref4.item, offset = _ref4.offset;
	var itemProps = item.type.defaultProps !== void 0 ? _objectSpread$23(_objectSpread$23({}, item.type.defaultProps), item.props) : item.props;
	var pieData = _Pie.getRealPieData(itemProps);
	if (!pieData || !pieData.length) return null;
	var cornerRadius = itemProps.cornerRadius, startAngle = itemProps.startAngle, endAngle = itemProps.endAngle, paddingAngle = itemProps.paddingAngle, dataKey = itemProps.dataKey, nameKey = itemProps.nameKey, valueKey = itemProps.valueKey, tooltipType = itemProps.tooltipType;
	var minAngle = Math.abs(itemProps.minAngle);
	var coordinate = _Pie.parseCoordinateOfPie(itemProps, offset);
	var deltaAngle = _Pie.parseDeltaAngle(startAngle, endAngle);
	var absDeltaAngle = Math.abs(deltaAngle);
	var realDataKey = dataKey;
	if ((0, import_isNil.default)(dataKey) && (0, import_isNil.default)(valueKey)) {
		warn(false, "Use \"dataKey\" to specify the value of pie,\n      the props \"valueKey\" will be deprecated in 1.1.0");
		realDataKey = "value";
	} else if ((0, import_isNil.default)(dataKey)) {
		warn(false, "Use \"dataKey\" to specify the value of pie,\n      the props \"valueKey\" will be deprecated in 1.1.0");
		realDataKey = valueKey;
	}
	var notZeroItemCount = pieData.filter(function(entry) {
		return getValueByDataKey(entry, realDataKey, 0) !== 0;
	}).length;
	var totalPadingAngle = (absDeltaAngle >= 360 ? notZeroItemCount : notZeroItemCount - 1) * paddingAngle;
	var realTotalAngle = absDeltaAngle - notZeroItemCount * minAngle - totalPadingAngle;
	var sum = pieData.reduce(function(result, entry) {
		var val = getValueByDataKey(entry, realDataKey, 0);
		return result + (isNumber$1(val) ? val : 0);
	}, 0);
	var sectors;
	if (sum > 0) {
		var prev;
		sectors = pieData.map(function(entry, i) {
			var val = getValueByDataKey(entry, realDataKey, 0);
			var name = getValueByDataKey(entry, nameKey, i);
			var percent = (isNumber$1(val) ? val : 0) / sum;
			var tempStartAngle;
			if (i) tempStartAngle = prev.endAngle + mathSign(deltaAngle) * paddingAngle * (val !== 0 ? 1 : 0);
			else tempStartAngle = startAngle;
			var tempEndAngle = tempStartAngle + mathSign(deltaAngle) * ((val !== 0 ? minAngle : 0) + percent * realTotalAngle);
			var midAngle = (tempStartAngle + tempEndAngle) / 2;
			var middleRadius = (coordinate.innerRadius + coordinate.outerRadius) / 2;
			prev = _objectSpread$23(_objectSpread$23(_objectSpread$23({
				percent,
				cornerRadius,
				name,
				tooltipPayload: [{
					name,
					value: val,
					payload: entry,
					dataKey: realDataKey,
					type: tooltipType
				}],
				midAngle,
				middleRadius,
				tooltipPosition: polarToCartesian(coordinate.cx, coordinate.cy, middleRadius, midAngle)
			}, entry), coordinate), {}, {
				value: getValueByDataKey(entry, realDataKey),
				startAngle: tempStartAngle,
				endAngle: tempEndAngle,
				payload: entry,
				paddingAngle: mathSign(deltaAngle) * paddingAngle
			});
			return prev;
		});
	}
	return _objectSpread$23(_objectSpread$23({}, coordinate), {}, {
		sectors,
		data: pieData
	});
});
//#endregion
//#region node_modules/recharts/es6/polar/Radar.js
/**
* @fileOverview Radar
*/
var import_first = /* @__PURE__ */ __toESM(require_first());
var _excluded$11 = ["key"];
function _typeof$26(o) {
	"@babel/helpers - typeof";
	return _typeof$26 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$26(o);
}
function _objectWithoutProperties$11(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$11(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$11(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
function _extends$22() {
	_extends$22 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$22.apply(this, arguments);
}
function ownKeys$22(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$22(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$22(Object(t), !0).forEach(function(r) {
			_defineProperty$26(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$22(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _classCallCheck$19(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$19(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$26(descriptor.key), descriptor);
	}
}
function _createClass$19(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$19(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$19(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$17(t, o, e) {
	return o = _getPrototypeOf$17(o), _possibleConstructorReturn$17(t, _isNativeReflectConstruct$17() ? Reflect.construct(o, e || [], _getPrototypeOf$17(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$17(self, call) {
	if (call && (_typeof$26(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$17(self);
}
function _assertThisInitialized$17(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$17() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$17 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$17(o) {
	_getPrototypeOf$17 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$17(o);
}
function _inherits$17(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$17(subClass, superClass);
}
function _setPrototypeOf$17(o, p) {
	_setPrototypeOf$17 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$17(o, p);
}
function _defineProperty$26(obj, key, value) {
	key = _toPropertyKey$26(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$26(t) {
	var i = _toPrimitive$26(t, "string");
	return "symbol" == _typeof$26(i) ? i : i + "";
}
function _toPrimitive$26(t, r) {
	if ("object" != _typeof$26(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$26(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var Radar = /*#__PURE__*/ function(_PureComponent) {
	function Radar() {
		var _this;
		_classCallCheck$19(this, Radar);
		for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
		_this = _callSuper$17(this, Radar, [].concat(args));
		_defineProperty$26(_this, "state", { isAnimationFinished: false });
		_defineProperty$26(_this, "handleAnimationEnd", function() {
			var onAnimationEnd = _this.props.onAnimationEnd;
			_this.setState({ isAnimationFinished: true });
			if ((0, import_isFunction.default)(onAnimationEnd)) onAnimationEnd();
		});
		_defineProperty$26(_this, "handleAnimationStart", function() {
			var onAnimationStart = _this.props.onAnimationStart;
			_this.setState({ isAnimationFinished: false });
			if ((0, import_isFunction.default)(onAnimationStart)) onAnimationStart();
		});
		_defineProperty$26(_this, "handleMouseEnter", function(e) {
			var onMouseEnter = _this.props.onMouseEnter;
			if (onMouseEnter) onMouseEnter(_this.props, e);
		});
		_defineProperty$26(_this, "handleMouseLeave", function(e) {
			var onMouseLeave = _this.props.onMouseLeave;
			if (onMouseLeave) onMouseLeave(_this.props, e);
		});
		return _this;
	}
	_inherits$17(Radar, _PureComponent);
	return _createClass$19(Radar, [
		{
			key: "renderDots",
			value: function renderDots(points) {
				var _this$props = this.props, dot = _this$props.dot, dataKey = _this$props.dataKey;
				var baseProps = filterProps(this.props, false);
				var customDotProps = filterProps(dot, true);
				var dots = points.map(function(entry, i) {
					var dotProps = _objectSpread$22(_objectSpread$22(_objectSpread$22({
						key: "dot-".concat(i),
						r: 3
					}, baseProps), customDotProps), {}, {
						dataKey,
						cx: entry.x,
						cy: entry.y,
						index: i,
						payload: entry
					});
					return Radar.renderDotItem(dot, dotProps);
				});
				return /*#__PURE__*/ import_react.createElement(Layer, { className: "recharts-radar-dots" }, dots);
			}
		},
		{
			key: "renderPolygonStatically",
			value: function renderPolygonStatically(points) {
				var _this$props2 = this.props, shape = _this$props2.shape, dot = _this$props2.dot, isRange = _this$props2.isRange, baseLinePoints = _this$props2.baseLinePoints, connectNulls = _this$props2.connectNulls;
				var radar;
				if (/*#__PURE__*/ import_react.isValidElement(shape)) radar = /*#__PURE__*/ import_react.cloneElement(shape, _objectSpread$22(_objectSpread$22({}, this.props), {}, { points }));
				else if ((0, import_isFunction.default)(shape)) radar = shape(_objectSpread$22(_objectSpread$22({}, this.props), {}, { points }));
				else radar = /*#__PURE__*/ import_react.createElement(Polygon, _extends$22({}, filterProps(this.props, true), {
					onMouseEnter: this.handleMouseEnter,
					onMouseLeave: this.handleMouseLeave,
					points,
					baseLinePoints: isRange ? baseLinePoints : null,
					connectNulls
				}));
				return /*#__PURE__*/ import_react.createElement(Layer, { className: "recharts-radar-polygon" }, radar, dot ? this.renderDots(points) : null);
			}
		},
		{
			key: "renderPolygonWithAnimation",
			value: function renderPolygonWithAnimation() {
				var _this2 = this;
				var _this$props3 = this.props, points = _this$props3.points, isAnimationActive = _this$props3.isAnimationActive, animationBegin = _this$props3.animationBegin, animationDuration = _this$props3.animationDuration, animationEasing = _this$props3.animationEasing, animationId = _this$props3.animationId;
				var prevPoints = this.state.prevPoints;
				return /*#__PURE__*/ import_react.createElement(es6_default, {
					begin: animationBegin,
					duration: animationDuration,
					isActive: isAnimationActive,
					easing: animationEasing,
					from: { t: 0 },
					to: { t: 1 },
					key: "radar-".concat(animationId),
					onAnimationEnd: this.handleAnimationEnd,
					onAnimationStart: this.handleAnimationStart
				}, function(_ref) {
					var t = _ref.t;
					var prevPointsDiffFactor = prevPoints && prevPoints.length / points.length;
					var stepData = points.map(function(entry, index) {
						var prev = prevPoints && prevPoints[Math.floor(index * prevPointsDiffFactor)];
						if (prev) {
							var _interpolatorX = interpolateNumber$1(prev.x, entry.x);
							var _interpolatorY = interpolateNumber$1(prev.y, entry.y);
							return _objectSpread$22(_objectSpread$22({}, entry), {}, {
								x: _interpolatorX(t),
								y: _interpolatorY(t)
							});
						}
						var interpolatorX = interpolateNumber$1(entry.cx, entry.x);
						var interpolatorY = interpolateNumber$1(entry.cy, entry.y);
						return _objectSpread$22(_objectSpread$22({}, entry), {}, {
							x: interpolatorX(t),
							y: interpolatorY(t)
						});
					});
					return _this2.renderPolygonStatically(stepData);
				});
			}
		},
		{
			key: "renderPolygon",
			value: function renderPolygon() {
				var _this$props4 = this.props, points = _this$props4.points, isAnimationActive = _this$props4.isAnimationActive, isRange = _this$props4.isRange;
				var prevPoints = this.state.prevPoints;
				if (isAnimationActive && points && points.length && !isRange && (!prevPoints || !(0, import_isEqual.default)(prevPoints, points))) return this.renderPolygonWithAnimation();
				return this.renderPolygonStatically(points);
			}
		},
		{
			key: "render",
			value: function render() {
				var _this$props5 = this.props, hide = _this$props5.hide, className = _this$props5.className, points = _this$props5.points, isAnimationActive = _this$props5.isAnimationActive;
				if (hide || !points || !points.length) return null;
				var isAnimationFinished = this.state.isAnimationFinished;
				var layerClass = clsx("recharts-radar", className);
				return /*#__PURE__*/ import_react.createElement(Layer, { className: layerClass }, this.renderPolygon(), (!isAnimationActive || isAnimationFinished) && LabelList.renderCallByParent(this.props, points));
			}
		}
	], [{
		key: "getDerivedStateFromProps",
		value: function getDerivedStateFromProps(nextProps, prevState) {
			if (nextProps.animationId !== prevState.prevAnimationId) return {
				prevAnimationId: nextProps.animationId,
				curPoints: nextProps.points,
				prevPoints: prevState.curPoints
			};
			if (nextProps.points !== prevState.curPoints) return { curPoints: nextProps.points };
			return null;
		}
	}, {
		key: "renderDotItem",
		value: function renderDotItem(option, props) {
			var dotItem;
			if (/*#__PURE__*/ import_react.isValidElement(option)) dotItem = /*#__PURE__*/ import_react.cloneElement(option, props);
			else if ((0, import_isFunction.default)(option)) dotItem = option(props);
			else {
				var key = props.key, dotProps = _objectWithoutProperties$11(props, _excluded$11);
				dotItem = /*#__PURE__*/ import_react.createElement(Dot, _extends$22({}, dotProps, {
					key,
					className: clsx("recharts-radar-dot", typeof option !== "boolean" ? option.className : "")
				}));
			}
			return dotItem;
		}
	}]);
}(import_react.PureComponent);
_defineProperty$26(Radar, "displayName", "Radar");
_defineProperty$26(Radar, "defaultProps", {
	angleAxisId: 0,
	radiusAxisId: 0,
	hide: false,
	activeDot: true,
	dot: false,
	legendType: "rect",
	isAnimationActive: !Global.isSsr,
	animationBegin: 0,
	animationDuration: 1500,
	animationEasing: "ease"
});
_defineProperty$26(Radar, "getComposedData", function(_ref2) {
	var radiusAxis = _ref2.radiusAxis, angleAxis = _ref2.angleAxis, displayedData = _ref2.displayedData, dataKey = _ref2.dataKey, bandSize = _ref2.bandSize;
	var cx = angleAxis.cx, cy = angleAxis.cy;
	var isRange = false;
	var points = [];
	var angleBandSize = angleAxis.type !== "number" ? bandSize !== null && bandSize !== void 0 ? bandSize : 0 : 0;
	displayedData.forEach(function(entry, i) {
		var name = getValueByDataKey(entry, angleAxis.dataKey, i);
		var value = getValueByDataKey(entry, dataKey);
		var angle = angleAxis.scale(name) + angleBandSize;
		var pointValue = Array.isArray(value) ? (0, import_last.default)(value) : value;
		var radius = (0, import_isNil.default)(pointValue) ? void 0 : radiusAxis.scale(pointValue);
		if (Array.isArray(value) && value.length >= 2) isRange = true;
		points.push(_objectSpread$22(_objectSpread$22({}, polarToCartesian(cx, cy, radius, angle)), {}, {
			name,
			value,
			cx,
			cy,
			radius,
			angle,
			payload: entry
		}));
	});
	var baseLinePoints = [];
	if (isRange) points.forEach(function(point) {
		if (Array.isArray(point.value)) {
			var baseValue = (0, import_first.default)(point.value);
			var radius = (0, import_isNil.default)(baseValue) ? void 0 : radiusAxis.scale(baseValue);
			baseLinePoints.push(_objectSpread$22(_objectSpread$22({}, point), {}, { radius }, polarToCartesian(cx, cy, radius, point.angle)));
		} else baseLinePoints.push(point);
	});
	return {
		points,
		isRange,
		baseLinePoints
	};
});
//#endregion
//#region node_modules/recharts/es6/util/RadialBarUtils.js
function _typeof$25(o) {
	"@babel/helpers - typeof";
	return _typeof$25 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$25(o);
}
function _extends$21() {
	_extends$21 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$21.apply(this, arguments);
}
function ownKeys$21(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$21(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$21(Object(t), !0).forEach(function(r) {
			_defineProperty$25(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$21(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$25(obj, key, value) {
	key = _toPropertyKey$25(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$25(t) {
	var i = _toPrimitive$25(t, "string");
	return "symbol" == _typeof$25(i) ? i : i + "";
}
function _toPrimitive$25(t, r) {
	if ("object" != _typeof$25(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$25(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function parseCornerRadius(cornerRadius) {
	if (typeof cornerRadius === "string") return parseInt(cornerRadius, 10);
	return cornerRadius;
}
function typeGuardSectorProps(option, props) {
	var cxValue = "".concat(props.cx || option.cx);
	var cx = Number(cxValue);
	var cyValue = "".concat(props.cy || option.cy);
	var cy = Number(cyValue);
	return _objectSpread$21(_objectSpread$21(_objectSpread$21({}, props), option), {}, {
		cx,
		cy
	});
}
function RadialBarSector(props) {
	return /*#__PURE__*/ import_react.createElement(Shape, _extends$21({
		shapeType: "sector",
		propTransformer: typeGuardSectorProps
	}, props));
}
//#endregion
//#region node_modules/recharts/es6/polar/RadialBar.js
/**
* @fileOverview Render a group of radial bar
*/
var _excluded$10 = [
	"shape",
	"activeShape",
	"activeIndex",
	"cornerRadius"
];
var _excluded2$6 = ["value", "background"];
function _typeof$24(o) {
	"@babel/helpers - typeof";
	return _typeof$24 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$24(o);
}
function _extends$20() {
	_extends$20 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$20.apply(this, arguments);
}
function ownKeys$20(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$20(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$20(Object(t), !0).forEach(function(r) {
			_defineProperty$24(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$20(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _objectWithoutProperties$10(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$10(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$10(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
function _classCallCheck$18(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$18(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$24(descriptor.key), descriptor);
	}
}
function _createClass$18(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$18(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$18(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$16(t, o, e) {
	return o = _getPrototypeOf$16(o), _possibleConstructorReturn$16(t, _isNativeReflectConstruct$16() ? Reflect.construct(o, e || [], _getPrototypeOf$16(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$16(self, call) {
	if (call && (_typeof$24(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$16(self);
}
function _assertThisInitialized$16(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$16() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$16 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$16(o) {
	_getPrototypeOf$16 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$16(o);
}
function _inherits$16(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$16(subClass, superClass);
}
function _setPrototypeOf$16(o, p) {
	_setPrototypeOf$16 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$16(o, p);
}
function _defineProperty$24(obj, key, value) {
	key = _toPropertyKey$24(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$24(t) {
	var i = _toPrimitive$24(t, "string");
	return "symbol" == _typeof$24(i) ? i : i + "";
}
function _toPrimitive$24(t, r) {
	if ("object" != _typeof$24(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$24(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var RadialBar = /*#__PURE__*/ function(_PureComponent) {
	function RadialBar() {
		var _this;
		_classCallCheck$18(this, RadialBar);
		for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
		_this = _callSuper$16(this, RadialBar, [].concat(args));
		_defineProperty$24(_this, "state", { isAnimationFinished: false });
		_defineProperty$24(_this, "handleAnimationEnd", function() {
			var onAnimationEnd = _this.props.onAnimationEnd;
			_this.setState({ isAnimationFinished: true });
			if ((0, import_isFunction.default)(onAnimationEnd)) onAnimationEnd();
		});
		_defineProperty$24(_this, "handleAnimationStart", function() {
			var onAnimationStart = _this.props.onAnimationStart;
			_this.setState({ isAnimationFinished: false });
			if ((0, import_isFunction.default)(onAnimationStart)) onAnimationStart();
		});
		return _this;
	}
	_inherits$16(RadialBar, _PureComponent);
	return _createClass$18(RadialBar, [
		{
			key: "getDeltaAngle",
			value: function getDeltaAngle() {
				var _this$props = this.props, startAngle = _this$props.startAngle, endAngle = _this$props.endAngle;
				return mathSign(endAngle - startAngle) * Math.min(Math.abs(endAngle - startAngle), 360);
			}
		},
		{
			key: "renderSectorsStatically",
			value: function renderSectorsStatically(sectors) {
				var _this2 = this;
				var _this$props2 = this.props, shape = _this$props2.shape, activeShape = _this$props2.activeShape, activeIndex = _this$props2.activeIndex, cornerRadius = _this$props2.cornerRadius, others = _objectWithoutProperties$10(_this$props2, _excluded$10);
				var baseProps = filterProps(others, false);
				return sectors.map(function(entry, i) {
					var isActive = i === activeIndex;
					var props = _objectSpread$20(_objectSpread$20(_objectSpread$20(_objectSpread$20({}, baseProps), {}, { cornerRadius: parseCornerRadius(cornerRadius) }, entry), adaptEventsOfChild(_this2.props, entry, i)), {}, {
						className: "recharts-radial-bar-sector ".concat(entry.className),
						forceCornerRadius: others.forceCornerRadius,
						cornerIsExternal: others.cornerIsExternal,
						isActive,
						option: isActive ? activeShape : shape
					});
					return /*#__PURE__*/ import_react.createElement(RadialBarSector, _extends$20({}, props, { key: "sector-".concat(i) }));
				});
			}
		},
		{
			key: "renderSectorsWithAnimation",
			value: function renderSectorsWithAnimation() {
				var _this3 = this;
				var _this$props3 = this.props, data = _this$props3.data, isAnimationActive = _this$props3.isAnimationActive, animationBegin = _this$props3.animationBegin, animationDuration = _this$props3.animationDuration, animationEasing = _this$props3.animationEasing, animationId = _this$props3.animationId;
				var prevData = this.state.prevData;
				return /*#__PURE__*/ import_react.createElement(es6_default, {
					begin: animationBegin,
					duration: animationDuration,
					isActive: isAnimationActive,
					easing: animationEasing,
					from: { t: 0 },
					to: { t: 1 },
					key: "radialBar-".concat(animationId),
					onAnimationStart: this.handleAnimationStart,
					onAnimationEnd: this.handleAnimationEnd
				}, function(_ref) {
					var t = _ref.t;
					var stepData = data.map(function(entry, index) {
						var prev = prevData && prevData[index];
						if (prev) {
							var interpolatorStartAngle = interpolateNumber$1(prev.startAngle, entry.startAngle);
							var interpolatorEndAngle = interpolateNumber$1(prev.endAngle, entry.endAngle);
							return _objectSpread$20(_objectSpread$20({}, entry), {}, {
								startAngle: interpolatorStartAngle(t),
								endAngle: interpolatorEndAngle(t)
							});
						}
						var endAngle = entry.endAngle, startAngle = entry.startAngle;
						var interpolator = interpolateNumber$1(startAngle, endAngle);
						return _objectSpread$20(_objectSpread$20({}, entry), {}, { endAngle: interpolator(t) });
					});
					return /*#__PURE__*/ import_react.createElement(Layer, null, _this3.renderSectorsStatically(stepData));
				});
			}
		},
		{
			key: "renderSectors",
			value: function renderSectors() {
				var _this$props4 = this.props, data = _this$props4.data, isAnimationActive = _this$props4.isAnimationActive;
				var prevData = this.state.prevData;
				if (isAnimationActive && data && data.length && (!prevData || !(0, import_isEqual.default)(prevData, data))) return this.renderSectorsWithAnimation();
				return this.renderSectorsStatically(data);
			}
		},
		{
			key: "renderBackground",
			value: function renderBackground(sectors) {
				var _this4 = this;
				var cornerRadius = this.props.cornerRadius;
				var backgroundProps = filterProps(this.props.background, false);
				return sectors.map(function(entry, i) {
					entry.value;
					var background = entry.background, rest = _objectWithoutProperties$10(entry, _excluded2$6);
					if (!background) return null;
					var props = _objectSpread$20(_objectSpread$20(_objectSpread$20(_objectSpread$20(_objectSpread$20({ cornerRadius: parseCornerRadius(cornerRadius) }, rest), {}, { fill: "#eee" }, background), backgroundProps), adaptEventsOfChild(_this4.props, entry, i)), {}, {
						index: i,
						className: clsx("recharts-radial-bar-background-sector", backgroundProps === null || backgroundProps === void 0 ? void 0 : backgroundProps.className),
						option: background,
						isActive: false
					});
					return /*#__PURE__*/ import_react.createElement(RadialBarSector, _extends$20({}, props, { key: "sector-".concat(i) }));
				});
			}
		},
		{
			key: "render",
			value: function render() {
				var _this$props5 = this.props, hide = _this$props5.hide, data = _this$props5.data, className = _this$props5.className, background = _this$props5.background, isAnimationActive = _this$props5.isAnimationActive;
				if (hide || !data || !data.length) return null;
				var isAnimationFinished = this.state.isAnimationFinished;
				var layerClass = clsx("recharts-area", className);
				return /*#__PURE__*/ import_react.createElement(Layer, { className: layerClass }, background && /*#__PURE__*/ import_react.createElement(Layer, { className: "recharts-radial-bar-background" }, this.renderBackground(data)), /*#__PURE__*/ import_react.createElement(Layer, { className: "recharts-radial-bar-sectors" }, this.renderSectors()), (!isAnimationActive || isAnimationFinished) && LabelList.renderCallByParent(_objectSpread$20({}, this.props), data));
			}
		}
	], [{
		key: "getDerivedStateFromProps",
		value: function getDerivedStateFromProps(nextProps, prevState) {
			if (nextProps.animationId !== prevState.prevAnimationId) return {
				prevAnimationId: nextProps.animationId,
				curData: nextProps.data,
				prevData: prevState.curData
			};
			if (nextProps.data !== prevState.curData) return { curData: nextProps.data };
			return null;
		}
	}]);
}(import_react.PureComponent);
_defineProperty$24(RadialBar, "displayName", "RadialBar");
_defineProperty$24(RadialBar, "defaultProps", {
	angleAxisId: 0,
	radiusAxisId: 0,
	minPointSize: 0,
	hide: false,
	legendType: "rect",
	data: [],
	isAnimationActive: !Global.isSsr,
	animationBegin: 0,
	animationDuration: 1500,
	animationEasing: "ease",
	forceCornerRadius: false,
	cornerIsExternal: false
});
_defineProperty$24(RadialBar, "getComposedData", function(_ref2) {
	var item = _ref2.item, props = _ref2.props, radiusAxis = _ref2.radiusAxis, radiusAxisTicks = _ref2.radiusAxisTicks, angleAxis = _ref2.angleAxis, angleAxisTicks = _ref2.angleAxisTicks, displayedData = _ref2.displayedData, dataKey = _ref2.dataKey, stackedData = _ref2.stackedData, barPosition = _ref2.barPosition, bandSize = _ref2.bandSize, dataStartIndex = _ref2.dataStartIndex;
	var pos = findPositionOfBar(barPosition, item);
	if (!pos) return null;
	var cx = angleAxis.cx, cy = angleAxis.cy;
	var layout = props.layout;
	var _item$props = item.props, children = _item$props.children, minPointSize = _item$props.minPointSize;
	var numericAxis = layout === "radial" ? angleAxis : radiusAxis;
	var stackedDomain = stackedData ? numericAxis.scale.domain() : null;
	var baseValue = getBaseValueOfBar({ numericAxis });
	var cells = findAllByType(children, Cell);
	return {
		data: displayedData.map(function(entry, index) {
			var value, innerRadius, outerRadius, startAngle, endAngle, backgroundSector;
			if (stackedData) value = truncateByDomain(stackedData[dataStartIndex + index], stackedDomain);
			else {
				value = getValueByDataKey(entry, dataKey);
				if (!Array.isArray(value)) value = [baseValue, value];
			}
			if (layout === "radial") {
				innerRadius = getCateCoordinateOfBar({
					axis: radiusAxis,
					ticks: radiusAxisTicks,
					bandSize,
					offset: pos.offset,
					entry,
					index
				});
				endAngle = angleAxis.scale(value[1]);
				startAngle = angleAxis.scale(value[0]);
				outerRadius = innerRadius + pos.size;
				var deltaAngle = endAngle - startAngle;
				if (Math.abs(minPointSize) > 0 && Math.abs(deltaAngle) < Math.abs(minPointSize)) {
					var delta = mathSign(deltaAngle || minPointSize) * (Math.abs(minPointSize) - Math.abs(deltaAngle));
					endAngle += delta;
				}
				backgroundSector = { background: {
					cx,
					cy,
					innerRadius,
					outerRadius,
					startAngle: props.startAngle,
					endAngle: props.endAngle
				} };
			} else {
				innerRadius = radiusAxis.scale(value[0]);
				outerRadius = radiusAxis.scale(value[1]);
				startAngle = getCateCoordinateOfBar({
					axis: angleAxis,
					ticks: angleAxisTicks,
					bandSize,
					offset: pos.offset,
					entry,
					index
				});
				endAngle = startAngle + pos.size;
				var deltaRadius = outerRadius - innerRadius;
				if (Math.abs(minPointSize) > 0 && Math.abs(deltaRadius) < Math.abs(minPointSize)) {
					var _delta = mathSign(deltaRadius || minPointSize) * (Math.abs(minPointSize) - Math.abs(deltaRadius));
					outerRadius += _delta;
				}
			}
			return _objectSpread$20(_objectSpread$20(_objectSpread$20(_objectSpread$20({}, entry), backgroundSector), {}, {
				payload: entry,
				value: stackedData ? value : value[1],
				cx,
				cy,
				innerRadius,
				outerRadius,
				startAngle,
				endAngle
			}, cells && cells[index] && cells[index].props), {}, {
				tooltipPayload: [getTooltipItem(item, entry)],
				tooltipPosition: polarToCartesian(cx, cy, (innerRadius + outerRadius) / 2, (startAngle + endAngle) / 2)
			});
		}),
		layout
	};
});
//#endregion
//#region node_modules/recharts/es6/util/CssPrefixUtils.js
var import_range = /* @__PURE__ */ __toESM(require_range());
function _typeof$23(o) {
	"@babel/helpers - typeof";
	return _typeof$23 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$23(o);
}
function ownKeys$19(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$19(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$19(Object(t), !0).forEach(function(r) {
			_defineProperty$23(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$19(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$23(obj, key, value) {
	key = _toPropertyKey$23(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$23(t) {
	var i = _toPrimitive$23(t, "string");
	return "symbol" == _typeof$23(i) ? i : i + "";
}
function _toPrimitive$23(t, r) {
	if ("object" != _typeof$23(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$23(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var PREFIX_LIST = [
	"Webkit",
	"Moz",
	"O",
	"ms"
];
var generatePrefixStyle = function generatePrefixStyle(name, value) {
	if (!name) return null;
	var camelName = name.replace(/(\w)/, function(v) {
		return v.toUpperCase();
	});
	var result = PREFIX_LIST.reduce(function(res, entry) {
		return _objectSpread$19(_objectSpread$19({}, res), {}, _defineProperty$23({}, entry + camelName, value));
	}, {});
	result[name] = value;
	return result;
};
//#endregion
//#region node_modules/recharts/es6/cartesian/Brush.js
/**
* @fileOverview Brush
*/
function _typeof$22(o) {
	"@babel/helpers - typeof";
	return _typeof$22 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$22(o);
}
function _extends$19() {
	_extends$19 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$19.apply(this, arguments);
}
function ownKeys$18(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$18(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$18(Object(t), !0).forEach(function(r) {
			_defineProperty$22(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$18(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _classCallCheck$17(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$17(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$22(descriptor.key), descriptor);
	}
}
function _createClass$17(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$17(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$17(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$15(t, o, e) {
	return o = _getPrototypeOf$15(o), _possibleConstructorReturn$15(t, _isNativeReflectConstruct$15() ? Reflect.construct(o, e || [], _getPrototypeOf$15(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$15(self, call) {
	if (call && (_typeof$22(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$15(self);
}
function _assertThisInitialized$15(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$15() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$15 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$15(o) {
	_getPrototypeOf$15 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$15(o);
}
function _inherits$15(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$15(subClass, superClass);
}
function _setPrototypeOf$15(o, p) {
	_setPrototypeOf$15 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$15(o, p);
}
function _defineProperty$22(obj, key, value) {
	key = _toPropertyKey$22(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$22(t) {
	var i = _toPrimitive$22(t, "string");
	return "symbol" == _typeof$22(i) ? i : i + "";
}
function _toPrimitive$22(t, r) {
	if ("object" != _typeof$22(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$22(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var createScale = function createScale(_ref) {
	var data = _ref.data, startIndex = _ref.startIndex, endIndex = _ref.endIndex, x = _ref.x, width = _ref.width, travellerWidth = _ref.travellerWidth;
	if (!data || !data.length) return {};
	var len = data.length;
	var scale = point().domain((0, import_range.default)(0, len)).range([x, x + width - travellerWidth]);
	var scaleValues = scale.domain().map(function(entry) {
		return scale(entry);
	});
	return {
		isTextActive: false,
		isSlideMoving: false,
		isTravellerMoving: false,
		isTravellerFocused: false,
		startX: scale(startIndex),
		endX: scale(endIndex),
		scale,
		scaleValues
	};
};
var isTouch = function isTouch(e) {
	return e.changedTouches && !!e.changedTouches.length;
};
var Brush = /*#__PURE__*/ function(_PureComponent) {
	function Brush(props) {
		var _this;
		_classCallCheck$17(this, Brush);
		_this = _callSuper$15(this, Brush, [props]);
		_defineProperty$22(_this, "handleDrag", function(e) {
			if (_this.leaveTimer) {
				clearTimeout(_this.leaveTimer);
				_this.leaveTimer = null;
			}
			if (_this.state.isTravellerMoving) _this.handleTravellerMove(e);
			else if (_this.state.isSlideMoving) _this.handleSlideDrag(e);
		});
		_defineProperty$22(_this, "handleTouchMove", function(e) {
			if (e.changedTouches != null && e.changedTouches.length > 0) _this.handleDrag(e.changedTouches[0]);
		});
		_defineProperty$22(_this, "handleDragEnd", function() {
			_this.setState({
				isTravellerMoving: false,
				isSlideMoving: false
			}, function() {
				var _this$props = _this.props, endIndex = _this$props.endIndex, onDragEnd = _this$props.onDragEnd, startIndex = _this$props.startIndex;
				onDragEnd === null || onDragEnd === void 0 || onDragEnd({
					endIndex,
					startIndex
				});
			});
			_this.detachDragEndListener();
		});
		_defineProperty$22(_this, "handleLeaveWrapper", function() {
			if (_this.state.isTravellerMoving || _this.state.isSlideMoving) _this.leaveTimer = window.setTimeout(_this.handleDragEnd, _this.props.leaveTimeOut);
		});
		_defineProperty$22(_this, "handleEnterSlideOrTraveller", function() {
			_this.setState({ isTextActive: true });
		});
		_defineProperty$22(_this, "handleLeaveSlideOrTraveller", function() {
			_this.setState({ isTextActive: false });
		});
		_defineProperty$22(_this, "handleSlideDragStart", function(e) {
			var event = isTouch(e) ? e.changedTouches[0] : e;
			_this.setState({
				isTravellerMoving: false,
				isSlideMoving: true,
				slideMoveStartX: event.pageX
			});
			_this.attachDragEndListener();
		});
		_this.travellerDragStartHandlers = {
			startX: _this.handleTravellerDragStart.bind(_this, "startX"),
			endX: _this.handleTravellerDragStart.bind(_this, "endX")
		};
		_this.state = {};
		return _this;
	}
	_inherits$15(Brush, _PureComponent);
	return _createClass$17(Brush, [
		{
			key: "componentWillUnmount",
			value: function componentWillUnmount() {
				if (this.leaveTimer) {
					clearTimeout(this.leaveTimer);
					this.leaveTimer = null;
				}
				this.detachDragEndListener();
			}
		},
		{
			key: "getIndex",
			value: function getIndex(_ref2) {
				var startX = _ref2.startX, endX = _ref2.endX;
				var scaleValues = this.state.scaleValues;
				var _this$props2 = this.props, gap = _this$props2.gap;
				var lastIndex = _this$props2.data.length - 1;
				var min = Math.min(startX, endX);
				var max = Math.max(startX, endX);
				var minIndex = Brush.getIndexInRange(scaleValues, min);
				var maxIndex = Brush.getIndexInRange(scaleValues, max);
				return {
					startIndex: minIndex - minIndex % gap,
					endIndex: maxIndex === lastIndex ? lastIndex : maxIndex - maxIndex % gap
				};
			}
		},
		{
			key: "getTextOfTick",
			value: function getTextOfTick(index) {
				var _this$props3 = this.props, data = _this$props3.data, tickFormatter = _this$props3.tickFormatter, dataKey = _this$props3.dataKey;
				var text = getValueByDataKey(data[index], dataKey, index);
				return (0, import_isFunction.default)(tickFormatter) ? tickFormatter(text, index) : text;
			}
		},
		{
			key: "attachDragEndListener",
			value: function attachDragEndListener() {
				window.addEventListener("mouseup", this.handleDragEnd, true);
				window.addEventListener("touchend", this.handleDragEnd, true);
				window.addEventListener("mousemove", this.handleDrag, true);
			}
		},
		{
			key: "detachDragEndListener",
			value: function detachDragEndListener() {
				window.removeEventListener("mouseup", this.handleDragEnd, true);
				window.removeEventListener("touchend", this.handleDragEnd, true);
				window.removeEventListener("mousemove", this.handleDrag, true);
			}
		},
		{
			key: "handleSlideDrag",
			value: function handleSlideDrag(e) {
				var _this$state = this.state, slideMoveStartX = _this$state.slideMoveStartX, startX = _this$state.startX, endX = _this$state.endX;
				var _this$props4 = this.props, x = _this$props4.x, width = _this$props4.width, travellerWidth = _this$props4.travellerWidth, startIndex = _this$props4.startIndex, endIndex = _this$props4.endIndex, onChange = _this$props4.onChange;
				var delta = e.pageX - slideMoveStartX;
				if (delta > 0) delta = Math.min(delta, x + width - travellerWidth - endX, x + width - travellerWidth - startX);
				else if (delta < 0) delta = Math.max(delta, x - startX, x - endX);
				var newIndex = this.getIndex({
					startX: startX + delta,
					endX: endX + delta
				});
				if ((newIndex.startIndex !== startIndex || newIndex.endIndex !== endIndex) && onChange) onChange(newIndex);
				this.setState({
					startX: startX + delta,
					endX: endX + delta,
					slideMoveStartX: e.pageX
				});
			}
		},
		{
			key: "handleTravellerDragStart",
			value: function handleTravellerDragStart(id, e) {
				var event = isTouch(e) ? e.changedTouches[0] : e;
				this.setState({
					isSlideMoving: false,
					isTravellerMoving: true,
					movingTravellerId: id,
					brushMoveStartX: event.pageX
				});
				this.attachDragEndListener();
			}
		},
		{
			key: "handleTravellerMove",
			value: function handleTravellerMove(e) {
				var _this$state2 = this.state, brushMoveStartX = _this$state2.brushMoveStartX, movingTravellerId = _this$state2.movingTravellerId, endX = _this$state2.endX, startX = _this$state2.startX;
				var prevValue = this.state[movingTravellerId];
				var _this$props5 = this.props, x = _this$props5.x, width = _this$props5.width, travellerWidth = _this$props5.travellerWidth, onChange = _this$props5.onChange, gap = _this$props5.gap, data = _this$props5.data;
				var params = {
					startX: this.state.startX,
					endX: this.state.endX
				};
				var delta = e.pageX - brushMoveStartX;
				if (delta > 0) delta = Math.min(delta, x + width - travellerWidth - prevValue);
				else if (delta < 0) delta = Math.max(delta, x - prevValue);
				params[movingTravellerId] = prevValue + delta;
				var newIndex = this.getIndex(params);
				var startIndex = newIndex.startIndex, endIndex = newIndex.endIndex;
				var isFullGap = function isFullGap() {
					var lastIndex = data.length - 1;
					if (movingTravellerId === "startX" && (endX > startX ? startIndex % gap === 0 : endIndex % gap === 0) || endX < startX && endIndex === lastIndex || movingTravellerId === "endX" && (endX > startX ? endIndex % gap === 0 : startIndex % gap === 0) || endX > startX && endIndex === lastIndex) return true;
					return false;
				};
				this.setState(_defineProperty$22(_defineProperty$22({}, movingTravellerId, prevValue + delta), "brushMoveStartX", e.pageX), function() {
					if (onChange) {
						if (isFullGap()) onChange(newIndex);
					}
				});
			}
		},
		{
			key: "handleTravellerMoveKeyboard",
			value: function handleTravellerMoveKeyboard(direction, id) {
				var _this2 = this;
				var _this$state3 = this.state, scaleValues = _this$state3.scaleValues, startX = _this$state3.startX, endX = _this$state3.endX;
				var currentScaleValue = this.state[id];
				var currentIndex = scaleValues.indexOf(currentScaleValue);
				if (currentIndex === -1) return;
				var newIndex = currentIndex + direction;
				if (newIndex === -1 || newIndex >= scaleValues.length) return;
				var newScaleValue = scaleValues[newIndex];
				if (id === "startX" && newScaleValue >= endX || id === "endX" && newScaleValue <= startX) return;
				this.setState(_defineProperty$22({}, id, newScaleValue), function() {
					_this2.props.onChange(_this2.getIndex({
						startX: _this2.state.startX,
						endX: _this2.state.endX
					}));
				});
			}
		},
		{
			key: "renderBackground",
			value: function renderBackground() {
				var _this$props6 = this.props, x = _this$props6.x, y = _this$props6.y, width = _this$props6.width, height = _this$props6.height, fill = _this$props6.fill, stroke = _this$props6.stroke;
				return /*#__PURE__*/ import_react.createElement("rect", {
					stroke,
					fill,
					x,
					y,
					width,
					height
				});
			}
		},
		{
			key: "renderPanorama",
			value: function renderPanorama() {
				var _this$props7 = this.props, x = _this$props7.x, y = _this$props7.y, width = _this$props7.width, height = _this$props7.height, data = _this$props7.data, children = _this$props7.children, padding = _this$props7.padding;
				var chartElement = import_react.Children.only(children);
				if (!chartElement) return null;
				return /*#__PURE__*/ import_react.cloneElement(chartElement, {
					x,
					y,
					width,
					height,
					margin: padding,
					compact: true,
					data
				});
			}
		},
		{
			key: "renderTravellerLayer",
			value: function renderTravellerLayer(travellerX, id) {
				var _data$startIndex, _data$endIndex, _this3 = this;
				var _this$props8 = this.props, y = _this$props8.y, travellerWidth = _this$props8.travellerWidth, height = _this$props8.height, traveller = _this$props8.traveller, ariaLabel = _this$props8.ariaLabel, data = _this$props8.data, startIndex = _this$props8.startIndex, endIndex = _this$props8.endIndex;
				var x = Math.max(travellerX, this.props.x);
				var travellerProps = _objectSpread$18(_objectSpread$18({}, filterProps(this.props, false)), {}, {
					x,
					y,
					width: travellerWidth,
					height
				});
				var ariaLabelBrush = ariaLabel || "Min value: ".concat((_data$startIndex = data[startIndex]) === null || _data$startIndex === void 0 ? void 0 : _data$startIndex.name, ", Max value: ").concat((_data$endIndex = data[endIndex]) === null || _data$endIndex === void 0 ? void 0 : _data$endIndex.name);
				return /*#__PURE__*/ import_react.createElement(Layer, {
					tabIndex: 0,
					role: "slider",
					"aria-label": ariaLabelBrush,
					"aria-valuenow": travellerX,
					className: "recharts-brush-traveller",
					onMouseEnter: this.handleEnterSlideOrTraveller,
					onMouseLeave: this.handleLeaveSlideOrTraveller,
					onMouseDown: this.travellerDragStartHandlers[id],
					onTouchStart: this.travellerDragStartHandlers[id],
					onKeyDown: function onKeyDown(e) {
						if (!["ArrowLeft", "ArrowRight"].includes(e.key)) return;
						e.preventDefault();
						e.stopPropagation();
						_this3.handleTravellerMoveKeyboard(e.key === "ArrowRight" ? 1 : -1, id);
					},
					onFocus: function onFocus() {
						_this3.setState({ isTravellerFocused: true });
					},
					onBlur: function onBlur() {
						_this3.setState({ isTravellerFocused: false });
					},
					style: { cursor: "col-resize" }
				}, Brush.renderTraveller(traveller, travellerProps));
			}
		},
		{
			key: "renderSlide",
			value: function renderSlide(startX, endX) {
				var _this$props9 = this.props, y = _this$props9.y, height = _this$props9.height, stroke = _this$props9.stroke, travellerWidth = _this$props9.travellerWidth;
				var x = Math.min(startX, endX) + travellerWidth;
				var width = Math.max(Math.abs(endX - startX) - travellerWidth, 0);
				return /*#__PURE__*/ import_react.createElement("rect", {
					className: "recharts-brush-slide",
					onMouseEnter: this.handleEnterSlideOrTraveller,
					onMouseLeave: this.handleLeaveSlideOrTraveller,
					onMouseDown: this.handleSlideDragStart,
					onTouchStart: this.handleSlideDragStart,
					style: { cursor: "move" },
					stroke: "none",
					fill: stroke,
					fillOpacity: .2,
					x,
					y,
					width,
					height
				});
			}
		},
		{
			key: "renderText",
			value: function renderText() {
				var _this$props10 = this.props, startIndex = _this$props10.startIndex, endIndex = _this$props10.endIndex, y = _this$props10.y, height = _this$props10.height, travellerWidth = _this$props10.travellerWidth, stroke = _this$props10.stroke;
				var _this$state4 = this.state, startX = _this$state4.startX, endX = _this$state4.endX;
				var offset = 5;
				var attrs = {
					pointerEvents: "none",
					fill: stroke
				};
				return /*#__PURE__*/ import_react.createElement(Layer, { className: "recharts-brush-texts" }, /*#__PURE__*/ import_react.createElement(Text, _extends$19({
					textAnchor: "end",
					verticalAnchor: "middle",
					x: Math.min(startX, endX) - offset,
					y: y + height / 2
				}, attrs), this.getTextOfTick(startIndex)), /*#__PURE__*/ import_react.createElement(Text, _extends$19({
					textAnchor: "start",
					verticalAnchor: "middle",
					x: Math.max(startX, endX) + travellerWidth + offset,
					y: y + height / 2
				}, attrs), this.getTextOfTick(endIndex)));
			}
		},
		{
			key: "render",
			value: function render() {
				var _this$props11 = this.props, data = _this$props11.data, className = _this$props11.className, children = _this$props11.children, x = _this$props11.x, y = _this$props11.y, width = _this$props11.width, height = _this$props11.height, alwaysShowText = _this$props11.alwaysShowText;
				var _this$state5 = this.state, startX = _this$state5.startX, endX = _this$state5.endX, isTextActive = _this$state5.isTextActive, isSlideMoving = _this$state5.isSlideMoving, isTravellerMoving = _this$state5.isTravellerMoving, isTravellerFocused = _this$state5.isTravellerFocused;
				if (!data || !data.length || !isNumber$1(x) || !isNumber$1(y) || !isNumber$1(width) || !isNumber$1(height) || width <= 0 || height <= 0) return null;
				var layerClass = clsx("recharts-brush", className);
				var isPanoramic = import_react.Children.count(children) === 1;
				var style = generatePrefixStyle("userSelect", "none");
				return /*#__PURE__*/ import_react.createElement(Layer, {
					className: layerClass,
					onMouseLeave: this.handleLeaveWrapper,
					onTouchMove: this.handleTouchMove,
					style
				}, this.renderBackground(), isPanoramic && this.renderPanorama(), this.renderSlide(startX, endX), this.renderTravellerLayer(startX, "startX"), this.renderTravellerLayer(endX, "endX"), (isTextActive || isSlideMoving || isTravellerMoving || isTravellerFocused || alwaysShowText) && this.renderText());
			}
		}
	], [
		{
			key: "renderDefaultTraveller",
			value: function renderDefaultTraveller(props) {
				var x = props.x, y = props.y, width = props.width, height = props.height, stroke = props.stroke;
				var lineY = Math.floor(y + height / 2) - 1;
				return /*#__PURE__*/ import_react.createElement(import_react.Fragment, null, /*#__PURE__*/ import_react.createElement("rect", {
					x,
					y,
					width,
					height,
					fill: stroke,
					stroke: "none"
				}), /*#__PURE__*/ import_react.createElement("line", {
					x1: x + 1,
					y1: lineY,
					x2: x + width - 1,
					y2: lineY,
					fill: "none",
					stroke: "#fff"
				}), /*#__PURE__*/ import_react.createElement("line", {
					x1: x + 1,
					y1: lineY + 2,
					x2: x + width - 1,
					y2: lineY + 2,
					fill: "none",
					stroke: "#fff"
				}));
			}
		},
		{
			key: "renderTraveller",
			value: function renderTraveller(option, props) {
				var rectangle;
				if (/*#__PURE__*/ import_react.isValidElement(option)) rectangle = /*#__PURE__*/ import_react.cloneElement(option, props);
				else if ((0, import_isFunction.default)(option)) rectangle = option(props);
				else rectangle = Brush.renderDefaultTraveller(props);
				return rectangle;
			}
		},
		{
			key: "getDerivedStateFromProps",
			value: function getDerivedStateFromProps(nextProps, prevState) {
				var data = nextProps.data, width = nextProps.width, x = nextProps.x, travellerWidth = nextProps.travellerWidth, updateId = nextProps.updateId, startIndex = nextProps.startIndex, endIndex = nextProps.endIndex;
				if (data !== prevState.prevData || updateId !== prevState.prevUpdateId) return _objectSpread$18({
					prevData: data,
					prevTravellerWidth: travellerWidth,
					prevUpdateId: updateId,
					prevX: x,
					prevWidth: width
				}, data && data.length ? createScale({
					data,
					width,
					x,
					travellerWidth,
					startIndex,
					endIndex
				}) : {
					scale: null,
					scaleValues: null
				});
				if (prevState.scale && (width !== prevState.prevWidth || x !== prevState.prevX || travellerWidth !== prevState.prevTravellerWidth)) {
					prevState.scale.range([x, x + width - travellerWidth]);
					var scaleValues = prevState.scale.domain().map(function(entry) {
						return prevState.scale(entry);
					});
					return {
						prevData: data,
						prevTravellerWidth: travellerWidth,
						prevUpdateId: updateId,
						prevX: x,
						prevWidth: width,
						startX: prevState.scale(nextProps.startIndex),
						endX: prevState.scale(nextProps.endIndex),
						scaleValues
					};
				}
				return null;
			}
		},
		{
			key: "getIndexInRange",
			value: function getIndexInRange(valueRange, x) {
				var len = valueRange.length;
				var start = 0;
				var end = len - 1;
				while (end - start > 1) {
					var middle = Math.floor((start + end) / 2);
					if (valueRange[middle] > x) end = middle;
					else start = middle;
				}
				return x >= valueRange[end] ? end : start;
			}
		}
	]);
}(import_react.PureComponent);
_defineProperty$22(Brush, "displayName", "Brush");
_defineProperty$22(Brush, "defaultProps", {
	height: 40,
	travellerWidth: 5,
	gap: 1,
	fill: "#fff",
	stroke: "#666",
	padding: {
		top: 1,
		right: 1,
		bottom: 1,
		left: 1
	},
	leaveTimeOut: 1e3,
	alwaysShowText: false
});
//#endregion
//#region node_modules/recharts/es6/util/IfOverflowMatches.js
var import_some = /* @__PURE__ */ __toESM(require_some());
var ifOverflowMatches = function ifOverflowMatches(props, value) {
	var alwaysShow = props.alwaysShow;
	var ifOverflow = props.ifOverflow;
	if (alwaysShow) ifOverflow = "extendDomain";
	return ifOverflow === value;
};
//#endregion
//#region node_modules/recharts/es6/util/BarUtils.js
var import_mapValues = /* @__PURE__ */ __toESM(require_mapValues());
var import_every = /* @__PURE__ */ __toESM(require_every());
var _excluded$9 = ["x", "y"];
function _typeof$21(o) {
	"@babel/helpers - typeof";
	return _typeof$21 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$21(o);
}
function _extends$18() {
	_extends$18 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$18.apply(this, arguments);
}
function ownKeys$17(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$17(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$17(Object(t), !0).forEach(function(r) {
			_defineProperty$21(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$17(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$21(obj, key, value) {
	key = _toPropertyKey$21(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$21(t) {
	var i = _toPrimitive$21(t, "string");
	return "symbol" == _typeof$21(i) ? i : i + "";
}
function _toPrimitive$21(t, r) {
	if ("object" != _typeof$21(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$21(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _objectWithoutProperties$9(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$9(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$9(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
function typeguardBarRectangleProps(_ref, props) {
	var xProp = _ref.x, yProp = _ref.y, option = _objectWithoutProperties$9(_ref, _excluded$9);
	var xValue = "".concat(xProp);
	var x = parseInt(xValue, 10);
	var yValue = "".concat(yProp);
	var y = parseInt(yValue, 10);
	var heightValue = "".concat(props.height || option.height);
	var height = parseInt(heightValue, 10);
	var widthValue = "".concat(props.width || option.width);
	var width = parseInt(widthValue, 10);
	return _objectSpread$17(_objectSpread$17(_objectSpread$17(_objectSpread$17(_objectSpread$17({}, props), option), x ? { x } : {}), y ? { y } : {}), {}, {
		height,
		width,
		name: props.name,
		radius: props.radius
	});
}
function BarRectangle(props) {
	return /*#__PURE__*/ import_react.createElement(Shape, _extends$18({
		shapeType: "rectangle",
		propTransformer: typeguardBarRectangleProps,
		activeClassName: "recharts-active-bar"
	}, props));
}
/**
* Safely gets minPointSize from from the minPointSize prop if it is a function
* @param minPointSize minPointSize as passed to the Bar component
* @param defaultValue default minPointSize
* @returns minPointSize
*/
var minPointSizeCallback = function minPointSizeCallback(minPointSize) {
	var defaultValue = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0;
	return function(value, index) {
		if (typeof minPointSize === "number") return minPointSize;
		var isValueNumberOrNil = isNumber$1(value) || isNullish(value);
		if (isValueNumberOrNil) return minPointSize(value, index);
		!isValueNumberOrNil && invariant(false);
		return defaultValue;
	};
};
//#endregion
//#region node_modules/recharts/es6/cartesian/Bar.js
/**
* @fileOverview Render a group of bar
*/
var _excluded$8 = ["value", "background"];
var _Bar;
function _typeof$20(o) {
	"@babel/helpers - typeof";
	return _typeof$20 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$20(o);
}
function _objectWithoutProperties$8(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$8(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$8(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
function _extends$17() {
	_extends$17 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$17.apply(this, arguments);
}
function ownKeys$16(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$16(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$16(Object(t), !0).forEach(function(r) {
			_defineProperty$20(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$16(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _classCallCheck$16(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$16(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$20(descriptor.key), descriptor);
	}
}
function _createClass$16(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$16(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$16(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$14(t, o, e) {
	return o = _getPrototypeOf$14(o), _possibleConstructorReturn$14(t, _isNativeReflectConstruct$14() ? Reflect.construct(o, e || [], _getPrototypeOf$14(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$14(self, call) {
	if (call && (_typeof$20(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$14(self);
}
function _assertThisInitialized$14(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$14() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$14 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$14(o) {
	_getPrototypeOf$14 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$14(o);
}
function _inherits$14(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$14(subClass, superClass);
}
function _setPrototypeOf$14(o, p) {
	_setPrototypeOf$14 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$14(o, p);
}
function _defineProperty$20(obj, key, value) {
	key = _toPropertyKey$20(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$20(t) {
	var i = _toPrimitive$20(t, "string");
	return "symbol" == _typeof$20(i) ? i : i + "";
}
function _toPrimitive$20(t, r) {
	if ("object" != _typeof$20(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$20(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var Bar = /*#__PURE__*/ function(_PureComponent) {
	function Bar() {
		var _this;
		_classCallCheck$16(this, Bar);
		for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
		_this = _callSuper$14(this, Bar, [].concat(args));
		_defineProperty$20(_this, "state", { isAnimationFinished: false });
		_defineProperty$20(_this, "id", uniqueId("recharts-bar-"));
		_defineProperty$20(_this, "handleAnimationEnd", function() {
			var onAnimationEnd = _this.props.onAnimationEnd;
			_this.setState({ isAnimationFinished: true });
			if (onAnimationEnd) onAnimationEnd();
		});
		_defineProperty$20(_this, "handleAnimationStart", function() {
			var onAnimationStart = _this.props.onAnimationStart;
			_this.setState({ isAnimationFinished: false });
			if (onAnimationStart) onAnimationStart();
		});
		return _this;
	}
	_inherits$14(Bar, _PureComponent);
	return _createClass$16(Bar, [
		{
			key: "renderRectanglesStatically",
			value: function renderRectanglesStatically(data) {
				var _this2 = this;
				var _this$props = this.props, shape = _this$props.shape, dataKey = _this$props.dataKey, activeIndex = _this$props.activeIndex, activeBar = _this$props.activeBar;
				var baseProps = filterProps(this.props, false);
				return data && data.map(function(entry, i) {
					var isActive = i === activeIndex;
					var option = isActive ? activeBar : shape;
					var props = _objectSpread$16(_objectSpread$16(_objectSpread$16({}, baseProps), entry), {}, {
						isActive,
						option,
						index: i,
						dataKey,
						onAnimationStart: _this2.handleAnimationStart,
						onAnimationEnd: _this2.handleAnimationEnd
					});
					return /*#__PURE__*/ import_react.createElement(Layer, _extends$17({ className: "recharts-bar-rectangle" }, adaptEventsOfChild(_this2.props, entry, i), { key: "rectangle-".concat(entry === null || entry === void 0 ? void 0 : entry.x, "-").concat(entry === null || entry === void 0 ? void 0 : entry.y, "-").concat(entry === null || entry === void 0 ? void 0 : entry.value, "-").concat(i) }), /*#__PURE__*/ import_react.createElement(BarRectangle, props));
				});
			}
		},
		{
			key: "renderRectanglesWithAnimation",
			value: function renderRectanglesWithAnimation() {
				var _this3 = this;
				var _this$props2 = this.props, data = _this$props2.data, layout = _this$props2.layout, isAnimationActive = _this$props2.isAnimationActive, animationBegin = _this$props2.animationBegin, animationDuration = _this$props2.animationDuration, animationEasing = _this$props2.animationEasing, animationId = _this$props2.animationId;
				var prevData = this.state.prevData;
				return /*#__PURE__*/ import_react.createElement(es6_default, {
					begin: animationBegin,
					duration: animationDuration,
					isActive: isAnimationActive,
					easing: animationEasing,
					from: { t: 0 },
					to: { t: 1 },
					key: "bar-".concat(animationId),
					onAnimationEnd: this.handleAnimationEnd,
					onAnimationStart: this.handleAnimationStart
				}, function(_ref) {
					var t = _ref.t;
					var stepData = data.map(function(entry, index) {
						var prev = prevData && prevData[index];
						if (prev) {
							var interpolatorX = interpolateNumber$1(prev.x, entry.x);
							var interpolatorY = interpolateNumber$1(prev.y, entry.y);
							var interpolatorWidth = interpolateNumber$1(prev.width, entry.width);
							var interpolatorHeight = interpolateNumber$1(prev.height, entry.height);
							return _objectSpread$16(_objectSpread$16({}, entry), {}, {
								x: interpolatorX(t),
								y: interpolatorY(t),
								width: interpolatorWidth(t),
								height: interpolatorHeight(t)
							});
						}
						if (layout === "horizontal") {
							var h = interpolateNumber$1(0, entry.height)(t);
							return _objectSpread$16(_objectSpread$16({}, entry), {}, {
								y: entry.y + entry.height - h,
								height: h
							});
						}
						var w = interpolateNumber$1(0, entry.width)(t);
						return _objectSpread$16(_objectSpread$16({}, entry), {}, { width: w });
					});
					return /*#__PURE__*/ import_react.createElement(Layer, null, _this3.renderRectanglesStatically(stepData));
				});
			}
		},
		{
			key: "renderRectangles",
			value: function renderRectangles() {
				var _this$props3 = this.props, data = _this$props3.data, isAnimationActive = _this$props3.isAnimationActive;
				var prevData = this.state.prevData;
				if (isAnimationActive && data && data.length && (!prevData || !(0, import_isEqual.default)(prevData, data))) return this.renderRectanglesWithAnimation();
				return this.renderRectanglesStatically(data);
			}
		},
		{
			key: "renderBackground",
			value: function renderBackground() {
				var _this4 = this;
				var _this$props4 = this.props, data = _this$props4.data, dataKey = _this$props4.dataKey, activeIndex = _this$props4.activeIndex;
				var backgroundProps = filterProps(this.props.background, false);
				return data.map(function(entry, i) {
					entry.value;
					var background = entry.background, rest = _objectWithoutProperties$8(entry, _excluded$8);
					if (!background) return null;
					var props = _objectSpread$16(_objectSpread$16(_objectSpread$16(_objectSpread$16(_objectSpread$16({}, rest), {}, { fill: "#eee" }, background), backgroundProps), adaptEventsOfChild(_this4.props, entry, i)), {}, {
						onAnimationStart: _this4.handleAnimationStart,
						onAnimationEnd: _this4.handleAnimationEnd,
						dataKey,
						index: i,
						className: "recharts-bar-background-rectangle"
					});
					return /*#__PURE__*/ import_react.createElement(BarRectangle, _extends$17({
						key: "background-bar-".concat(i),
						option: _this4.props.background,
						isActive: i === activeIndex
					}, props));
				});
			}
		},
		{
			key: "renderErrorBar",
			value: function renderErrorBar(needClip, clipPathId) {
				if (this.props.isAnimationActive && !this.state.isAnimationFinished) return null;
				var _this$props5 = this.props, data = _this$props5.data, xAxis = _this$props5.xAxis, yAxis = _this$props5.yAxis, layout = _this$props5.layout, children = _this$props5.children;
				var errorBarItems = findAllByType(children, ErrorBar);
				if (!errorBarItems) return null;
				var offset = layout === "vertical" ? data[0].height / 2 : data[0].width / 2;
				var dataPointFormatter = function dataPointFormatter(dataPoint, dataKey) {
					/**
					* if the value coming from `getComposedData` is an array then this is a stacked bar chart.
					* arr[1] represents end value of the bar since the data is in the form of [startValue, endValue].
					* */
					var value = Array.isArray(dataPoint.value) ? dataPoint.value[1] : dataPoint.value;
					return {
						x: dataPoint.x,
						y: dataPoint.y,
						value,
						errorVal: getValueByDataKey(dataPoint, dataKey)
					};
				};
				var errorBarProps = { clipPath: needClip ? "url(#clipPath-".concat(clipPathId, ")") : null };
				return /*#__PURE__*/ import_react.createElement(Layer, errorBarProps, errorBarItems.map(function(item) {
					return /*#__PURE__*/ import_react.cloneElement(item, {
						key: "error-bar-".concat(clipPathId, "-").concat(item.props.dataKey),
						data,
						xAxis,
						yAxis,
						layout,
						offset,
						dataPointFormatter
					});
				}));
			}
		},
		{
			key: "render",
			value: function render() {
				var _this$props6 = this.props, hide = _this$props6.hide, data = _this$props6.data, className = _this$props6.className, xAxis = _this$props6.xAxis, yAxis = _this$props6.yAxis, left = _this$props6.left, top = _this$props6.top, width = _this$props6.width, height = _this$props6.height, isAnimationActive = _this$props6.isAnimationActive, background = _this$props6.background, id = _this$props6.id;
				if (hide || !data || !data.length) return null;
				var isAnimationFinished = this.state.isAnimationFinished;
				var layerClass = clsx("recharts-bar", className);
				var needClipX = xAxis && xAxis.allowDataOverflow;
				var needClipY = yAxis && yAxis.allowDataOverflow;
				var needClip = needClipX || needClipY;
				var clipPathId = (0, import_isNil.default)(id) ? this.id : id;
				return /*#__PURE__*/ import_react.createElement(Layer, { className: layerClass }, needClipX || needClipY ? /*#__PURE__*/ import_react.createElement("defs", null, /*#__PURE__*/ import_react.createElement("clipPath", { id: "clipPath-".concat(clipPathId) }, /*#__PURE__*/ import_react.createElement("rect", {
					x: needClipX ? left : left - width / 2,
					y: needClipY ? top : top - height / 2,
					width: needClipX ? width : width * 2,
					height: needClipY ? height : height * 2
				}))) : null, /*#__PURE__*/ import_react.createElement(Layer, {
					className: "recharts-bar-rectangles",
					clipPath: needClip ? "url(#clipPath-".concat(clipPathId, ")") : null
				}, background ? this.renderBackground() : null, this.renderRectangles()), this.renderErrorBar(needClip, clipPathId), (!isAnimationActive || isAnimationFinished) && LabelList.renderCallByParent(this.props, data));
			}
		}
	], [{
		key: "getDerivedStateFromProps",
		value: function getDerivedStateFromProps(nextProps, prevState) {
			if (nextProps.animationId !== prevState.prevAnimationId) return {
				prevAnimationId: nextProps.animationId,
				curData: nextProps.data,
				prevData: prevState.curData
			};
			if (nextProps.data !== prevState.curData) return { curData: nextProps.data };
			return null;
		}
	}]);
}(import_react.PureComponent);
_Bar = Bar;
_defineProperty$20(Bar, "displayName", "Bar");
_defineProperty$20(Bar, "defaultProps", {
	xAxisId: 0,
	yAxisId: 0,
	legendType: "rect",
	minPointSize: 0,
	hide: false,
	data: [],
	layout: "vertical",
	activeBar: false,
	isAnimationActive: !Global.isSsr,
	animationBegin: 0,
	animationDuration: 400,
	animationEasing: "ease"
});
/**
* Compose the data of each group
* @param {Object} props Props for the component
* @param {Object} item        An instance of Bar
* @param {Array} barPosition  The offset and size of each bar
* @param {Object} xAxis       The configuration of x-axis
* @param {Object} yAxis       The configuration of y-axis
* @param {Array} stackedData  The stacked data of a bar item
* @return{Array} Composed data
*/
_defineProperty$20(Bar, "getComposedData", function(_ref2) {
	var props = _ref2.props, item = _ref2.item, barPosition = _ref2.barPosition, bandSize = _ref2.bandSize, xAxis = _ref2.xAxis, yAxis = _ref2.yAxis, xAxisTicks = _ref2.xAxisTicks, yAxisTicks = _ref2.yAxisTicks, stackedData = _ref2.stackedData, dataStartIndex = _ref2.dataStartIndex, displayedData = _ref2.displayedData, offset = _ref2.offset;
	var pos = findPositionOfBar(barPosition, item);
	if (!pos) return null;
	var layout = props.layout;
	var itemDefaultProps = item.type.defaultProps;
	var itemProps = itemDefaultProps !== void 0 ? _objectSpread$16(_objectSpread$16({}, itemDefaultProps), item.props) : item.props;
	var dataKey = itemProps.dataKey, children = itemProps.children, minPointSizeProp = itemProps.minPointSize;
	var numericAxis = layout === "horizontal" ? yAxis : xAxis;
	var stackedDomain = stackedData ? numericAxis.scale.domain() : null;
	var baseValue = getBaseValueOfBar({ numericAxis });
	var cells = findAllByType(children, Cell);
	return _objectSpread$16({
		data: displayedData.map(function(entry, index) {
			var value, x, y, width, height, background;
			if (stackedData) value = truncateByDomain(stackedData[dataStartIndex + index], stackedDomain);
			else {
				value = getValueByDataKey(entry, dataKey);
				if (!Array.isArray(value)) value = [baseValue, value];
			}
			var minPointSize = minPointSizeCallback(minPointSizeProp, _Bar.defaultProps.minPointSize)(value[1], index);
			if (layout === "horizontal") {
				var _ref4;
				var _ref3 = [yAxis.scale(value[0]), yAxis.scale(value[1])], baseValueScale = _ref3[0], currentValueScale = _ref3[1];
				x = getCateCoordinateOfBar({
					axis: xAxis,
					ticks: xAxisTicks,
					bandSize,
					offset: pos.offset,
					entry,
					index
				});
				y = (_ref4 = currentValueScale !== null && currentValueScale !== void 0 ? currentValueScale : baseValueScale) !== null && _ref4 !== void 0 ? _ref4 : void 0;
				width = pos.size;
				var computedHeight = baseValueScale - currentValueScale;
				height = Number.isNaN(computedHeight) ? 0 : computedHeight;
				background = {
					x,
					y: yAxis.y,
					width,
					height: yAxis.height
				};
				if (Math.abs(minPointSize) > 0 && Math.abs(height) < Math.abs(minPointSize)) {
					var delta = mathSign(height || minPointSize) * (Math.abs(minPointSize) - Math.abs(height));
					y -= delta;
					height += delta;
				}
			} else {
				var _ref5 = [xAxis.scale(value[0]), xAxis.scale(value[1])], _baseValueScale = _ref5[0], _currentValueScale = _ref5[1];
				x = _baseValueScale;
				y = getCateCoordinateOfBar({
					axis: yAxis,
					ticks: yAxisTicks,
					bandSize,
					offset: pos.offset,
					entry,
					index
				});
				width = _currentValueScale - _baseValueScale;
				height = pos.size;
				background = {
					x: xAxis.x,
					y,
					width: xAxis.width,
					height
				};
				if (Math.abs(minPointSize) > 0 && Math.abs(width) < Math.abs(minPointSize)) {
					var _delta = mathSign(width || minPointSize) * (Math.abs(minPointSize) - Math.abs(width));
					width += _delta;
				}
			}
			return _objectSpread$16(_objectSpread$16(_objectSpread$16({}, entry), {}, {
				x,
				y,
				width,
				height,
				value: stackedData ? value : value[1],
				payload: entry,
				background
			}, cells && cells[index] && cells[index].props), {}, {
				tooltipPayload: [getTooltipItem(item, entry)],
				tooltipPosition: {
					x: x + width / 2,
					y: y + height / 2
				}
			});
		}),
		layout
	}, offset);
});
//#endregion
//#region node_modules/recharts/es6/util/CartesianUtils.js
function _typeof$19(o) {
	"@babel/helpers - typeof";
	return _typeof$19 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$19(o);
}
function _classCallCheck$15(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$15(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$19(descriptor.key), descriptor);
	}
}
function _createClass$15(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$15(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$15(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function ownKeys$15(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$15(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$15(Object(t), !0).forEach(function(r) {
			_defineProperty$19(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$15(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$19(obj, key, value) {
	key = _toPropertyKey$19(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$19(t) {
	var i = _toPrimitive$19(t, "string");
	return "symbol" == _typeof$19(i) ? i : i + "";
}
function _toPrimitive$19(t, r) {
	if ("object" != _typeof$19(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$19(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
/**
* Calculate the scale function, position, width, height of axes
* @param  {Object} props     Latest props
* @param  {Object} axisMap   The configuration of axes
* @param  {Object} offset    The offset of main part in the svg element
* @param  {String} axisType  The type of axes, x-axis or y-axis
* @param  {String} chartName The name of chart
* @return {Object} Configuration
*/
var formatAxisMap = function formatAxisMap(props, axisMap, offset, axisType, chartName) {
	var width = props.width, height = props.height, layout = props.layout, children = props.children;
	var ids = Object.keys(axisMap);
	var steps = {
		left: offset.left,
		leftMirror: offset.left,
		right: width - offset.right,
		rightMirror: width - offset.right,
		top: offset.top,
		topMirror: offset.top,
		bottom: height - offset.bottom,
		bottomMirror: height - offset.bottom
	};
	var hasBar = !!findChildByType(children, Bar);
	return ids.reduce(function(result, id) {
		var axis = axisMap[id];
		var orientation = axis.orientation, domain = axis.domain, _axis$padding = axis.padding, padding = _axis$padding === void 0 ? {} : _axis$padding, mirror = axis.mirror, reversed = axis.reversed;
		var offsetKey = "".concat(orientation).concat(mirror ? "Mirror" : "");
		var calculatedPadding, range, x, y, needSpace;
		if (axis.type === "number" && (axis.padding === "gap" || axis.padding === "no-gap")) {
			var diff = domain[1] - domain[0];
			var smallestDistanceBetweenValues = Infinity;
			var sortedValues = axis.categoricalDomain.sort(compareValues);
			sortedValues.forEach(function(value, index) {
				if (index > 0) smallestDistanceBetweenValues = Math.min((value || 0) - (sortedValues[index - 1] || 0), smallestDistanceBetweenValues);
			});
			if (Number.isFinite(smallestDistanceBetweenValues)) {
				var smallestDistanceInPercent = smallestDistanceBetweenValues / diff;
				var rangeWidth = axis.layout === "vertical" ? offset.height : offset.width;
				if (axis.padding === "gap") calculatedPadding = smallestDistanceInPercent * rangeWidth / 2;
				if (axis.padding === "no-gap") {
					var gap = getPercentValue(props.barCategoryGap, smallestDistanceInPercent * rangeWidth);
					var halfBand = smallestDistanceInPercent * rangeWidth / 2;
					calculatedPadding = halfBand - gap - (halfBand - gap) / rangeWidth * gap;
				}
			}
		}
		if (axisType === "xAxis") range = [offset.left + (padding.left || 0) + (calculatedPadding || 0), offset.left + offset.width - (padding.right || 0) - (calculatedPadding || 0)];
		else if (axisType === "yAxis") range = layout === "horizontal" ? [offset.top + offset.height - (padding.bottom || 0), offset.top + (padding.top || 0)] : [offset.top + (padding.top || 0) + (calculatedPadding || 0), offset.top + offset.height - (padding.bottom || 0) - (calculatedPadding || 0)];
		else range = axis.range;
		if (reversed) range = [range[1], range[0]];
		var _parseScale = parseScale(axis, chartName, hasBar), scale = _parseScale.scale, realScaleType = _parseScale.realScaleType;
		scale.domain(domain).range(range);
		checkDomainOfScale(scale);
		var ticks = getTicksOfScale(scale, _objectSpread$15(_objectSpread$15({}, axis), {}, { realScaleType }));
		if (axisType === "xAxis") {
			needSpace = orientation === "top" && !mirror || orientation === "bottom" && mirror;
			x = offset.left;
			y = steps[offsetKey] - needSpace * axis.height;
		} else if (axisType === "yAxis") {
			needSpace = orientation === "left" && !mirror || orientation === "right" && mirror;
			x = steps[offsetKey] - needSpace * axis.width;
			y = offset.top;
		}
		var finalAxis = _objectSpread$15(_objectSpread$15(_objectSpread$15({}, axis), ticks), {}, {
			realScaleType,
			x,
			y,
			scale,
			width: axisType === "xAxis" ? offset.width : axis.width,
			height: axisType === "yAxis" ? offset.height : axis.height
		});
		finalAxis.bandSize = getBandSizeOfAxis(finalAxis, ticks);
		if (!axis.hide && axisType === "xAxis") steps[offsetKey] += (needSpace ? -1 : 1) * finalAxis.height;
		else if (!axis.hide) steps[offsetKey] += (needSpace ? -1 : 1) * finalAxis.width;
		return _objectSpread$15(_objectSpread$15({}, result), {}, _defineProperty$19({}, id, finalAxis));
	}, {});
};
var rectWithPoints = function rectWithPoints(_ref, _ref2) {
	var x1 = _ref.x, y1 = _ref.y;
	var x2 = _ref2.x, y2 = _ref2.y;
	return {
		x: Math.min(x1, x2),
		y: Math.min(y1, y2),
		width: Math.abs(x2 - x1),
		height: Math.abs(y2 - y1)
	};
};
/**
* Compute the x, y, width, and height of a box from two reference points.
* @param  {Object} coords     x1, x2, y1, and y2
* @return {Object} object
*/
var rectWithCoords = function rectWithCoords(_ref3) {
	var x1 = _ref3.x1, y1 = _ref3.y1, x2 = _ref3.x2, y2 = _ref3.y2;
	return rectWithPoints({
		x: x1,
		y: y1
	}, {
		x: x2,
		y: y2
	});
};
var ScaleHelper = /*#__PURE__*/ function() {
	function ScaleHelper(scale) {
		_classCallCheck$15(this, ScaleHelper);
		this.scale = scale;
	}
	return _createClass$15(ScaleHelper, [
		{
			key: "domain",
			get: function get() {
				return this.scale.domain;
			}
		},
		{
			key: "range",
			get: function get() {
				return this.scale.range;
			}
		},
		{
			key: "rangeMin",
			get: function get() {
				return this.range()[0];
			}
		},
		{
			key: "rangeMax",
			get: function get() {
				return this.range()[1];
			}
		},
		{
			key: "bandwidth",
			get: function get() {
				return this.scale.bandwidth;
			}
		},
		{
			key: "apply",
			value: function apply(value) {
				var _ref4 = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, bandAware = _ref4.bandAware, position = _ref4.position;
				if (value === void 0) return;
				if (position) switch (position) {
					case "start": return this.scale(value);
					case "middle":
						var offset = this.bandwidth ? this.bandwidth() / 2 : 0;
						return this.scale(value) + offset;
					case "end":
						var _offset = this.bandwidth ? this.bandwidth() : 0;
						return this.scale(value) + _offset;
					default: return this.scale(value);
				}
				if (bandAware) {
					var _offset2 = this.bandwidth ? this.bandwidth() / 2 : 0;
					return this.scale(value) + _offset2;
				}
				return this.scale(value);
			}
		},
		{
			key: "isInRange",
			value: function isInRange(value) {
				var range = this.range();
				var first = range[0];
				var last = range[range.length - 1];
				return first <= last ? value >= first && value <= last : value >= last && value <= first;
			}
		}
	], [{
		key: "create",
		value: function create(obj) {
			return new ScaleHelper(obj);
		}
	}]);
}();
_defineProperty$19(ScaleHelper, "EPS", 1e-4);
var createLabeledScales = function createLabeledScales(options) {
	var scales = Object.keys(options).reduce(function(res, key) {
		return _objectSpread$15(_objectSpread$15({}, res), {}, _defineProperty$19({}, key, ScaleHelper.create(options[key])));
	}, {});
	return _objectSpread$15(_objectSpread$15({}, scales), {}, {
		apply: function apply(coord) {
			var _ref5 = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, bandAware = _ref5.bandAware, position = _ref5.position;
			return (0, import_mapValues.default)(coord, function(value, label) {
				return scales[label].apply(value, {
					bandAware,
					position
				});
			});
		},
		isInRange: function isInRange(coord) {
			return (0, import_every.default)(coord, function(value, label) {
				return scales[label].isInRange(value);
			});
		}
	});
};
/** Normalizes the angle so that 0 <= angle < 180.
* @param {number} angle Angle in degrees.
* @return {number} the normalized angle with a value of at least 0 and never greater or equal to 180. */
function normalizeAngle(angle) {
	return (angle % 180 + 180) % 180;
}
/** Calculates the width of the largest horizontal line that fits inside a rectangle that is displayed at an angle.
* @param {Object} size Width and height of the text in a horizontal position.
* @param {number} angle Angle in degrees in which the text is displayed.
* @return {number} The width of the largest horizontal line that fits inside a rectangle that is displayed at an angle.
*/
var getAngledRectangleWidth = function getAngledRectangleWidth(_ref6) {
	var width = _ref6.width, height = _ref6.height;
	var angleRadians = normalizeAngle(arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0) * Math.PI / 180;
	var angleThreshold = Math.atan(height / width);
	var angledWidth = angleRadians > angleThreshold && angleRadians < Math.PI - angleThreshold ? height / Math.sin(angleRadians) : width / Math.cos(angleRadians);
	return Math.abs(angledWidth);
};
//#endregion
//#region node_modules/recharts/es6/util/calculateViewBox.js
var import_find = /* @__PURE__ */ __toESM(require_find());
/**
* This is memoized because the viewBox is unlikely to change often
* - but because it is computed from offset, any change to it would re-render all children.
*
* And because we have many readers of the viewBox, and update it only rarely,
* then let's optimize with memoization.
*/
var calculateViewBox = (0, (/* @__PURE__ */ __toESM(require_memoize())).default)(function(offset) {
	return {
		x: offset.left,
		y: offset.top,
		width: offset.width,
		height: offset.height
	};
}, function(offset) {
	return [
		"l",
		offset.left,
		"t",
		offset.top,
		"w",
		offset.width,
		"h",
		offset.height
	].join("");
});
//#endregion
//#region node_modules/recharts/es6/context/chartLayoutContext.js
var XAxisContext = /*#__PURE__*/ (0, import_react.createContext)(void 0);
var YAxisContext = /*#__PURE__*/ (0, import_react.createContext)(void 0);
var ViewBoxContext = /*#__PURE__*/ (0, import_react.createContext)(void 0);
var OffsetContext = /*#__PURE__*/ (0, import_react.createContext)({});
var ClipPathIdContext = /*#__PURE__*/ (0, import_react.createContext)(void 0);
var ChartHeightContext = /*#__PURE__*/ (0, import_react.createContext)(0);
var ChartWidthContext = /*#__PURE__*/ (0, import_react.createContext)(0);
/**
* Will add all the properties required to render all individual Recharts components into a React Context.
*
* If you want to read these properties, see the collection of hooks exported from this file.
*
* @param {object} props CategoricalChartState, plus children
* @returns {ReactElement} React Context Provider
*/
var ChartLayoutContextProvider = function ChartLayoutContextProvider(props) {
	var _props$state = props.state, xAxisMap = _props$state.xAxisMap, yAxisMap = _props$state.yAxisMap, offset = _props$state.offset, clipPathId = props.clipPathId, children = props.children, width = props.width, height = props.height;
	/**
	* Perhaps we should compute this property when reading? Let's see what is more often used
	*/
	var viewBox = calculateViewBox(offset);
	return /*#__PURE__*/ import_react.createElement(XAxisContext.Provider, { value: xAxisMap }, /*#__PURE__*/ import_react.createElement(YAxisContext.Provider, { value: yAxisMap }, /*#__PURE__*/ import_react.createElement(OffsetContext.Provider, { value: offset }, /*#__PURE__*/ import_react.createElement(ViewBoxContext.Provider, { value: viewBox }, /*#__PURE__*/ import_react.createElement(ClipPathIdContext.Provider, { value: clipPathId }, /*#__PURE__*/ import_react.createElement(ChartHeightContext.Provider, { value: height }, /*#__PURE__*/ import_react.createElement(ChartWidthContext.Provider, { value: width }, children)))))));
};
var useClipPathId = function useClipPathId() {
	return (0, import_react.useContext)(ClipPathIdContext);
};
/**
* This either finds and returns Axis by the specified ID, or throws an exception if an axis with this ID does not exist.
*
* @param xAxisId identifier of the axis - it's either autogenerated ('0'), or passed via `id` prop as <XAxis id='foo' />
* @returns axis configuration object
* @throws Error if no axis with this ID exists
*/
var useXAxisOrThrow = function useXAxisOrThrow(xAxisId) {
	var xAxisMap = (0, import_react.useContext)(XAxisContext);
	xAxisMap ?? invariant(false);
	var xAxis = xAxisMap[xAxisId];
	xAxis ?? invariant(false);
	return xAxis;
};
/**
* This will find an arbitrary first XAxis. If there's exactly one it always returns that one
* - but if there are multiple then it can return any of those.
*
* If you want specific XAxis out of multiple then prefer using useXAxisOrThrow
*
* @returns X axisOptions, or undefined - if there are no X axes
*/
var useArbitraryXAxis = function useArbitraryXAxis() {
	return getAnyElementOfObject((0, import_react.useContext)(XAxisContext));
};
/**
* This hooks will:
* 1st attempt to find an YAxis that has all elements in its domain finite
* If no such axis exists, it will return an arbitrary YAxis
* if there are no Y axes then it returns undefined
*
* @returns Either Y axisOptions, or undefined if there are no Y axes
*/
var useYAxisWithFiniteDomainOrRandom = function useYAxisWithFiniteDomainOrRandom() {
	var yAxisMap = (0, import_react.useContext)(YAxisContext);
	return (0, import_find.default)(yAxisMap, function(axis) {
		return (0, import_every.default)(axis.domain, Number.isFinite);
	}) || getAnyElementOfObject(yAxisMap);
};
/**
* This either finds and returns Axis by the specified ID, or throws an exception if an axis with this ID does not exist.
*
* @param yAxisId identifier of the axis - it's either autogenerated ('0'), or passed via `id` prop as <YAxis id='foo' />
* @returns axis configuration object
* @throws Error if no axis with this ID exists
*/
var useYAxisOrThrow = function useYAxisOrThrow(yAxisId) {
	var yAxisMap = (0, import_react.useContext)(YAxisContext);
	yAxisMap ?? invariant(false);
	var yAxis = yAxisMap[yAxisId];
	yAxis ?? invariant(false);
	return yAxis;
};
var useViewBox = function useViewBox() {
	return (0, import_react.useContext)(ViewBoxContext);
};
var useOffset = function useOffset() {
	return (0, import_react.useContext)(OffsetContext);
};
var useChartWidth = function useChartWidth() {
	return (0, import_react.useContext)(ChartWidthContext);
};
var useChartHeight = function useChartHeight() {
	return (0, import_react.useContext)(ChartHeightContext);
};
//#endregion
//#region node_modules/recharts/es6/cartesian/ReferenceLine.js
/**
* @fileOverview Reference Line
*/
function _typeof$18(o) {
	"@babel/helpers - typeof";
	return _typeof$18 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$18(o);
}
function _classCallCheck$14(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$14(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$18(descriptor.key), descriptor);
	}
}
function _createClass$14(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$14(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$14(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$13(t, o, e) {
	return o = _getPrototypeOf$13(o), _possibleConstructorReturn$13(t, _isNativeReflectConstruct$13() ? Reflect.construct(o, e || [], _getPrototypeOf$13(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$13(self, call) {
	if (call && (_typeof$18(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$13(self);
}
function _assertThisInitialized$13(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$13() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$13 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$13(o) {
	_getPrototypeOf$13 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$13(o);
}
function _inherits$13(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$13(subClass, superClass);
}
function _setPrototypeOf$13(o, p) {
	_setPrototypeOf$13 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$13(o, p);
}
function ownKeys$14(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$14(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$14(Object(t), !0).forEach(function(r) {
			_defineProperty$18(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$14(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$18(obj, key, value) {
	key = _toPropertyKey$18(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$18(t) {
	var i = _toPrimitive$18(t, "string");
	return "symbol" == _typeof$18(i) ? i : i + "";
}
function _toPrimitive$18(t, r) {
	if ("object" != _typeof$18(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$18(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _slicedToArray$3(arr, i) {
	return _arrayWithHoles$3(arr) || _iterableToArrayLimit$3(arr, i) || _unsupportedIterableToArray$5(arr, i) || _nonIterableRest$3();
}
function _nonIterableRest$3() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$5(o, minLen) {
	if (!o) return;
	if (typeof o === "string") return _arrayLikeToArray$5(o, minLen);
	var n = Object.prototype.toString.call(o).slice(8, -1);
	if (n === "Object" && o.constructor) n = o.constructor.name;
	if (n === "Map" || n === "Set") return Array.from(o);
	if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$5(o, minLen);
}
function _arrayLikeToArray$5(arr, len) {
	if (len == null || len > arr.length) len = arr.length;
	for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
	return arr2;
}
function _iterableToArrayLimit$3(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = !0, o = !1;
		try {
			if (i = (t = t.call(r)).next, 0 === l) {
				if (Object(t) !== t) return;
				f = !1;
			} else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = !0, n = r;
		} finally {
			try {
				if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
function _arrayWithHoles$3(arr) {
	if (Array.isArray(arr)) return arr;
}
function _extends$16() {
	_extends$16 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$16.apply(this, arguments);
}
/**
* This excludes `viewBox` prop from svg for two reasons:
* 1. The components wants viewBox of object type, and svg wants string
*    - so there's a conflict, and the component will throw if it gets string
* 2. Internally the component calls `filterProps` which filters the viewBox away anyway
*/
var renderLine = function renderLine(option, props) {
	var line;
	if (/*#__PURE__*/ import_react.isValidElement(option)) line = /*#__PURE__*/ import_react.cloneElement(option, props);
	else if ((0, import_isFunction.default)(option)) line = option(props);
	else line = /*#__PURE__*/ import_react.createElement("line", _extends$16({}, props, { className: "recharts-reference-line-line" }));
	return line;
};
var getEndPoints = function getEndPoints(scales, isFixedX, isFixedY, isSegment, viewBox, position, xAxisOrientation, yAxisOrientation, props) {
	var x = viewBox.x, y = viewBox.y, width = viewBox.width, height = viewBox.height;
	if (isFixedY) {
		var yCoord = props.y;
		var coord = scales.y.apply(yCoord, { position });
		if (ifOverflowMatches(props, "discard") && !scales.y.isInRange(coord)) return null;
		var points = [{
			x: x + width,
			y: coord
		}, {
			x,
			y: coord
		}];
		return yAxisOrientation === "left" ? points.reverse() : points;
	}
	if (isFixedX) {
		var xCoord = props.x;
		var _coord = scales.x.apply(xCoord, { position });
		if (ifOverflowMatches(props, "discard") && !scales.x.isInRange(_coord)) return null;
		var _points = [{
			x: _coord,
			y: y + height
		}, {
			x: _coord,
			y
		}];
		return xAxisOrientation === "top" ? _points.reverse() : _points;
	}
	if (isSegment) {
		var _points2 = props.segment.map(function(p) {
			return scales.apply(p, { position });
		});
		if (ifOverflowMatches(props, "discard") && (0, import_some.default)(_points2, function(p) {
			return !scales.isInRange(p);
		})) return null;
		return _points2;
	}
	return null;
};
function ReferenceLineImpl(props) {
	var fixedX = props.x, fixedY = props.y, segment = props.segment, xAxisId = props.xAxisId, yAxisId = props.yAxisId, shape = props.shape, className = props.className, alwaysShow = props.alwaysShow;
	var clipPathId = useClipPathId();
	var xAxis = useXAxisOrThrow(xAxisId);
	var yAxis = useYAxisOrThrow(yAxisId);
	var viewBox = useViewBox();
	if (!clipPathId || !viewBox) return null;
	warn(alwaysShow === void 0, "The alwaysShow prop is deprecated. Please use ifOverflow=\"extendDomain\" instead.");
	var endPoints = getEndPoints(createLabeledScales({
		x: xAxis.scale,
		y: yAxis.scale
	}), isNumOrStr(fixedX), isNumOrStr(fixedY), segment && segment.length === 2, viewBox, props.position, xAxis.orientation, yAxis.orientation, props);
	if (!endPoints) return null;
	var _endPoints = _slicedToArray$3(endPoints, 2), _endPoints$ = _endPoints[0], x1 = _endPoints$.x, y1 = _endPoints$.y, _endPoints$2 = _endPoints[1], x2 = _endPoints$2.x, y2 = _endPoints$2.y;
	var lineProps = _objectSpread$14(_objectSpread$14({ clipPath: ifOverflowMatches(props, "hidden") ? "url(#".concat(clipPathId, ")") : void 0 }, filterProps(props, true)), {}, {
		x1,
		y1,
		x2,
		y2
	});
	return /*#__PURE__*/ import_react.createElement(Layer, { className: clsx("recharts-reference-line", className) }, renderLine(shape, lineProps), Label.renderCallByParent(props, rectWithCoords({
		x1,
		y1,
		x2,
		y2
	})));
}
var ReferenceLine = /*#__PURE__*/ function(_React$Component) {
	function ReferenceLine() {
		_classCallCheck$14(this, ReferenceLine);
		return _callSuper$13(this, ReferenceLine, arguments);
	}
	_inherits$13(ReferenceLine, _React$Component);
	return _createClass$14(ReferenceLine, [{
		key: "render",
		value: function render() {
			return /*#__PURE__*/ import_react.createElement(ReferenceLineImpl, this.props);
		}
	}]);
}(import_react.Component);
_defineProperty$18(ReferenceLine, "displayName", "ReferenceLine");
_defineProperty$18(ReferenceLine, "defaultProps", {
	isFront: false,
	ifOverflow: "discard",
	xAxisId: 0,
	yAxisId: 0,
	fill: "none",
	stroke: "#ccc",
	fillOpacity: 1,
	strokeWidth: 1,
	position: "middle"
});
//#endregion
//#region node_modules/recharts/es6/cartesian/ReferenceDot.js
/**
* @fileOverview Reference Dot
*/
function _extends$15() {
	_extends$15 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$15.apply(this, arguments);
}
function _typeof$17(o) {
	"@babel/helpers - typeof";
	return _typeof$17 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$17(o);
}
function ownKeys$13(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$13(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$13(Object(t), !0).forEach(function(r) {
			_defineProperty$17(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$13(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _classCallCheck$13(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$13(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$17(descriptor.key), descriptor);
	}
}
function _createClass$13(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$13(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$13(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$12(t, o, e) {
	return o = _getPrototypeOf$12(o), _possibleConstructorReturn$12(t, _isNativeReflectConstruct$12() ? Reflect.construct(o, e || [], _getPrototypeOf$12(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$12(self, call) {
	if (call && (_typeof$17(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$12(self);
}
function _assertThisInitialized$12(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$12() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$12 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$12(o) {
	_getPrototypeOf$12 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$12(o);
}
function _inherits$12(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$12(subClass, superClass);
}
function _setPrototypeOf$12(o, p) {
	_setPrototypeOf$12 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$12(o, p);
}
function _defineProperty$17(obj, key, value) {
	key = _toPropertyKey$17(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$17(t) {
	var i = _toPrimitive$17(t, "string");
	return "symbol" == _typeof$17(i) ? i : i + "";
}
function _toPrimitive$17(t, r) {
	if ("object" != _typeof$17(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$17(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var getCoordinate = function getCoordinate(props) {
	var x = props.x, y = props.y, xAxis = props.xAxis, yAxis = props.yAxis;
	var scales = createLabeledScales({
		x: xAxis.scale,
		y: yAxis.scale
	});
	var result = scales.apply({
		x,
		y
	}, { bandAware: true });
	if (ifOverflowMatches(props, "discard") && !scales.isInRange(result)) return null;
	return result;
};
var ReferenceDot = /*#__PURE__*/ function(_React$Component) {
	function ReferenceDot() {
		_classCallCheck$13(this, ReferenceDot);
		return _callSuper$12(this, ReferenceDot, arguments);
	}
	_inherits$12(ReferenceDot, _React$Component);
	return _createClass$13(ReferenceDot, [{
		key: "render",
		value: function render() {
			var _this$props = this.props, x = _this$props.x, y = _this$props.y, r = _this$props.r, alwaysShow = _this$props.alwaysShow, clipPathId = _this$props.clipPathId;
			var isX = isNumOrStr(x);
			var isY = isNumOrStr(y);
			warn(alwaysShow === void 0, "The alwaysShow prop is deprecated. Please use ifOverflow=\"extendDomain\" instead.");
			if (!isX || !isY) return null;
			var coordinate = getCoordinate(this.props);
			if (!coordinate) return null;
			var cx = coordinate.x, cy = coordinate.y;
			var _this$props2 = this.props, shape = _this$props2.shape, className = _this$props2.className;
			var dotProps = _objectSpread$13(_objectSpread$13({ clipPath: ifOverflowMatches(this.props, "hidden") ? "url(#".concat(clipPathId, ")") : void 0 }, filterProps(this.props, true)), {}, {
				cx,
				cy
			});
			return /*#__PURE__*/ import_react.createElement(Layer, { className: clsx("recharts-reference-dot", className) }, ReferenceDot.renderDot(shape, dotProps), Label.renderCallByParent(this.props, {
				x: cx - r,
				y: cy - r,
				width: 2 * r,
				height: 2 * r
			}));
		}
	}]);
}(import_react.Component);
_defineProperty$17(ReferenceDot, "displayName", "ReferenceDot");
_defineProperty$17(ReferenceDot, "defaultProps", {
	isFront: false,
	ifOverflow: "discard",
	xAxisId: 0,
	yAxisId: 0,
	r: 10,
	fill: "#fff",
	stroke: "#ccc",
	fillOpacity: 1,
	strokeWidth: 1
});
_defineProperty$17(ReferenceDot, "renderDot", function(option, props) {
	var dot;
	if (/*#__PURE__*/ import_react.isValidElement(option)) dot = /*#__PURE__*/ import_react.cloneElement(option, props);
	else if ((0, import_isFunction.default)(option)) dot = option(props);
	else dot = /*#__PURE__*/ import_react.createElement(Dot, _extends$15({}, props, {
		cx: props.cx,
		cy: props.cy,
		className: "recharts-reference-dot-dot"
	}));
	return dot;
});
//#endregion
//#region node_modules/recharts/es6/cartesian/ReferenceArea.js
/**
* @fileOverview Reference Line
*/
function _extends$14() {
	_extends$14 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$14.apply(this, arguments);
}
function _typeof$16(o) {
	"@babel/helpers - typeof";
	return _typeof$16 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$16(o);
}
function ownKeys$12(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$12(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$12(Object(t), !0).forEach(function(r) {
			_defineProperty$16(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$12(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _classCallCheck$12(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$12(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$16(descriptor.key), descriptor);
	}
}
function _createClass$12(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$12(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$12(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$11(t, o, e) {
	return o = _getPrototypeOf$11(o), _possibleConstructorReturn$11(t, _isNativeReflectConstruct$11() ? Reflect.construct(o, e || [], _getPrototypeOf$11(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$11(self, call) {
	if (call && (_typeof$16(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$11(self);
}
function _assertThisInitialized$11(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$11() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$11 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$11(o) {
	_getPrototypeOf$11 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$11(o);
}
function _inherits$11(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$11(subClass, superClass);
}
function _setPrototypeOf$11(o, p) {
	_setPrototypeOf$11 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$11(o, p);
}
function _defineProperty$16(obj, key, value) {
	key = _toPropertyKey$16(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$16(t) {
	var i = _toPrimitive$16(t, "string");
	return "symbol" == _typeof$16(i) ? i : i + "";
}
function _toPrimitive$16(t, r) {
	if ("object" != _typeof$16(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$16(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var getRect = function getRect(hasX1, hasX2, hasY1, hasY2, props) {
	var xValue1 = props.x1, xValue2 = props.x2, yValue1 = props.y1, yValue2 = props.y2, xAxis = props.xAxis, yAxis = props.yAxis;
	if (!xAxis || !yAxis) return null;
	var scales = createLabeledScales({
		x: xAxis.scale,
		y: yAxis.scale
	});
	var p1 = {
		x: hasX1 ? scales.x.apply(xValue1, { position: "start" }) : scales.x.rangeMin,
		y: hasY1 ? scales.y.apply(yValue1, { position: "start" }) : scales.y.rangeMin
	};
	var p2 = {
		x: hasX2 ? scales.x.apply(xValue2, { position: "end" }) : scales.x.rangeMax,
		y: hasY2 ? scales.y.apply(yValue2, { position: "end" }) : scales.y.rangeMax
	};
	if (ifOverflowMatches(props, "discard") && (!scales.isInRange(p1) || !scales.isInRange(p2))) return null;
	return rectWithPoints(p1, p2);
};
var ReferenceArea = /*#__PURE__*/ function(_React$Component) {
	function ReferenceArea() {
		_classCallCheck$12(this, ReferenceArea);
		return _callSuper$11(this, ReferenceArea, arguments);
	}
	_inherits$11(ReferenceArea, _React$Component);
	return _createClass$12(ReferenceArea, [{
		key: "render",
		value: function render() {
			var _this$props = this.props, x1 = _this$props.x1, x2 = _this$props.x2, y1 = _this$props.y1, y2 = _this$props.y2, className = _this$props.className, alwaysShow = _this$props.alwaysShow, clipPathId = _this$props.clipPathId;
			warn(alwaysShow === void 0, "The alwaysShow prop is deprecated. Please use ifOverflow=\"extendDomain\" instead.");
			var hasX1 = isNumOrStr(x1);
			var hasX2 = isNumOrStr(x2);
			var hasY1 = isNumOrStr(y1);
			var hasY2 = isNumOrStr(y2);
			var shape = this.props.shape;
			if (!hasX1 && !hasX2 && !hasY1 && !hasY2 && !shape) return null;
			var rect = getRect(hasX1, hasX2, hasY1, hasY2, this.props);
			if (!rect && !shape) return null;
			var clipPath = ifOverflowMatches(this.props, "hidden") ? "url(#".concat(clipPathId, ")") : void 0;
			return /*#__PURE__*/ import_react.createElement(Layer, { className: clsx("recharts-reference-area", className) }, ReferenceArea.renderRect(shape, _objectSpread$12(_objectSpread$12({ clipPath }, filterProps(this.props, true)), rect)), Label.renderCallByParent(this.props, rect));
		}
	}]);
}(import_react.Component);
_defineProperty$16(ReferenceArea, "displayName", "ReferenceArea");
_defineProperty$16(ReferenceArea, "defaultProps", {
	isFront: false,
	ifOverflow: "discard",
	xAxisId: 0,
	yAxisId: 0,
	r: 10,
	fill: "#ccc",
	fillOpacity: .5,
	stroke: "none",
	strokeWidth: 1
});
_defineProperty$16(ReferenceArea, "renderRect", function(option, props) {
	var rect;
	if (/*#__PURE__*/ import_react.isValidElement(option)) rect = /*#__PURE__*/ import_react.cloneElement(option, props);
	else if ((0, import_isFunction.default)(option)) rect = option(props);
	else rect = /*#__PURE__*/ import_react.createElement(Rectangle, _extends$14({}, props, { className: "recharts-reference-area-rect" }));
	return rect;
});
//#endregion
//#region node_modules/recharts/es6/util/getEveryNthWithCondition.js
/**
* Given an array and a number N, return a new array which contains every nTh
* element of the input array. For n below 1, an empty array is returned.
* If isValid is provided, all candidates must suffice the condition, else undefined is returned.
* @param {T[]} array An input array.
* @param {integer} n A number
* @param {Function} isValid A function to evaluate a candidate form the array
* @returns {T[]} The result array of the same type as the input array.
*/
function getEveryNthWithCondition(array, n, isValid) {
	if (n < 1) return [];
	if (n === 1 && isValid === void 0) return array;
	var result = [];
	for (var i = 0; i < array.length; i += n) if (isValid === void 0 || isValid(array[i]) === true) result.push(array[i]);
	else return;
	return result;
}
//#endregion
//#region node_modules/recharts/es6/util/TickUtils.js
function getAngledTickWidth(contentSize, unitSize, angle) {
	return getAngledRectangleWidth({
		width: contentSize.width + unitSize.width,
		height: contentSize.height + unitSize.height
	}, angle);
}
function getTickBoundaries(viewBox, sign, sizeKey) {
	var isWidth = sizeKey === "width";
	var x = viewBox.x, y = viewBox.y, width = viewBox.width, height = viewBox.height;
	if (sign === 1) return {
		start: isWidth ? x : y,
		end: isWidth ? x + width : y + height
	};
	return {
		start: isWidth ? x + width : y + height,
		end: isWidth ? x : y
	};
}
function isVisible(sign, tickPosition, getSize, start, end) {
	if (sign * tickPosition < sign * start || sign * tickPosition > sign * end) return false;
	var size = getSize();
	return sign * (tickPosition - sign * size / 2 - start) >= 0 && sign * (tickPosition + sign * size / 2 - end) <= 0;
}
function getNumberIntervalTicks(ticks, interval) {
	return getEveryNthWithCondition(ticks, interval + 1);
}
//#endregion
//#region node_modules/recharts/es6/cartesian/getEquidistantTicks.js
function getEquidistantTicks(sign, boundaries, getTickSize, ticks, minTickGap) {
	var result = (ticks || []).slice();
	var initialStart = boundaries.start, end = boundaries.end;
	var index = 0;
	var stepsize = 1;
	var start = initialStart;
	var _loop = function _loop() {
		var entry = ticks === null || ticks === void 0 ? void 0 : ticks[index];
		if (entry === void 0) return { v: getEveryNthWithCondition(ticks, stepsize) };
		var i = index;
		var size;
		var getSize = function getSize() {
			if (size === void 0) size = getTickSize(entry, i);
			return size;
		};
		var tickCoord = entry.coordinate;
		var isShow = index === 0 || isVisible(sign, tickCoord, getSize, start, end);
		if (!isShow) {
			index = 0;
			start = initialStart;
			stepsize += 1;
		}
		if (isShow) {
			start = tickCoord + sign * (getSize() / 2 + minTickGap);
			index += stepsize;
		}
	}, _ret;
	while (stepsize <= result.length) {
		_ret = _loop();
		if (_ret) return _ret.v;
	}
	return [];
}
//#endregion
//#region node_modules/recharts/es6/cartesian/getTicks.js
function _typeof$15(o) {
	"@babel/helpers - typeof";
	return _typeof$15 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$15(o);
}
function ownKeys$11(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$11(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$11(Object(t), !0).forEach(function(r) {
			_defineProperty$15(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$11(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$15(obj, key, value) {
	key = _toPropertyKey$15(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$15(t) {
	var i = _toPrimitive$15(t, "string");
	return "symbol" == _typeof$15(i) ? i : i + "";
}
function _toPrimitive$15(t, r) {
	if ("object" != _typeof$15(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$15(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function getTicksEnd(sign, boundaries, getTickSize, ticks, minTickGap) {
	var result = (ticks || []).slice();
	var len = result.length;
	var start = boundaries.start;
	var end = boundaries.end;
	var _loop = function _loop(i) {
		var entry = result[i];
		var size;
		var getSize = function getSize() {
			if (size === void 0) size = getTickSize(entry, i);
			return size;
		};
		if (i === len - 1) {
			var gap = sign * (entry.coordinate + sign * getSize() / 2 - end);
			result[i] = entry = _objectSpread$11(_objectSpread$11({}, entry), {}, { tickCoord: gap > 0 ? entry.coordinate - gap * sign : entry.coordinate });
		} else result[i] = entry = _objectSpread$11(_objectSpread$11({}, entry), {}, { tickCoord: entry.coordinate });
		if (isVisible(sign, entry.tickCoord, getSize, start, end)) {
			end = entry.tickCoord - sign * (getSize() / 2 + minTickGap);
			result[i] = _objectSpread$11(_objectSpread$11({}, entry), {}, { isShow: true });
		}
	};
	for (var i = len - 1; i >= 0; i--) _loop(i);
	return result;
}
function getTicksStart(sign, boundaries, getTickSize, ticks, minTickGap, preserveEnd) {
	var result = (ticks || []).slice();
	var len = result.length;
	var start = boundaries.start, end = boundaries.end;
	if (preserveEnd) {
		var tail = ticks[len - 1];
		var tailSize = getTickSize(tail, len - 1);
		var tailGap = sign * (tail.coordinate + sign * tailSize / 2 - end);
		result[len - 1] = tail = _objectSpread$11(_objectSpread$11({}, tail), {}, { tickCoord: tailGap > 0 ? tail.coordinate - tailGap * sign : tail.coordinate });
		if (isVisible(sign, tail.tickCoord, function() {
			return tailSize;
		}, start, end)) {
			end = tail.tickCoord - sign * (tailSize / 2 + minTickGap);
			result[len - 1] = _objectSpread$11(_objectSpread$11({}, tail), {}, { isShow: true });
		}
	}
	var count = preserveEnd ? len - 1 : len;
	var _loop2 = function _loop2(i) {
		var entry = result[i];
		var size;
		var getSize = function getSize() {
			if (size === void 0) size = getTickSize(entry, i);
			return size;
		};
		if (i === 0) {
			var gap = sign * (entry.coordinate - sign * getSize() / 2 - start);
			result[i] = entry = _objectSpread$11(_objectSpread$11({}, entry), {}, { tickCoord: gap < 0 ? entry.coordinate - gap * sign : entry.coordinate });
		} else result[i] = entry = _objectSpread$11(_objectSpread$11({}, entry), {}, { tickCoord: entry.coordinate });
		if (isVisible(sign, entry.tickCoord, getSize, start, end)) {
			start = entry.tickCoord + sign * (getSize() / 2 + minTickGap);
			result[i] = _objectSpread$11(_objectSpread$11({}, entry), {}, { isShow: true });
		}
	};
	for (var i = 0; i < count; i++) _loop2(i);
	return result;
}
function getTicks(props, fontSize, letterSpacing) {
	var tick = props.tick, ticks = props.ticks, viewBox = props.viewBox, minTickGap = props.minTickGap, orientation = props.orientation, interval = props.interval, tickFormatter = props.tickFormatter, unit = props.unit, angle = props.angle;
	if (!ticks || !ticks.length || !tick) return [];
	if (isNumber$1(interval) || Global.isSsr) return getNumberIntervalTicks(ticks, typeof interval === "number" && isNumber$1(interval) ? interval : 0);
	var candidates = [];
	var sizeKey = orientation === "top" || orientation === "bottom" ? "width" : "height";
	var unitSize = unit && sizeKey === "width" ? getStringSize(unit, {
		fontSize,
		letterSpacing
	}) : {
		width: 0,
		height: 0
	};
	var getTickSize = function getTickSize(content, index) {
		var value = (0, import_isFunction.default)(tickFormatter) ? tickFormatter(content.value, index) : content.value;
		return sizeKey === "width" ? getAngledTickWidth(getStringSize(value, {
			fontSize,
			letterSpacing
		}), unitSize, angle) : getStringSize(value, {
			fontSize,
			letterSpacing
		})[sizeKey];
	};
	var sign = ticks.length >= 2 ? mathSign(ticks[1].coordinate - ticks[0].coordinate) : 1;
	var boundaries = getTickBoundaries(viewBox, sign, sizeKey);
	if (interval === "equidistantPreserveStart") return getEquidistantTicks(sign, boundaries, getTickSize, ticks, minTickGap);
	if (interval === "preserveStart" || interval === "preserveStartEnd") candidates = getTicksStart(sign, boundaries, getTickSize, ticks, minTickGap, interval === "preserveStartEnd");
	else candidates = getTicksEnd(sign, boundaries, getTickSize, ticks, minTickGap);
	return candidates.filter(function(entry) {
		return entry.isShow;
	});
}
//#endregion
//#region node_modules/recharts/es6/cartesian/CartesianAxis.js
/**
* @fileOverview Cartesian Axis
*/
var _excluded$7 = ["viewBox"];
var _excluded2$5 = ["viewBox"];
var _excluded3 = ["ticks"];
function _typeof$14(o) {
	"@babel/helpers - typeof";
	return _typeof$14 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$14(o);
}
function _extends$13() {
	_extends$13 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$13.apply(this, arguments);
}
function ownKeys$10(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$10(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$10(Object(t), !0).forEach(function(r) {
			_defineProperty$14(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$10(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _objectWithoutProperties$7(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$7(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$7(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
function _classCallCheck$11(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$11(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$14(descriptor.key), descriptor);
	}
}
function _createClass$11(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$11(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$11(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$10(t, o, e) {
	return o = _getPrototypeOf$10(o), _possibleConstructorReturn$10(t, _isNativeReflectConstruct$10() ? Reflect.construct(o, e || [], _getPrototypeOf$10(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$10(self, call) {
	if (call && (_typeof$14(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$10(self);
}
function _assertThisInitialized$10(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$10() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$10 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$10(o) {
	_getPrototypeOf$10 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$10(o);
}
function _inherits$10(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$10(subClass, superClass);
}
function _setPrototypeOf$10(o, p) {
	_setPrototypeOf$10 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$10(o, p);
}
function _defineProperty$14(obj, key, value) {
	key = _toPropertyKey$14(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$14(t) {
	var i = _toPrimitive$14(t, "string");
	return "symbol" == _typeof$14(i) ? i : i + "";
}
function _toPrimitive$14(t, r) {
	if ("object" != _typeof$14(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$14(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
/** The orientation of the axis in correspondence to the chart */
/** A unit to be appended to a value */
/** The formatter function of tick */
var CartesianAxis = /*#__PURE__*/ function(_Component) {
	function CartesianAxis(props) {
		var _this;
		_classCallCheck$11(this, CartesianAxis);
		_this = _callSuper$10(this, CartesianAxis, [props]);
		_this.state = {
			fontSize: "",
			letterSpacing: ""
		};
		return _this;
	}
	_inherits$10(CartesianAxis, _Component);
	return _createClass$11(CartesianAxis, [
		{
			key: "shouldComponentUpdate",
			value: function shouldComponentUpdate(_ref, nextState) {
				var viewBox = _ref.viewBox, restProps = _objectWithoutProperties$7(_ref, _excluded$7);
				var _this$props = this.props, viewBoxOld = _this$props.viewBox, restPropsOld = _objectWithoutProperties$7(_this$props, _excluded2$5);
				return !shallowEqual(viewBox, viewBoxOld) || !shallowEqual(restProps, restPropsOld) || !shallowEqual(nextState, this.state);
			}
		},
		{
			key: "componentDidMount",
			value: function componentDidMount() {
				var htmlLayer = this.layerReference;
				if (!htmlLayer) return;
				var tick = htmlLayer.getElementsByClassName("recharts-cartesian-axis-tick-value")[0];
				if (tick) this.setState({
					fontSize: window.getComputedStyle(tick).fontSize,
					letterSpacing: window.getComputedStyle(tick).letterSpacing
				});
			}
		},
		{
			key: "getTickLineCoord",
			value: function getTickLineCoord(data) {
				var _this$props2 = this.props, x = _this$props2.x, y = _this$props2.y, width = _this$props2.width, height = _this$props2.height, orientation = _this$props2.orientation, tickSize = _this$props2.tickSize, mirror = _this$props2.mirror, tickMargin = _this$props2.tickMargin;
				var x1, x2, y1, y2, tx, ty;
				var sign = mirror ? -1 : 1;
				var finalTickSize = data.tickSize || tickSize;
				var tickCoord = isNumber$1(data.tickCoord) ? data.tickCoord : data.coordinate;
				switch (orientation) {
					case "top":
						x1 = x2 = data.coordinate;
						y2 = y + +!mirror * height;
						y1 = y2 - sign * finalTickSize;
						ty = y1 - sign * tickMargin;
						tx = tickCoord;
						break;
					case "left":
						y1 = y2 = data.coordinate;
						x2 = x + +!mirror * width;
						x1 = x2 - sign * finalTickSize;
						tx = x1 - sign * tickMargin;
						ty = tickCoord;
						break;
					case "right":
						y1 = y2 = data.coordinate;
						x2 = x + +mirror * width;
						x1 = x2 + sign * finalTickSize;
						tx = x1 + sign * tickMargin;
						ty = tickCoord;
						break;
					default:
						x1 = x2 = data.coordinate;
						y2 = y + +mirror * height;
						y1 = y2 + sign * finalTickSize;
						ty = y1 + sign * tickMargin;
						tx = tickCoord;
				}
				return {
					line: {
						x1,
						y1,
						x2,
						y2
					},
					tick: {
						x: tx,
						y: ty
					}
				};
			}
		},
		{
			key: "getTickTextAnchor",
			value: function getTickTextAnchor() {
				var _this$props3 = this.props, orientation = _this$props3.orientation, mirror = _this$props3.mirror;
				var textAnchor;
				switch (orientation) {
					case "left":
						textAnchor = mirror ? "start" : "end";
						break;
					case "right":
						textAnchor = mirror ? "end" : "start";
						break;
					default: textAnchor = "middle";
				}
				return textAnchor;
			}
		},
		{
			key: "getTickVerticalAnchor",
			value: function getTickVerticalAnchor() {
				var _this$props4 = this.props, orientation = _this$props4.orientation, mirror = _this$props4.mirror;
				var verticalAnchor = "end";
				switch (orientation) {
					case "left":
					case "right":
						verticalAnchor = "middle";
						break;
					case "top":
						verticalAnchor = mirror ? "start" : "end";
						break;
					default: verticalAnchor = mirror ? "end" : "start";
				}
				return verticalAnchor;
			}
		},
		{
			key: "renderAxisLine",
			value: function renderAxisLine() {
				var _this$props5 = this.props, x = _this$props5.x, y = _this$props5.y, width = _this$props5.width, height = _this$props5.height, orientation = _this$props5.orientation, mirror = _this$props5.mirror, axisLine = _this$props5.axisLine;
				var props = _objectSpread$10(_objectSpread$10(_objectSpread$10({}, filterProps(this.props, false)), filterProps(axisLine, false)), {}, { fill: "none" });
				if (orientation === "top" || orientation === "bottom") {
					var needHeight = +(orientation === "top" && !mirror || orientation === "bottom" && mirror);
					props = _objectSpread$10(_objectSpread$10({}, props), {}, {
						x1: x,
						y1: y + needHeight * height,
						x2: x + width,
						y2: y + needHeight * height
					});
				} else {
					var needWidth = +(orientation === "left" && !mirror || orientation === "right" && mirror);
					props = _objectSpread$10(_objectSpread$10({}, props), {}, {
						x1: x + needWidth * width,
						y1: y,
						x2: x + needWidth * width,
						y2: y + height
					});
				}
				return /*#__PURE__*/ import_react.createElement("line", _extends$13({}, props, { className: clsx("recharts-cartesian-axis-line", (0, import_get.default)(axisLine, "className")) }));
			}
		},
		{
			key: "renderTicks",
			value: 
			/**
			* render the ticks
			* @param {Array} ticks The ticks to actually render (overrides what was passed in props)
			* @param {string} fontSize Fontsize to consider for tick spacing
			* @param {string} letterSpacing Letterspacing to consider for tick spacing
			* @return {ReactComponent} renderedTicks
			*/
			function renderTicks(ticks, fontSize, letterSpacing) {
				var _this2 = this;
				var _this$props6 = this.props, tickLine = _this$props6.tickLine, stroke = _this$props6.stroke, tick = _this$props6.tick, tickFormatter = _this$props6.tickFormatter, unit = _this$props6.unit;
				var finalTicks = getTicks(_objectSpread$10(_objectSpread$10({}, this.props), {}, { ticks }), fontSize, letterSpacing);
				var textAnchor = this.getTickTextAnchor();
				var verticalAnchor = this.getTickVerticalAnchor();
				var axisProps = filterProps(this.props, false);
				var customTickProps = filterProps(tick, false);
				var tickLineProps = _objectSpread$10(_objectSpread$10({}, axisProps), {}, { fill: "none" }, filterProps(tickLine, false));
				var items = finalTicks.map(function(entry, i) {
					var _this2$getTickLineCoo = _this2.getTickLineCoord(entry), lineCoord = _this2$getTickLineCoo.line, tickCoord = _this2$getTickLineCoo.tick;
					var tickProps = _objectSpread$10(_objectSpread$10(_objectSpread$10(_objectSpread$10({
						textAnchor,
						verticalAnchor
					}, axisProps), {}, {
						stroke: "none",
						fill: stroke
					}, customTickProps), tickCoord), {}, {
						index: i,
						payload: entry,
						visibleTicksCount: finalTicks.length,
						tickFormatter
					});
					return /*#__PURE__*/ import_react.createElement(Layer, _extends$13({
						className: "recharts-cartesian-axis-tick",
						key: "tick-".concat(entry.value, "-").concat(entry.coordinate, "-").concat(entry.tickCoord)
					}, adaptEventsOfChild(_this2.props, entry, i)), tickLine && /*#__PURE__*/ import_react.createElement("line", _extends$13({}, tickLineProps, lineCoord, { className: clsx("recharts-cartesian-axis-tick-line", (0, import_get.default)(tickLine, "className")) })), tick && CartesianAxis.renderTickItem(tick, tickProps, "".concat((0, import_isFunction.default)(tickFormatter) ? tickFormatter(entry.value, i) : entry.value).concat(unit || "")));
				});
				return /*#__PURE__*/ import_react.createElement("g", { className: "recharts-cartesian-axis-ticks" }, items);
			}
		},
		{
			key: "render",
			value: function render() {
				var _this3 = this;
				var _this$props7 = this.props, axisLine = _this$props7.axisLine, width = _this$props7.width, height = _this$props7.height, ticksGenerator = _this$props7.ticksGenerator, className = _this$props7.className;
				if (_this$props7.hide) return null;
				var _this$props8 = this.props, ticks = _this$props8.ticks, noTicksProps = _objectWithoutProperties$7(_this$props8, _excluded3);
				var finalTicks = ticks;
				if ((0, import_isFunction.default)(ticksGenerator)) finalTicks = ticks && ticks.length > 0 ? ticksGenerator(this.props) : ticksGenerator(noTicksProps);
				if (width <= 0 || height <= 0 || !finalTicks || !finalTicks.length) return null;
				return /*#__PURE__*/ import_react.createElement(Layer, {
					className: clsx("recharts-cartesian-axis", className),
					ref: function ref(_ref2) {
						_this3.layerReference = _ref2;
					}
				}, axisLine && this.renderAxisLine(), this.renderTicks(finalTicks, this.state.fontSize, this.state.letterSpacing), Label.renderCallByParent(this.props));
			}
		}
	], [{
		key: "renderTickItem",
		value: function renderTickItem(option, props, value) {
			var tickItem;
			var combinedClassName = clsx(props.className, "recharts-cartesian-axis-tick-value");
			if (/*#__PURE__*/ import_react.isValidElement(option)) tickItem = /*#__PURE__*/ import_react.cloneElement(option, _objectSpread$10(_objectSpread$10({}, props), {}, { className: combinedClassName }));
			else if ((0, import_isFunction.default)(option)) tickItem = option(_objectSpread$10(_objectSpread$10({}, props), {}, { className: combinedClassName }));
			else tickItem = /*#__PURE__*/ import_react.createElement(Text, _extends$13({}, props, { className: "recharts-cartesian-axis-tick-value" }), value);
			return tickItem;
		}
	}]);
}(import_react.Component);
_defineProperty$14(CartesianAxis, "displayName", "CartesianAxis");
_defineProperty$14(CartesianAxis, "defaultProps", {
	x: 0,
	y: 0,
	width: 0,
	height: 0,
	viewBox: {
		x: 0,
		y: 0,
		width: 0,
		height: 0
	},
	orientation: "bottom",
	ticks: [],
	stroke: "#666",
	tickLine: true,
	axisLine: true,
	tick: true,
	mirror: false,
	minTickGap: 5,
	tickSize: 6,
	tickMargin: 2,
	interval: "preserveEnd"
});
//#endregion
//#region node_modules/recharts/es6/cartesian/CartesianGrid.js
/**
* @fileOverview Cartesian Grid
*/
var _excluded$6 = [
	"x1",
	"y1",
	"x2",
	"y2",
	"key"
];
var _excluded2$4 = ["offset"];
function _typeof$13(o) {
	"@babel/helpers - typeof";
	return _typeof$13 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$13(o);
}
function ownKeys$9(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$9(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$9(Object(t), !0).forEach(function(r) {
			_defineProperty$13(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$9(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$13(obj, key, value) {
	key = _toPropertyKey$13(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$13(t) {
	var i = _toPrimitive$13(t, "string");
	return "symbol" == _typeof$13(i) ? i : i + "";
}
function _toPrimitive$13(t, r) {
	if ("object" != _typeof$13(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$13(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _extends$12() {
	_extends$12 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$12.apply(this, arguments);
}
function _objectWithoutProperties$6(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$6(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$6(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
/**
* The <CartesianGrid horizontal
*/
var Background = function Background(props) {
	var fill = props.fill;
	if (!fill || fill === "none") return null;
	var fillOpacity = props.fillOpacity, x = props.x, y = props.y, width = props.width, height = props.height, ry = props.ry;
	return /*#__PURE__*/ import_react.createElement("rect", {
		x,
		y,
		ry,
		width,
		height,
		stroke: "none",
		fill,
		fillOpacity,
		className: "recharts-cartesian-grid-bg"
	});
};
function renderLineItem(option, props) {
	var lineItem;
	if (/*#__PURE__*/ import_react.isValidElement(option)) lineItem = /*#__PURE__*/ import_react.cloneElement(option, props);
	else if ((0, import_isFunction.default)(option)) lineItem = option(props);
	else {
		var x1 = props.x1, y1 = props.y1, x2 = props.x2, y2 = props.y2, key = props.key, _filterProps = filterProps(_objectWithoutProperties$6(props, _excluded$6), false);
		_filterProps.offset;
		var restOfFilteredProps = _objectWithoutProperties$6(_filterProps, _excluded2$4);
		lineItem = /*#__PURE__*/ import_react.createElement("line", _extends$12({}, restOfFilteredProps, {
			x1,
			y1,
			x2,
			y2,
			fill: "none",
			key
		}));
	}
	return lineItem;
}
function HorizontalGridLines(props) {
	var x = props.x, width = props.width, _props$horizontal = props.horizontal, horizontal = _props$horizontal === void 0 ? true : _props$horizontal, horizontalPoints = props.horizontalPoints;
	if (!horizontal || !horizontalPoints || !horizontalPoints.length) return null;
	var items = horizontalPoints.map(function(entry, i) {
		return renderLineItem(horizontal, _objectSpread$9(_objectSpread$9({}, props), {}, {
			x1: x,
			y1: entry,
			x2: x + width,
			y2: entry,
			key: "line-".concat(i),
			index: i
		}));
	});
	return /*#__PURE__*/ import_react.createElement("g", { className: "recharts-cartesian-grid-horizontal" }, items);
}
function VerticalGridLines(props) {
	var y = props.y, height = props.height, _props$vertical = props.vertical, vertical = _props$vertical === void 0 ? true : _props$vertical, verticalPoints = props.verticalPoints;
	if (!vertical || !verticalPoints || !verticalPoints.length) return null;
	var items = verticalPoints.map(function(entry, i) {
		return renderLineItem(vertical, _objectSpread$9(_objectSpread$9({}, props), {}, {
			x1: entry,
			y1: y,
			x2: entry,
			y2: y + height,
			key: "line-".concat(i),
			index: i
		}));
	});
	return /*#__PURE__*/ import_react.createElement("g", { className: "recharts-cartesian-grid-vertical" }, items);
}
function HorizontalStripes(props) {
	var horizontalFill = props.horizontalFill, fillOpacity = props.fillOpacity, x = props.x, y = props.y, width = props.width, height = props.height, horizontalPoints = props.horizontalPoints, _props$horizontal2 = props.horizontal;
	if (!(_props$horizontal2 === void 0 ? true : _props$horizontal2) || !horizontalFill || !horizontalFill.length) return null;
	var roundedSortedHorizontalPoints = horizontalPoints.map(function(e) {
		return Math.round(e + y - y);
	}).sort(function(a, b) {
		return a - b;
	});
	if (y !== roundedSortedHorizontalPoints[0]) roundedSortedHorizontalPoints.unshift(0);
	var items = roundedSortedHorizontalPoints.map(function(entry, i) {
		var lineHeight = !roundedSortedHorizontalPoints[i + 1] ? y + height - entry : roundedSortedHorizontalPoints[i + 1] - entry;
		if (lineHeight <= 0) return null;
		var colorIndex = i % horizontalFill.length;
		return /*#__PURE__*/ import_react.createElement("rect", {
			key: "react-".concat(i),
			y: entry,
			x,
			height: lineHeight,
			width,
			stroke: "none",
			fill: horizontalFill[colorIndex],
			fillOpacity,
			className: "recharts-cartesian-grid-bg"
		});
	});
	return /*#__PURE__*/ import_react.createElement("g", { className: "recharts-cartesian-gridstripes-horizontal" }, items);
}
function VerticalStripes(props) {
	var _props$vertical2 = props.vertical, vertical = _props$vertical2 === void 0 ? true : _props$vertical2, verticalFill = props.verticalFill, fillOpacity = props.fillOpacity, x = props.x, y = props.y, width = props.width, height = props.height, verticalPoints = props.verticalPoints;
	if (!vertical || !verticalFill || !verticalFill.length) return null;
	var roundedSortedVerticalPoints = verticalPoints.map(function(e) {
		return Math.round(e + x - x);
	}).sort(function(a, b) {
		return a - b;
	});
	if (x !== roundedSortedVerticalPoints[0]) roundedSortedVerticalPoints.unshift(0);
	var items = roundedSortedVerticalPoints.map(function(entry, i) {
		var lineWidth = !roundedSortedVerticalPoints[i + 1] ? x + width - entry : roundedSortedVerticalPoints[i + 1] - entry;
		if (lineWidth <= 0) return null;
		var colorIndex = i % verticalFill.length;
		return /*#__PURE__*/ import_react.createElement("rect", {
			key: "react-".concat(i),
			x: entry,
			y,
			width: lineWidth,
			height,
			stroke: "none",
			fill: verticalFill[colorIndex],
			fillOpacity,
			className: "recharts-cartesian-grid-bg"
		});
	});
	return /*#__PURE__*/ import_react.createElement("g", { className: "recharts-cartesian-gridstripes-vertical" }, items);
}
var defaultVerticalCoordinatesGenerator = function defaultVerticalCoordinatesGenerator(_ref, syncWithTicks) {
	var xAxis = _ref.xAxis, width = _ref.width, height = _ref.height, offset = _ref.offset;
	return getCoordinatesOfGrid(getTicks(_objectSpread$9(_objectSpread$9(_objectSpread$9({}, CartesianAxis.defaultProps), xAxis), {}, {
		ticks: getTicksOfAxis(xAxis, true),
		viewBox: {
			x: 0,
			y: 0,
			width,
			height
		}
	})), offset.left, offset.left + offset.width, syncWithTicks);
};
var defaultHorizontalCoordinatesGenerator = function defaultHorizontalCoordinatesGenerator(_ref2, syncWithTicks) {
	var yAxis = _ref2.yAxis, width = _ref2.width, height = _ref2.height, offset = _ref2.offset;
	return getCoordinatesOfGrid(getTicks(_objectSpread$9(_objectSpread$9(_objectSpread$9({}, CartesianAxis.defaultProps), yAxis), {}, {
		ticks: getTicksOfAxis(yAxis, true),
		viewBox: {
			x: 0,
			y: 0,
			width,
			height
		}
	})), offset.top, offset.top + offset.height, syncWithTicks);
};
var defaultProps = {
	horizontal: true,
	vertical: true,
	horizontalPoints: [],
	verticalPoints: [],
	stroke: "#ccc",
	fill: "none",
	verticalFill: [],
	horizontalFill: []
};
function CartesianGrid(props) {
	var _props$stroke, _props$fill, _props$horizontal3, _props$horizontalFill, _props$vertical3, _props$verticalFill;
	var chartWidth = useChartWidth();
	var chartHeight = useChartHeight();
	var offset = useOffset();
	var propsIncludingDefaults = _objectSpread$9(_objectSpread$9({}, props), {}, {
		stroke: (_props$stroke = props.stroke) !== null && _props$stroke !== void 0 ? _props$stroke : defaultProps.stroke,
		fill: (_props$fill = props.fill) !== null && _props$fill !== void 0 ? _props$fill : defaultProps.fill,
		horizontal: (_props$horizontal3 = props.horizontal) !== null && _props$horizontal3 !== void 0 ? _props$horizontal3 : defaultProps.horizontal,
		horizontalFill: (_props$horizontalFill = props.horizontalFill) !== null && _props$horizontalFill !== void 0 ? _props$horizontalFill : defaultProps.horizontalFill,
		vertical: (_props$vertical3 = props.vertical) !== null && _props$vertical3 !== void 0 ? _props$vertical3 : defaultProps.vertical,
		verticalFill: (_props$verticalFill = props.verticalFill) !== null && _props$verticalFill !== void 0 ? _props$verticalFill : defaultProps.verticalFill,
		x: isNumber$1(props.x) ? props.x : offset.left,
		y: isNumber$1(props.y) ? props.y : offset.top,
		width: isNumber$1(props.width) ? props.width : offset.width,
		height: isNumber$1(props.height) ? props.height : offset.height
	});
	var x = propsIncludingDefaults.x, y = propsIncludingDefaults.y, width = propsIncludingDefaults.width, height = propsIncludingDefaults.height, syncWithTicks = propsIncludingDefaults.syncWithTicks, horizontalValues = propsIncludingDefaults.horizontalValues, verticalValues = propsIncludingDefaults.verticalValues;
	var xAxis = useArbitraryXAxis();
	var yAxis = useYAxisWithFiniteDomainOrRandom();
	if (!isNumber$1(width) || width <= 0 || !isNumber$1(height) || height <= 0 || !isNumber$1(x) || x !== +x || !isNumber$1(y) || y !== +y) return null;
	var verticalCoordinatesGenerator = propsIncludingDefaults.verticalCoordinatesGenerator || defaultVerticalCoordinatesGenerator;
	var horizontalCoordinatesGenerator = propsIncludingDefaults.horizontalCoordinatesGenerator || defaultHorizontalCoordinatesGenerator;
	var horizontalPoints = propsIncludingDefaults.horizontalPoints, verticalPoints = propsIncludingDefaults.verticalPoints;
	if ((!horizontalPoints || !horizontalPoints.length) && (0, import_isFunction.default)(horizontalCoordinatesGenerator)) {
		var isHorizontalValues = horizontalValues && horizontalValues.length;
		var generatorResult = horizontalCoordinatesGenerator({
			yAxis: yAxis ? _objectSpread$9(_objectSpread$9({}, yAxis), {}, { ticks: isHorizontalValues ? horizontalValues : yAxis.ticks }) : void 0,
			width: chartWidth,
			height: chartHeight,
			offset
		}, isHorizontalValues ? true : syncWithTicks);
		warn(Array.isArray(generatorResult), "horizontalCoordinatesGenerator should return Array but instead it returned [".concat(_typeof$13(generatorResult), "]"));
		if (Array.isArray(generatorResult)) horizontalPoints = generatorResult;
	}
	if ((!verticalPoints || !verticalPoints.length) && (0, import_isFunction.default)(verticalCoordinatesGenerator)) {
		var isVerticalValues = verticalValues && verticalValues.length;
		var _generatorResult = verticalCoordinatesGenerator({
			xAxis: xAxis ? _objectSpread$9(_objectSpread$9({}, xAxis), {}, { ticks: isVerticalValues ? verticalValues : xAxis.ticks }) : void 0,
			width: chartWidth,
			height: chartHeight,
			offset
		}, isVerticalValues ? true : syncWithTicks);
		warn(Array.isArray(_generatorResult), "verticalCoordinatesGenerator should return Array but instead it returned [".concat(_typeof$13(_generatorResult), "]"));
		if (Array.isArray(_generatorResult)) verticalPoints = _generatorResult;
	}
	return /*#__PURE__*/ import_react.createElement("g", { className: "recharts-cartesian-grid" }, /*#__PURE__*/ import_react.createElement(Background, {
		fill: propsIncludingDefaults.fill,
		fillOpacity: propsIncludingDefaults.fillOpacity,
		x: propsIncludingDefaults.x,
		y: propsIncludingDefaults.y,
		width: propsIncludingDefaults.width,
		height: propsIncludingDefaults.height,
		ry: propsIncludingDefaults.ry
	}), /*#__PURE__*/ import_react.createElement(HorizontalGridLines, _extends$12({}, propsIncludingDefaults, {
		offset,
		horizontalPoints,
		xAxis,
		yAxis
	})), /*#__PURE__*/ import_react.createElement(VerticalGridLines, _extends$12({}, propsIncludingDefaults, {
		offset,
		verticalPoints,
		xAxis,
		yAxis
	})), /*#__PURE__*/ import_react.createElement(HorizontalStripes, _extends$12({}, propsIncludingDefaults, { horizontalPoints })), /*#__PURE__*/ import_react.createElement(VerticalStripes, _extends$12({}, propsIncludingDefaults, { verticalPoints })));
}
CartesianGrid.displayName = "CartesianGrid";
//#endregion
//#region node_modules/recharts/es6/cartesian/Line.js
/**
* @fileOverview Line
*/
var _excluded$5 = [
	"type",
	"layout",
	"connectNulls",
	"ref"
];
var _excluded2$3 = ["key"];
function _typeof$12(o) {
	"@babel/helpers - typeof";
	return _typeof$12 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$12(o);
}
function _objectWithoutProperties$5(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$5(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$5(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
function _extends$11() {
	_extends$11 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$11.apply(this, arguments);
}
function ownKeys$8(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$8(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$8(Object(t), !0).forEach(function(r) {
			_defineProperty$12(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$8(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _toConsumableArray$3(arr) {
	return _arrayWithoutHoles$3(arr) || _iterableToArray$3(arr) || _unsupportedIterableToArray$4(arr) || _nonIterableSpread$3();
}
function _nonIterableSpread$3() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$4(o, minLen) {
	if (!o) return;
	if (typeof o === "string") return _arrayLikeToArray$4(o, minLen);
	var n = Object.prototype.toString.call(o).slice(8, -1);
	if (n === "Object" && o.constructor) n = o.constructor.name;
	if (n === "Map" || n === "Set") return Array.from(o);
	if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$4(o, minLen);
}
function _iterableToArray$3(iter) {
	if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _arrayWithoutHoles$3(arr) {
	if (Array.isArray(arr)) return _arrayLikeToArray$4(arr);
}
function _arrayLikeToArray$4(arr, len) {
	if (len == null || len > arr.length) len = arr.length;
	for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
	return arr2;
}
function _classCallCheck$10(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$10(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$12(descriptor.key), descriptor);
	}
}
function _createClass$10(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$10(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$10(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$9(t, o, e) {
	return o = _getPrototypeOf$9(o), _possibleConstructorReturn$9(t, _isNativeReflectConstruct$9() ? Reflect.construct(o, e || [], _getPrototypeOf$9(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$9(self, call) {
	if (call && (_typeof$12(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$9(self);
}
function _assertThisInitialized$9(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$9() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$9 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$9(o) {
	_getPrototypeOf$9 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$9(o);
}
function _inherits$9(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$9(subClass, superClass);
}
function _setPrototypeOf$9(o, p) {
	_setPrototypeOf$9 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$9(o, p);
}
function _defineProperty$12(obj, key, value) {
	key = _toPropertyKey$12(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$12(t) {
	var i = _toPrimitive$12(t, "string");
	return "symbol" == _typeof$12(i) ? i : i + "";
}
function _toPrimitive$12(t, r) {
	if ("object" != _typeof$12(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$12(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var Line = /*#__PURE__*/ function(_PureComponent) {
	function Line() {
		var _this;
		_classCallCheck$10(this, Line);
		for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
		_this = _callSuper$9(this, Line, [].concat(args));
		_defineProperty$12(_this, "state", {
			isAnimationFinished: true,
			totalLength: 0
		});
		_defineProperty$12(_this, "generateSimpleStrokeDasharray", function(totalLength, length) {
			return "".concat(length, "px ").concat(totalLength - length, "px");
		});
		_defineProperty$12(_this, "getStrokeDasharray", function(length, totalLength, lines) {
			var lineLength = lines.reduce(function(pre, next) {
				return pre + next;
			});
			if (!lineLength) return _this.generateSimpleStrokeDasharray(totalLength, length);
			var count = Math.floor(length / lineLength);
			var remainLength = length % lineLength;
			var restLength = totalLength - length;
			var remainLines = [];
			for (var i = 0, sum = 0; i < lines.length; sum += lines[i], ++i) if (sum + lines[i] > remainLength) {
				remainLines = [].concat(_toConsumableArray$3(lines.slice(0, i)), [remainLength - sum]);
				break;
			}
			var emptyLines = remainLines.length % 2 === 0 ? [0, restLength] : [restLength];
			return [].concat(_toConsumableArray$3(Line.repeat(lines, count)), _toConsumableArray$3(remainLines), emptyLines).map(function(line) {
				return "".concat(line, "px");
			}).join(", ");
		});
		_defineProperty$12(_this, "id", uniqueId("recharts-line-"));
		_defineProperty$12(_this, "pathRef", function(node) {
			_this.mainCurve = node;
		});
		_defineProperty$12(_this, "handleAnimationEnd", function() {
			_this.setState({ isAnimationFinished: true });
			if (_this.props.onAnimationEnd) _this.props.onAnimationEnd();
		});
		_defineProperty$12(_this, "handleAnimationStart", function() {
			_this.setState({ isAnimationFinished: false });
			if (_this.props.onAnimationStart) _this.props.onAnimationStart();
		});
		return _this;
	}
	_inherits$9(Line, _PureComponent);
	return _createClass$10(Line, [
		{
			key: "componentDidMount",
			value: function componentDidMount() {
				if (!this.props.isAnimationActive) return;
				var totalLength = this.getTotalLength();
				this.setState({ totalLength });
			}
		},
		{
			key: "componentDidUpdate",
			value: function componentDidUpdate() {
				if (!this.props.isAnimationActive) return;
				var totalLength = this.getTotalLength();
				if (totalLength !== this.state.totalLength) this.setState({ totalLength });
			}
		},
		{
			key: "getTotalLength",
			value: function getTotalLength() {
				var curveDom = this.mainCurve;
				try {
					return curveDom && curveDom.getTotalLength && curveDom.getTotalLength() || 0;
				} catch (err) {
					return 0;
				}
			}
		},
		{
			key: "renderErrorBar",
			value: function renderErrorBar(needClip, clipPathId) {
				if (this.props.isAnimationActive && !this.state.isAnimationFinished) return null;
				var _this$props = this.props, points = _this$props.points, xAxis = _this$props.xAxis, yAxis = _this$props.yAxis, layout = _this$props.layout, children = _this$props.children;
				var errorBarItems = findAllByType(children, ErrorBar);
				if (!errorBarItems) return null;
				var dataPointFormatter = function dataPointFormatter(dataPoint, dataKey) {
					return {
						x: dataPoint.x,
						y: dataPoint.y,
						value: dataPoint.value,
						errorVal: getValueByDataKey(dataPoint.payload, dataKey)
					};
				};
				var errorBarProps = { clipPath: needClip ? "url(#clipPath-".concat(clipPathId, ")") : null };
				return /*#__PURE__*/ import_react.createElement(Layer, errorBarProps, errorBarItems.map(function(item) {
					return /*#__PURE__*/ import_react.cloneElement(item, {
						key: "bar-".concat(item.props.dataKey),
						data: points,
						xAxis,
						yAxis,
						layout,
						dataPointFormatter
					});
				}));
			}
		},
		{
			key: "renderDots",
			value: function renderDots(needClip, clipDot, clipPathId) {
				if (this.props.isAnimationActive && !this.state.isAnimationFinished) return null;
				var _this$props2 = this.props, dot = _this$props2.dot, points = _this$props2.points, dataKey = _this$props2.dataKey;
				var lineProps = filterProps(this.props, false);
				var customDotProps = filterProps(dot, true);
				var dots = points.map(function(entry, i) {
					var dotProps = _objectSpread$8(_objectSpread$8(_objectSpread$8({
						key: "dot-".concat(i),
						r: 3
					}, lineProps), customDotProps), {}, {
						index: i,
						cx: entry.x,
						cy: entry.y,
						value: entry.value,
						dataKey,
						payload: entry.payload,
						points
					});
					return Line.renderDotItem(dot, dotProps);
				});
				var dotsProps = { clipPath: needClip ? "url(#clipPath-".concat(clipDot ? "" : "dots-").concat(clipPathId, ")") : null };
				return /*#__PURE__*/ import_react.createElement(Layer, _extends$11({
					className: "recharts-line-dots",
					key: "dots"
				}, dotsProps), dots);
			}
		},
		{
			key: "renderCurveStatically",
			value: function renderCurveStatically(points, needClip, clipPathId, props) {
				var _this$props3 = this.props, type = _this$props3.type, layout = _this$props3.layout, connectNulls = _this$props3.connectNulls;
				_this$props3.ref;
				var curveProps = _objectSpread$8(_objectSpread$8(_objectSpread$8({}, filterProps(_objectWithoutProperties$5(_this$props3, _excluded$5), true)), {}, {
					fill: "none",
					className: "recharts-line-curve",
					clipPath: needClip ? "url(#clipPath-".concat(clipPathId, ")") : null,
					points
				}, props), {}, {
					type,
					layout,
					connectNulls
				});
				return /*#__PURE__*/ import_react.createElement(Curve, _extends$11({}, curveProps, { pathRef: this.pathRef }));
			}
		},
		{
			key: "renderCurveWithAnimation",
			value: function renderCurveWithAnimation(needClip, clipPathId) {
				var _this2 = this;
				var _this$props4 = this.props, points = _this$props4.points, strokeDasharray = _this$props4.strokeDasharray, isAnimationActive = _this$props4.isAnimationActive, animationBegin = _this$props4.animationBegin, animationDuration = _this$props4.animationDuration, animationEasing = _this$props4.animationEasing, animationId = _this$props4.animationId, animateNewValues = _this$props4.animateNewValues, width = _this$props4.width, height = _this$props4.height;
				var _this$state = this.state, prevPoints = _this$state.prevPoints, totalLength = _this$state.totalLength;
				return /*#__PURE__*/ import_react.createElement(es6_default, {
					begin: animationBegin,
					duration: animationDuration,
					isActive: isAnimationActive,
					easing: animationEasing,
					from: { t: 0 },
					to: { t: 1 },
					key: "line-".concat(animationId),
					onAnimationEnd: this.handleAnimationEnd,
					onAnimationStart: this.handleAnimationStart
				}, function(_ref) {
					var t = _ref.t;
					if (prevPoints) {
						var prevPointsDiffFactor = prevPoints.length / points.length;
						var stepData = points.map(function(entry, index) {
							var prevPointIndex = Math.floor(index * prevPointsDiffFactor);
							if (prevPoints[prevPointIndex]) {
								var prev = prevPoints[prevPointIndex];
								var interpolatorX = interpolateNumber$1(prev.x, entry.x);
								var interpolatorY = interpolateNumber$1(prev.y, entry.y);
								return _objectSpread$8(_objectSpread$8({}, entry), {}, {
									x: interpolatorX(t),
									y: interpolatorY(t)
								});
							}
							if (animateNewValues) {
								var _interpolatorX = interpolateNumber$1(width * 2, entry.x);
								var _interpolatorY = interpolateNumber$1(height / 2, entry.y);
								return _objectSpread$8(_objectSpread$8({}, entry), {}, {
									x: _interpolatorX(t),
									y: _interpolatorY(t)
								});
							}
							return _objectSpread$8(_objectSpread$8({}, entry), {}, {
								x: entry.x,
								y: entry.y
							});
						});
						return _this2.renderCurveStatically(stepData, needClip, clipPathId);
					}
					var curLength = interpolateNumber$1(0, totalLength)(t);
					var currentStrokeDasharray;
					if (strokeDasharray) {
						var lines = "".concat(strokeDasharray).split(/[,\s]+/gim).map(function(num) {
							return parseFloat(num);
						});
						currentStrokeDasharray = _this2.getStrokeDasharray(curLength, totalLength, lines);
					} else currentStrokeDasharray = _this2.generateSimpleStrokeDasharray(totalLength, curLength);
					return _this2.renderCurveStatically(points, needClip, clipPathId, { strokeDasharray: currentStrokeDasharray });
				});
			}
		},
		{
			key: "renderCurve",
			value: function renderCurve(needClip, clipPathId) {
				var _this$props5 = this.props, points = _this$props5.points, isAnimationActive = _this$props5.isAnimationActive;
				var _this$state2 = this.state, prevPoints = _this$state2.prevPoints, totalLength = _this$state2.totalLength;
				if (isAnimationActive && points && points.length && (!prevPoints && totalLength > 0 || !(0, import_isEqual.default)(prevPoints, points))) return this.renderCurveWithAnimation(needClip, clipPathId);
				return this.renderCurveStatically(points, needClip, clipPathId);
			}
		},
		{
			key: "render",
			value: function render() {
				var _filterProps;
				var _this$props6 = this.props, hide = _this$props6.hide, dot = _this$props6.dot, points = _this$props6.points, className = _this$props6.className, xAxis = _this$props6.xAxis, yAxis = _this$props6.yAxis, top = _this$props6.top, left = _this$props6.left, width = _this$props6.width, height = _this$props6.height, isAnimationActive = _this$props6.isAnimationActive, id = _this$props6.id;
				if (hide || !points || !points.length) return null;
				var isAnimationFinished = this.state.isAnimationFinished;
				var hasSinglePoint = points.length === 1;
				var layerClass = clsx("recharts-line", className);
				var needClipX = xAxis && xAxis.allowDataOverflow;
				var needClipY = yAxis && yAxis.allowDataOverflow;
				var needClip = needClipX || needClipY;
				var clipPathId = (0, import_isNil.default)(id) ? this.id : id;
				var _ref2 = (_filterProps = filterProps(dot, false)) !== null && _filterProps !== void 0 ? _filterProps : {
					r: 3,
					strokeWidth: 2
				}, _ref2$r = _ref2.r, r = _ref2$r === void 0 ? 3 : _ref2$r, _ref2$strokeWidth = _ref2.strokeWidth, strokeWidth = _ref2$strokeWidth === void 0 ? 2 : _ref2$strokeWidth;
				var _ref3$clipDot = (hasClipDot(dot) ? dot : {}).clipDot, clipDot = _ref3$clipDot === void 0 ? true : _ref3$clipDot;
				var dotSize = r * 2 + strokeWidth;
				return /*#__PURE__*/ import_react.createElement(Layer, { className: layerClass }, needClipX || needClipY ? /*#__PURE__*/ import_react.createElement("defs", null, /*#__PURE__*/ import_react.createElement("clipPath", { id: "clipPath-".concat(clipPathId) }, /*#__PURE__*/ import_react.createElement("rect", {
					x: needClipX ? left : left - width / 2,
					y: needClipY ? top : top - height / 2,
					width: needClipX ? width : width * 2,
					height: needClipY ? height : height * 2
				})), !clipDot && /*#__PURE__*/ import_react.createElement("clipPath", { id: "clipPath-dots-".concat(clipPathId) }, /*#__PURE__*/ import_react.createElement("rect", {
					x: left - dotSize / 2,
					y: top - dotSize / 2,
					width: width + dotSize,
					height: height + dotSize
				}))) : null, !hasSinglePoint && this.renderCurve(needClip, clipPathId), this.renderErrorBar(needClip, clipPathId), (hasSinglePoint || dot) && this.renderDots(needClip, clipDot, clipPathId), (!isAnimationActive || isAnimationFinished) && LabelList.renderCallByParent(this.props, points));
			}
		}
	], [
		{
			key: "getDerivedStateFromProps",
			value: function getDerivedStateFromProps(nextProps, prevState) {
				if (nextProps.animationId !== prevState.prevAnimationId) return {
					prevAnimationId: nextProps.animationId,
					curPoints: nextProps.points,
					prevPoints: prevState.curPoints
				};
				if (nextProps.points !== prevState.curPoints) return { curPoints: nextProps.points };
				return null;
			}
		},
		{
			key: "repeat",
			value: function repeat(lines, count) {
				var linesUnit = lines.length % 2 !== 0 ? [].concat(_toConsumableArray$3(lines), [0]) : lines;
				var result = [];
				for (var i = 0; i < count; ++i) result = [].concat(_toConsumableArray$3(result), _toConsumableArray$3(linesUnit));
				return result;
			}
		},
		{
			key: "renderDotItem",
			value: function renderDotItem(option, props) {
				var dotItem;
				if (/*#__PURE__*/ import_react.isValidElement(option)) dotItem = /*#__PURE__*/ import_react.cloneElement(option, props);
				else if ((0, import_isFunction.default)(option)) dotItem = option(props);
				else {
					var key = props.key, dotProps = _objectWithoutProperties$5(props, _excluded2$3);
					var className = clsx("recharts-line-dot", typeof option !== "boolean" ? option.className : "");
					dotItem = /*#__PURE__*/ import_react.createElement(Dot, _extends$11({ key }, dotProps, { className }));
				}
				return dotItem;
			}
		}
	]);
}(import_react.PureComponent);
_defineProperty$12(Line, "displayName", "Line");
_defineProperty$12(Line, "defaultProps", {
	xAxisId: 0,
	yAxisId: 0,
	connectNulls: false,
	activeDot: true,
	dot: true,
	legendType: "line",
	stroke: "#3182bd",
	strokeWidth: 1,
	fill: "#fff",
	points: [],
	isAnimationActive: !Global.isSsr,
	animateNewValues: true,
	animationBegin: 0,
	animationDuration: 1500,
	animationEasing: "ease",
	hide: false,
	label: false
});
/**
* Compose the data of each group
* @param {Object} props The props from the component
* @param  {Object} xAxis   The configuration of x-axis
* @param  {Object} yAxis   The configuration of y-axis
* @param  {String} dataKey The unique key of a group
* @return {Array}  Composed data
*/
_defineProperty$12(Line, "getComposedData", function(_ref4) {
	var props = _ref4.props, xAxis = _ref4.xAxis, yAxis = _ref4.yAxis, xAxisTicks = _ref4.xAxisTicks, yAxisTicks = _ref4.yAxisTicks, dataKey = _ref4.dataKey, bandSize = _ref4.bandSize, displayedData = _ref4.displayedData, offset = _ref4.offset;
	var layout = props.layout;
	return _objectSpread$8({
		points: displayedData.map(function(entry, index) {
			var value = getValueByDataKey(entry, dataKey);
			if (layout === "horizontal") return {
				x: getCateCoordinateOfLine({
					axis: xAxis,
					ticks: xAxisTicks,
					bandSize,
					entry,
					index
				}),
				y: (0, import_isNil.default)(value) ? null : yAxis.scale(value),
				value,
				payload: entry
			};
			return {
				x: (0, import_isNil.default)(value) ? null : xAxis.scale(value),
				y: getCateCoordinateOfLine({
					axis: yAxis,
					ticks: yAxisTicks,
					bandSize,
					entry,
					index
				}),
				value,
				payload: entry
			};
		}),
		layout
	}, offset);
});
//#endregion
//#region node_modules/recharts/es6/cartesian/Area.js
/**
* @fileOverview Area
*/
var _excluded$4 = [
	"layout",
	"type",
	"stroke",
	"connectNulls",
	"isRange",
	"ref"
];
var _excluded2$2 = ["key"];
var _Area;
function _typeof$11(o) {
	"@babel/helpers - typeof";
	return _typeof$11 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$11(o);
}
function _objectWithoutProperties$4(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$4(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$4(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
function _extends$10() {
	_extends$10 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$10.apply(this, arguments);
}
function ownKeys$7(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$7(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$7(Object(t), !0).forEach(function(r) {
			_defineProperty$11(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$7(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _classCallCheck$9(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$9(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$11(descriptor.key), descriptor);
	}
}
function _createClass$9(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$9(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$9(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$8(t, o, e) {
	return o = _getPrototypeOf$8(o), _possibleConstructorReturn$8(t, _isNativeReflectConstruct$8() ? Reflect.construct(o, e || [], _getPrototypeOf$8(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$8(self, call) {
	if (call && (_typeof$11(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$8(self);
}
function _assertThisInitialized$8(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$8() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$8 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$8(o) {
	_getPrototypeOf$8 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$8(o);
}
function _inherits$8(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$8(subClass, superClass);
}
function _setPrototypeOf$8(o, p) {
	_setPrototypeOf$8 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$8(o, p);
}
function _defineProperty$11(obj, key, value) {
	key = _toPropertyKey$11(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$11(t) {
	var i = _toPrimitive$11(t, "string");
	return "symbol" == _typeof$11(i) ? i : i + "";
}
function _toPrimitive$11(t, r) {
	if ("object" != _typeof$11(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$11(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var Area = /*#__PURE__*/ function(_PureComponent) {
	function Area() {
		var _this;
		_classCallCheck$9(this, Area);
		for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
		_this = _callSuper$8(this, Area, [].concat(args));
		_defineProperty$11(_this, "state", { isAnimationFinished: true });
		_defineProperty$11(_this, "id", uniqueId("recharts-area-"));
		_defineProperty$11(_this, "handleAnimationEnd", function() {
			var onAnimationEnd = _this.props.onAnimationEnd;
			_this.setState({ isAnimationFinished: true });
			if ((0, import_isFunction.default)(onAnimationEnd)) onAnimationEnd();
		});
		_defineProperty$11(_this, "handleAnimationStart", function() {
			var onAnimationStart = _this.props.onAnimationStart;
			_this.setState({ isAnimationFinished: false });
			if ((0, import_isFunction.default)(onAnimationStart)) onAnimationStart();
		});
		return _this;
	}
	_inherits$8(Area, _PureComponent);
	return _createClass$9(Area, [
		{
			key: "renderDots",
			value: function renderDots(needClip, clipDot, clipPathId) {
				var isAnimationActive = this.props.isAnimationActive;
				var isAnimationFinished = this.state.isAnimationFinished;
				if (isAnimationActive && !isAnimationFinished) return null;
				var _this$props = this.props, dot = _this$props.dot, points = _this$props.points, dataKey = _this$props.dataKey;
				var areaProps = filterProps(this.props, false);
				var customDotProps = filterProps(dot, true);
				var dots = points.map(function(entry, i) {
					var dotProps = _objectSpread$7(_objectSpread$7(_objectSpread$7({
						key: "dot-".concat(i),
						r: 3
					}, areaProps), customDotProps), {}, {
						index: i,
						cx: entry.x,
						cy: entry.y,
						dataKey,
						value: entry.value,
						payload: entry.payload,
						points
					});
					return Area.renderDotItem(dot, dotProps);
				});
				var dotsProps = { clipPath: needClip ? "url(#clipPath-".concat(clipDot ? "" : "dots-").concat(clipPathId, ")") : null };
				return /*#__PURE__*/ import_react.createElement(Layer, _extends$10({ className: "recharts-area-dots" }, dotsProps), dots);
			}
		},
		{
			key: "renderHorizontalRect",
			value: function renderHorizontalRect(alpha) {
				var _this$props2 = this.props, baseLine = _this$props2.baseLine, points = _this$props2.points, strokeWidth = _this$props2.strokeWidth;
				var startX = points[0].x;
				var endX = points[points.length - 1].x;
				var width = alpha * Math.abs(startX - endX);
				var maxY = (0, import_max.default)(points.map(function(entry) {
					return entry.y || 0;
				}));
				if (isNumber$1(baseLine) && typeof baseLine === "number") maxY = Math.max(baseLine, maxY);
				else if (baseLine && Array.isArray(baseLine) && baseLine.length) maxY = Math.max((0, import_max.default)(baseLine.map(function(entry) {
					return entry.y || 0;
				})), maxY);
				if (isNumber$1(maxY)) return /*#__PURE__*/ import_react.createElement("rect", {
					x: startX < endX ? startX : startX - width,
					y: 0,
					width,
					height: Math.floor(maxY + (strokeWidth ? parseInt("".concat(strokeWidth), 10) : 1))
				});
				return null;
			}
		},
		{
			key: "renderVerticalRect",
			value: function renderVerticalRect(alpha) {
				var _this$props3 = this.props, baseLine = _this$props3.baseLine, points = _this$props3.points, strokeWidth = _this$props3.strokeWidth;
				var startY = points[0].y;
				var endY = points[points.length - 1].y;
				var height = alpha * Math.abs(startY - endY);
				var maxX = (0, import_max.default)(points.map(function(entry) {
					return entry.x || 0;
				}));
				if (isNumber$1(baseLine) && typeof baseLine === "number") maxX = Math.max(baseLine, maxX);
				else if (baseLine && Array.isArray(baseLine) && baseLine.length) maxX = Math.max((0, import_max.default)(baseLine.map(function(entry) {
					return entry.x || 0;
				})), maxX);
				if (isNumber$1(maxX)) return /*#__PURE__*/ import_react.createElement("rect", {
					x: 0,
					y: startY < endY ? startY : startY - height,
					width: maxX + (strokeWidth ? parseInt("".concat(strokeWidth), 10) : 1),
					height: Math.floor(height)
				});
				return null;
			}
		},
		{
			key: "renderClipRect",
			value: function renderClipRect(alpha) {
				if (this.props.layout === "vertical") return this.renderVerticalRect(alpha);
				return this.renderHorizontalRect(alpha);
			}
		},
		{
			key: "renderAreaStatically",
			value: function renderAreaStatically(points, baseLine, needClip, clipPathId) {
				var _this$props4 = this.props, layout = _this$props4.layout, type = _this$props4.type, stroke = _this$props4.stroke, connectNulls = _this$props4.connectNulls, isRange = _this$props4.isRange;
				_this$props4.ref;
				var others = _objectWithoutProperties$4(_this$props4, _excluded$4);
				return /*#__PURE__*/ import_react.createElement(Layer, { clipPath: needClip ? "url(#clipPath-".concat(clipPathId, ")") : null }, /*#__PURE__*/ import_react.createElement(Curve, _extends$10({}, filterProps(others, true), {
					points,
					connectNulls,
					type,
					baseLine,
					layout,
					stroke: "none",
					className: "recharts-area-area"
				})), stroke !== "none" && /*#__PURE__*/ import_react.createElement(Curve, _extends$10({}, filterProps(this.props, false), {
					className: "recharts-area-curve",
					layout,
					type,
					connectNulls,
					fill: "none",
					points
				})), stroke !== "none" && isRange && /*#__PURE__*/ import_react.createElement(Curve, _extends$10({}, filterProps(this.props, false), {
					className: "recharts-area-curve",
					layout,
					type,
					connectNulls,
					fill: "none",
					points: baseLine
				})));
			}
		},
		{
			key: "renderAreaWithAnimation",
			value: function renderAreaWithAnimation(needClip, clipPathId) {
				var _this2 = this;
				var _this$props5 = this.props, points = _this$props5.points, baseLine = _this$props5.baseLine, isAnimationActive = _this$props5.isAnimationActive, animationBegin = _this$props5.animationBegin, animationDuration = _this$props5.animationDuration, animationEasing = _this$props5.animationEasing, animationId = _this$props5.animationId;
				var _this$state = this.state, prevPoints = _this$state.prevPoints, prevBaseLine = _this$state.prevBaseLine;
				return /*#__PURE__*/ import_react.createElement(es6_default, {
					begin: animationBegin,
					duration: animationDuration,
					isActive: isAnimationActive,
					easing: animationEasing,
					from: { t: 0 },
					to: { t: 1 },
					key: "area-".concat(animationId),
					onAnimationEnd: this.handleAnimationEnd,
					onAnimationStart: this.handleAnimationStart
				}, function(_ref) {
					var t = _ref.t;
					if (prevPoints) {
						var prevPointsDiffFactor = prevPoints.length / points.length;
						var stepPoints = points.map(function(entry, index) {
							var prevPointIndex = Math.floor(index * prevPointsDiffFactor);
							if (prevPoints[prevPointIndex]) {
								var prev = prevPoints[prevPointIndex];
								var interpolatorX = interpolateNumber$1(prev.x, entry.x);
								var interpolatorY = interpolateNumber$1(prev.y, entry.y);
								return _objectSpread$7(_objectSpread$7({}, entry), {}, {
									x: interpolatorX(t),
									y: interpolatorY(t)
								});
							}
							return entry;
						});
						var stepBaseLine;
						if (isNumber$1(baseLine) && typeof baseLine === "number") stepBaseLine = interpolateNumber$1(prevBaseLine, baseLine)(t);
						else if ((0, import_isNil.default)(baseLine) || (0, import_isNaN.default)(baseLine)) stepBaseLine = interpolateNumber$1(prevBaseLine, 0)(t);
						else stepBaseLine = baseLine.map(function(entry, index) {
							var prevPointIndex = Math.floor(index * prevPointsDiffFactor);
							if (prevBaseLine[prevPointIndex]) {
								var prev = prevBaseLine[prevPointIndex];
								var interpolatorX = interpolateNumber$1(prev.x, entry.x);
								var interpolatorY = interpolateNumber$1(prev.y, entry.y);
								return _objectSpread$7(_objectSpread$7({}, entry), {}, {
									x: interpolatorX(t),
									y: interpolatorY(t)
								});
							}
							return entry;
						});
						return _this2.renderAreaStatically(stepPoints, stepBaseLine, needClip, clipPathId);
					}
					return /*#__PURE__*/ import_react.createElement(Layer, null, /*#__PURE__*/ import_react.createElement("defs", null, /*#__PURE__*/ import_react.createElement("clipPath", { id: "animationClipPath-".concat(clipPathId) }, _this2.renderClipRect(t))), /*#__PURE__*/ import_react.createElement(Layer, { clipPath: "url(#animationClipPath-".concat(clipPathId, ")") }, _this2.renderAreaStatically(points, baseLine, needClip, clipPathId)));
				});
			}
		},
		{
			key: "renderArea",
			value: function renderArea(needClip, clipPathId) {
				var _this$props6 = this.props, points = _this$props6.points, baseLine = _this$props6.baseLine, isAnimationActive = _this$props6.isAnimationActive;
				var _this$state2 = this.state, prevPoints = _this$state2.prevPoints, prevBaseLine = _this$state2.prevBaseLine, totalLength = _this$state2.totalLength;
				if (isAnimationActive && points && points.length && (!prevPoints && totalLength > 0 || !(0, import_isEqual.default)(prevPoints, points) || !(0, import_isEqual.default)(prevBaseLine, baseLine))) return this.renderAreaWithAnimation(needClip, clipPathId);
				return this.renderAreaStatically(points, baseLine, needClip, clipPathId);
			}
		},
		{
			key: "render",
			value: function render() {
				var _filterProps;
				var _this$props7 = this.props, hide = _this$props7.hide, dot = _this$props7.dot, points = _this$props7.points, className = _this$props7.className, top = _this$props7.top, left = _this$props7.left, xAxis = _this$props7.xAxis, yAxis = _this$props7.yAxis, width = _this$props7.width, height = _this$props7.height, isAnimationActive = _this$props7.isAnimationActive, id = _this$props7.id;
				if (hide || !points || !points.length) return null;
				var isAnimationFinished = this.state.isAnimationFinished;
				var hasSinglePoint = points.length === 1;
				var layerClass = clsx("recharts-area", className);
				var needClipX = xAxis && xAxis.allowDataOverflow;
				var needClipY = yAxis && yAxis.allowDataOverflow;
				var needClip = needClipX || needClipY;
				var clipPathId = (0, import_isNil.default)(id) ? this.id : id;
				var _ref2 = (_filterProps = filterProps(dot, false)) !== null && _filterProps !== void 0 ? _filterProps : {
					r: 3,
					strokeWidth: 2
				}, _ref2$r = _ref2.r, r = _ref2$r === void 0 ? 3 : _ref2$r, _ref2$strokeWidth = _ref2.strokeWidth, strokeWidth = _ref2$strokeWidth === void 0 ? 2 : _ref2$strokeWidth;
				var _ref3$clipDot = (hasClipDot(dot) ? dot : {}).clipDot, clipDot = _ref3$clipDot === void 0 ? true : _ref3$clipDot;
				var dotSize = r * 2 + strokeWidth;
				return /*#__PURE__*/ import_react.createElement(Layer, { className: layerClass }, needClipX || needClipY ? /*#__PURE__*/ import_react.createElement("defs", null, /*#__PURE__*/ import_react.createElement("clipPath", { id: "clipPath-".concat(clipPathId) }, /*#__PURE__*/ import_react.createElement("rect", {
					x: needClipX ? left : left - width / 2,
					y: needClipY ? top : top - height / 2,
					width: needClipX ? width : width * 2,
					height: needClipY ? height : height * 2
				})), !clipDot && /*#__PURE__*/ import_react.createElement("clipPath", { id: "clipPath-dots-".concat(clipPathId) }, /*#__PURE__*/ import_react.createElement("rect", {
					x: left - dotSize / 2,
					y: top - dotSize / 2,
					width: width + dotSize,
					height: height + dotSize
				}))) : null, !hasSinglePoint ? this.renderArea(needClip, clipPathId) : null, (dot || hasSinglePoint) && this.renderDots(needClip, clipDot, clipPathId), (!isAnimationActive || isAnimationFinished) && LabelList.renderCallByParent(this.props, points));
			}
		}
	], [{
		key: "getDerivedStateFromProps",
		value: function getDerivedStateFromProps(nextProps, prevState) {
			if (nextProps.animationId !== prevState.prevAnimationId) return {
				prevAnimationId: nextProps.animationId,
				curPoints: nextProps.points,
				curBaseLine: nextProps.baseLine,
				prevPoints: prevState.curPoints,
				prevBaseLine: prevState.curBaseLine
			};
			if (nextProps.points !== prevState.curPoints || nextProps.baseLine !== prevState.curBaseLine) return {
				curPoints: nextProps.points,
				curBaseLine: nextProps.baseLine
			};
			return null;
		}
	}]);
}(import_react.PureComponent);
_Area = Area;
_defineProperty$11(Area, "displayName", "Area");
_defineProperty$11(Area, "defaultProps", {
	stroke: "#3182bd",
	fill: "#3182bd",
	fillOpacity: .6,
	xAxisId: 0,
	yAxisId: 0,
	legendType: "line",
	connectNulls: false,
	points: [],
	dot: false,
	activeDot: true,
	hide: false,
	isAnimationActive: !Global.isSsr,
	animationBegin: 0,
	animationDuration: 1500,
	animationEasing: "ease"
});
_defineProperty$11(Area, "getBaseValue", function(props, item, xAxis, yAxis) {
	var layout = props.layout, chartBaseValue = props.baseValue;
	var itemBaseValue = item.props.baseValue;
	var baseValue = itemBaseValue !== null && itemBaseValue !== void 0 ? itemBaseValue : chartBaseValue;
	if (isNumber$1(baseValue) && typeof baseValue === "number") return baseValue;
	var numericAxis = layout === "horizontal" ? yAxis : xAxis;
	var domain = numericAxis.scale.domain();
	if (numericAxis.type === "number") {
		var domainMax = Math.max(domain[0], domain[1]);
		var domainMin = Math.min(domain[0], domain[1]);
		if (baseValue === "dataMin") return domainMin;
		if (baseValue === "dataMax") return domainMax;
		return domainMax < 0 ? domainMax : Math.max(Math.min(domain[0], domain[1]), 0);
	}
	if (baseValue === "dataMin") return domain[0];
	if (baseValue === "dataMax") return domain[1];
	return domain[0];
});
_defineProperty$11(Area, "getComposedData", function(_ref4) {
	var props = _ref4.props, item = _ref4.item, xAxis = _ref4.xAxis, yAxis = _ref4.yAxis, xAxisTicks = _ref4.xAxisTicks, yAxisTicks = _ref4.yAxisTicks, bandSize = _ref4.bandSize, dataKey = _ref4.dataKey, stackedData = _ref4.stackedData, dataStartIndex = _ref4.dataStartIndex, displayedData = _ref4.displayedData, offset = _ref4.offset;
	var layout = props.layout;
	var hasStack = stackedData && stackedData.length;
	var baseValue = _Area.getBaseValue(props, item, xAxis, yAxis);
	var isHorizontalLayout = layout === "horizontal";
	var isRange = false;
	var points = displayedData.map(function(entry, index) {
		var value;
		if (hasStack) value = stackedData[dataStartIndex + index];
		else {
			value = getValueByDataKey(entry, dataKey);
			if (!Array.isArray(value)) value = [baseValue, value];
			else isRange = true;
		}
		var isBreakPoint = value[1] == null || hasStack && getValueByDataKey(entry, dataKey) == null;
		if (isHorizontalLayout) return {
			x: getCateCoordinateOfLine({
				axis: xAxis,
				ticks: xAxisTicks,
				bandSize,
				entry,
				index
			}),
			y: isBreakPoint ? null : yAxis.scale(value[1]),
			value,
			payload: entry
		};
		return {
			x: isBreakPoint ? null : xAxis.scale(value[1]),
			y: getCateCoordinateOfLine({
				axis: yAxis,
				ticks: yAxisTicks,
				bandSize,
				entry,
				index
			}),
			value,
			payload: entry
		};
	});
	var baseLine;
	if (hasStack || isRange) baseLine = points.map(function(entry) {
		var x = Array.isArray(entry.value) ? entry.value[0] : null;
		if (isHorizontalLayout) return {
			x: entry.x,
			y: x != null && entry.y != null ? yAxis.scale(x) : null
		};
		return {
			x: x != null ? xAxis.scale(x) : null,
			y: entry.y
		};
	});
	else baseLine = isHorizontalLayout ? yAxis.scale(baseValue) : xAxis.scale(baseValue);
	return _objectSpread$7({
		points,
		baseLine,
		layout,
		isRange
	}, offset);
});
_defineProperty$11(Area, "renderDotItem", function(option, props) {
	var dotItem;
	if (/*#__PURE__*/ import_react.isValidElement(option)) dotItem = /*#__PURE__*/ import_react.cloneElement(option, props);
	else if ((0, import_isFunction.default)(option)) dotItem = option(props);
	else {
		var className = clsx("recharts-area-dot", typeof option !== "boolean" ? option.className : "");
		var key = props.key, rest = _objectWithoutProperties$4(props, _excluded2$2);
		dotItem = /*#__PURE__*/ import_react.createElement(Dot, _extends$10({}, rest, {
			key,
			className
		}));
	}
	return dotItem;
});
//#endregion
//#region node_modules/recharts/es6/cartesian/ZAxis.js
/**
* @fileOverview Z Axis
*/
function _typeof$10(o) {
	"@babel/helpers - typeof";
	return _typeof$10 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$10(o);
}
function _classCallCheck$8(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$8(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$10(descriptor.key), descriptor);
	}
}
function _createClass$8(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$8(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$8(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$7(t, o, e) {
	return o = _getPrototypeOf$7(o), _possibleConstructorReturn$7(t, _isNativeReflectConstruct$7() ? Reflect.construct(o, e || [], _getPrototypeOf$7(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$7(self, call) {
	if (call && (_typeof$10(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$7(self);
}
function _assertThisInitialized$7(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$7() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$7 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$7(o) {
	_getPrototypeOf$7 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$7(o);
}
function _inherits$7(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$7(subClass, superClass);
}
function _setPrototypeOf$7(o, p) {
	_setPrototypeOf$7 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$7(o, p);
}
function _defineProperty$10(obj, key, value) {
	key = _toPropertyKey$10(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$10(t) {
	var i = _toPrimitive$10(t, "string");
	return "symbol" == _typeof$10(i) ? i : i + "";
}
function _toPrimitive$10(t, r) {
	if ("object" != _typeof$10(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$10(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var ZAxis = /*#__PURE__*/ function(_React$Component) {
	function ZAxis() {
		_classCallCheck$8(this, ZAxis);
		return _callSuper$7(this, ZAxis, arguments);
	}
	_inherits$7(ZAxis, _React$Component);
	return _createClass$8(ZAxis, [{
		key: "render",
		value: function render() {
			return null;
		}
	}]);
}(import_react.Component);
_defineProperty$10(ZAxis, "displayName", "ZAxis");
_defineProperty$10(ZAxis, "defaultProps", {
	zAxisId: 0,
	range: [64, 64],
	scale: "auto",
	type: "number"
});
//#endregion
//#region node_modules/recharts/es6/util/ScatterUtils.js
var _excluded$3 = ["option", "isActive"];
function _extends$9() {
	_extends$9 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$9.apply(this, arguments);
}
function _objectWithoutProperties$3(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$3(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$3(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
function ScatterSymbol(_ref) {
	var option = _ref.option, isActive = _ref.isActive, props = _objectWithoutProperties$3(_ref, _excluded$3);
	if (typeof option === "string") return /*#__PURE__*/ import_react.createElement(Shape, _extends$9({
		option: /*#__PURE__*/ import_react.createElement(Symbols, _extends$9({ type: option }, props)),
		isActive,
		shapeType: "symbols"
	}, props));
	return /*#__PURE__*/ import_react.createElement(Shape, _extends$9({
		option,
		isActive,
		shapeType: "symbols"
	}, props));
}
//#endregion
//#region node_modules/recharts/es6/cartesian/Scatter.js
/**
* @fileOverview Render a group of scatters
*/
function _typeof$9(o) {
	"@babel/helpers - typeof";
	return _typeof$9 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$9(o);
}
function _extends$8() {
	_extends$8 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$8.apply(this, arguments);
}
function ownKeys$6(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$6(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$6(Object(t), !0).forEach(function(r) {
			_defineProperty$9(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$6(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _classCallCheck$7(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$7(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$9(descriptor.key), descriptor);
	}
}
function _createClass$7(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$7(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$7(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$6(t, o, e) {
	return o = _getPrototypeOf$6(o), _possibleConstructorReturn$6(t, _isNativeReflectConstruct$6() ? Reflect.construct(o, e || [], _getPrototypeOf$6(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$6(self, call) {
	if (call && (_typeof$9(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$6(self);
}
function _assertThisInitialized$6(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$6() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$6 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$6(o) {
	_getPrototypeOf$6 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$6(o);
}
function _inherits$6(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$6(subClass, superClass);
}
function _setPrototypeOf$6(o, p) {
	_setPrototypeOf$6 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$6(o, p);
}
function _defineProperty$9(obj, key, value) {
	key = _toPropertyKey$9(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$9(t) {
	var i = _toPrimitive$9(t, "string");
	return "symbol" == _typeof$9(i) ? i : i + "";
}
function _toPrimitive$9(t, r) {
	if ("object" != _typeof$9(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$9(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var Scatter = /*#__PURE__*/ function(_PureComponent) {
	function Scatter() {
		var _this;
		_classCallCheck$7(this, Scatter);
		for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
		_this = _callSuper$6(this, Scatter, [].concat(args));
		_defineProperty$9(_this, "state", { isAnimationFinished: false });
		_defineProperty$9(_this, "handleAnimationEnd", function() {
			_this.setState({ isAnimationFinished: true });
		});
		_defineProperty$9(_this, "handleAnimationStart", function() {
			_this.setState({ isAnimationFinished: false });
		});
		_defineProperty$9(_this, "id", uniqueId("recharts-scatter-"));
		return _this;
	}
	_inherits$6(Scatter, _PureComponent);
	return _createClass$7(Scatter, [
		{
			key: "renderSymbolsStatically",
			value: function renderSymbolsStatically(points) {
				var _this2 = this;
				var _this$props = this.props, shape = _this$props.shape, activeShape = _this$props.activeShape, activeIndex = _this$props.activeIndex;
				var baseProps = filterProps(this.props, false);
				return points.map(function(entry, i) {
					var isActive = activeIndex === i;
					var option = isActive ? activeShape : shape;
					var props = _objectSpread$6(_objectSpread$6({}, baseProps), entry);
					return /*#__PURE__*/ import_react.createElement(Layer, _extends$8({
						className: "recharts-scatter-symbol",
						key: "symbol-".concat(entry === null || entry === void 0 ? void 0 : entry.cx, "-").concat(entry === null || entry === void 0 ? void 0 : entry.cy, "-").concat(entry === null || entry === void 0 ? void 0 : entry.size, "-").concat(i)
					}, adaptEventsOfChild(_this2.props, entry, i), { role: "img" }), /*#__PURE__*/ import_react.createElement(ScatterSymbol, _extends$8({
						option,
						isActive,
						key: "symbol-".concat(i)
					}, props)));
				});
			}
		},
		{
			key: "renderSymbolsWithAnimation",
			value: function renderSymbolsWithAnimation() {
				var _this3 = this;
				var _this$props2 = this.props, points = _this$props2.points, isAnimationActive = _this$props2.isAnimationActive, animationBegin = _this$props2.animationBegin, animationDuration = _this$props2.animationDuration, animationEasing = _this$props2.animationEasing, animationId = _this$props2.animationId;
				var prevPoints = this.state.prevPoints;
				return /*#__PURE__*/ import_react.createElement(es6_default, {
					begin: animationBegin,
					duration: animationDuration,
					isActive: isAnimationActive,
					easing: animationEasing,
					from: { t: 0 },
					to: { t: 1 },
					key: "pie-".concat(animationId),
					onAnimationEnd: this.handleAnimationEnd,
					onAnimationStart: this.handleAnimationStart
				}, function(_ref) {
					var t = _ref.t;
					var stepData = points.map(function(entry, index) {
						var prev = prevPoints && prevPoints[index];
						if (prev) {
							var interpolatorCx = interpolateNumber$1(prev.cx, entry.cx);
							var interpolatorCy = interpolateNumber$1(prev.cy, entry.cy);
							var interpolatorSize = interpolateNumber$1(prev.size, entry.size);
							return _objectSpread$6(_objectSpread$6({}, entry), {}, {
								cx: interpolatorCx(t),
								cy: interpolatorCy(t),
								size: interpolatorSize(t)
							});
						}
						var interpolator = interpolateNumber$1(0, entry.size);
						return _objectSpread$6(_objectSpread$6({}, entry), {}, { size: interpolator(t) });
					});
					return /*#__PURE__*/ import_react.createElement(Layer, null, _this3.renderSymbolsStatically(stepData));
				});
			}
		},
		{
			key: "renderSymbols",
			value: function renderSymbols() {
				var _this$props3 = this.props, points = _this$props3.points, isAnimationActive = _this$props3.isAnimationActive;
				var prevPoints = this.state.prevPoints;
				if (isAnimationActive && points && points.length && (!prevPoints || !(0, import_isEqual.default)(prevPoints, points))) return this.renderSymbolsWithAnimation();
				return this.renderSymbolsStatically(points);
			}
		},
		{
			key: "renderErrorBar",
			value: function renderErrorBar() {
				if (this.props.isAnimationActive && !this.state.isAnimationFinished) return null;
				var _this$props4 = this.props, points = _this$props4.points, xAxis = _this$props4.xAxis, yAxis = _this$props4.yAxis, children = _this$props4.children;
				var errorBarItems = findAllByType(children, ErrorBar);
				if (!errorBarItems) return null;
				return errorBarItems.map(function(item, i) {
					var _item$props = item.props, direction = _item$props.direction, errorDataKey = _item$props.dataKey;
					return /*#__PURE__*/ import_react.cloneElement(item, {
						key: "".concat(direction, "-").concat(errorDataKey, "-").concat(points[i]),
						data: points,
						xAxis,
						yAxis,
						layout: direction === "x" ? "vertical" : "horizontal",
						dataPointFormatter: function dataPointFormatter(dataPoint, dataKey) {
							return {
								x: dataPoint.cx,
								y: dataPoint.cy,
								value: direction === "x" ? +dataPoint.node.x : +dataPoint.node.y,
								errorVal: getValueByDataKey(dataPoint, dataKey)
							};
						}
					});
				});
			}
		},
		{
			key: "renderLine",
			value: function renderLine() {
				var _this$props5 = this.props, points = _this$props5.points, line = _this$props5.line, lineType = _this$props5.lineType, lineJointType = _this$props5.lineJointType;
				var scatterProps = filterProps(this.props, false);
				var customLineProps = filterProps(line, false);
				var linePoints, lineItem;
				if (lineType === "joint") linePoints = points.map(function(entry) {
					return {
						x: entry.cx,
						y: entry.cy
					};
				});
				else if (lineType === "fitting") {
					var _getLinearRegression = getLinearRegression(points), xmin = _getLinearRegression.xmin, xmax = _getLinearRegression.xmax, a = _getLinearRegression.a, b = _getLinearRegression.b;
					var linearExp = function linearExp(x) {
						return a * x + b;
					};
					linePoints = [{
						x: xmin,
						y: linearExp(xmin)
					}, {
						x: xmax,
						y: linearExp(xmax)
					}];
				}
				var lineProps = _objectSpread$6(_objectSpread$6(_objectSpread$6({}, scatterProps), {}, {
					fill: "none",
					stroke: scatterProps && scatterProps.fill
				}, customLineProps), {}, { points: linePoints });
				if (/*#__PURE__*/ import_react.isValidElement(line)) lineItem = /*#__PURE__*/ import_react.cloneElement(line, lineProps);
				else if ((0, import_isFunction.default)(line)) lineItem = line(lineProps);
				else lineItem = /*#__PURE__*/ import_react.createElement(Curve, _extends$8({}, lineProps, { type: lineJointType }));
				return /*#__PURE__*/ import_react.createElement(Layer, {
					className: "recharts-scatter-line",
					key: "recharts-scatter-line"
				}, lineItem);
			}
		},
		{
			key: "render",
			value: function render() {
				var _this$props6 = this.props, hide = _this$props6.hide, points = _this$props6.points, line = _this$props6.line, className = _this$props6.className, xAxis = _this$props6.xAxis, yAxis = _this$props6.yAxis, left = _this$props6.left, top = _this$props6.top, width = _this$props6.width, height = _this$props6.height, id = _this$props6.id, isAnimationActive = _this$props6.isAnimationActive;
				if (hide || !points || !points.length) return null;
				var isAnimationFinished = this.state.isAnimationFinished;
				var layerClass = clsx("recharts-scatter", className);
				var needClipX = xAxis && xAxis.allowDataOverflow;
				var needClipY = yAxis && yAxis.allowDataOverflow;
				var needClip = needClipX || needClipY;
				var clipPathId = (0, import_isNil.default)(id) ? this.id : id;
				return /*#__PURE__*/ import_react.createElement(Layer, {
					className: layerClass,
					clipPath: needClip ? "url(#clipPath-".concat(clipPathId, ")") : null
				}, needClipX || needClipY ? /*#__PURE__*/ import_react.createElement("defs", null, /*#__PURE__*/ import_react.createElement("clipPath", { id: "clipPath-".concat(clipPathId) }, /*#__PURE__*/ import_react.createElement("rect", {
					x: needClipX ? left : left - width / 2,
					y: needClipY ? top : top - height / 2,
					width: needClipX ? width : width * 2,
					height: needClipY ? height : height * 2
				}))) : null, line && this.renderLine(), this.renderErrorBar(), /*#__PURE__*/ import_react.createElement(Layer, { key: "recharts-scatter-symbols" }, this.renderSymbols()), (!isAnimationActive || isAnimationFinished) && LabelList.renderCallByParent(this.props, points));
			}
		}
	], [{
		key: "getDerivedStateFromProps",
		value: function getDerivedStateFromProps(nextProps, prevState) {
			if (nextProps.animationId !== prevState.prevAnimationId) return {
				prevAnimationId: nextProps.animationId,
				curPoints: nextProps.points,
				prevPoints: prevState.curPoints
			};
			if (nextProps.points !== prevState.curPoints) return { curPoints: nextProps.points };
			return null;
		}
	}]);
}(import_react.PureComponent);
_defineProperty$9(Scatter, "displayName", "Scatter");
_defineProperty$9(Scatter, "defaultProps", {
	xAxisId: 0,
	yAxisId: 0,
	zAxisId: 0,
	legendType: "circle",
	lineType: "joint",
	lineJointType: "linear",
	data: [],
	shape: "circle",
	hide: false,
	isAnimationActive: !Global.isSsr,
	animationBegin: 0,
	animationDuration: 400,
	animationEasing: "linear"
});
/**
* Compose the data of each group
* @param  {Object} xAxis   The configuration of x-axis
* @param  {Object} yAxis   The configuration of y-axis
* @param  {String} dataKey The unique key of a group
* @return {Array}  Composed data
*/
_defineProperty$9(Scatter, "getComposedData", function(_ref2) {
	var xAxis = _ref2.xAxis, yAxis = _ref2.yAxis, zAxis = _ref2.zAxis, item = _ref2.item, displayedData = _ref2.displayedData, xAxisTicks = _ref2.xAxisTicks, yAxisTicks = _ref2.yAxisTicks, offset = _ref2.offset;
	var tooltipType = item.props.tooltipType;
	var cells = findAllByType(item.props.children, Cell);
	var xAxisDataKey = (0, import_isNil.default)(xAxis.dataKey) ? item.props.dataKey : xAxis.dataKey;
	var yAxisDataKey = (0, import_isNil.default)(yAxis.dataKey) ? item.props.dataKey : yAxis.dataKey;
	var zAxisDataKey = zAxis && zAxis.dataKey;
	var defaultRangeZ = zAxis ? zAxis.range : ZAxis.defaultProps.range;
	var defaultZ = defaultRangeZ && defaultRangeZ[0];
	var xBandSize = xAxis.scale.bandwidth ? xAxis.scale.bandwidth() : 0;
	var yBandSize = yAxis.scale.bandwidth ? yAxis.scale.bandwidth() : 0;
	return _objectSpread$6({ points: displayedData.map(function(entry, index) {
		var x = getValueByDataKey(entry, xAxisDataKey);
		var y = getValueByDataKey(entry, yAxisDataKey);
		var z = !(0, import_isNil.default)(zAxisDataKey) && getValueByDataKey(entry, zAxisDataKey) || "-";
		var tooltipPayload = [{
			name: (0, import_isNil.default)(xAxis.dataKey) ? item.props.name : xAxis.name || xAxis.dataKey,
			unit: xAxis.unit || "",
			value: x,
			payload: entry,
			dataKey: xAxisDataKey,
			type: tooltipType
		}, {
			name: (0, import_isNil.default)(yAxis.dataKey) ? item.props.name : yAxis.name || yAxis.dataKey,
			unit: yAxis.unit || "",
			value: y,
			payload: entry,
			dataKey: yAxisDataKey,
			type: tooltipType
		}];
		if (z !== "-") tooltipPayload.push({
			name: zAxis.name || zAxis.dataKey,
			unit: zAxis.unit || "",
			value: z,
			payload: entry,
			dataKey: zAxisDataKey,
			type: tooltipType
		});
		var cx = getCateCoordinateOfLine({
			axis: xAxis,
			ticks: xAxisTicks,
			bandSize: xBandSize,
			entry,
			index,
			dataKey: xAxisDataKey
		});
		var cy = getCateCoordinateOfLine({
			axis: yAxis,
			ticks: yAxisTicks,
			bandSize: yBandSize,
			entry,
			index,
			dataKey: yAxisDataKey
		});
		var size = z !== "-" ? zAxis.scale(z) : defaultZ;
		var radius = Math.sqrt(Math.max(size, 0) / Math.PI);
		return _objectSpread$6(_objectSpread$6({}, entry), {}, {
			cx,
			cy,
			x: cx - radius,
			y: cy - radius,
			xAxis,
			yAxis,
			zAxis,
			width: 2 * radius,
			height: 2 * radius,
			size,
			node: {
				x,
				y,
				z
			},
			tooltipPayload,
			tooltipPosition: {
				x: cx,
				y: cy
			},
			payload: entry
		}, cells && cells[index] && cells[index].props);
	}) }, offset);
});
//#endregion
//#region node_modules/recharts/es6/cartesian/XAxis.js
/**
* @fileOverview X Axis
*/
function _typeof$8(o) {
	"@babel/helpers - typeof";
	return _typeof$8 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$8(o);
}
function _classCallCheck$6(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$6(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$8(descriptor.key), descriptor);
	}
}
function _createClass$6(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$6(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$6(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$5(t, o, e) {
	return o = _getPrototypeOf$5(o), _possibleConstructorReturn$5(t, _isNativeReflectConstruct$5() ? Reflect.construct(o, e || [], _getPrototypeOf$5(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$5(self, call) {
	if (call && (_typeof$8(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$5(self);
}
function _assertThisInitialized$5(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$5() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$5 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$5(o) {
	_getPrototypeOf$5 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$5(o);
}
function _inherits$5(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$5(subClass, superClass);
}
function _setPrototypeOf$5(o, p) {
	_setPrototypeOf$5 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$5(o, p);
}
function _defineProperty$8(obj, key, value) {
	key = _toPropertyKey$8(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$8(t) {
	var i = _toPrimitive$8(t, "string");
	return "symbol" == _typeof$8(i) ? i : i + "";
}
function _toPrimitive$8(t, r) {
	if ("object" != _typeof$8(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$8(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _extends$7() {
	_extends$7 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$7.apply(this, arguments);
}
/** Define of XAxis props */
function XAxisImpl(_ref) {
	var xAxisId = _ref.xAxisId;
	var width = useChartWidth();
	var height = useChartHeight();
	var axisOptions = useXAxisOrThrow(xAxisId);
	if (axisOptions == null) return null;
	return /*#__PURE__*/ import_react.createElement(CartesianAxis, _extends$7({}, axisOptions, {
		className: clsx("recharts-".concat(axisOptions.axisType, " ").concat(axisOptions.axisType), axisOptions.className),
		viewBox: {
			x: 0,
			y: 0,
			width,
			height
		},
		ticksGenerator: function ticksGenerator(axis) {
			return getTicksOfAxis(axis, true);
		}
	}));
}
var XAxis = /*#__PURE__*/ function(_React$Component) {
	function XAxis() {
		_classCallCheck$6(this, XAxis);
		return _callSuper$5(this, XAxis, arguments);
	}
	_inherits$5(XAxis, _React$Component);
	return _createClass$6(XAxis, [{
		key: "render",
		value: function render() {
			return /*#__PURE__*/ import_react.createElement(XAxisImpl, this.props);
		}
	}]);
}(import_react.Component);
_defineProperty$8(XAxis, "displayName", "XAxis");
_defineProperty$8(XAxis, "defaultProps", {
	allowDecimals: true,
	hide: false,
	orientation: "bottom",
	width: 0,
	height: 30,
	mirror: false,
	xAxisId: 0,
	tickCount: 5,
	type: "category",
	padding: {
		left: 0,
		right: 0
	},
	allowDataOverflow: false,
	scale: "auto",
	reversed: false,
	allowDuplicatedCategory: true
});
//#endregion
//#region node_modules/recharts/es6/cartesian/YAxis.js
/**
* @fileOverview Y Axis
*/
function _typeof$7(o) {
	"@babel/helpers - typeof";
	return _typeof$7 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$7(o);
}
function _classCallCheck$5(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$5(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$7(descriptor.key), descriptor);
	}
}
function _createClass$5(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$5(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$5(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$4(t, o, e) {
	return o = _getPrototypeOf$4(o), _possibleConstructorReturn$4(t, _isNativeReflectConstruct$4() ? Reflect.construct(o, e || [], _getPrototypeOf$4(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$4(self, call) {
	if (call && (_typeof$7(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$4(self);
}
function _assertThisInitialized$4(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$4() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$4 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$4(o) {
	_getPrototypeOf$4 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$4(o);
}
function _inherits$4(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$4(subClass, superClass);
}
function _setPrototypeOf$4(o, p) {
	_setPrototypeOf$4 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$4(o, p);
}
function _defineProperty$7(obj, key, value) {
	key = _toPropertyKey$7(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$7(t) {
	var i = _toPrimitive$7(t, "string");
	return "symbol" == _typeof$7(i) ? i : i + "";
}
function _toPrimitive$7(t, r) {
	if ("object" != _typeof$7(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$7(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _extends$6() {
	_extends$6 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$6.apply(this, arguments);
}
var YAxisImpl = function YAxisImpl(_ref) {
	var yAxisId = _ref.yAxisId;
	var width = useChartWidth();
	var height = useChartHeight();
	var axisOptions = useYAxisOrThrow(yAxisId);
	if (axisOptions == null) return null;
	return /*#__PURE__*/ import_react.createElement(CartesianAxis, _extends$6({}, axisOptions, {
		className: clsx("recharts-".concat(axisOptions.axisType, " ").concat(axisOptions.axisType), axisOptions.className),
		viewBox: {
			x: 0,
			y: 0,
			width,
			height
		},
		ticksGenerator: function ticksGenerator(axis) {
			return getTicksOfAxis(axis, true);
		}
	}));
};
var YAxis = /*#__PURE__*/ function(_React$Component) {
	function YAxis() {
		_classCallCheck$5(this, YAxis);
		return _callSuper$4(this, YAxis, arguments);
	}
	_inherits$4(YAxis, _React$Component);
	return _createClass$5(YAxis, [{
		key: "render",
		value: function render() {
			return /*#__PURE__*/ import_react.createElement(YAxisImpl, this.props);
		}
	}]);
}(import_react.Component);
_defineProperty$7(YAxis, "displayName", "YAxis");
_defineProperty$7(YAxis, "defaultProps", {
	allowDuplicatedCategory: true,
	allowDecimals: true,
	hide: false,
	orientation: "left",
	width: 60,
	height: 0,
	mirror: false,
	yAxisId: 0,
	tickCount: 5,
	type: "number",
	padding: {
		top: 0,
		bottom: 0
	},
	allowDataOverflow: false,
	scale: "auto",
	reversed: false
});
//#endregion
//#region node_modules/recharts/es6/util/DetectReferenceElementsDomain.js
function _toConsumableArray$2(arr) {
	return _arrayWithoutHoles$2(arr) || _iterableToArray$2(arr) || _unsupportedIterableToArray$3(arr) || _nonIterableSpread$2();
}
function _nonIterableSpread$2() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$3(o, minLen) {
	if (!o) return;
	if (typeof o === "string") return _arrayLikeToArray$3(o, minLen);
	var n = Object.prototype.toString.call(o).slice(8, -1);
	if (n === "Object" && o.constructor) n = o.constructor.name;
	if (n === "Map" || n === "Set") return Array.from(o);
	if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$3(o, minLen);
}
function _iterableToArray$2(iter) {
	if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _arrayWithoutHoles$2(arr) {
	if (Array.isArray(arr)) return _arrayLikeToArray$3(arr);
}
function _arrayLikeToArray$3(arr, len) {
	if (len == null || len > arr.length) len = arr.length;
	for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
	return arr2;
}
var detectReferenceElementsDomain = function detectReferenceElementsDomain(children, domain, axisId, axisType, specifiedTicks) {
	var lines = findAllByType(children, ReferenceLine);
	var dots = findAllByType(children, ReferenceDot);
	var elements = [].concat(_toConsumableArray$2(lines), _toConsumableArray$2(dots));
	var areas = findAllByType(children, ReferenceArea);
	var idKey = "".concat(axisType, "Id");
	var valueKey = axisType[0];
	var finalDomain = domain;
	if (elements.length) finalDomain = elements.reduce(function(result, el) {
		if (el.props[idKey] === axisId && ifOverflowMatches(el.props, "extendDomain") && isNumber$1(el.props[valueKey])) {
			var value = el.props[valueKey];
			return [Math.min(result[0], value), Math.max(result[1], value)];
		}
		return result;
	}, finalDomain);
	if (areas.length) {
		var key1 = "".concat(valueKey, "1");
		var key2 = "".concat(valueKey, "2");
		finalDomain = areas.reduce(function(result, el) {
			if (el.props[idKey] === axisId && ifOverflowMatches(el.props, "extendDomain") && isNumber$1(el.props[key1]) && isNumber$1(el.props[key2])) {
				var value1 = el.props[key1];
				var value2 = el.props[key2];
				return [Math.min(result[0], value1, value2), Math.max(result[1], value1, value2)];
			}
			return result;
		}, finalDomain);
	}
	if (specifiedTicks && specifiedTicks.length) finalDomain = specifiedTicks.reduce(function(result, tick) {
		if (isNumber$1(tick)) return [Math.min(result[0], tick), Math.max(result[1], tick)];
		return result;
	}, finalDomain);
	return finalDomain;
};
var eventCenter = new (/* @__PURE__ */ __toESM(require_eventemitter3())).default();
var SYNC_EVENT = "recharts.syncMouseEvents";
//#endregion
//#region node_modules/recharts/es6/chart/AccessibilityManager.js
function _typeof$6(o) {
	"@babel/helpers - typeof";
	return _typeof$6 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$6(o);
}
function _classCallCheck$4(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$4(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$6(descriptor.key), descriptor);
	}
}
function _createClass$4(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$4(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$4(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _defineProperty$6(obj, key, value) {
	key = _toPropertyKey$6(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$6(t) {
	var i = _toPrimitive$6(t, "string");
	return "symbol" == _typeof$6(i) ? i : i + "";
}
function _toPrimitive$6(t, r) {
	if ("object" != _typeof$6(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$6(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var AccessibilityManager = /*#__PURE__*/ function() {
	function AccessibilityManager() {
		_classCallCheck$4(this, AccessibilityManager);
		_defineProperty$6(this, "activeIndex", 0);
		_defineProperty$6(this, "coordinateList", []);
		_defineProperty$6(this, "layout", "horizontal");
	}
	return _createClass$4(AccessibilityManager, [
		{
			key: "setDetails",
			value: function setDetails(_ref) {
				var _ref2;
				var _ref$coordinateList = _ref.coordinateList, coordinateList = _ref$coordinateList === void 0 ? null : _ref$coordinateList, _ref$container = _ref.container, container = _ref$container === void 0 ? null : _ref$container, _ref$layout = _ref.layout, layout = _ref$layout === void 0 ? null : _ref$layout, _ref$offset = _ref.offset, offset = _ref$offset === void 0 ? null : _ref$offset, _ref$mouseHandlerCall = _ref.mouseHandlerCallback, mouseHandlerCallback = _ref$mouseHandlerCall === void 0 ? null : _ref$mouseHandlerCall;
				this.coordinateList = (_ref2 = coordinateList !== null && coordinateList !== void 0 ? coordinateList : this.coordinateList) !== null && _ref2 !== void 0 ? _ref2 : [];
				this.container = container !== null && container !== void 0 ? container : this.container;
				this.layout = layout !== null && layout !== void 0 ? layout : this.layout;
				this.offset = offset !== null && offset !== void 0 ? offset : this.offset;
				this.mouseHandlerCallback = mouseHandlerCallback !== null && mouseHandlerCallback !== void 0 ? mouseHandlerCallback : this.mouseHandlerCallback;
				this.activeIndex = Math.min(Math.max(this.activeIndex, 0), this.coordinateList.length - 1);
			}
		},
		{
			key: "focus",
			value: function focus() {
				this.spoofMouse();
			}
		},
		{
			key: "keyboardEvent",
			value: function keyboardEvent(e) {
				if (this.coordinateList.length === 0) return;
				switch (e.key) {
					case "ArrowRight":
						if (this.layout !== "horizontal") return;
						this.activeIndex = Math.min(this.activeIndex + 1, this.coordinateList.length - 1);
						this.spoofMouse();
						break;
					case "ArrowLeft":
						if (this.layout !== "horizontal") return;
						this.activeIndex = Math.max(this.activeIndex - 1, 0);
						this.spoofMouse();
				}
			}
		},
		{
			key: "setIndex",
			value: function setIndex(newIndex) {
				this.activeIndex = newIndex;
			}
		},
		{
			key: "spoofMouse",
			value: function spoofMouse() {
				var _window, _window2;
				if (this.layout !== "horizontal") return;
				if (this.coordinateList.length === 0) return;
				var _this$container$getBo = this.container.getBoundingClientRect(), x = _this$container$getBo.x, y = _this$container$getBo.y, height = _this$container$getBo.height;
				var coordinate = this.coordinateList[this.activeIndex].coordinate;
				var scrollOffsetX = ((_window = window) === null || _window === void 0 ? void 0 : _window.scrollX) || 0;
				var scrollOffsetY = ((_window2 = window) === null || _window2 === void 0 ? void 0 : _window2.scrollY) || 0;
				var pageX = x + coordinate + scrollOffsetX;
				var pageY = y + this.offset.top + height / 2 + scrollOffsetY;
				this.mouseHandlerCallback({
					pageX,
					pageY
				});
			}
		}
	]);
}();
//#endregion
//#region node_modules/recharts/es6/util/isDomainSpecifiedByUser.js
/**
* Takes a domain and user props to determine whether he provided the domain via props or if we need to calculate it.
* @param   {AxisDomain}  domain              The potential domain from props
* @param   {Boolean}     allowDataOverflow   from props
* @param   {String}      axisType            from props
* @returns {Boolean}                         `true` if domain is specified by user
*/
function isDomainSpecifiedByUser(domain, allowDataOverflow, axisType) {
	if (axisType === "number" && allowDataOverflow === true && Array.isArray(domain)) {
		var domainStart = domain === null || domain === void 0 ? void 0 : domain[0];
		var domainEnd = domain === null || domain === void 0 ? void 0 : domain[1];
		if (!!domainStart && !!domainEnd && isNumber$1(domainStart) && isNumber$1(domainEnd)) return true;
	}
	return false;
}
//#endregion
//#region node_modules/recharts/es6/util/cursor/getCursorRectangle.js
function getCursorRectangle(layout, activeCoordinate, offset, tooltipAxisBandSize) {
	var halfSize = tooltipAxisBandSize / 2;
	return {
		stroke: "none",
		fill: "#ccc",
		x: layout === "horizontal" ? activeCoordinate.x - halfSize : offset.left + .5,
		y: layout === "horizontal" ? offset.top + .5 : activeCoordinate.y - halfSize,
		width: layout === "horizontal" ? tooltipAxisBandSize : offset.width - 1,
		height: layout === "horizontal" ? offset.height - 1 : tooltipAxisBandSize
	};
}
//#endregion
//#region node_modules/recharts/es6/util/cursor/getRadialCursorPoints.js
/**
* Only applicable for radial layouts
* @param {Object} activeCoordinate ChartCoordinate
* @returns {Object} RadialCursorPoints
*/
function getRadialCursorPoints(activeCoordinate) {
	var cx = activeCoordinate.cx, cy = activeCoordinate.cy, radius = activeCoordinate.radius, startAngle = activeCoordinate.startAngle, endAngle = activeCoordinate.endAngle;
	return {
		points: [polarToCartesian(cx, cy, radius, startAngle), polarToCartesian(cx, cy, radius, endAngle)],
		cx,
		cy,
		radius,
		startAngle,
		endAngle
	};
}
//#endregion
//#region node_modules/recharts/es6/util/cursor/getCursorPoints.js
function getCursorPoints(layout, activeCoordinate, offset) {
	var x1, y1, x2, y2;
	if (layout === "horizontal") {
		x1 = activeCoordinate.x;
		x2 = x1;
		y1 = offset.top;
		y2 = offset.top + offset.height;
	} else if (layout === "vertical") {
		y1 = activeCoordinate.y;
		y2 = y1;
		x1 = offset.left;
		x2 = offset.left + offset.width;
	} else if (activeCoordinate.cx != null && activeCoordinate.cy != null) {
		if (layout === "centric") {
			var cx = activeCoordinate.cx, cy = activeCoordinate.cy, innerRadius = activeCoordinate.innerRadius, outerRadius = activeCoordinate.outerRadius, angle = activeCoordinate.angle;
			var innerPoint = polarToCartesian(cx, cy, innerRadius, angle);
			var outerPoint = polarToCartesian(cx, cy, outerRadius, angle);
			x1 = innerPoint.x;
			y1 = innerPoint.y;
			x2 = outerPoint.x;
			y2 = outerPoint.y;
		} else return getRadialCursorPoints(activeCoordinate);
	}
	return [{
		x: x1,
		y: y1
	}, {
		x: x2,
		y: y2
	}];
}
//#endregion
//#region node_modules/recharts/es6/component/Cursor.js
function _typeof$5(o) {
	"@babel/helpers - typeof";
	return _typeof$5 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$5(o);
}
function ownKeys$5(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$5(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$5(Object(t), !0).forEach(function(r) {
			_defineProperty$5(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$5(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$5(obj, key, value) {
	key = _toPropertyKey$5(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$5(t) {
	var i = _toPrimitive$5(t, "string");
	return "symbol" == _typeof$5(i) ? i : i + "";
}
function _toPrimitive$5(t, r) {
	if ("object" != _typeof$5(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$5(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function Cursor(props) {
	var _element$props$cursor, _defaultProps;
	var element = props.element, tooltipEventType = props.tooltipEventType, isActive = props.isActive, activeCoordinate = props.activeCoordinate, activePayload = props.activePayload, offset = props.offset, activeTooltipIndex = props.activeTooltipIndex, tooltipAxisBandSize = props.tooltipAxisBandSize, layout = props.layout, chartName = props.chartName;
	var elementPropsCursor = (_element$props$cursor = element.props.cursor) !== null && _element$props$cursor !== void 0 ? _element$props$cursor : (_defaultProps = element.type.defaultProps) === null || _defaultProps === void 0 ? void 0 : _defaultProps.cursor;
	if (!element || !elementPropsCursor || !isActive || !activeCoordinate || chartName !== "ScatterChart" && tooltipEventType !== "axis") return null;
	var restProps;
	var cursorComp = Curve;
	if (chartName === "ScatterChart") {
		restProps = activeCoordinate;
		cursorComp = Cross;
	} else if (chartName === "BarChart") {
		restProps = getCursorRectangle(layout, activeCoordinate, offset, tooltipAxisBandSize);
		cursorComp = Rectangle;
	} else if (layout === "radial") {
		var _getRadialCursorPoint = getRadialCursorPoints(activeCoordinate), cx = _getRadialCursorPoint.cx, cy = _getRadialCursorPoint.cy, radius = _getRadialCursorPoint.radius;
		restProps = {
			cx,
			cy,
			startAngle: _getRadialCursorPoint.startAngle,
			endAngle: _getRadialCursorPoint.endAngle,
			innerRadius: radius,
			outerRadius: radius
		};
		cursorComp = Sector;
	} else {
		restProps = { points: getCursorPoints(layout, activeCoordinate, offset) };
		cursorComp = Curve;
	}
	var cursorProps = _objectSpread$5(_objectSpread$5(_objectSpread$5(_objectSpread$5({
		stroke: "#ccc",
		pointerEvents: "none"
	}, offset), restProps), filterProps(elementPropsCursor, false)), {}, {
		payload: activePayload,
		payloadIndex: activeTooltipIndex,
		className: clsx("recharts-tooltip-cursor", elementPropsCursor.className)
	});
	return /*#__PURE__*/ (0, import_react.isValidElement)(elementPropsCursor) ? /*#__PURE__*/ (0, import_react.cloneElement)(elementPropsCursor, cursorProps) : /*#__PURE__*/ (0, import_react.createElement)(cursorComp, cursorProps);
}
//#endregion
//#region node_modules/recharts/es6/chart/generateCategoricalChart.js
var _excluded$2 = ["item"];
var _excluded2$1 = [
	"children",
	"className",
	"width",
	"height",
	"style",
	"compact",
	"title",
	"desc"
];
function _typeof$4(o) {
	"@babel/helpers - typeof";
	return _typeof$4 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$4(o);
}
function _extends$5() {
	_extends$5 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$5.apply(this, arguments);
}
function _slicedToArray$2(arr, i) {
	return _arrayWithHoles$2(arr) || _iterableToArrayLimit$2(arr, i) || _unsupportedIterableToArray$2(arr, i) || _nonIterableRest$2();
}
function _nonIterableRest$2() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _iterableToArrayLimit$2(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = !0, o = !1;
		try {
			if (i = (t = t.call(r)).next, 0 === l) {
				if (Object(t) !== t) return;
				f = !1;
			} else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = !0, n = r;
		} finally {
			try {
				if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
function _arrayWithHoles$2(arr) {
	if (Array.isArray(arr)) return arr;
}
function _objectWithoutProperties$2(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$2(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$2(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
function _classCallCheck$3(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$3(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$4(descriptor.key), descriptor);
	}
}
function _createClass$3(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$3(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$3(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$3(t, o, e) {
	return o = _getPrototypeOf$3(o), _possibleConstructorReturn$3(t, _isNativeReflectConstruct$3() ? Reflect.construct(o, e || [], _getPrototypeOf$3(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$3(self, call) {
	if (call && (_typeof$4(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$3(self);
}
function _assertThisInitialized$3(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$3() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$3 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$3(o) {
	_getPrototypeOf$3 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$3(o);
}
function _inherits$3(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$3(subClass, superClass);
}
function _setPrototypeOf$3(o, p) {
	_setPrototypeOf$3 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$3(o, p);
}
function _toConsumableArray$1(arr) {
	return _arrayWithoutHoles$1(arr) || _iterableToArray$1(arr) || _unsupportedIterableToArray$2(arr) || _nonIterableSpread$1();
}
function _nonIterableSpread$1() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$2(o, minLen) {
	if (!o) return;
	if (typeof o === "string") return _arrayLikeToArray$2(o, minLen);
	var n = Object.prototype.toString.call(o).slice(8, -1);
	if (n === "Object" && o.constructor) n = o.constructor.name;
	if (n === "Map" || n === "Set") return Array.from(o);
	if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$2(o, minLen);
}
function _iterableToArray$1(iter) {
	if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _arrayWithoutHoles$1(arr) {
	if (Array.isArray(arr)) return _arrayLikeToArray$2(arr);
}
function _arrayLikeToArray$2(arr, len) {
	if (len == null || len > arr.length) len = arr.length;
	for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
	return arr2;
}
function ownKeys$4(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$4(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$4(Object(t), !0).forEach(function(r) {
			_defineProperty$4(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$4(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$4(obj, key, value) {
	key = _toPropertyKey$4(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$4(t) {
	var i = _toPrimitive$4(t, "string");
	return "symbol" == _typeof$4(i) ? i : i + "";
}
function _toPrimitive$4(t, r) {
	if ("object" != _typeof$4(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$4(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var ORIENT_MAP = {
	xAxis: ["bottom", "top"],
	yAxis: ["left", "right"]
};
var FULL_WIDTH_AND_HEIGHT = {
	width: "100%",
	height: "100%"
};
var originCoordinate = {
	x: 0,
	y: 0
};
/**
* This function exists as a temporary workaround.
*
* Why? generateCategoricalChart does not render `{children}` directly;
* instead it passes them through `renderByOrder` function which reads their handlers.
*
* So, this is a handler that does nothing.
* Once we get rid of `renderByOrder` and switch to JSX only, we can get rid of this handler too.
*
* @param {JSX} element as is in JSX
* @returns {JSX} the same element
*/
function renderAsIs(element) {
	return element;
}
var calculateTooltipPos = function calculateTooltipPos(rangeObj, layout) {
	if (layout === "horizontal") return rangeObj.x;
	if (layout === "vertical") return rangeObj.y;
	if (layout === "centric") return rangeObj.angle;
	return rangeObj.radius;
};
var getActiveCoordinate = function getActiveCoordinate(layout, tooltipTicks, activeIndex, rangeObj) {
	var entry = tooltipTicks.find(function(tick) {
		return tick && tick.index === activeIndex;
	});
	if (entry) {
		if (layout === "horizontal") return {
			x: entry.coordinate,
			y: rangeObj.y
		};
		if (layout === "vertical") return {
			x: rangeObj.x,
			y: entry.coordinate
		};
		if (layout === "centric") {
			var _angle = entry.coordinate;
			var _radius = rangeObj.radius;
			return _objectSpread$4(_objectSpread$4(_objectSpread$4({}, rangeObj), polarToCartesian(rangeObj.cx, rangeObj.cy, _radius, _angle)), {}, {
				angle: _angle,
				radius: _radius
			});
		}
		var radius = entry.coordinate;
		var angle = rangeObj.angle;
		return _objectSpread$4(_objectSpread$4(_objectSpread$4({}, rangeObj), polarToCartesian(rangeObj.cx, rangeObj.cy, radius, angle)), {}, {
			angle,
			radius
		});
	}
	return originCoordinate;
};
var getDisplayedData = function getDisplayedData(data, _ref) {
	var graphicalItems = _ref.graphicalItems, dataStartIndex = _ref.dataStartIndex, dataEndIndex = _ref.dataEndIndex;
	var itemsData = (graphicalItems !== null && graphicalItems !== void 0 ? graphicalItems : []).reduce(function(result, child) {
		var itemData = child.props.data;
		if (itemData && itemData.length) return [].concat(_toConsumableArray$1(result), _toConsumableArray$1(itemData));
		return result;
	}, []);
	if (itemsData.length > 0) return itemsData;
	if (data && data.length && isNumber$1(dataStartIndex) && isNumber$1(dataEndIndex)) return data.slice(dataStartIndex, dataEndIndex + 1);
	return [];
};
function getDefaultDomainByAxisType(axisType) {
	return axisType === "number" ? [0, "auto"] : void 0;
}
/**
* Get the content to be displayed in the tooltip
* @param  {Object} state          Current state
* @param  {Array}  chartData      The data defined in chart
* @param  {Number} activeIndex    Active index of data
* @param  {String} activeLabel    Active label of data
* @return {Array}                 The content of tooltip
*/
var getTooltipContent = function getTooltipContent(state, chartData, activeIndex, activeLabel) {
	var graphicalItems = state.graphicalItems, tooltipAxis = state.tooltipAxis;
	var displayedData = getDisplayedData(chartData, state);
	if (activeIndex < 0 || !graphicalItems || !graphicalItems.length || activeIndex >= displayedData.length) return null;
	return graphicalItems.reduce(function(result, child) {
		var _child$props$data;
		/**
		* Fixes: https://github.com/recharts/recharts/issues/3669
		* Defaulting to chartData below to fix an edge case where the tooltip does not include data from all charts
		* when a separate dataset is passed to chart prop data and specified on Line/Area/etc prop data
		*/
		var data = (_child$props$data = child.props.data) !== null && _child$props$data !== void 0 ? _child$props$data : chartData;
		if (data && state.dataStartIndex + state.dataEndIndex !== 0 && state.dataEndIndex - state.dataStartIndex >= activeIndex) data = data.slice(state.dataStartIndex, state.dataEndIndex + 1);
		var payload;
		if (tooltipAxis.dataKey && !tooltipAxis.allowDuplicatedCategory) payload = findEntryInArray(data === void 0 ? displayedData : data, tooltipAxis.dataKey, activeLabel);
		else payload = data && data[activeIndex] || displayedData[activeIndex];
		if (!payload) return result;
		return [].concat(_toConsumableArray$1(result), [getTooltipItem(child, payload)]);
	}, []);
};
/**
* Returns tooltip data based on a mouse position (as a parameter or in state)
* @param  {Object} state     current state
* @param  {Array}  chartData the data defined in chart
* @param  {String} layout     The layout type of chart
* @param  {Object} rangeObj  { x, y } coordinates
* @return {Object}           Tooltip data data
*/
var getTooltipData = function getTooltipData(state, chartData, layout, rangeObj) {
	var rangeData = rangeObj || {
		x: state.chartX,
		y: state.chartY
	};
	var pos = calculateTooltipPos(rangeData, layout);
	var ticks = state.orderedTooltipTicks, axis = state.tooltipAxis, tooltipTicks = state.tooltipTicks;
	var activeIndex = calculateActiveTickIndex(pos, ticks, tooltipTicks, axis);
	if (activeIndex >= 0 && tooltipTicks) {
		var activeLabel = tooltipTicks[activeIndex] && tooltipTicks[activeIndex].value;
		return {
			activeTooltipIndex: activeIndex,
			activeLabel,
			activePayload: getTooltipContent(state, chartData, activeIndex, activeLabel),
			activeCoordinate: getActiveCoordinate(layout, ticks, activeIndex, rangeData)
		};
	}
	return null;
};
/**
* Get the configuration of axis by the options of axis instance
* @param  {Object} props         Latest props
* @param {Array}  axes           The instance of axes
* @param  {Array} graphicalItems The instances of item
* @param  {String} axisType      The type of axis, xAxis - x-axis, yAxis - y-axis
* @param  {String} axisIdKey     The unique id of an axis
* @param  {Object} stackGroups   The items grouped by axisId and stackId
* @param {Number} dataStartIndex The start index of the data series when a brush is applied
* @param {Number} dataEndIndex   The end index of the data series when a brush is applied
* @return {Object}      Configuration
*/
var getAxisMapByAxes = function getAxisMapByAxes(props, _ref2) {
	var axes = _ref2.axes, graphicalItems = _ref2.graphicalItems, axisType = _ref2.axisType, axisIdKey = _ref2.axisIdKey, stackGroups = _ref2.stackGroups, dataStartIndex = _ref2.dataStartIndex, dataEndIndex = _ref2.dataEndIndex;
	var layout = props.layout, children = props.children, stackOffset = props.stackOffset;
	var isCategorical = isCategoricalAxis(layout, axisType);
	return axes.reduce(function(result, child) {
		var _childProps$domain2;
		var childProps = child.type.defaultProps !== void 0 ? _objectSpread$4(_objectSpread$4({}, child.type.defaultProps), child.props) : child.props;
		var type = childProps.type, dataKey = childProps.dataKey, allowDataOverflow = childProps.allowDataOverflow, allowDuplicatedCategory = childProps.allowDuplicatedCategory, scale = childProps.scale, ticks = childProps.ticks, includeHidden = childProps.includeHidden;
		var axisId = childProps[axisIdKey];
		if (result[axisId]) return result;
		var displayedData = getDisplayedData(props.data, {
			graphicalItems: graphicalItems.filter(function(item) {
				var _defaultProps;
				return (axisIdKey in item.props ? item.props[axisIdKey] : (_defaultProps = item.type.defaultProps) === null || _defaultProps === void 0 ? void 0 : _defaultProps[axisIdKey]) === axisId;
			}),
			dataStartIndex,
			dataEndIndex
		});
		var len = displayedData.length;
		var domain, duplicateDomain, categoricalDomain;
		if (isDomainSpecifiedByUser(childProps.domain, allowDataOverflow, type)) {
			domain = parseSpecifiedDomain(childProps.domain, null, allowDataOverflow);
			if (isCategorical && (type === "number" || scale !== "auto")) categoricalDomain = getDomainOfDataByKey(displayedData, dataKey, "category");
		}
		var defaultDomain = getDefaultDomainByAxisType(type);
		if (!domain || domain.length === 0) {
			var _childProps$domain;
			var childDomain = (_childProps$domain = childProps.domain) !== null && _childProps$domain !== void 0 ? _childProps$domain : defaultDomain;
			if (dataKey) {
				domain = getDomainOfDataByKey(displayedData, dataKey, type);
				if (type === "category" && isCategorical) {
					var duplicate = hasDuplicate(domain);
					if (allowDuplicatedCategory && duplicate) {
						duplicateDomain = domain;
						domain = (0, import_range.default)(0, len);
					} else if (!allowDuplicatedCategory) domain = parseDomainOfCategoryAxis(childDomain, domain, child).reduce(function(finalDomain, entry) {
						return finalDomain.indexOf(entry) >= 0 ? finalDomain : [].concat(_toConsumableArray$1(finalDomain), [entry]);
					}, []);
				} else if (type === "category") {
					if (!allowDuplicatedCategory) domain = parseDomainOfCategoryAxis(childDomain, domain, child).reduce(function(finalDomain, entry) {
						return finalDomain.indexOf(entry) >= 0 || entry === "" || (0, import_isNil.default)(entry) ? finalDomain : [].concat(_toConsumableArray$1(finalDomain), [entry]);
					}, []);
					else domain = domain.filter(function(entry) {
						return entry !== "" && !(0, import_isNil.default)(entry);
					});
				} else if (type === "number") {
					var errorBarsDomain = parseErrorBarsOfAxis(displayedData, graphicalItems.filter(function(item) {
						var _defaultProps2, _defaultProps3;
						var itemAxisId = axisIdKey in item.props ? item.props[axisIdKey] : (_defaultProps2 = item.type.defaultProps) === null || _defaultProps2 === void 0 ? void 0 : _defaultProps2[axisIdKey];
						var itemHide = "hide" in item.props ? item.props.hide : (_defaultProps3 = item.type.defaultProps) === null || _defaultProps3 === void 0 ? void 0 : _defaultProps3.hide;
						return itemAxisId === axisId && (includeHidden || !itemHide);
					}), dataKey, axisType, layout);
					if (errorBarsDomain) domain = errorBarsDomain;
				}
				if (isCategorical && (type === "number" || scale !== "auto")) categoricalDomain = getDomainOfDataByKey(displayedData, dataKey, "category");
			} else if (isCategorical) domain = (0, import_range.default)(0, len);
			else if (stackGroups && stackGroups[axisId] && stackGroups[axisId].hasStack && type === "number") domain = stackOffset === "expand" ? [0, 1] : getDomainOfStackGroups(stackGroups[axisId].stackGroups, dataStartIndex, dataEndIndex);
			else domain = getDomainOfItemsWithSameAxis(displayedData, graphicalItems.filter(function(item) {
				var itemAxisId = axisIdKey in item.props ? item.props[axisIdKey] : item.type.defaultProps[axisIdKey];
				var itemHide = "hide" in item.props ? item.props.hide : item.type.defaultProps.hide;
				return itemAxisId === axisId && (includeHidden || !itemHide);
			}), type, layout, true);
			if (type === "number") {
				domain = detectReferenceElementsDomain(children, domain, axisId, axisType, ticks);
				if (childDomain) domain = parseSpecifiedDomain(childDomain, domain, allowDataOverflow);
			} else if (type === "category" && childDomain) {
				var axisDomain = childDomain;
				if (domain.every(function(entry) {
					return axisDomain.indexOf(entry) >= 0;
				})) domain = axisDomain;
			}
		}
		return _objectSpread$4(_objectSpread$4({}, result), {}, _defineProperty$4({}, axisId, _objectSpread$4(_objectSpread$4({}, childProps), {}, {
			axisType,
			domain,
			categoricalDomain,
			duplicateDomain,
			originalDomain: (_childProps$domain2 = childProps.domain) !== null && _childProps$domain2 !== void 0 ? _childProps$domain2 : defaultDomain,
			isCategorical,
			layout
		})));
	}, {});
};
/**
* Get the configuration of axis by the options of item,
* this kind of axis does not display in chart
* @param  {Object} props         Latest props
* @param  {Array} graphicalItems The instances of item
* @param  {ReactElement} Axis    Axis Component
* @param  {String} axisType      The type of axis, xAxis - x-axis, yAxis - y-axis
* @param  {String} axisIdKey     The unique id of an axis
* @param  {Object} stackGroups   The items grouped by axisId and stackId
* @param {Number} dataStartIndex The start index of the data series when a brush is applied
* @param {Number} dataEndIndex   The end index of the data series when a brush is applied
* @return {Object}               Configuration
*/
var getAxisMapByItems = function getAxisMapByItems(props, _ref3) {
	var graphicalItems = _ref3.graphicalItems, Axis = _ref3.Axis, axisType = _ref3.axisType, axisIdKey = _ref3.axisIdKey, stackGroups = _ref3.stackGroups, dataStartIndex = _ref3.dataStartIndex, dataEndIndex = _ref3.dataEndIndex;
	var layout = props.layout, children = props.children;
	var displayedData = getDisplayedData(props.data, {
		graphicalItems,
		dataStartIndex,
		dataEndIndex
	});
	var len = displayedData.length;
	var isCategorical = isCategoricalAxis(layout, axisType);
	var index = -1;
	return graphicalItems.reduce(function(result, child) {
		var axisId = (child.type.defaultProps !== void 0 ? _objectSpread$4(_objectSpread$4({}, child.type.defaultProps), child.props) : child.props)[axisIdKey];
		var originalDomain = getDefaultDomainByAxisType("number");
		if (!result[axisId]) {
			index++;
			var domain;
			if (isCategorical) domain = (0, import_range.default)(0, len);
			else if (stackGroups && stackGroups[axisId] && stackGroups[axisId].hasStack) {
				domain = getDomainOfStackGroups(stackGroups[axisId].stackGroups, dataStartIndex, dataEndIndex);
				domain = detectReferenceElementsDomain(children, domain, axisId, axisType);
			} else {
				domain = parseSpecifiedDomain(originalDomain, getDomainOfItemsWithSameAxis(displayedData, graphicalItems.filter(function(item) {
					var _defaultProps4, _defaultProps5;
					var itemAxisId = axisIdKey in item.props ? item.props[axisIdKey] : (_defaultProps4 = item.type.defaultProps) === null || _defaultProps4 === void 0 ? void 0 : _defaultProps4[axisIdKey];
					var itemHide = "hide" in item.props ? item.props.hide : (_defaultProps5 = item.type.defaultProps) === null || _defaultProps5 === void 0 ? void 0 : _defaultProps5.hide;
					return itemAxisId === axisId && !itemHide;
				}), "number", layout), Axis.defaultProps.allowDataOverflow);
				domain = detectReferenceElementsDomain(children, domain, axisId, axisType);
			}
			return _objectSpread$4(_objectSpread$4({}, result), {}, _defineProperty$4({}, axisId, _objectSpread$4(_objectSpread$4({ axisType }, Axis.defaultProps), {}, {
				hide: true,
				orientation: (0, import_get.default)(ORIENT_MAP, "".concat(axisType, ".").concat(index % 2), null),
				domain,
				originalDomain,
				isCategorical,
				layout
			})));
		}
		return result;
	}, {});
};
/**
* Get the configuration of all x-axis or y-axis
* @param  {Object} props          Latest props
* @param  {String} axisType       The type of axis
* @param  {React.ComponentType}  [AxisComp]      Axis Component
* @param  {Array}  graphicalItems The instances of item
* @param  {Object} stackGroups    The items grouped by axisId and stackId
* @param {Number} dataStartIndex  The start index of the data series when a brush is applied
* @param {Number} dataEndIndex    The end index of the data series when a brush is applied
* @return {Object}          Configuration
*/
var getAxisMap = function getAxisMap(props, _ref4) {
	var _ref4$axisType = _ref4.axisType, axisType = _ref4$axisType === void 0 ? "xAxis" : _ref4$axisType, AxisComp = _ref4.AxisComp, graphicalItems = _ref4.graphicalItems, stackGroups = _ref4.stackGroups, dataStartIndex = _ref4.dataStartIndex, dataEndIndex = _ref4.dataEndIndex;
	var children = props.children;
	var axisIdKey = "".concat(axisType, "Id");
	var axes = findAllByType(children, AxisComp);
	var axisMap = {};
	if (axes && axes.length) axisMap = getAxisMapByAxes(props, {
		axes,
		graphicalItems,
		axisType,
		axisIdKey,
		stackGroups,
		dataStartIndex,
		dataEndIndex
	});
	else if (graphicalItems && graphicalItems.length) axisMap = getAxisMapByItems(props, {
		Axis: AxisComp,
		graphicalItems,
		axisType,
		axisIdKey,
		stackGroups,
		dataStartIndex,
		dataEndIndex
	});
	return axisMap;
};
var tooltipTicksGenerator = function tooltipTicksGenerator(axisMap) {
	var axis = getAnyElementOfObject(axisMap);
	var tooltipTicks = getTicksOfAxis(axis, false, true);
	return {
		tooltipTicks,
		orderedTooltipTicks: (0, import_sortBy.default)(tooltipTicks, function(o) {
			return o.coordinate;
		}),
		tooltipAxis: axis,
		tooltipAxisBandSize: getBandSizeOfAxis(axis, tooltipTicks)
	};
};
/**
* Returns default, reset state for the categorical chart.
* @param {Object} props Props object to use when creating the default state
* @return {Object} Whole new state
*/
var createDefaultState = function createDefaultState(props) {
	var children = props.children, defaultShowTooltip = props.defaultShowTooltip;
	var brushItem = findChildByType(children, Brush);
	var startIndex = 0;
	var endIndex = 0;
	if (props.data && props.data.length !== 0) endIndex = props.data.length - 1;
	if (brushItem && brushItem.props) {
		if (brushItem.props.startIndex >= 0) startIndex = brushItem.props.startIndex;
		if (brushItem.props.endIndex >= 0) endIndex = brushItem.props.endIndex;
	}
	return {
		chartX: 0,
		chartY: 0,
		dataStartIndex: startIndex,
		dataEndIndex: endIndex,
		activeTooltipIndex: -1,
		isTooltipActive: Boolean(defaultShowTooltip)
	};
};
var hasGraphicalBarItem = function hasGraphicalBarItem(graphicalItems) {
	if (!graphicalItems || !graphicalItems.length) return false;
	return graphicalItems.some(function(item) {
		var name = getDisplayName(item && item.type);
		return name && name.indexOf("Bar") >= 0;
	});
};
var getAxisNameByLayout = function getAxisNameByLayout(layout) {
	if (layout === "horizontal") return {
		numericAxisName: "yAxis",
		cateAxisName: "xAxis"
	};
	if (layout === "vertical") return {
		numericAxisName: "xAxis",
		cateAxisName: "yAxis"
	};
	if (layout === "centric") return {
		numericAxisName: "radiusAxis",
		cateAxisName: "angleAxis"
	};
	return {
		numericAxisName: "angleAxis",
		cateAxisName: "radiusAxis"
	};
};
/**
* Calculate the offset of main part in the svg element
* @param  {Object} params.props          Latest props
* @param  {Array}  params.graphicalItems The instances of item
* @param  {Object} params.xAxisMap       The configuration of x-axis
* @param  {Object} params.yAxisMap       The configuration of y-axis
* @param  {Object} prevLegendBBox        The boundary box of legend
* @return {Object} The offset of main part in the svg element
*/
var calculateOffset = function calculateOffset(_ref5, prevLegendBBox) {
	var props = _ref5.props, graphicalItems = _ref5.graphicalItems, _ref5$xAxisMap = _ref5.xAxisMap, xAxisMap = _ref5$xAxisMap === void 0 ? {} : _ref5$xAxisMap, _ref5$yAxisMap = _ref5.yAxisMap, yAxisMap = _ref5$yAxisMap === void 0 ? {} : _ref5$yAxisMap;
	var width = props.width, height = props.height, children = props.children;
	var margin = props.margin || {};
	var brushItem = findChildByType(children, Brush);
	var legendItem = findChildByType(children, Legend);
	var offsetH = Object.keys(yAxisMap).reduce(function(result, id) {
		var entry = yAxisMap[id];
		var orientation = entry.orientation;
		if (!entry.mirror && !entry.hide) return _objectSpread$4(_objectSpread$4({}, result), {}, _defineProperty$4({}, orientation, result[orientation] + entry.width));
		return result;
	}, {
		left: margin.left || 0,
		right: margin.right || 0
	});
	var offset = _objectSpread$4(_objectSpread$4({}, Object.keys(xAxisMap).reduce(function(result, id) {
		var entry = xAxisMap[id];
		var orientation = entry.orientation;
		if (!entry.mirror && !entry.hide) return _objectSpread$4(_objectSpread$4({}, result), {}, _defineProperty$4({}, orientation, (0, import_get.default)(result, "".concat(orientation)) + entry.height));
		return result;
	}, {
		top: margin.top || 0,
		bottom: margin.bottom || 0
	})), offsetH);
	var brushBottom = offset.bottom;
	if (brushItem) offset.bottom += brushItem.props.height || Brush.defaultProps.height;
	if (legendItem && prevLegendBBox) offset = appendOffsetOfLegend(offset, graphicalItems, props, prevLegendBBox);
	var offsetWidth = width - offset.left - offset.right;
	var offsetHeight = height - offset.top - offset.bottom;
	return _objectSpread$4(_objectSpread$4({ brushBottom }, offset), {}, {
		width: Math.max(offsetWidth, 0),
		height: Math.max(offsetHeight, 0)
	});
};
var getCartesianAxisSize = function getCartesianAxisSize(axisObj, axisName) {
	if (axisName === "xAxis") return axisObj[axisName].width;
	if (axisName === "yAxis") return axisObj[axisName].height;
};
var generateCategoricalChart = function generateCategoricalChart(_ref6) {
	var chartName = _ref6.chartName, GraphicalChild = _ref6.GraphicalChild, _ref6$defaultTooltipE = _ref6.defaultTooltipEventType, defaultTooltipEventType = _ref6$defaultTooltipE === void 0 ? "axis" : _ref6$defaultTooltipE, _ref6$validateTooltip = _ref6.validateTooltipEventTypes, validateTooltipEventTypes = _ref6$validateTooltip === void 0 ? ["axis"] : _ref6$validateTooltip, axisComponents = _ref6.axisComponents, legendContent = _ref6.legendContent, formatAxisMap = _ref6.formatAxisMap, defaultProps = _ref6.defaultProps;
	var getFormatItems = function getFormatItems(props, currentState) {
		var graphicalItems = currentState.graphicalItems, stackGroups = currentState.stackGroups, offset = currentState.offset, updateId = currentState.updateId, dataStartIndex = currentState.dataStartIndex, dataEndIndex = currentState.dataEndIndex;
		var barSize = props.barSize, layout = props.layout, barGap = props.barGap, barCategoryGap = props.barCategoryGap, globalMaxBarSize = props.maxBarSize;
		var _getAxisNameByLayout = getAxisNameByLayout(layout), numericAxisName = _getAxisNameByLayout.numericAxisName, cateAxisName = _getAxisNameByLayout.cateAxisName;
		var hasBar = hasGraphicalBarItem(graphicalItems);
		var formattedItems = [];
		graphicalItems.forEach(function(item, index) {
			var displayedData = getDisplayedData(props.data, {
				graphicalItems: [item],
				dataStartIndex,
				dataEndIndex
			});
			var itemProps = item.type.defaultProps !== void 0 ? _objectSpread$4(_objectSpread$4({}, item.type.defaultProps), item.props) : item.props;
			var dataKey = itemProps.dataKey, childMaxBarSize = itemProps.maxBarSize;
			var numericAxisId = itemProps["".concat(numericAxisName, "Id")];
			var cateAxisId = itemProps["".concat(cateAxisName, "Id")];
			var axisObj = axisComponents.reduce(function(result, entry) {
				var axisMap = currentState["".concat(entry.axisType, "Map")];
				var id = itemProps["".concat(entry.axisType, "Id")];
				/**
				* tell the user in dev mode that their configuration is incorrect if we cannot find a match between
				* axisId on the chart and axisId on the axis. zAxis does not get passed in the map for ComposedChart,
				* leave it out of the check for now.
				*/
				!(axisMap && axisMap[id] || entry.axisType === "zAxis") && invariant(false);
				var axis = axisMap[id];
				return _objectSpread$4(_objectSpread$4({}, result), {}, _defineProperty$4(_defineProperty$4({}, entry.axisType, axis), "".concat(entry.axisType, "Ticks"), getTicksOfAxis(axis)));
			}, {});
			var cateAxis = axisObj[cateAxisName];
			var cateTicks = axisObj["".concat(cateAxisName, "Ticks")];
			var stackedData = stackGroups && stackGroups[numericAxisId] && stackGroups[numericAxisId].hasStack && getStackedDataOfItem(item, stackGroups[numericAxisId].stackGroups);
			var itemIsBar = getDisplayName(item.type).indexOf("Bar") >= 0;
			var bandSize = getBandSizeOfAxis(cateAxis, cateTicks);
			var barPosition = [];
			var sizeList = hasBar && getBarSizeList({
				barSize,
				stackGroups,
				totalSize: getCartesianAxisSize(axisObj, cateAxisName)
			});
			if (itemIsBar) {
				var _ref7, _getBandSizeOfAxis;
				var maxBarSize = (0, import_isNil.default)(childMaxBarSize) ? globalMaxBarSize : childMaxBarSize;
				var barBandSize = (_ref7 = (_getBandSizeOfAxis = getBandSizeOfAxis(cateAxis, cateTicks, true)) !== null && _getBandSizeOfAxis !== void 0 ? _getBandSizeOfAxis : maxBarSize) !== null && _ref7 !== void 0 ? _ref7 : 0;
				barPosition = getBarPosition({
					barGap,
					barCategoryGap,
					bandSize: barBandSize !== bandSize ? barBandSize : bandSize,
					sizeList: sizeList[cateAxisId],
					maxBarSize
				});
				if (barBandSize !== bandSize) barPosition = barPosition.map(function(pos) {
					return _objectSpread$4(_objectSpread$4({}, pos), {}, { position: _objectSpread$4(_objectSpread$4({}, pos.position), {}, { offset: pos.position.offset - barBandSize / 2 }) });
				});
			}
			var composedFn = item && item.type && item.type.getComposedData;
			if (composedFn) formattedItems.push({
				props: _objectSpread$4(_objectSpread$4({}, composedFn(_objectSpread$4(_objectSpread$4({}, axisObj), {}, {
					displayedData,
					props,
					dataKey,
					item,
					bandSize,
					barPosition,
					offset,
					stackedData,
					layout,
					dataStartIndex,
					dataEndIndex
				}))), {}, _defineProperty$4(_defineProperty$4(_defineProperty$4({ key: item.key || "item-".concat(index) }, numericAxisName, axisObj[numericAxisName]), cateAxisName, axisObj[cateAxisName]), "animationId", updateId)),
				childIndex: parseChildIndex(item, props.children),
				item
			});
		});
		return formattedItems;
	};
	/**
	* The AxisMaps are expensive to render on large data sets
	* so provide the ability to store them in state and only update them when necessary
	* they are dependent upon the start and end index of
	* the brush so it's important that this method is called _after_
	* the state is updated with any new start/end indices
	*
	* @param {Object} props          The props object to be used for updating the axismaps
	* dataStartIndex: The start index of the data series when a brush is applied
	* dataEndIndex: The end index of the data series when a brush is applied
	* updateId: The update id
	* @param {Object} prevState      Prev state
	* @return {Object} state New state to set
	*/
	var updateStateOfAxisMapsOffsetAndStackGroups = function updateStateOfAxisMapsOffsetAndStackGroups(_ref8, prevState) {
		var props = _ref8.props, dataStartIndex = _ref8.dataStartIndex, dataEndIndex = _ref8.dataEndIndex, updateId = _ref8.updateId;
		if (!validateWidthHeight({ props })) return null;
		var children = props.children, layout = props.layout, stackOffset = props.stackOffset, data = props.data, reverseStackOrder = props.reverseStackOrder;
		var _getAxisNameByLayout2 = getAxisNameByLayout(layout), numericAxisName = _getAxisNameByLayout2.numericAxisName, cateAxisName = _getAxisNameByLayout2.cateAxisName;
		var graphicalItems = findAllByType(children, GraphicalChild);
		var stackGroups = getStackGroupsByAxisId(data, graphicalItems, "".concat(numericAxisName, "Id"), "".concat(cateAxisName, "Id"), stackOffset, reverseStackOrder);
		var axisObj = axisComponents.reduce(function(result, entry) {
			var name = "".concat(entry.axisType, "Map");
			return _objectSpread$4(_objectSpread$4({}, result), {}, _defineProperty$4({}, name, getAxisMap(props, _objectSpread$4(_objectSpread$4({}, entry), {}, {
				graphicalItems,
				stackGroups: entry.axisType === numericAxisName && stackGroups,
				dataStartIndex,
				dataEndIndex
			}))));
		}, {});
		var offset = calculateOffset(_objectSpread$4(_objectSpread$4({}, axisObj), {}, {
			props,
			graphicalItems
		}), prevState === null || prevState === void 0 ? void 0 : prevState.legendBBox);
		Object.keys(axisObj).forEach(function(key) {
			axisObj[key] = formatAxisMap(props, axisObj[key], offset, key.replace("Map", ""), chartName);
		});
		var cateAxisMap = axisObj["".concat(cateAxisName, "Map")];
		var ticksObj = tooltipTicksGenerator(cateAxisMap);
		return _objectSpread$4(_objectSpread$4({
			formattedGraphicalItems: getFormatItems(props, _objectSpread$4(_objectSpread$4({}, axisObj), {}, {
				dataStartIndex,
				dataEndIndex,
				updateId,
				graphicalItems,
				stackGroups,
				offset
			})),
			graphicalItems,
			offset,
			stackGroups
		}, ticksObj), axisObj);
	};
	var CategoricalChartWrapper = /*#__PURE__*/ function(_Component) {
		function CategoricalChartWrapper(_props) {
			var _props$id, _props$throttleDelay;
			var _this;
			_classCallCheck$3(this, CategoricalChartWrapper);
			_this = _callSuper$3(this, CategoricalChartWrapper, [_props]);
			_defineProperty$4(_this, "eventEmitterSymbol", Symbol("rechartsEventEmitter"));
			_defineProperty$4(_this, "accessibilityManager", new AccessibilityManager());
			_defineProperty$4(_this, "handleLegendBBoxUpdate", function(box) {
				if (box) {
					var _this$state = _this.state, dataStartIndex = _this$state.dataStartIndex, dataEndIndex = _this$state.dataEndIndex, updateId = _this$state.updateId;
					_this.setState(_objectSpread$4({ legendBBox: box }, updateStateOfAxisMapsOffsetAndStackGroups({
						props: _this.props,
						dataStartIndex,
						dataEndIndex,
						updateId
					}, _objectSpread$4(_objectSpread$4({}, _this.state), {}, { legendBBox: box }))));
				}
			});
			_defineProperty$4(_this, "handleReceiveSyncEvent", function(cId, data, emitter) {
				if (_this.props.syncId === cId) {
					if (emitter === _this.eventEmitterSymbol && typeof _this.props.syncMethod !== "function") return;
					_this.applySyncEvent(data);
				}
			});
			_defineProperty$4(_this, "handleBrushChange", function(_ref9) {
				var startIndex = _ref9.startIndex, endIndex = _ref9.endIndex;
				if (startIndex !== _this.state.dataStartIndex || endIndex !== _this.state.dataEndIndex) {
					var updateId = _this.state.updateId;
					_this.setState(function() {
						return _objectSpread$4({
							dataStartIndex: startIndex,
							dataEndIndex: endIndex
						}, updateStateOfAxisMapsOffsetAndStackGroups({
							props: _this.props,
							dataStartIndex: startIndex,
							dataEndIndex: endIndex,
							updateId
						}, _this.state));
					});
					_this.triggerSyncEvent({
						dataStartIndex: startIndex,
						dataEndIndex: endIndex
					});
				}
			});
			/**
			* The handler of mouse entering chart
			* @param  {Object} e              Event object
			* @return {Null}                  null
			*/
			_defineProperty$4(_this, "handleMouseEnter", function(e) {
				var mouse = _this.getMouseInfo(e);
				if (mouse) {
					var _nextState = _objectSpread$4(_objectSpread$4({}, mouse), {}, { isTooltipActive: true });
					_this.setState(_nextState);
					_this.triggerSyncEvent(_nextState);
					var onMouseEnter = _this.props.onMouseEnter;
					if ((0, import_isFunction.default)(onMouseEnter)) onMouseEnter(_nextState, e);
				}
			});
			_defineProperty$4(_this, "triggeredAfterMouseMove", function(e) {
				var mouse = _this.getMouseInfo(e);
				var nextState = mouse ? _objectSpread$4(_objectSpread$4({}, mouse), {}, { isTooltipActive: true }) : { isTooltipActive: false };
				_this.setState(nextState);
				_this.triggerSyncEvent(nextState);
				var onMouseMove = _this.props.onMouseMove;
				if ((0, import_isFunction.default)(onMouseMove)) onMouseMove(nextState, e);
			});
			/**
			* The handler of mouse entering a scatter
			* @param {Object} el The active scatter
			* @return {Object} no return
			*/
			_defineProperty$4(_this, "handleItemMouseEnter", function(el) {
				_this.setState(function() {
					return {
						isTooltipActive: true,
						activeItem: el,
						activePayload: el.tooltipPayload,
						activeCoordinate: el.tooltipPosition || {
							x: el.cx,
							y: el.cy
						}
					};
				});
			});
			/**
			* The handler of mouse leaving a scatter
			* @return {Object} no return
			*/
			_defineProperty$4(_this, "handleItemMouseLeave", function() {
				_this.setState(function() {
					return { isTooltipActive: false };
				});
			});
			/**
			* The handler of mouse moving in chart
			* @param  {React.MouseEvent} e        Event object
			* @return {void} no return
			*/
			_defineProperty$4(_this, "handleMouseMove", function(e) {
				e.persist();
				_this.throttleTriggeredAfterMouseMove(e);
			});
			/**
			* The handler if mouse leaving chart
			* @param {Object} e Event object
			* @return {Null} no return
			*/
			_defineProperty$4(_this, "handleMouseLeave", function(e) {
				_this.throttleTriggeredAfterMouseMove.cancel();
				var nextState = { isTooltipActive: false };
				_this.setState(nextState);
				_this.triggerSyncEvent(nextState);
				var onMouseLeave = _this.props.onMouseLeave;
				if ((0, import_isFunction.default)(onMouseLeave)) onMouseLeave(nextState, e);
			});
			_defineProperty$4(_this, "handleOuterEvent", function(e) {
				var eventName = getReactEventByType(e);
				var event = (0, import_get.default)(_this.props, "".concat(eventName));
				if (eventName && (0, import_isFunction.default)(event)) {
					var _mouse;
					var mouse;
					if (/.*touch.*/i.test(eventName)) mouse = _this.getMouseInfo(e.changedTouches[0]);
					else mouse = _this.getMouseInfo(e);
					event((_mouse = mouse) !== null && _mouse !== void 0 ? _mouse : {}, e);
				}
			});
			_defineProperty$4(_this, "handleClick", function(e) {
				var mouse = _this.getMouseInfo(e);
				if (mouse) {
					var _nextState2 = _objectSpread$4(_objectSpread$4({}, mouse), {}, { isTooltipActive: true });
					_this.setState(_nextState2);
					_this.triggerSyncEvent(_nextState2);
					var onClick = _this.props.onClick;
					if ((0, import_isFunction.default)(onClick)) onClick(_nextState2, e);
				}
			});
			_defineProperty$4(_this, "handleMouseDown", function(e) {
				var onMouseDown = _this.props.onMouseDown;
				if ((0, import_isFunction.default)(onMouseDown)) onMouseDown(_this.getMouseInfo(e), e);
			});
			_defineProperty$4(_this, "handleMouseUp", function(e) {
				var onMouseUp = _this.props.onMouseUp;
				if ((0, import_isFunction.default)(onMouseUp)) onMouseUp(_this.getMouseInfo(e), e);
			});
			_defineProperty$4(_this, "handleTouchMove", function(e) {
				if (e.changedTouches != null && e.changedTouches.length > 0) _this.throttleTriggeredAfterMouseMove(e.changedTouches[0]);
			});
			_defineProperty$4(_this, "handleTouchStart", function(e) {
				if (e.changedTouches != null && e.changedTouches.length > 0) _this.handleMouseDown(e.changedTouches[0]);
			});
			_defineProperty$4(_this, "handleTouchEnd", function(e) {
				if (e.changedTouches != null && e.changedTouches.length > 0) _this.handleMouseUp(e.changedTouches[0]);
			});
			_defineProperty$4(_this, "handleDoubleClick", function(e) {
				var onDoubleClick = _this.props.onDoubleClick;
				if ((0, import_isFunction.default)(onDoubleClick)) onDoubleClick(_this.getMouseInfo(e), e);
			});
			_defineProperty$4(_this, "handleContextMenu", function(e) {
				var onContextMenu = _this.props.onContextMenu;
				if ((0, import_isFunction.default)(onContextMenu)) onContextMenu(_this.getMouseInfo(e), e);
			});
			_defineProperty$4(_this, "triggerSyncEvent", function(data) {
				if (_this.props.syncId !== void 0) eventCenter.emit(SYNC_EVENT, _this.props.syncId, data, _this.eventEmitterSymbol);
			});
			_defineProperty$4(_this, "applySyncEvent", function(data) {
				var _this$props = _this.props, layout = _this$props.layout, syncMethod = _this$props.syncMethod;
				var updateId = _this.state.updateId;
				var dataStartIndex = data.dataStartIndex, dataEndIndex = data.dataEndIndex;
				if (data.dataStartIndex !== void 0 || data.dataEndIndex !== void 0) _this.setState(_objectSpread$4({
					dataStartIndex,
					dataEndIndex
				}, updateStateOfAxisMapsOffsetAndStackGroups({
					props: _this.props,
					dataStartIndex,
					dataEndIndex,
					updateId
				}, _this.state)));
				else if (data.activeTooltipIndex !== void 0) {
					var chartX = data.chartX, chartY = data.chartY;
					var activeTooltipIndex = data.activeTooltipIndex;
					var _this$state2 = _this.state, offset = _this$state2.offset, tooltipTicks = _this$state2.tooltipTicks;
					if (!offset) return;
					if (typeof syncMethod === "function") activeTooltipIndex = syncMethod(tooltipTicks, data);
					else if (syncMethod === "value") {
						activeTooltipIndex = -1;
						for (var i = 0; i < tooltipTicks.length; i++) if (tooltipTicks[i].value === data.activeLabel) {
							activeTooltipIndex = i;
							break;
						}
					}
					var viewBox = _objectSpread$4(_objectSpread$4({}, offset), {}, {
						x: offset.left,
						y: offset.top
					});
					var validateChartX = Math.min(chartX, viewBox.x + viewBox.width);
					var validateChartY = Math.min(chartY, viewBox.y + viewBox.height);
					var activeLabel = tooltipTicks[activeTooltipIndex] && tooltipTicks[activeTooltipIndex].value;
					var activePayload = getTooltipContent(_this.state, _this.props.data, activeTooltipIndex);
					var activeCoordinate = tooltipTicks[activeTooltipIndex] ? {
						x: layout === "horizontal" ? tooltipTicks[activeTooltipIndex].coordinate : validateChartX,
						y: layout === "horizontal" ? validateChartY : tooltipTicks[activeTooltipIndex].coordinate
					} : originCoordinate;
					_this.setState(_objectSpread$4(_objectSpread$4({}, data), {}, {
						activeLabel,
						activeCoordinate,
						activePayload,
						activeTooltipIndex
					}));
				} else _this.setState(data);
			});
			_defineProperty$4(_this, "renderCursor", function(element) {
				var _element$props$active;
				var _this$state3 = _this.state, isTooltipActive = _this$state3.isTooltipActive, activeCoordinate = _this$state3.activeCoordinate, activePayload = _this$state3.activePayload, offset = _this$state3.offset, activeTooltipIndex = _this$state3.activeTooltipIndex, tooltipAxisBandSize = _this$state3.tooltipAxisBandSize;
				var tooltipEventType = _this.getTooltipEventType();
				var isActive = (_element$props$active = element.props.active) !== null && _element$props$active !== void 0 ? _element$props$active : isTooltipActive;
				var layout = _this.props.layout;
				var key = element.key || "_recharts-cursor";
				return /*#__PURE__*/ import_react.createElement(Cursor, {
					key,
					activeCoordinate,
					activePayload,
					activeTooltipIndex,
					chartName,
					element,
					isActive,
					layout,
					offset,
					tooltipAxisBandSize,
					tooltipEventType
				});
			});
			_defineProperty$4(_this, "renderPolarAxis", function(element, displayName, index) {
				var axisType = (0, import_get.default)(element, "type.axisType");
				var axisMap = (0, import_get.default)(_this.state, "".concat(axisType, "Map"));
				var elementDefaultProps = element.type.defaultProps;
				var elementProps = elementDefaultProps !== void 0 ? _objectSpread$4(_objectSpread$4({}, elementDefaultProps), element.props) : element.props;
				var axisOption = axisMap && axisMap[elementProps["".concat(axisType, "Id")]];
				return /*#__PURE__*/ (0, import_react.cloneElement)(element, _objectSpread$4(_objectSpread$4({}, axisOption), {}, {
					className: clsx(axisType, axisOption.className),
					key: element.key || "".concat(displayName, "-").concat(index),
					ticks: getTicksOfAxis(axisOption, true)
				}));
			});
			_defineProperty$4(_this, "renderPolarGrid", function(element) {
				var _element$props = element.props, radialLines = _element$props.radialLines, polarAngles = _element$props.polarAngles, polarRadius = _element$props.polarRadius;
				var _this$state4 = _this.state, radiusAxisMap = _this$state4.radiusAxisMap, angleAxisMap = _this$state4.angleAxisMap;
				var radiusAxis = getAnyElementOfObject(radiusAxisMap);
				var angleAxis = getAnyElementOfObject(angleAxisMap);
				var cx = angleAxis.cx, cy = angleAxis.cy, innerRadius = angleAxis.innerRadius, outerRadius = angleAxis.outerRadius;
				return /*#__PURE__*/ (0, import_react.cloneElement)(element, {
					polarAngles: Array.isArray(polarAngles) ? polarAngles : getTicksOfAxis(angleAxis, true).map(function(entry) {
						return entry.coordinate;
					}),
					polarRadius: Array.isArray(polarRadius) ? polarRadius : getTicksOfAxis(radiusAxis, true).map(function(entry) {
						return entry.coordinate;
					}),
					cx,
					cy,
					innerRadius,
					outerRadius,
					key: element.key || "polar-grid",
					radialLines
				});
			});
			/**
			* Draw legend
			* @return {ReactElement}            The instance of Legend
			*/
			_defineProperty$4(_this, "renderLegend", function() {
				var formattedGraphicalItems = _this.state.formattedGraphicalItems;
				var _this$props2 = _this.props, children = _this$props2.children, width = _this$props2.width, height = _this$props2.height;
				var margin = _this.props.margin || {};
				var props = getLegendProps({
					children,
					formattedGraphicalItems,
					legendWidth: width - (margin.left || 0) - (margin.right || 0),
					legendContent
				});
				if (!props) return null;
				var item = props.item, otherProps = _objectWithoutProperties$2(props, _excluded$2);
				return /*#__PURE__*/ (0, import_react.cloneElement)(item, _objectSpread$4(_objectSpread$4({}, otherProps), {}, {
					chartWidth: width,
					chartHeight: height,
					margin,
					onBBoxUpdate: _this.handleLegendBBoxUpdate
				}));
			});
			/**
			* Draw Tooltip
			* @return {ReactElement}  The instance of Tooltip
			*/
			_defineProperty$4(_this, "renderTooltip", function() {
				var _tooltipItem$props$ac;
				var _this$props3 = _this.props, children = _this$props3.children, accessibilityLayer = _this$props3.accessibilityLayer;
				var tooltipItem = findChildByType(children, Tooltip);
				if (!tooltipItem) return null;
				var _this$state5 = _this.state, isTooltipActive = _this$state5.isTooltipActive, activeCoordinate = _this$state5.activeCoordinate, activePayload = _this$state5.activePayload, activeLabel = _this$state5.activeLabel, offset = _this$state5.offset;
				var isActive = (_tooltipItem$props$ac = tooltipItem.props.active) !== null && _tooltipItem$props$ac !== void 0 ? _tooltipItem$props$ac : isTooltipActive;
				return /*#__PURE__*/ (0, import_react.cloneElement)(tooltipItem, {
					viewBox: _objectSpread$4(_objectSpread$4({}, offset), {}, {
						x: offset.left,
						y: offset.top
					}),
					active: isActive,
					label: activeLabel,
					payload: isActive ? activePayload : [],
					coordinate: activeCoordinate,
					accessibilityLayer
				});
			});
			_defineProperty$4(_this, "renderBrush", function(element) {
				var _this$props4 = _this.props, margin = _this$props4.margin, data = _this$props4.data;
				var _this$state6 = _this.state, offset = _this$state6.offset, dataStartIndex = _this$state6.dataStartIndex, dataEndIndex = _this$state6.dataEndIndex, updateId = _this$state6.updateId;
				return /*#__PURE__*/ (0, import_react.cloneElement)(element, {
					key: element.key || "_recharts-brush",
					onChange: combineEventHandlers(_this.handleBrushChange, element.props.onChange),
					data,
					x: isNumber$1(element.props.x) ? element.props.x : offset.left,
					y: isNumber$1(element.props.y) ? element.props.y : offset.top + offset.height + offset.brushBottom - (margin.bottom || 0),
					width: isNumber$1(element.props.width) ? element.props.width : offset.width,
					startIndex: dataStartIndex,
					endIndex: dataEndIndex,
					updateId: "brush-".concat(updateId)
				});
			});
			_defineProperty$4(_this, "renderReferenceElement", function(element, displayName, index) {
				if (!element) return null;
				var clipPathId = _this.clipPathId;
				var _this$state7 = _this.state, xAxisMap = _this$state7.xAxisMap, yAxisMap = _this$state7.yAxisMap, offset = _this$state7.offset;
				var elementDefaultProps = element.type.defaultProps || {};
				var _element$props2 = element.props, _element$props2$xAxis = _element$props2.xAxisId, xAxisId = _element$props2$xAxis === void 0 ? elementDefaultProps.xAxisId : _element$props2$xAxis, _element$props2$yAxis = _element$props2.yAxisId, yAxisId = _element$props2$yAxis === void 0 ? elementDefaultProps.yAxisId : _element$props2$yAxis;
				return /*#__PURE__*/ (0, import_react.cloneElement)(element, {
					key: element.key || "".concat(displayName, "-").concat(index),
					xAxis: xAxisMap[xAxisId],
					yAxis: yAxisMap[yAxisId],
					viewBox: {
						x: offset.left,
						y: offset.top,
						width: offset.width,
						height: offset.height
					},
					clipPathId
				});
			});
			_defineProperty$4(_this, "renderActivePoints", function(_ref10) {
				var item = _ref10.item, activePoint = _ref10.activePoint, basePoint = _ref10.basePoint, childIndex = _ref10.childIndex, isRange = _ref10.isRange;
				var result = [];
				var key = item.props.key;
				var itemItemProps = item.item.type.defaultProps !== void 0 ? _objectSpread$4(_objectSpread$4({}, item.item.type.defaultProps), item.item.props) : item.item.props;
				var activeDot = itemItemProps.activeDot, dataKey = itemItemProps.dataKey;
				var dotProps = _objectSpread$4(_objectSpread$4({
					index: childIndex,
					dataKey,
					cx: activePoint.x,
					cy: activePoint.y,
					r: 4,
					fill: getMainColorOfGraphicItem(item.item),
					strokeWidth: 2,
					stroke: "#fff",
					payload: activePoint.payload,
					value: activePoint.value
				}, filterProps(activeDot, false)), adaptEventHandlers(activeDot));
				result.push(CategoricalChartWrapper.renderActiveDot(activeDot, dotProps, "".concat(key, "-activePoint-").concat(childIndex)));
				if (basePoint) result.push(CategoricalChartWrapper.renderActiveDot(activeDot, _objectSpread$4(_objectSpread$4({}, dotProps), {}, {
					cx: basePoint.x,
					cy: basePoint.y
				}), "".concat(key, "-basePoint-").concat(childIndex)));
				else if (isRange) result.push(null);
				return result;
			});
			_defineProperty$4(_this, "renderGraphicChild", function(element, displayName, index) {
				var item = _this.filterFormatItem(element, displayName, index);
				if (!item) return null;
				var tooltipEventType = _this.getTooltipEventType();
				var _this$state8 = _this.state, isTooltipActive = _this$state8.isTooltipActive, tooltipAxis = _this$state8.tooltipAxis, activeTooltipIndex = _this$state8.activeTooltipIndex, activeLabel = _this$state8.activeLabel;
				var children = _this.props.children;
				var tooltipItem = findChildByType(children, Tooltip);
				var _item$props = item.props, points = _item$props.points, isRange = _item$props.isRange, baseLine = _item$props.baseLine;
				var itemItemProps = item.item.type.defaultProps !== void 0 ? _objectSpread$4(_objectSpread$4({}, item.item.type.defaultProps), item.item.props) : item.item.props;
				var activeDot = itemItemProps.activeDot, hide = itemItemProps.hide, activeBar = itemItemProps.activeBar, activeShape = itemItemProps.activeShape;
				var hasActive = Boolean(!hide && isTooltipActive && tooltipItem && (activeDot || activeBar || activeShape));
				var itemEvents = {};
				if (tooltipEventType !== "axis" && tooltipItem && tooltipItem.props.trigger === "click") itemEvents = { onClick: combineEventHandlers(_this.handleItemMouseEnter, element.props.onClick) };
				else if (tooltipEventType !== "axis") itemEvents = {
					onMouseLeave: combineEventHandlers(_this.handleItemMouseLeave, element.props.onMouseLeave),
					onMouseEnter: combineEventHandlers(_this.handleItemMouseEnter, element.props.onMouseEnter)
				};
				var graphicalItem = /*#__PURE__*/ (0, import_react.cloneElement)(element, _objectSpread$4(_objectSpread$4({}, item.props), itemEvents));
				function findWithPayload(entry) {
					return typeof tooltipAxis.dataKey === "function" ? tooltipAxis.dataKey(entry.payload) : null;
				}
				if (hasActive) {
					if (activeTooltipIndex >= 0) {
						var activePoint, basePoint;
						if (tooltipAxis.dataKey && !tooltipAxis.allowDuplicatedCategory) {
							var specifiedKey = typeof tooltipAxis.dataKey === "function" ? findWithPayload : "payload.".concat(tooltipAxis.dataKey.toString());
							activePoint = findEntryInArray(points, specifiedKey, activeLabel);
							basePoint = isRange && baseLine && findEntryInArray(baseLine, specifiedKey, activeLabel);
						} else {
							activePoint = points === null || points === void 0 ? void 0 : points[activeTooltipIndex];
							basePoint = isRange && baseLine && baseLine[activeTooltipIndex];
						}
						if (activeShape || activeBar) {
							var activeIndex = element.props.activeIndex !== void 0 ? element.props.activeIndex : activeTooltipIndex;
							return [
								/*#__PURE__*/ (0, import_react.cloneElement)(element, _objectSpread$4(_objectSpread$4(_objectSpread$4({}, item.props), itemEvents), {}, { activeIndex })),
								null,
								null
							];
						}
						if (!(0, import_isNil.default)(activePoint)) return [graphicalItem].concat(_toConsumableArray$1(_this.renderActivePoints({
							item,
							activePoint,
							basePoint,
							childIndex: activeTooltipIndex,
							isRange
						})));
					} else {
						var _this$getItemByXY;
						/**
						* We hit this block if consumer uses a Tooltip without XAxis and/or YAxis.
						* In which case, this.state.activeTooltipIndex never gets set
						* because the mouse events that trigger that value getting set never get trigged without the axis components.
						*
						* An example usage case is a FunnelChart
						*/
						var _ref11$graphicalItem = ((_this$getItemByXY = _this.getItemByXY(_this.state.activeCoordinate)) !== null && _this$getItemByXY !== void 0 ? _this$getItemByXY : { graphicalItem }).graphicalItem, _ref11$graphicalItem$ = _ref11$graphicalItem.item, xyItem = _ref11$graphicalItem$ === void 0 ? element : _ref11$graphicalItem$, childIndex = _ref11$graphicalItem.childIndex;
						var elementProps = _objectSpread$4(_objectSpread$4(_objectSpread$4({}, item.props), itemEvents), {}, { activeIndex: childIndex });
						return [
							/*#__PURE__*/ (0, import_react.cloneElement)(xyItem, elementProps),
							null,
							null
						];
					}
				}
				if (isRange) return [
					graphicalItem,
					null,
					null
				];
				return [graphicalItem, null];
			});
			_defineProperty$4(_this, "renderCustomized", function(element, displayName, index) {
				return /*#__PURE__*/ (0, import_react.cloneElement)(element, _objectSpread$4(_objectSpread$4({ key: "recharts-customized-".concat(index) }, _this.props), _this.state));
			});
			_defineProperty$4(_this, "renderMap", {
				CartesianGrid: {
					handler: renderAsIs,
					once: true
				},
				ReferenceArea: { handler: _this.renderReferenceElement },
				ReferenceLine: { handler: renderAsIs },
				ReferenceDot: { handler: _this.renderReferenceElement },
				XAxis: { handler: renderAsIs },
				YAxis: { handler: renderAsIs },
				Brush: {
					handler: _this.renderBrush,
					once: true
				},
				Bar: { handler: _this.renderGraphicChild },
				Line: { handler: _this.renderGraphicChild },
				Area: { handler: _this.renderGraphicChild },
				Radar: { handler: _this.renderGraphicChild },
				RadialBar: { handler: _this.renderGraphicChild },
				Scatter: { handler: _this.renderGraphicChild },
				Pie: { handler: _this.renderGraphicChild },
				Funnel: { handler: _this.renderGraphicChild },
				Tooltip: {
					handler: _this.renderCursor,
					once: true
				},
				PolarGrid: {
					handler: _this.renderPolarGrid,
					once: true
				},
				PolarAngleAxis: { handler: _this.renderPolarAxis },
				PolarRadiusAxis: { handler: _this.renderPolarAxis },
				Customized: { handler: _this.renderCustomized }
			});
			_this.clipPathId = "".concat((_props$id = _props.id) !== null && _props$id !== void 0 ? _props$id : uniqueId("recharts"), "-clip");
			_this.throttleTriggeredAfterMouseMove = (0, import_throttle.default)(_this.triggeredAfterMouseMove, (_props$throttleDelay = _props.throttleDelay) !== null && _props$throttleDelay !== void 0 ? _props$throttleDelay : 1e3 / 60);
			_this.state = {};
			return _this;
		}
		_inherits$3(CategoricalChartWrapper, _Component);
		return _createClass$3(CategoricalChartWrapper, [
			{
				key: "componentDidMount",
				value: function componentDidMount() {
					var _this$props$margin$le, _this$props$margin$to;
					this.addListener();
					this.accessibilityManager.setDetails({
						container: this.container,
						offset: {
							left: (_this$props$margin$le = this.props.margin.left) !== null && _this$props$margin$le !== void 0 ? _this$props$margin$le : 0,
							top: (_this$props$margin$to = this.props.margin.top) !== null && _this$props$margin$to !== void 0 ? _this$props$margin$to : 0
						},
						coordinateList: this.state.tooltipTicks,
						mouseHandlerCallback: this.triggeredAfterMouseMove,
						layout: this.props.layout
					});
					this.displayDefaultTooltip();
				}
			},
			{
				key: "displayDefaultTooltip",
				value: function displayDefaultTooltip() {
					var _this$props5 = this.props, children = _this$props5.children, data = _this$props5.data, height = _this$props5.height, layout = _this$props5.layout;
					var tooltipElem = findChildByType(children, Tooltip);
					if (!tooltipElem) return;
					var defaultIndex = tooltipElem.props.defaultIndex;
					if (typeof defaultIndex !== "number" || defaultIndex < 0 || defaultIndex > this.state.tooltipTicks.length - 1) return;
					var activeLabel = this.state.tooltipTicks[defaultIndex] && this.state.tooltipTicks[defaultIndex].value;
					var activePayload = getTooltipContent(this.state, data, defaultIndex, activeLabel);
					var independentAxisCoord = this.state.tooltipTicks[defaultIndex].coordinate;
					var dependentAxisCoord = (this.state.offset.top + height) / 2;
					var activeCoordinate = layout === "horizontal" ? {
						x: independentAxisCoord,
						y: dependentAxisCoord
					} : {
						y: independentAxisCoord,
						x: dependentAxisCoord
					};
					var scatterPlotElement = this.state.formattedGraphicalItems.find(function(_ref12) {
						return _ref12.item.type.name === "Scatter";
					});
					if (scatterPlotElement) {
						activeCoordinate = _objectSpread$4(_objectSpread$4({}, activeCoordinate), scatterPlotElement.props.points[defaultIndex].tooltipPosition);
						activePayload = scatterPlotElement.props.points[defaultIndex].tooltipPayload;
					}
					var nextState = {
						activeTooltipIndex: defaultIndex,
						isTooltipActive: true,
						activeLabel,
						activePayload,
						activeCoordinate
					};
					this.setState(nextState);
					this.renderCursor(tooltipElem);
					this.accessibilityManager.setIndex(defaultIndex);
				}
			},
			{
				key: "getSnapshotBeforeUpdate",
				value: function getSnapshotBeforeUpdate(prevProps, prevState) {
					if (!this.props.accessibilityLayer) return null;
					if (this.state.tooltipTicks !== prevState.tooltipTicks) this.accessibilityManager.setDetails({ coordinateList: this.state.tooltipTicks });
					if (this.props.layout !== prevProps.layout) this.accessibilityManager.setDetails({ layout: this.props.layout });
					if (this.props.margin !== prevProps.margin) {
						var _this$props$margin$le2, _this$props$margin$to2;
						this.accessibilityManager.setDetails({ offset: {
							left: (_this$props$margin$le2 = this.props.margin.left) !== null && _this$props$margin$le2 !== void 0 ? _this$props$margin$le2 : 0,
							top: (_this$props$margin$to2 = this.props.margin.top) !== null && _this$props$margin$to2 !== void 0 ? _this$props$margin$to2 : 0
						} });
					}
					return null;
				}
			},
			{
				key: "componentDidUpdate",
				value: function componentDidUpdate(prevProps) {
					if (!isChildrenEqual([findChildByType(prevProps.children, Tooltip)], [findChildByType(this.props.children, Tooltip)])) this.displayDefaultTooltip();
				}
			},
			{
				key: "componentWillUnmount",
				value: function componentWillUnmount() {
					this.removeListener();
					this.throttleTriggeredAfterMouseMove.cancel();
				}
			},
			{
				key: "getTooltipEventType",
				value: function getTooltipEventType() {
					var tooltipItem = findChildByType(this.props.children, Tooltip);
					if (tooltipItem && typeof tooltipItem.props.shared === "boolean") {
						var eventType = tooltipItem.props.shared ? "axis" : "item";
						return validateTooltipEventTypes.indexOf(eventType) >= 0 ? eventType : defaultTooltipEventType;
					}
					return defaultTooltipEventType;
				}
			},
			{
				key: "getMouseInfo",
				value: function getMouseInfo(event) {
					if (!this.container) return null;
					var element = this.container;
					var boundingRect = element.getBoundingClientRect();
					var containerOffset = getOffset(boundingRect);
					var e = {
						chartX: Math.round(event.pageX - containerOffset.left),
						chartY: Math.round(event.pageY - containerOffset.top)
					};
					var scale = boundingRect.width / element.offsetWidth || 1;
					var rangeObj = this.inRange(e.chartX, e.chartY, scale);
					if (!rangeObj) return null;
					var _this$state9 = this.state, xAxisMap = _this$state9.xAxisMap, yAxisMap = _this$state9.yAxisMap;
					var tooltipEventType = this.getTooltipEventType();
					var toolTipData = getTooltipData(this.state, this.props.data, this.props.layout, rangeObj);
					if (tooltipEventType !== "axis" && xAxisMap && yAxisMap) {
						var xScale = getAnyElementOfObject(xAxisMap).scale;
						var yScale = getAnyElementOfObject(yAxisMap).scale;
						var xValue = xScale && xScale.invert ? xScale.invert(e.chartX) : null;
						var yValue = yScale && yScale.invert ? yScale.invert(e.chartY) : null;
						return _objectSpread$4(_objectSpread$4({}, e), {}, {
							xValue,
							yValue
						}, toolTipData);
					}
					if (toolTipData) return _objectSpread$4(_objectSpread$4({}, e), toolTipData);
					return null;
				}
			},
			{
				key: "inRange",
				value: function inRange(x, y) {
					var scale = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1;
					var layout = this.props.layout;
					var scaledX = x / scale, scaledY = y / scale;
					if (layout === "horizontal" || layout === "vertical") {
						var offset = this.state.offset;
						return scaledX >= offset.left && scaledX <= offset.left + offset.width && scaledY >= offset.top && scaledY <= offset.top + offset.height ? {
							x: scaledX,
							y: scaledY
						} : null;
					}
					var _this$state10 = this.state, angleAxisMap = _this$state10.angleAxisMap, radiusAxisMap = _this$state10.radiusAxisMap;
					if (angleAxisMap && radiusAxisMap) {
						var angleAxis = getAnyElementOfObject(angleAxisMap);
						return inRangeOfSector({
							x: scaledX,
							y: scaledY
						}, angleAxis);
					}
					return null;
				}
			},
			{
				key: "parseEventsOfWrapper",
				value: function parseEventsOfWrapper() {
					var children = this.props.children;
					var tooltipEventType = this.getTooltipEventType();
					var tooltipItem = findChildByType(children, Tooltip);
					var tooltipEvents = {};
					if (tooltipItem && tooltipEventType === "axis") {
						if (tooltipItem.props.trigger === "click") tooltipEvents = { onClick: this.handleClick };
						else tooltipEvents = {
							onMouseEnter: this.handleMouseEnter,
							onDoubleClick: this.handleDoubleClick,
							onMouseMove: this.handleMouseMove,
							onMouseLeave: this.handleMouseLeave,
							onTouchMove: this.handleTouchMove,
							onTouchStart: this.handleTouchStart,
							onTouchEnd: this.handleTouchEnd,
							onContextMenu: this.handleContextMenu
						};
					}
					return _objectSpread$4(_objectSpread$4({}, adaptEventHandlers(this.props, this.handleOuterEvent)), tooltipEvents);
				}
			},
			{
				key: "addListener",
				value: function addListener() {
					eventCenter.on(SYNC_EVENT, this.handleReceiveSyncEvent);
				}
			},
			{
				key: "removeListener",
				value: function removeListener() {
					eventCenter.removeListener(SYNC_EVENT, this.handleReceiveSyncEvent);
				}
			},
			{
				key: "filterFormatItem",
				value: function filterFormatItem(item, displayName, childIndex) {
					var formattedGraphicalItems = this.state.formattedGraphicalItems;
					for (var i = 0, len = formattedGraphicalItems.length; i < len; i++) {
						var entry = formattedGraphicalItems[i];
						if (entry.item === item || entry.props.key === item.key || displayName === getDisplayName(entry.item.type) && childIndex === entry.childIndex) return entry;
					}
					return null;
				}
			},
			{
				key: "renderClipPath",
				value: function renderClipPath() {
					var clipPathId = this.clipPathId;
					var _this$state$offset = this.state.offset, left = _this$state$offset.left, top = _this$state$offset.top, height = _this$state$offset.height, width = _this$state$offset.width;
					return /*#__PURE__*/ import_react.createElement("defs", null, /*#__PURE__*/ import_react.createElement("clipPath", { id: clipPathId }, /*#__PURE__*/ import_react.createElement("rect", {
						x: left,
						y: top,
						height,
						width
					})));
				}
			},
			{
				key: "getXScales",
				value: function getXScales() {
					var xAxisMap = this.state.xAxisMap;
					return xAxisMap ? Object.entries(xAxisMap).reduce(function(res, _ref13) {
						var _ref14 = _slicedToArray$2(_ref13, 2), axisId = _ref14[0], axisProps = _ref14[1];
						return _objectSpread$4(_objectSpread$4({}, res), {}, _defineProperty$4({}, axisId, axisProps.scale));
					}, {}) : null;
				}
			},
			{
				key: "getYScales",
				value: function getYScales() {
					var yAxisMap = this.state.yAxisMap;
					return yAxisMap ? Object.entries(yAxisMap).reduce(function(res, _ref15) {
						var _ref16 = _slicedToArray$2(_ref15, 2), axisId = _ref16[0], axisProps = _ref16[1];
						return _objectSpread$4(_objectSpread$4({}, res), {}, _defineProperty$4({}, axisId, axisProps.scale));
					}, {}) : null;
				}
			},
			{
				key: "getXScaleByAxisId",
				value: function getXScaleByAxisId(axisId) {
					var _this$state$xAxisMap;
					return (_this$state$xAxisMap = this.state.xAxisMap) === null || _this$state$xAxisMap === void 0 || (_this$state$xAxisMap = _this$state$xAxisMap[axisId]) === null || _this$state$xAxisMap === void 0 ? void 0 : _this$state$xAxisMap.scale;
				}
			},
			{
				key: "getYScaleByAxisId",
				value: function getYScaleByAxisId(axisId) {
					var _this$state$yAxisMap;
					return (_this$state$yAxisMap = this.state.yAxisMap) === null || _this$state$yAxisMap === void 0 || (_this$state$yAxisMap = _this$state$yAxisMap[axisId]) === null || _this$state$yAxisMap === void 0 ? void 0 : _this$state$yAxisMap.scale;
				}
			},
			{
				key: "getItemByXY",
				value: function getItemByXY(chartXY) {
					var _this$state11 = this.state, formattedGraphicalItems = _this$state11.formattedGraphicalItems, activeItem = _this$state11.activeItem;
					if (formattedGraphicalItems && formattedGraphicalItems.length) for (var i = 0, len = formattedGraphicalItems.length; i < len; i++) {
						var graphicalItem = formattedGraphicalItems[i];
						var props = graphicalItem.props, item = graphicalItem.item;
						var itemProps = item.type.defaultProps !== void 0 ? _objectSpread$4(_objectSpread$4({}, item.type.defaultProps), item.props) : item.props;
						var itemDisplayName = getDisplayName(item.type);
						if (itemDisplayName === "Bar") {
							var activeBarItem = (props.data || []).find(function(entry) {
								return isInRectangle(chartXY, entry);
							});
							if (activeBarItem) return {
								graphicalItem,
								payload: activeBarItem
							};
						} else if (itemDisplayName === "RadialBar") {
							var _activeBarItem = (props.data || []).find(function(entry) {
								return inRangeOfSector(chartXY, entry);
							});
							if (_activeBarItem) return {
								graphicalItem,
								payload: _activeBarItem
							};
						} else if (isFunnel(graphicalItem, activeItem) || isPie(graphicalItem, activeItem) || isScatter(graphicalItem, activeItem)) {
							var activeIndex = getActiveShapeIndexForTooltip({
								graphicalItem,
								activeTooltipItem: activeItem,
								itemData: itemProps.data
							});
							var childIndex = itemProps.activeIndex === void 0 ? activeIndex : itemProps.activeIndex;
							return {
								graphicalItem: _objectSpread$4(_objectSpread$4({}, graphicalItem), {}, { childIndex }),
								payload: isScatter(graphicalItem, activeItem) ? itemProps.data[activeIndex] : graphicalItem.props.data[activeIndex]
							};
						}
					}
					return null;
				}
			},
			{
				key: "render",
				value: function render() {
					var _this3 = this;
					if (!validateWidthHeight(this)) return null;
					var _this$props6 = this.props, children = _this$props6.children, className = _this$props6.className, width = _this$props6.width, height = _this$props6.height, style = _this$props6.style, compact = _this$props6.compact, title = _this$props6.title, desc = _this$props6.desc;
					var attrs = filterProps(_objectWithoutProperties$2(_this$props6, _excluded2$1), false);
					if (compact) return /*#__PURE__*/ import_react.createElement(ChartLayoutContextProvider, {
						state: this.state,
						width: this.props.width,
						height: this.props.height,
						clipPathId: this.clipPathId
					}, /*#__PURE__*/ import_react.createElement(Surface, _extends$5({}, attrs, {
						width,
						height,
						title,
						desc
					}), this.renderClipPath(), renderByOrder(children, this.renderMap)));
					if (this.props.accessibilityLayer) {
						var _this$props$tabIndex, _this$props$role;
						attrs.tabIndex = (_this$props$tabIndex = this.props.tabIndex) !== null && _this$props$tabIndex !== void 0 ? _this$props$tabIndex : 0;
						attrs.role = (_this$props$role = this.props.role) !== null && _this$props$role !== void 0 ? _this$props$role : "application";
						attrs.onKeyDown = function(e) {
							_this3.accessibilityManager.keyboardEvent(e);
						};
						attrs.onFocus = function() {
							_this3.accessibilityManager.focus();
						};
					}
					var events = this.parseEventsOfWrapper();
					return /*#__PURE__*/ import_react.createElement(ChartLayoutContextProvider, {
						state: this.state,
						width: this.props.width,
						height: this.props.height,
						clipPathId: this.clipPathId
					}, /*#__PURE__*/ import_react.createElement("div", _extends$5({
						className: clsx("recharts-wrapper", className),
						style: _objectSpread$4({
							position: "relative",
							cursor: "default",
							width,
							height
						}, style)
					}, events, { ref: function ref(node) {
						_this3.container = node;
					} }), /*#__PURE__*/ import_react.createElement(Surface, _extends$5({}, attrs, {
						width,
						height,
						title,
						desc,
						style: FULL_WIDTH_AND_HEIGHT
					}), this.renderClipPath(), renderByOrder(children, this.renderMap)), this.renderLegend(), this.renderTooltip()));
				}
			}
		]);
	}(import_react.Component);
	_defineProperty$4(CategoricalChartWrapper, "displayName", chartName);
	_defineProperty$4(CategoricalChartWrapper, "defaultProps", _objectSpread$4({
		layout: "horizontal",
		stackOffset: "none",
		barCategoryGap: "10%",
		barGap: 4,
		margin: {
			top: 5,
			right: 5,
			bottom: 5,
			left: 5
		},
		reverseStackOrder: false,
		syncMethod: "index"
	}, defaultProps));
	_defineProperty$4(CategoricalChartWrapper, "getDerivedStateFromProps", function(nextProps, prevState) {
		var dataKey = nextProps.dataKey, data = nextProps.data, children = nextProps.children, width = nextProps.width, height = nextProps.height, layout = nextProps.layout, stackOffset = nextProps.stackOffset, margin = nextProps.margin;
		var dataStartIndex = prevState.dataStartIndex, dataEndIndex = prevState.dataEndIndex;
		if (prevState.updateId === void 0) {
			var defaultState = createDefaultState(nextProps);
			return _objectSpread$4(_objectSpread$4(_objectSpread$4({}, defaultState), {}, { updateId: 0 }, updateStateOfAxisMapsOffsetAndStackGroups(_objectSpread$4(_objectSpread$4({ props: nextProps }, defaultState), {}, { updateId: 0 }), prevState)), {}, {
				prevDataKey: dataKey,
				prevData: data,
				prevWidth: width,
				prevHeight: height,
				prevLayout: layout,
				prevStackOffset: stackOffset,
				prevMargin: margin,
				prevChildren: children
			});
		}
		if (dataKey !== prevState.prevDataKey || data !== prevState.prevData || width !== prevState.prevWidth || height !== prevState.prevHeight || layout !== prevState.prevLayout || stackOffset !== prevState.prevStackOffset || !shallowEqual(margin, prevState.prevMargin)) {
			var _defaultState = createDefaultState(nextProps);
			var keepFromPrevState = {
				chartX: prevState.chartX,
				chartY: prevState.chartY,
				isTooltipActive: prevState.isTooltipActive
			};
			var updatesToState = _objectSpread$4(_objectSpread$4({}, getTooltipData(prevState, data, layout)), {}, { updateId: prevState.updateId + 1 });
			var newState = _objectSpread$4(_objectSpread$4(_objectSpread$4({}, _defaultState), keepFromPrevState), updatesToState);
			return _objectSpread$4(_objectSpread$4(_objectSpread$4({}, newState), updateStateOfAxisMapsOffsetAndStackGroups(_objectSpread$4({ props: nextProps }, newState), prevState)), {}, {
				prevDataKey: dataKey,
				prevData: data,
				prevWidth: width,
				prevHeight: height,
				prevLayout: layout,
				prevStackOffset: stackOffset,
				prevMargin: margin,
				prevChildren: children
			});
		}
		if (!isChildrenEqual(children, prevState.prevChildren)) {
			var _brush$props$startInd, _brush$props, _brush$props$endIndex, _brush$props2;
			var brush = findChildByType(children, Brush);
			var startIndex = brush ? (_brush$props$startInd = (_brush$props = brush.props) === null || _brush$props === void 0 ? void 0 : _brush$props.startIndex) !== null && _brush$props$startInd !== void 0 ? _brush$props$startInd : dataStartIndex : dataStartIndex;
			var endIndex = brush ? (_brush$props$endIndex = (_brush$props2 = brush.props) === null || _brush$props2 === void 0 ? void 0 : _brush$props2.endIndex) !== null && _brush$props$endIndex !== void 0 ? _brush$props$endIndex : dataEndIndex : dataEndIndex;
			var hasDifferentStartOrEndIndex = startIndex !== dataStartIndex || endIndex !== dataEndIndex;
			var newUpdateId = !(0, import_isNil.default)(data) && !hasDifferentStartOrEndIndex ? prevState.updateId : prevState.updateId + 1;
			return _objectSpread$4(_objectSpread$4({ updateId: newUpdateId }, updateStateOfAxisMapsOffsetAndStackGroups(_objectSpread$4(_objectSpread$4({ props: nextProps }, prevState), {}, {
				updateId: newUpdateId,
				dataStartIndex: startIndex,
				dataEndIndex: endIndex
			}), prevState)), {}, {
				prevChildren: children,
				dataStartIndex: startIndex,
				dataEndIndex: endIndex
			});
		}
		return null;
	});
	_defineProperty$4(CategoricalChartWrapper, "renderActiveDot", function(option, props, key) {
		var dot;
		if (/*#__PURE__*/ (0, import_react.isValidElement)(option)) dot = /*#__PURE__*/ (0, import_react.cloneElement)(option, props);
		else if ((0, import_isFunction.default)(option)) dot = option(props);
		else dot = /*#__PURE__*/ import_react.createElement(Dot, props);
		return /*#__PURE__*/ import_react.createElement(Layer, {
			className: "recharts-active-dot",
			key
		}, dot);
	});
	var CategoricalChart = /*#__PURE__*/ (0, import_react.forwardRef)(function CategoricalChart(props, ref) {
		return /*#__PURE__*/ import_react.createElement(CategoricalChartWrapper, _extends$5({}, props, { ref }));
	});
	CategoricalChart.displayName = CategoricalChartWrapper.displayName;
	return CategoricalChart;
};
//#endregion
//#region node_modules/recharts/es6/chart/LineChart.js
/**
* @fileOverview Line Chart
*/
var LineChart = generateCategoricalChart({
	chartName: "LineChart",
	GraphicalChild: Line,
	axisComponents: [{
		axisType: "xAxis",
		AxisComp: XAxis
	}, {
		axisType: "yAxis",
		AxisComp: YAxis
	}],
	formatAxisMap
});
//#endregion
//#region node_modules/recharts/es6/chart/BarChart.js
/**
* @fileOverview Bar Chart
*/
var BarChart = generateCategoricalChart({
	chartName: "BarChart",
	GraphicalChild: Bar,
	defaultTooltipEventType: "axis",
	validateTooltipEventTypes: ["axis", "item"],
	axisComponents: [{
		axisType: "xAxis",
		AxisComp: XAxis
	}, {
		axisType: "yAxis",
		AxisComp: YAxis
	}],
	formatAxisMap
});
//#endregion
//#region node_modules/recharts/es6/chart/PieChart.js
/**
* @fileOverview Pie Chart
*/
var PieChart = generateCategoricalChart({
	chartName: "PieChart",
	GraphicalChild: Pie,
	validateTooltipEventTypes: ["item"],
	defaultTooltipEventType: "item",
	legendContent: "children",
	axisComponents: [{
		axisType: "angleAxis",
		AxisComp: PolarAngleAxis
	}, {
		axisType: "radiusAxis",
		AxisComp: PolarRadiusAxis
	}],
	formatAxisMap: formatAxisMap$1,
	defaultProps: {
		layout: "centric",
		startAngle: 0,
		endAngle: 360,
		cx: "50%",
		cy: "50%",
		innerRadius: 0,
		outerRadius: "80%"
	}
});
//#endregion
//#region node_modules/recharts/es6/util/Constants.js
var import_omit = /* @__PURE__ */ __toESM(require_omit());
var COLOR_PANEL = [
	"#1890FF",
	"#66B5FF",
	"#41D9C7",
	"#2FC25B",
	"#6EDB8F",
	"#9AE65C",
	"#FACC14",
	"#E6965C",
	"#57AD71",
	"#223273",
	"#738AE6",
	"#7564CC",
	"#8543E0",
	"#A877ED",
	"#5C8EE6",
	"#13C2C2",
	"#70E0E0",
	"#5CA3E6",
	"#3436C7",
	"#8082FF",
	"#DD81E6",
	"#F04864",
	"#FA7D92",
	"#D598D9"
];
//#endregion
//#region node_modules/recharts/es6/chart/Treemap.js
/**
* @fileOverview TreemapChart
*/
var _excluded$1 = [
	"width",
	"height",
	"className",
	"style",
	"children",
	"type"
];
function _typeof$3(o) {
	"@babel/helpers - typeof";
	return _typeof$3 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$3(o);
}
function _extends$4() {
	_extends$4 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$4.apply(this, arguments);
}
function _objectWithoutProperties$1(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose$1(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose$1(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
function _classCallCheck$2(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$2(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$3(descriptor.key), descriptor);
	}
}
function _createClass$2(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$2(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$2(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$2(t, o, e) {
	return o = _getPrototypeOf$2(o), _possibleConstructorReturn$2(t, _isNativeReflectConstruct$2() ? Reflect.construct(o, e || [], _getPrototypeOf$2(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$2(self, call) {
	if (call && (_typeof$3(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$2(self);
}
function _assertThisInitialized$2(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$2() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$2 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$2(o) {
	_getPrototypeOf$2 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$2(o);
}
function _inherits$2(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$2(subClass, superClass);
}
function _setPrototypeOf$2(o, p) {
	_setPrototypeOf$2 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$2(o, p);
}
function ownKeys$3(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$3(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$3(Object(t), !0).forEach(function(r) {
			_defineProperty$3(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$3(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$3(obj, key, value) {
	key = _toPropertyKey$3(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$3(t) {
	var i = _toPrimitive$3(t, "string");
	return "symbol" == _typeof$3(i) ? i : i + "";
}
function _toPrimitive$3(t, r) {
	if ("object" != _typeof$3(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$3(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var NODE_VALUE_KEY = "value";
var computeNode = function computeNode(_ref) {
	var depth = _ref.depth, node = _ref.node, index = _ref.index, valueKey = _ref.valueKey;
	var children = node.children;
	var childDepth = depth + 1;
	var computedChildren = children && children.length ? children.map(function(child, i) {
		return computeNode({
			depth: childDepth,
			node: child,
			index: i,
			valueKey
		});
	}) : null;
	var nodeValue;
	if (children && children.length) nodeValue = computedChildren.reduce(function(result, child) {
		return result + child[NODE_VALUE_KEY];
	}, 0);
	else nodeValue = (0, import_isNaN.default)(node[valueKey]) || node[valueKey] <= 0 ? 0 : node[valueKey];
	return _objectSpread$3(_objectSpread$3({}, node), {}, _defineProperty$3(_defineProperty$3(_defineProperty$3({ children: computedChildren }, NODE_VALUE_KEY, nodeValue), "depth", depth), "index", index));
};
var filterRect = function filterRect(node) {
	return {
		x: node.x,
		y: node.y,
		width: node.width,
		height: node.height
	};
};
var getAreaOfChildren = function getAreaOfChildren(children, areaValueRatio) {
	var ratio = areaValueRatio < 0 ? 0 : areaValueRatio;
	return children.map(function(child) {
		var area = child[NODE_VALUE_KEY] * ratio;
		return _objectSpread$3(_objectSpread$3({}, child), {}, { area: (0, import_isNaN.default)(area) || area <= 0 ? 0 : area });
	});
};
var getWorstScore = function getWorstScore(row, parentSize, aspectRatio) {
	var parentArea = parentSize * parentSize;
	var rowArea = row.area * row.area;
	var _row$reduce = row.reduce(function(result, child) {
		return {
			min: Math.min(result.min, child.area),
			max: Math.max(result.max, child.area)
		};
	}, {
		min: Infinity,
		max: 0
	}), min = _row$reduce.min, max = _row$reduce.max;
	return rowArea ? Math.max(parentArea * max * aspectRatio / rowArea, rowArea / (parentArea * min * aspectRatio)) : Infinity;
};
var horizontalPosition = function horizontalPosition(row, parentSize, parentRect, isFlush) {
	var rowHeight = parentSize ? Math.round(row.area / parentSize) : 0;
	if (isFlush || rowHeight > parentRect.height) rowHeight = parentRect.height;
	var curX = parentRect.x;
	var child;
	for (var i = 0, len = row.length; i < len; i++) {
		child = row[i];
		child.x = curX;
		child.y = parentRect.y;
		child.height = rowHeight;
		child.width = Math.min(rowHeight ? Math.round(child.area / rowHeight) : 0, parentRect.x + parentRect.width - curX);
		curX += child.width;
	}
	child.width += parentRect.x + parentRect.width - curX;
	return _objectSpread$3(_objectSpread$3({}, parentRect), {}, {
		y: parentRect.y + rowHeight,
		height: parentRect.height - rowHeight
	});
};
var verticalPosition = function verticalPosition(row, parentSize, parentRect, isFlush) {
	var rowWidth = parentSize ? Math.round(row.area / parentSize) : 0;
	if (isFlush || rowWidth > parentRect.width) rowWidth = parentRect.width;
	var curY = parentRect.y;
	var child;
	for (var i = 0, len = row.length; i < len; i++) {
		child = row[i];
		child.x = parentRect.x;
		child.y = curY;
		child.width = rowWidth;
		child.height = Math.min(rowWidth ? Math.round(child.area / rowWidth) : 0, parentRect.y + parentRect.height - curY);
		curY += child.height;
	}
	if (child) child.height += parentRect.y + parentRect.height - curY;
	return _objectSpread$3(_objectSpread$3({}, parentRect), {}, {
		x: parentRect.x + rowWidth,
		width: parentRect.width - rowWidth
	});
};
var position = function position(row, parentSize, parentRect, isFlush) {
	if (parentSize === parentRect.width) return horizontalPosition(row, parentSize, parentRect, isFlush);
	return verticalPosition(row, parentSize, parentRect, isFlush);
};
var squarify = function squarify(node, aspectRatio) {
	var children = node.children;
	if (children && children.length) {
		var rect = filterRect(node);
		var row = [];
		var best = Infinity;
		var child, score;
		var size = Math.min(rect.width, rect.height);
		var scaleChildren = getAreaOfChildren(children, rect.width * rect.height / node[NODE_VALUE_KEY]);
		var tempChildren = scaleChildren.slice();
		row.area = 0;
		while (tempChildren.length > 0) {
			row.push(child = tempChildren[0]);
			row.area += child.area;
			score = getWorstScore(row, size, aspectRatio);
			if (score <= best) {
				tempChildren.shift();
				best = score;
			} else {
				row.area -= row.pop().area;
				rect = position(row, size, rect, false);
				size = Math.min(rect.width, rect.height);
				row.length = row.area = 0;
				best = Infinity;
			}
		}
		if (row.length) {
			rect = position(row, size, rect, true);
			row.length = row.area = 0;
		}
		return _objectSpread$3(_objectSpread$3({}, node), {}, { children: scaleChildren.map(function(c) {
			return squarify(c, aspectRatio);
		}) });
	}
	return node;
};
var defaultState = {
	isTooltipActive: false,
	isAnimationFinished: false,
	activeNode: null,
	formatRoot: null,
	currentRoot: null,
	nestIndex: []
};
var Treemap = /*#__PURE__*/ function(_PureComponent) {
	function Treemap() {
		var _this;
		_classCallCheck$2(this, Treemap);
		for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
		_this = _callSuper$2(this, Treemap, [].concat(args));
		_defineProperty$3(_this, "state", _objectSpread$3({}, defaultState));
		_defineProperty$3(_this, "handleAnimationEnd", function() {
			var onAnimationEnd = _this.props.onAnimationEnd;
			_this.setState({ isAnimationFinished: true });
			if ((0, import_isFunction.default)(onAnimationEnd)) onAnimationEnd();
		});
		_defineProperty$3(_this, "handleAnimationStart", function() {
			var onAnimationStart = _this.props.onAnimationStart;
			_this.setState({ isAnimationFinished: false });
			if ((0, import_isFunction.default)(onAnimationStart)) onAnimationStart();
		});
		return _this;
	}
	_inherits$2(Treemap, _PureComponent);
	return _createClass$2(Treemap, [
		{
			key: "handleMouseEnter",
			value: function handleMouseEnter(node, e) {
				e.persist();
				var _this$props = this.props, onMouseEnter = _this$props.onMouseEnter, children = _this$props.children;
				if (findChildByType(children, Tooltip)) this.setState({
					isTooltipActive: true,
					activeNode: node
				}, function() {
					if (onMouseEnter) onMouseEnter(node, e);
				});
				else if (onMouseEnter) onMouseEnter(node, e);
			}
		},
		{
			key: "handleMouseLeave",
			value: function handleMouseLeave(node, e) {
				e.persist();
				var _this$props2 = this.props, onMouseLeave = _this$props2.onMouseLeave, children = _this$props2.children;
				if (findChildByType(children, Tooltip)) this.setState({
					isTooltipActive: false,
					activeNode: null
				}, function() {
					if (onMouseLeave) onMouseLeave(node, e);
				});
				else if (onMouseLeave) onMouseLeave(node, e);
			}
		},
		{
			key: "handleClick",
			value: function handleClick(node) {
				var _this$props3 = this.props, onClick = _this$props3.onClick;
				if (_this$props3.type === "nest" && node.children) {
					var _this$props4 = this.props, width = _this$props4.width, height = _this$props4.height, dataKey = _this$props4.dataKey, aspectRatio = _this$props4.aspectRatio;
					var root = computeNode({
						depth: 0,
						node: _objectSpread$3(_objectSpread$3({}, node), {}, {
							x: 0,
							y: 0,
							width,
							height
						}),
						index: 0,
						valueKey: dataKey
					});
					var formatRoot = squarify(root, aspectRatio);
					var nestIndex = this.state.nestIndex;
					nestIndex.push(node);
					this.setState({
						formatRoot,
						currentRoot: root,
						nestIndex
					});
				}
				if (onClick) onClick(node);
			}
		},
		{
			key: "handleNestIndex",
			value: function handleNestIndex(node, i) {
				var nestIndex = this.state.nestIndex;
				var _this$props5 = this.props, width = _this$props5.width, height = _this$props5.height, dataKey = _this$props5.dataKey, aspectRatio = _this$props5.aspectRatio;
				var formatRoot = squarify(computeNode({
					depth: 0,
					node: _objectSpread$3(_objectSpread$3({}, node), {}, {
						x: 0,
						y: 0,
						width,
						height
					}),
					index: 0,
					valueKey: dataKey
				}), aspectRatio);
				nestIndex = nestIndex.slice(0, i + 1);
				this.setState({
					formatRoot,
					currentRoot: node,
					nestIndex
				});
			}
		},
		{
			key: "renderItem",
			value: function renderItem(content, nodeProps, isLeaf) {
				var _this2 = this;
				var _this$props6 = this.props, isAnimationActive = _this$props6.isAnimationActive, animationBegin = _this$props6.animationBegin, animationDuration = _this$props6.animationDuration, animationEasing = _this$props6.animationEasing, isUpdateAnimationActive = _this$props6.isUpdateAnimationActive, type = _this$props6.type, animationId = _this$props6.animationId, colorPanel = _this$props6.colorPanel;
				var isAnimationFinished = this.state.isAnimationFinished;
				var width = nodeProps.width, height = nodeProps.height, x = nodeProps.x, y = nodeProps.y, depth = nodeProps.depth;
				var translateX = parseInt("".concat((Math.random() * 2 - 1) * width), 10);
				var event = {};
				if (isLeaf || type === "nest") event = {
					onMouseEnter: this.handleMouseEnter.bind(this, nodeProps),
					onMouseLeave: this.handleMouseLeave.bind(this, nodeProps),
					onClick: this.handleClick.bind(this, nodeProps)
				};
				if (!isAnimationActive) return /*#__PURE__*/ import_react.createElement(Layer, event, this.constructor.renderContentItem(content, _objectSpread$3(_objectSpread$3({}, nodeProps), {}, {
					isAnimationActive: false,
					isUpdateAnimationActive: false,
					width,
					height,
					x,
					y
				}), type, colorPanel));
				return /*#__PURE__*/ import_react.createElement(es6_default, {
					begin: animationBegin,
					duration: animationDuration,
					isActive: isAnimationActive,
					easing: animationEasing,
					key: "treemap-".concat(animationId),
					from: {
						x,
						y,
						width,
						height
					},
					to: {
						x,
						y,
						width,
						height
					},
					onAnimationStart: this.handleAnimationStart,
					onAnimationEnd: this.handleAnimationEnd
				}, function(_ref2) {
					var currX = _ref2.x, currY = _ref2.y, currWidth = _ref2.width, currHeight = _ref2.height;
					return /*#__PURE__*/ import_react.createElement(es6_default, {
						from: "translate(".concat(translateX, "px, ").concat(translateX, "px)"),
						to: "translate(0, 0)",
						attributeName: "transform",
						begin: animationBegin,
						easing: animationEasing,
						isActive: isAnimationActive,
						duration: animationDuration
					}, /*#__PURE__*/ import_react.createElement(Layer, event, function() {
						if (depth > 2 && !isAnimationFinished) return null;
						return _this2.constructor.renderContentItem(content, _objectSpread$3(_objectSpread$3({}, nodeProps), {}, {
							isAnimationActive,
							isUpdateAnimationActive: !isUpdateAnimationActive,
							width: currWidth,
							height: currHeight,
							x: currX,
							y: currY
						}), type, colorPanel);
					}()));
				});
			}
		},
		{
			key: "renderNode",
			value: function renderNode(root, node) {
				var _this3 = this;
				var _this$props7 = this.props, content = _this$props7.content, type = _this$props7.type;
				var nodeProps = _objectSpread$3(_objectSpread$3(_objectSpread$3({}, filterProps(this.props, false)), node), {}, { root });
				var isLeaf = !node.children || !node.children.length;
				if (!(this.state.currentRoot.children || []).filter(function(item) {
					return item.depth === node.depth && item.name === node.name;
				}).length && root.depth && type === "nest") return null;
				return /*#__PURE__*/ import_react.createElement(Layer, {
					key: "recharts-treemap-node-".concat(nodeProps.x, "-").concat(nodeProps.y, "-").concat(nodeProps.name),
					className: "recharts-treemap-depth-".concat(node.depth)
				}, this.renderItem(content, nodeProps, isLeaf), node.children && node.children.length ? node.children.map(function(child) {
					return _this3.renderNode(node, child);
				}) : null);
			}
		},
		{
			key: "renderAllNodes",
			value: function renderAllNodes() {
				var formatRoot = this.state.formatRoot;
				if (!formatRoot) return null;
				return this.renderNode(formatRoot, formatRoot);
			}
		},
		{
			key: "renderTooltip",
			value: function renderTooltip() {
				var _this$props8 = this.props, children = _this$props8.children, nameKey = _this$props8.nameKey;
				var tooltipItem = findChildByType(children, Tooltip);
				if (!tooltipItem) return null;
				var _this$props9 = this.props, width = _this$props9.width, height = _this$props9.height;
				var _this$state = this.state, isTooltipActive = _this$state.isTooltipActive, activeNode = _this$state.activeNode;
				var viewBox = {
					x: 0,
					y: 0,
					width,
					height
				};
				var coordinate = activeNode ? {
					x: activeNode.x + activeNode.width / 2,
					y: activeNode.y + activeNode.height / 2
				} : null;
				var payload = isTooltipActive && activeNode ? [{
					payload: activeNode,
					name: getValueByDataKey(activeNode, nameKey, ""),
					value: getValueByDataKey(activeNode, NODE_VALUE_KEY)
				}] : [];
				return /*#__PURE__*/ import_react.cloneElement(tooltipItem, {
					viewBox,
					active: isTooltipActive,
					coordinate,
					label: "",
					payload
				});
			}
		},
		{
			key: "renderNestIndex",
			value: function renderNestIndex() {
				var _this4 = this;
				var _this$props10 = this.props, nameKey = _this$props10.nameKey, nestIndexContent = _this$props10.nestIndexContent;
				var nestIndex = this.state.nestIndex;
				return /*#__PURE__*/ import_react.createElement("div", {
					className: "recharts-treemap-nest-index-wrapper",
					style: {
						marginTop: "8px",
						textAlign: "center"
					}
				}, nestIndex.map(function(item, i) {
					var name = (0, import_get.default)(item, nameKey, "root");
					var content = null;
					if (/*#__PURE__*/ import_react.isValidElement(nestIndexContent)) content = /*#__PURE__*/ import_react.cloneElement(nestIndexContent, item, i);
					if ((0, import_isFunction.default)(nestIndexContent)) content = nestIndexContent(item, i);
					else content = name;
					return /*#__PURE__*/ import_react.createElement("div", {
						onClick: _this4.handleNestIndex.bind(_this4, item, i),
						key: "nest-index-".concat(uniqueId()),
						className: "recharts-treemap-nest-index-box",
						style: {
							cursor: "pointer",
							display: "inline-block",
							padding: "0 7px",
							background: "#000",
							color: "#fff",
							marginRight: "3px"
						}
					}, content);
				}));
			}
		},
		{
			key: "render",
			value: function render() {
				if (!validateWidthHeight(this)) return null;
				var _this$props11 = this.props, width = _this$props11.width, height = _this$props11.height, className = _this$props11.className, style = _this$props11.style, children = _this$props11.children, type = _this$props11.type;
				var attrs = filterProps(_objectWithoutProperties$1(_this$props11, _excluded$1), false);
				return /*#__PURE__*/ import_react.createElement("div", {
					className: clsx("recharts-wrapper", className),
					style: _objectSpread$3(_objectSpread$3({}, style), {}, {
						position: "relative",
						cursor: "default",
						width,
						height
					}),
					role: "region"
				}, /*#__PURE__*/ import_react.createElement(Surface, _extends$4({}, attrs, {
					width,
					height: type === "nest" ? height - 30 : height
				}), this.renderAllNodes(), filterSvgElements(children)), this.renderTooltip(), type === "nest" && this.renderNestIndex());
			}
		}
	], [{
		key: "getDerivedStateFromProps",
		value: function getDerivedStateFromProps(nextProps, prevState) {
			if (nextProps.data !== prevState.prevData || nextProps.type !== prevState.prevType || nextProps.width !== prevState.prevWidth || nextProps.height !== prevState.prevHeight || nextProps.dataKey !== prevState.prevDataKey || nextProps.aspectRatio !== prevState.prevAspectRatio) {
				var root = computeNode({
					depth: 0,
					node: {
						children: nextProps.data,
						x: 0,
						y: 0,
						width: nextProps.width,
						height: nextProps.height
					},
					index: 0,
					valueKey: nextProps.dataKey
				});
				var formatRoot = squarify(root, nextProps.aspectRatio);
				return _objectSpread$3(_objectSpread$3({}, prevState), {}, {
					formatRoot,
					currentRoot: root,
					nestIndex: [root],
					prevAspectRatio: nextProps.aspectRatio,
					prevData: nextProps.data,
					prevWidth: nextProps.width,
					prevHeight: nextProps.height,
					prevDataKey: nextProps.dataKey,
					prevType: nextProps.type
				});
			}
			return null;
		}
	}, {
		key: "renderContentItem",
		value: function renderContentItem(content, nodeProps, type, colorPanel) {
			if (/*#__PURE__*/ import_react.isValidElement(content)) return /*#__PURE__*/ import_react.cloneElement(content, nodeProps);
			if ((0, import_isFunction.default)(content)) return content(nodeProps);
			var x = nodeProps.x, y = nodeProps.y, width = nodeProps.width, height = nodeProps.height, index = nodeProps.index;
			var arrow = null;
			if (width > 10 && height > 10 && nodeProps.children && type === "nest") arrow = /*#__PURE__*/ import_react.createElement(Polygon, { points: [
				{
					x: x + 2,
					y: y + height / 2
				},
				{
					x: x + 6,
					y: y + height / 2 + 3
				},
				{
					x: x + 2,
					y: y + height / 2 + 6
				}
			] });
			var text = null;
			var nameSize = getStringSize(nodeProps.name);
			if (width > 20 && height > 20 && nameSize.width < width && nameSize.height < height) text = /*#__PURE__*/ import_react.createElement("text", {
				x: x + 8,
				y: y + height / 2 + 7,
				fontSize: 14
			}, nodeProps.name);
			var colors = colorPanel || COLOR_PANEL;
			return /*#__PURE__*/ import_react.createElement("g", null, /*#__PURE__*/ import_react.createElement(Rectangle, _extends$4({
				fill: nodeProps.depth < 2 ? colors[index % colors.length] : "rgba(255,255,255,0)",
				stroke: "#fff"
			}, (0, import_omit.default)(nodeProps, "children"), { role: "img" })), arrow, text);
		}
	}]);
}(import_react.PureComponent);
_defineProperty$3(Treemap, "displayName", "Treemap");
_defineProperty$3(Treemap, "defaultProps", {
	aspectRatio: .5 * (1 + Math.sqrt(5)),
	dataKey: "value",
	type: "flat",
	isAnimationActive: !Global.isSsr,
	isUpdateAnimationActive: !Global.isSsr,
	animationBegin: 0,
	animationDuration: 1500,
	animationEasing: "linear"
});
//#endregion
//#region node_modules/recharts/es6/chart/Sankey.js
/**
* @file TreemapChart
*/
var import_sumBy = /* @__PURE__ */ __toESM(require_sumBy());
var _excluded = [
	"width",
	"height",
	"className",
	"style",
	"children"
];
var _excluded2 = [
	"sourceX",
	"sourceY",
	"sourceControlX",
	"targetX",
	"targetY",
	"targetControlX",
	"linkWidth"
];
function _typeof$2(o) {
	"@babel/helpers - typeof";
	return _typeof$2 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$2(o);
}
function _objectWithoutProperties(source, excluded) {
	if (source == null) return {};
	var target = _objectWithoutPropertiesLoose(source, excluded);
	var key, i;
	if (Object.getOwnPropertySymbols) {
		var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
		for (i = 0; i < sourceSymbolKeys.length; i++) {
			key = sourceSymbolKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
			target[key] = source[key];
		}
	}
	return target;
}
function _objectWithoutPropertiesLoose(source, excluded) {
	if (source == null) return {};
	var target = {};
	for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
		if (excluded.indexOf(key) >= 0) continue;
		target[key] = source[key];
	}
	return target;
}
function _extends$3() {
	_extends$3 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$3.apply(this, arguments);
}
function _classCallCheck$1(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties$1(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey$2(descriptor.key), descriptor);
	}
}
function _createClass$1(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties$1(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties$1(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper$1(t, o, e) {
	return o = _getPrototypeOf$1(o), _possibleConstructorReturn$1(t, _isNativeReflectConstruct$1() ? Reflect.construct(o, e || [], _getPrototypeOf$1(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn$1(self, call) {
	if (call && (_typeof$2(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized$1(self);
}
function _assertThisInitialized$1(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct$1() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct$1 = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf$1(o) {
	_getPrototypeOf$1 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf$1(o);
}
function _inherits$1(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf$1(subClass, superClass);
}
function _setPrototypeOf$1(o, p) {
	_setPrototypeOf$1 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf$1(o, p);
}
function ownKeys$2(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$2(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$2(Object(t), !0).forEach(function(r) {
			_defineProperty$2(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$2(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$2(obj, key, value) {
	key = _toPropertyKey$2(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$2(t) {
	var i = _toPrimitive$2(t, "string");
	return "symbol" == _typeof$2(i) ? i : i + "";
}
function _toPrimitive$2(t, r) {
	if ("object" != _typeof$2(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$2(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var defaultCoordinateOfTooltip = {
	x: 0,
	y: 0
};
var interpolationGenerator = function interpolationGenerator(a, b) {
	var ka = +a;
	var kb = b - ka;
	return function(t) {
		return ka + kb * t;
	};
};
var centerY = function centerY(node) {
	return node.y + node.dy / 2;
};
var getValue = function getValue(entry) {
	return entry && entry.value || 0;
};
var getSumOfIds = function getSumOfIds(links, ids) {
	return ids.reduce(function(result, id) {
		return result + getValue(links[id]);
	}, 0);
};
var getSumWithWeightedSource = function getSumWithWeightedSource(tree, links, ids) {
	return ids.reduce(function(result, id) {
		var sourceNode = tree[links[id].source];
		return result + centerY(sourceNode) * getValue(links[id]);
	}, 0);
};
var getSumWithWeightedTarget = function getSumWithWeightedTarget(tree, links, ids) {
	return ids.reduce(function(result, id) {
		var targetNode = tree[links[id].target];
		return result + centerY(targetNode) * getValue(links[id]);
	}, 0);
};
var ascendingY = function ascendingY(a, b) {
	return a.y - b.y;
};
var searchTargetsAndSources = function searchTargetsAndSources(links, id) {
	var sourceNodes = [];
	var sourceLinks = [];
	var targetNodes = [];
	var targetLinks = [];
	for (var i = 0, len = links.length; i < len; i++) {
		var link = links[i];
		if (link.source === id) {
			targetNodes.push(link.target);
			targetLinks.push(i);
		}
		if (link.target === id) {
			sourceNodes.push(link.source);
			sourceLinks.push(i);
		}
	}
	return {
		sourceNodes,
		sourceLinks,
		targetLinks,
		targetNodes
	};
};
var updateDepthOfTargets = function updateDepthOfTargets(tree, curNode) {
	var targetNodes = curNode.targetNodes;
	for (var i = 0, len = targetNodes.length; i < len; i++) {
		var target = tree[targetNodes[i]];
		if (target) {
			target.depth = Math.max(curNode.depth + 1, target.depth);
			updateDepthOfTargets(tree, target);
		}
	}
};
var getNodesTree = function getNodesTree(_ref, width, nodeWidth) {
	var nodes = _ref.nodes, links = _ref.links;
	var tree = nodes.map(function(entry, index) {
		var result = searchTargetsAndSources(links, index);
		return _objectSpread$2(_objectSpread$2(_objectSpread$2({}, entry), result), {}, {
			value: Math.max(getSumOfIds(links, result.sourceLinks), getSumOfIds(links, result.targetLinks)),
			depth: 0
		});
	});
	for (var i = 0, len = tree.length; i < len; i++) {
		var node = tree[i];
		if (!node.sourceNodes.length) updateDepthOfTargets(tree, node);
	}
	var maxDepth = (0, import_maxBy.default)(tree, function(entry) {
		return entry.depth;
	}).depth;
	if (maxDepth >= 1) {
		var childWidth = (width - nodeWidth) / maxDepth;
		for (var _i = 0, _len = tree.length; _i < _len; _i++) {
			var _node = tree[_i];
			if (!_node.targetNodes.length) _node.depth = maxDepth;
			_node.x = _node.depth * childWidth;
			_node.dx = nodeWidth;
		}
	}
	return {
		tree,
		maxDepth
	};
};
var getDepthTree = function getDepthTree(tree) {
	var result = [];
	for (var i = 0, len = tree.length; i < len; i++) {
		var node = tree[i];
		if (!result[node.depth]) result[node.depth] = [];
		result[node.depth].push(node);
	}
	return result;
};
var updateYOfTree = function updateYOfTree(depthTree, height, nodePadding, links) {
	var yRatio = (0, import_min.default)(depthTree.map(function(nodes) {
		return (height - (nodes.length - 1) * nodePadding) / (0, import_sumBy.default)(nodes, getValue);
	}));
	for (var d = 0, maxDepth = depthTree.length; d < maxDepth; d++) for (var i = 0, len = depthTree[d].length; i < len; i++) {
		var node = depthTree[d][i];
		node.y = i;
		node.dy = node.value * yRatio;
	}
	return links.map(function(link) {
		return _objectSpread$2(_objectSpread$2({}, link), {}, { dy: getValue(link) * yRatio });
	});
};
var resolveCollisions = function resolveCollisions(depthTree, height, nodePadding) {
	var sort = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : true;
	for (var i = 0, len = depthTree.length; i < len; i++) {
		var nodes = depthTree[i];
		var n = nodes.length;
		if (sort) nodes.sort(ascendingY);
		var y0 = 0;
		for (var j = 0; j < n; j++) {
			var node = nodes[j];
			var dy = y0 - node.y;
			if (dy > 0) node.y += dy;
			y0 = node.y + node.dy + nodePadding;
		}
		y0 = height + nodePadding;
		for (var _j = n - 1; _j >= 0; _j--) {
			var _node2 = nodes[_j];
			var _dy = _node2.y + _node2.dy + nodePadding - y0;
			if (_dy > 0) {
				_node2.y -= _dy;
				y0 = _node2.y;
			} else break;
		}
	}
};
var relaxLeftToRight = function relaxLeftToRight(tree, depthTree, links, alpha) {
	for (var i = 0, maxDepth = depthTree.length; i < maxDepth; i++) {
		var nodes = depthTree[i];
		for (var j = 0, len = nodes.length; j < len; j++) {
			var node = nodes[j];
			if (node.sourceLinks.length) {
				var sourceSum = getSumOfIds(links, node.sourceLinks);
				var y = getSumWithWeightedSource(tree, links, node.sourceLinks) / sourceSum;
				node.y += (y - centerY(node)) * alpha;
			}
		}
	}
};
var relaxRightToLeft = function relaxRightToLeft(tree, depthTree, links, alpha) {
	for (var i = depthTree.length - 1; i >= 0; i--) {
		var nodes = depthTree[i];
		for (var j = 0, len = nodes.length; j < len; j++) {
			var node = nodes[j];
			if (node.targetLinks.length) {
				var targetSum = getSumOfIds(links, node.targetLinks);
				var y = getSumWithWeightedTarget(tree, links, node.targetLinks) / targetSum;
				node.y += (y - centerY(node)) * alpha;
			}
		}
	}
};
var updateYOfLinks = function updateYOfLinks(tree, links) {
	for (var i = 0, len = tree.length; i < len; i++) {
		var node = tree[i];
		var sy = 0;
		var ty = 0;
		node.targetLinks.sort(function(a, b) {
			return tree[links[a].target].y - tree[links[b].target].y;
		});
		node.sourceLinks.sort(function(a, b) {
			return tree[links[a].source].y - tree[links[b].source].y;
		});
		for (var j = 0, tLen = node.targetLinks.length; j < tLen; j++) {
			var link = links[node.targetLinks[j]];
			if (link) {
				link.sy = sy;
				sy += link.dy;
			}
		}
		for (var _j2 = 0, sLen = node.sourceLinks.length; _j2 < sLen; _j2++) {
			var _link = links[node.sourceLinks[_j2]];
			if (_link) {
				_link.ty = ty;
				ty += _link.dy;
			}
		}
	}
};
var computeData = function computeData(_ref2) {
	var data = _ref2.data, width = _ref2.width, height = _ref2.height, iterations = _ref2.iterations, nodeWidth = _ref2.nodeWidth, nodePadding = _ref2.nodePadding, sort = _ref2.sort;
	var links = data.links;
	var tree = getNodesTree(data, width, nodeWidth).tree;
	var depthTree = getDepthTree(tree);
	var newLinks = updateYOfTree(depthTree, height, nodePadding, links);
	resolveCollisions(depthTree, height, nodePadding, sort);
	var alpha = 1;
	for (var i = 1; i <= iterations; i++) {
		relaxRightToLeft(tree, depthTree, newLinks, alpha *= .99);
		resolveCollisions(depthTree, height, nodePadding, sort);
		relaxLeftToRight(tree, depthTree, newLinks, alpha);
		resolveCollisions(depthTree, height, nodePadding, sort);
	}
	updateYOfLinks(tree, newLinks);
	return {
		nodes: tree,
		links: newLinks
	};
};
var getCoordinateOfTooltip = function getCoordinateOfTooltip(el, type) {
	if (type === "node") return {
		x: el.x + el.width / 2,
		y: el.y + el.height / 2
	};
	return {
		x: (el.sourceX + el.targetX) / 2,
		y: (el.sourceY + el.targetY) / 2
	};
};
var getPayloadOfTooltip = function getPayloadOfTooltip(el, type, nameKey) {
	var payload = el.payload;
	if (type === "node") return [{
		payload: el,
		name: getValueByDataKey(payload, nameKey, ""),
		value: getValueByDataKey(payload, "value")
	}];
	if (payload.source && payload.target) {
		var sourceName = getValueByDataKey(payload.source, nameKey, "");
		var targetName = getValueByDataKey(payload.target, nameKey, "");
		return [{
			payload: el,
			name: "".concat(sourceName, " - ").concat(targetName),
			value: getValueByDataKey(payload, "value")
		}];
	}
	return [];
};
var Sankey = /*#__PURE__*/ function(_PureComponent) {
	function Sankey() {
		var _this;
		_classCallCheck$1(this, Sankey);
		for (var _len2 = arguments.length, args = new Array(_len2), _key = 0; _key < _len2; _key++) args[_key] = arguments[_key];
		_this = _callSuper$1(this, Sankey, [].concat(args));
		_defineProperty$2(_this, "state", {
			activeElement: null,
			activeElementType: null,
			isTooltipActive: false,
			nodes: [],
			links: []
		});
		return _this;
	}
	_inherits$1(Sankey, _PureComponent);
	return _createClass$1(Sankey, [
		{
			key: "handleMouseEnter",
			value: function handleMouseEnter(el, type, e) {
				var _this$props = this.props, onMouseEnter = _this$props.onMouseEnter, children = _this$props.children;
				var tooltipItem = findChildByType(children, Tooltip);
				if (tooltipItem) this.setState(function(prev) {
					if (tooltipItem.props.trigger === "hover") return _objectSpread$2(_objectSpread$2({}, prev), {}, {
						activeElement: el,
						activeElementType: type,
						isTooltipActive: true
					});
					return prev;
				}, function() {
					if (onMouseEnter) onMouseEnter(el, type, e);
				});
				else if (onMouseEnter) onMouseEnter(el, type, e);
			}
		},
		{
			key: "handleMouseLeave",
			value: function handleMouseLeave(el, type, e) {
				var _this$props2 = this.props, onMouseLeave = _this$props2.onMouseLeave, children = _this$props2.children;
				var tooltipItem = findChildByType(children, Tooltip);
				if (tooltipItem) this.setState(function(prev) {
					if (tooltipItem.props.trigger === "hover") return _objectSpread$2(_objectSpread$2({}, prev), {}, {
						activeElement: void 0,
						activeElementType: void 0,
						isTooltipActive: false
					});
					return prev;
				}, function() {
					if (onMouseLeave) onMouseLeave(el, type, e);
				});
				else if (onMouseLeave) onMouseLeave(el, type, e);
			}
		},
		{
			key: "handleClick",
			value: function handleClick(el, type, e) {
				var _this$props3 = this.props, onClick = _this$props3.onClick, children = _this$props3.children;
				var tooltipItem = findChildByType(children, Tooltip);
				if (tooltipItem && tooltipItem.props.trigger === "click") {
					if (this.state.isTooltipActive) this.setState(function(prev) {
						return _objectSpread$2(_objectSpread$2({}, prev), {}, {
							activeElement: void 0,
							activeElementType: void 0,
							isTooltipActive: false
						});
					});
					else this.setState(function(prev) {
						return _objectSpread$2(_objectSpread$2({}, prev), {}, {
							activeElement: el,
							activeElementType: type,
							isTooltipActive: true
						});
					});
				}
				if (onClick) onClick(el, type, e);
			}
		},
		{
			key: "renderLinks",
			value: function renderLinks(links, nodes) {
				var _this2 = this;
				var _this$props4 = this.props, linkCurvature = _this$props4.linkCurvature, linkContent = _this$props4.link, margin = _this$props4.margin;
				var top = (0, import_get.default)(margin, "top") || 0;
				var left = (0, import_get.default)(margin, "left") || 0;
				return /*#__PURE__*/ import_react.createElement(Layer, {
					className: "recharts-sankey-links",
					key: "recharts-sankey-links"
				}, links.map(function(link, i) {
					var sourceRelativeY = link.sy, targetRelativeY = link.ty, linkWidth = link.dy;
					var source = nodes[link.source];
					var target = nodes[link.target];
					var sourceX = source.x + source.dx + left;
					var targetX = target.x + left;
					var interpolationFunc = interpolationGenerator(sourceX, targetX);
					var sourceControlX = interpolationFunc(linkCurvature);
					var targetControlX = interpolationFunc(1 - linkCurvature);
					var linkProps = _objectSpread$2({
						sourceX,
						targetX,
						sourceY: source.y + sourceRelativeY + linkWidth / 2 + top,
						targetY: target.y + targetRelativeY + linkWidth / 2 + top,
						sourceControlX,
						targetControlX,
						sourceRelativeY,
						targetRelativeY,
						linkWidth,
						index: i,
						payload: _objectSpread$2(_objectSpread$2({}, link), {}, {
							source,
							target
						})
					}, filterProps(linkContent, false));
					var events = {
						onMouseEnter: _this2.handleMouseEnter.bind(_this2, linkProps, "link"),
						onMouseLeave: _this2.handleMouseLeave.bind(_this2, linkProps, "link"),
						onClick: _this2.handleClick.bind(_this2, linkProps, "link")
					};
					return /*#__PURE__*/ import_react.createElement(Layer, _extends$3({ key: "link-".concat(link.source, "-").concat(link.target, "-").concat(link.value) }, events), _this2.constructor.renderLinkItem(linkContent, linkProps));
				}));
			}
		},
		{
			key: "renderNodes",
			value: function renderNodes(nodes) {
				var _this3 = this;
				var _this$props5 = this.props, nodeContent = _this$props5.node, margin = _this$props5.margin;
				var top = (0, import_get.default)(margin, "top") || 0;
				var left = (0, import_get.default)(margin, "left") || 0;
				return /*#__PURE__*/ import_react.createElement(Layer, {
					className: "recharts-sankey-nodes",
					key: "recharts-sankey-nodes"
				}, nodes.map(function(node, i) {
					var x = node.x, y = node.y, dx = node.dx, dy = node.dy;
					var nodeProps = _objectSpread$2(_objectSpread$2({}, filterProps(nodeContent, false)), {}, {
						x: x + left,
						y: y + top,
						width: dx,
						height: dy,
						index: i,
						payload: node
					});
					var events = {
						onMouseEnter: _this3.handleMouseEnter.bind(_this3, nodeProps, "node"),
						onMouseLeave: _this3.handleMouseLeave.bind(_this3, nodeProps, "node"),
						onClick: _this3.handleClick.bind(_this3, nodeProps, "node")
					};
					return /*#__PURE__*/ import_react.createElement(Layer, _extends$3({ key: "node-".concat(node.x, "-").concat(node.y, "-").concat(node.value) }, events), _this3.constructor.renderNodeItem(nodeContent, nodeProps));
				}));
			}
		},
		{
			key: "renderTooltip",
			value: function renderTooltip() {
				var _this$props6 = this.props, children = _this$props6.children, width = _this$props6.width, height = _this$props6.height, nameKey = _this$props6.nameKey;
				var tooltipItem = findChildByType(children, Tooltip);
				if (!tooltipItem) return null;
				var _this$state = this.state, isTooltipActive = _this$state.isTooltipActive, activeElement = _this$state.activeElement, activeElementType = _this$state.activeElementType;
				var viewBox = {
					x: 0,
					y: 0,
					width,
					height
				};
				var coordinate = activeElement ? getCoordinateOfTooltip(activeElement, activeElementType) : defaultCoordinateOfTooltip;
				var payload = activeElement ? getPayloadOfTooltip(activeElement, activeElementType, nameKey) : [];
				return /*#__PURE__*/ import_react.cloneElement(tooltipItem, {
					viewBox,
					active: isTooltipActive,
					coordinate,
					label: "",
					payload
				});
			}
		},
		{
			key: "render",
			value: function render() {
				if (!validateWidthHeight(this)) return null;
				var _this$props7 = this.props, width = _this$props7.width, height = _this$props7.height, className = _this$props7.className, style = _this$props7.style, children = _this$props7.children, others = _objectWithoutProperties(_this$props7, _excluded);
				var _this$state2 = this.state, links = _this$state2.links, nodes = _this$state2.nodes;
				var attrs = filterProps(others, false);
				return /*#__PURE__*/ import_react.createElement("div", {
					className: clsx("recharts-wrapper", className),
					style: _objectSpread$2(_objectSpread$2({}, style), {}, {
						position: "relative",
						cursor: "default",
						width,
						height
					}),
					role: "region"
				}, /*#__PURE__*/ import_react.createElement(Surface, _extends$3({}, attrs, {
					width,
					height
				}), filterSvgElements(children), this.renderLinks(links, nodes), this.renderNodes(nodes)), this.renderTooltip());
			}
		}
	], [
		{
			key: "getDerivedStateFromProps",
			value: function getDerivedStateFromProps(nextProps, prevState) {
				var data = nextProps.data, width = nextProps.width, height = nextProps.height, margin = nextProps.margin, iterations = nextProps.iterations, nodeWidth = nextProps.nodeWidth, nodePadding = nextProps.nodePadding, sort = nextProps.sort;
				if (data !== prevState.prevData || width !== prevState.prevWidth || height !== prevState.prevHeight || !shallowEqual(margin, prevState.prevMargin) || iterations !== prevState.prevIterations || nodeWidth !== prevState.prevNodeWidth || nodePadding !== prevState.prevNodePadding || sort !== prevState.sort) {
					var _computeData = computeData({
						data,
						width: width - (margin && margin.left || 0) - (margin && margin.right || 0),
						height: height - (margin && margin.top || 0) - (margin && margin.bottom || 0),
						iterations,
						nodeWidth,
						nodePadding,
						sort
					}), links = _computeData.links, nodes = _computeData.nodes;
					return _objectSpread$2(_objectSpread$2({}, prevState), {}, {
						nodes,
						links,
						prevData: data,
						prevWidth: iterations,
						prevHeight: height,
						prevMargin: margin,
						prevNodePadding: nodePadding,
						prevNodeWidth: nodeWidth,
						prevIterations: iterations,
						prevSort: sort
					});
				}
				return null;
			}
		},
		{
			key: "renderLinkItem",
			value: function renderLinkItem(option, props) {
				if (/*#__PURE__*/ import_react.isValidElement(option)) return /*#__PURE__*/ import_react.cloneElement(option, props);
				if ((0, import_isFunction.default)(option)) return option(props);
				var sourceX = props.sourceX, sourceY = props.sourceY, sourceControlX = props.sourceControlX, targetX = props.targetX, targetY = props.targetY, targetControlX = props.targetControlX, linkWidth = props.linkWidth, others = _objectWithoutProperties(props, _excluded2);
				return /*#__PURE__*/ import_react.createElement("path", _extends$3({
					className: "recharts-sankey-link",
					d: "\n          M".concat(sourceX, ",").concat(sourceY, "\n          C").concat(sourceControlX, ",").concat(sourceY, " ").concat(targetControlX, ",").concat(targetY, " ").concat(targetX, ",").concat(targetY, "\n        "),
					fill: "none",
					stroke: "#333",
					strokeWidth: linkWidth,
					strokeOpacity: "0.2"
				}, filterProps(others, false)));
			}
		},
		{
			key: "renderNodeItem",
			value: function renderNodeItem(option, props) {
				if (/*#__PURE__*/ import_react.isValidElement(option)) return /*#__PURE__*/ import_react.cloneElement(option, props);
				if ((0, import_isFunction.default)(option)) return option(props);
				return /*#__PURE__*/ import_react.createElement(Rectangle, _extends$3({
					className: "recharts-sankey-node",
					fill: "#0088fe",
					fillOpacity: "0.8"
				}, filterProps(props, false), { role: "img" }));
			}
		}
	]);
}(import_react.PureComponent);
_defineProperty$2(Sankey, "displayName", "Sankey");
_defineProperty$2(Sankey, "defaultProps", {
	nameKey: "name",
	dataKey: "value",
	nodePadding: 10,
	nodeWidth: 10,
	linkCurvature: .5,
	iterations: 32,
	margin: {
		top: 5,
		right: 5,
		bottom: 5,
		left: 5
	},
	sort: true
});
//#endregion
//#region node_modules/recharts/es6/chart/RadarChart.js
/**
* @fileOverview Radar Chart
*/
var RadarChart = generateCategoricalChart({
	chartName: "RadarChart",
	GraphicalChild: Radar,
	axisComponents: [{
		axisType: "angleAxis",
		AxisComp: PolarAngleAxis
	}, {
		axisType: "radiusAxis",
		AxisComp: PolarRadiusAxis
	}],
	formatAxisMap: formatAxisMap$1,
	defaultProps: {
		layout: "centric",
		startAngle: 90,
		endAngle: -270,
		cx: "50%",
		cy: "50%",
		innerRadius: 0,
		outerRadius: "80%"
	}
});
//#endregion
//#region node_modules/recharts/es6/chart/ScatterChart.js
/**
* @fileOverview Scatter Chart
*/
var ScatterChart = generateCategoricalChart({
	chartName: "ScatterChart",
	GraphicalChild: Scatter,
	defaultTooltipEventType: "item",
	validateTooltipEventTypes: ["item"],
	axisComponents: [
		{
			axisType: "xAxis",
			AxisComp: XAxis
		},
		{
			axisType: "yAxis",
			AxisComp: YAxis
		},
		{
			axisType: "zAxis",
			AxisComp: ZAxis
		}
	],
	formatAxisMap
});
//#endregion
//#region node_modules/recharts/es6/chart/AreaChart.js
/**
* @fileOverview Area Chart
*/
var AreaChart = generateCategoricalChart({
	chartName: "AreaChart",
	GraphicalChild: Area,
	axisComponents: [{
		axisType: "xAxis",
		AxisComp: XAxis
	}, {
		axisType: "yAxis",
		AxisComp: YAxis
	}],
	formatAxisMap
});
//#endregion
//#region node_modules/recharts/es6/chart/RadialBarChart.js
/**
* @fileOverview Radar Bar Chart
*/
var RadialBarChart = generateCategoricalChart({
	chartName: "RadialBarChart",
	GraphicalChild: RadialBar,
	legendContent: "children",
	defaultTooltipEventType: "axis",
	validateTooltipEventTypes: ["axis", "item"],
	axisComponents: [{
		axisType: "angleAxis",
		AxisComp: PolarAngleAxis
	}, {
		axisType: "radiusAxis",
		AxisComp: PolarRadiusAxis
	}],
	formatAxisMap: formatAxisMap$1,
	defaultProps: {
		layout: "radial",
		startAngle: 0,
		endAngle: 360,
		cx: "50%",
		cy: "50%",
		innerRadius: 0,
		outerRadius: "80%"
	}
});
//#endregion
//#region node_modules/recharts/es6/chart/ComposedChart.js
/**
* @fileOverview Composed Chart
*/
var ComposedChart = generateCategoricalChart({
	chartName: "ComposedChart",
	GraphicalChild: [
		Line,
		Area,
		Bar,
		Scatter
	],
	axisComponents: [
		{
			axisType: "xAxis",
			AxisComp: XAxis
		},
		{
			axisType: "yAxis",
			AxisComp: YAxis
		},
		{
			axisType: "zAxis",
			AxisComp: ZAxis
		}
	],
	formatAxisMap
});
//#endregion
//#region node_modules/recharts/es6/chart/SunburstChart.js
function _extends$2() {
	_extends$2 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$2.apply(this, arguments);
}
function _slicedToArray$1(arr, i) {
	return _arrayWithHoles$1(arr) || _iterableToArrayLimit$1(arr, i) || _unsupportedIterableToArray$1(arr, i) || _nonIterableRest$1();
}
function _nonIterableRest$1() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _iterableToArrayLimit$1(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = !0, o = !1;
		try {
			if (i = (t = t.call(r)).next, 0 === l) {
				if (Object(t) !== t) return;
				f = !1;
			} else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = !0, n = r;
		} finally {
			try {
				if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
function _arrayWithHoles$1(arr) {
	if (Array.isArray(arr)) return arr;
}
function _toConsumableArray(arr) {
	return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray$1(arr) || _nonIterableSpread();
}
function _nonIterableSpread() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray$1(o, minLen) {
	if (!o) return;
	if (typeof o === "string") return _arrayLikeToArray$1(o, minLen);
	var n = Object.prototype.toString.call(o).slice(8, -1);
	if (n === "Object" && o.constructor) n = o.constructor.name;
	if (n === "Map" || n === "Set") return Array.from(o);
	if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray$1(o, minLen);
}
function _iterableToArray(iter) {
	if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _arrayWithoutHoles(arr) {
	if (Array.isArray(arr)) return _arrayLikeToArray$1(arr);
}
function _arrayLikeToArray$1(arr, len) {
	if (len == null || len > arr.length) len = arr.length;
	for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
	return arr2;
}
var defaultTextProps = {
	fontWeight: "bold",
	paintOrder: "stroke fill",
	fontSize: ".75rem",
	stroke: "#FFF",
	fill: "black",
	pointerEvents: "none"
};
function getMaxDepthOf(node) {
	if (!node.children || node.children.length === 0) return 1;
	var childDepths = node.children.map(function(d) {
		return getMaxDepthOf(d);
	});
	return 1 + Math.max.apply(Math, _toConsumableArray(childDepths));
}
var SunburstChart = function SunburstChart(_ref) {
	var className = _ref.className, data = _ref.data, children = _ref.children, width = _ref.width, height = _ref.height, _ref$padding = _ref.padding, padding = _ref$padding === void 0 ? 2 : _ref$padding, _ref$dataKey = _ref.dataKey, dataKey = _ref$dataKey === void 0 ? "value" : _ref$dataKey, _ref$ringPadding = _ref.ringPadding, ringPadding = _ref$ringPadding === void 0 ? 2 : _ref$ringPadding, _ref$innerRadius = _ref.innerRadius, innerRadius = _ref$innerRadius === void 0 ? 50 : _ref$innerRadius, _ref$fill = _ref.fill, fill = _ref$fill === void 0 ? "#333" : _ref$fill, _ref$stroke = _ref.stroke, stroke = _ref$stroke === void 0 ? "#FFF" : _ref$stroke, _ref$textOptions = _ref.textOptions, textOptions = _ref$textOptions === void 0 ? defaultTextProps : _ref$textOptions, _ref$outerRadius = _ref.outerRadius, outerRadius = _ref$outerRadius === void 0 ? Math.min(width, height) / 2 : _ref$outerRadius, _ref$cx = _ref.cx, cx = _ref$cx === void 0 ? width / 2 : _ref$cx, _ref$cy = _ref.cy, cy = _ref$cy === void 0 ? height / 2 : _ref$cy, _ref$startAngle = _ref.startAngle, startAngle = _ref$startAngle === void 0 ? 0 : _ref$startAngle, _ref$endAngle = _ref.endAngle, endAngle = _ref$endAngle === void 0 ? 360 : _ref$endAngle, onClick = _ref.onClick, onMouseEnter = _ref.onMouseEnter, onMouseLeave = _ref.onMouseLeave;
	var _useState2 = _slicedToArray$1((0, import_react.useState)(false), 2), isTooltipActive = _useState2[0], setIsTooltipActive = _useState2[1];
	var _useState4 = _slicedToArray$1((0, import_react.useState)(null), 2), activeNode = _useState4[0], setActiveNode = _useState4[1];
	var rScale = linear([0, data[dataKey]], [0, endAngle]);
	var treeDepth = getMaxDepthOf(data);
	var thickness = (outerRadius - innerRadius) / treeDepth;
	var sectors = [];
	var positions = /* @__PURE__ */ new Map([]);
	function handleMouseEnter(node, e) {
		if (onMouseEnter) onMouseEnter(node, e);
		setActiveNode(node);
		setIsTooltipActive(true);
	}
	function handleMouseLeave(node, e) {
		if (onMouseLeave) onMouseLeave(node, e);
		setActiveNode(null);
		setIsTooltipActive(false);
	}
	function handleClick(node) {
		if (onClick) onClick(node);
	}
	function drawArcs(childNodes, options) {
		var radius = options.radius, innerR = options.innerR, initialAngle = options.initialAngle, childColor = options.childColor;
		var currentAngle = initialAngle;
		if (!childNodes) return;
		childNodes.forEach(function(d) {
			var _ref2, _d$fill;
			var arcLength = rScale(d[dataKey]);
			var start = currentAngle;
			var fillColor = (_ref2 = (_d$fill = d === null || d === void 0 ? void 0 : d.fill) !== null && _d$fill !== void 0 ? _d$fill : childColor) !== null && _ref2 !== void 0 ? _ref2 : fill;
			var _polarToCartesian = polarToCartesian(0, 0, innerR + radius / 2, -(start + arcLength - arcLength / 2)), textX = _polarToCartesian.x, textY = _polarToCartesian.y;
			currentAngle += arcLength;
			sectors.push(/*#__PURE__*/ import_react.createElement("g", {
				"aria-label": d.name,
				tabIndex: 0
			}, /*#__PURE__*/ import_react.createElement(Sector, {
				onClick: function onClick() {
					return handleClick(d);
				},
				onMouseEnter: function onMouseEnter(e) {
					return handleMouseEnter(d, e);
				},
				onMouseLeave: function onMouseLeave(e) {
					return handleMouseLeave(d, e);
				},
				fill: fillColor,
				stroke,
				strokeWidth: padding,
				startAngle: start,
				endAngle: start + arcLength,
				innerRadius: innerR,
				outerRadius: innerR + radius,
				cx,
				cy
			}), /*#__PURE__*/ import_react.createElement(Text, _extends$2({}, textOptions, {
				alignmentBaseline: "middle",
				textAnchor: "middle",
				x: textX + cx,
				y: cy - textY
			}), d[dataKey])));
			var _polarToCartesian2 = polarToCartesian(cx, cy, innerR + radius / 2, start), tooltipX = _polarToCartesian2.x, tooltipY = _polarToCartesian2.y;
			positions.set(d.name, {
				x: tooltipX,
				y: tooltipY
			});
			return drawArcs(d.children, {
				radius,
				innerR: innerR + radius + ringPadding,
				initialAngle: start,
				childColor: fillColor
			});
		});
	}
	drawArcs(data.children, {
		radius: thickness,
		innerR: innerRadius,
		initialAngle: startAngle
	});
	var layerClass = clsx("recharts-sunburst", className);
	function renderTooltip() {
		var tooltipComponent = findChildByType([children], Tooltip);
		if (!tooltipComponent || !activeNode) return null;
		var viewBox = {
			x: 0,
			y: 0,
			width,
			height
		};
		return /*#__PURE__*/ import_react.cloneElement(tooltipComponent, {
			viewBox,
			coordinate: positions.get(activeNode.name),
			payload: [activeNode],
			active: isTooltipActive
		});
	}
	return /*#__PURE__*/ import_react.createElement("div", {
		className: clsx("recharts-wrapper", className),
		style: {
			position: "relative",
			width,
			height
		},
		role: "region"
	}, /*#__PURE__*/ import_react.createElement(Surface, {
		width,
		height
	}, children, /*#__PURE__*/ import_react.createElement(Layer, { className: layerClass }, sectors)), renderTooltip());
};
//#endregion
//#region node_modules/recharts/es6/util/FunnelUtils.js
function _typeof$1(o) {
	"@babel/helpers - typeof";
	return _typeof$1 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$1(o);
}
function _extends$1() {
	_extends$1 = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends$1.apply(this, arguments);
}
function ownKeys$1(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$1(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$1(Object(t), !0).forEach(function(r) {
			_defineProperty$1(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$1(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$1(obj, key, value) {
	key = _toPropertyKey$1(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey$1(t) {
	var i = _toPrimitive$1(t, "string");
	return "symbol" == _typeof$1(i) ? i : i + "";
}
function _toPrimitive$1(t, r) {
	if ("object" != _typeof$1(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof$1(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function typeGuardTrapezoidProps(option, props) {
	var xValue = "".concat(props.x || option.x);
	var x = parseInt(xValue, 10);
	var yValue = "".concat(props.y || option.y);
	var y = parseInt(yValue, 10);
	var heightValue = "".concat((props === null || props === void 0 ? void 0 : props.height) || (option === null || option === void 0 ? void 0 : option.height));
	var height = parseInt(heightValue, 10);
	return _objectSpread$1(_objectSpread$1(_objectSpread$1({}, props), getPropsFromShapeOption(option)), {}, {
		height,
		x,
		y
	});
}
function FunnelTrapezoid(props) {
	return /*#__PURE__*/ import_react.createElement(Shape, _extends$1({
		shapeType: "trapezoid",
		propTransformer: typeGuardTrapezoidProps
	}, props));
}
//#endregion
//#region node_modules/recharts/es6/numberAxis/Funnel.js
/**
* @fileOverview Render sectors of a funnel
*/
var _Funnel;
function _slicedToArray(arr, i) {
	return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
	if (!o) return;
	if (typeof o === "string") return _arrayLikeToArray(o, minLen);
	var n = Object.prototype.toString.call(o).slice(8, -1);
	if (n === "Object" && o.constructor) n = o.constructor.name;
	if (n === "Map" || n === "Set") return Array.from(o);
	if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
	if (len == null || len > arr.length) len = arr.length;
	for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
	return arr2;
}
function _iterableToArrayLimit(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = !0, o = !1;
		try {
			if (i = (t = t.call(r)).next, 0 === l) {
				if (Object(t) !== t) return;
				f = !1;
			} else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = !0, n = r;
		} finally {
			try {
				if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
function _arrayWithHoles(arr) {
	if (Array.isArray(arr)) return arr;
}
function _typeof(o) {
	"@babel/helpers - typeof";
	return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof(o);
}
function _extends() {
	_extends = Object.assign ? Object.assign.bind() : function(target) {
		for (var i = 1; i < arguments.length; i++) {
			var source = arguments[i];
			for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
		}
		return target;
	};
	return _extends.apply(this, arguments);
}
function ownKeys(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
			_defineProperty(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _classCallCheck(instance, Constructor) {
	if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties(target, props) {
	for (var i = 0; i < props.length; i++) {
		var descriptor = props[i];
		descriptor.enumerable = descriptor.enumerable || false;
		descriptor.configurable = true;
		if ("value" in descriptor) descriptor.writable = true;
		Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor);
	}
}
function _createClass(Constructor, protoProps, staticProps) {
	if (protoProps) _defineProperties(Constructor.prototype, protoProps);
	if (staticProps) _defineProperties(Constructor, staticProps);
	Object.defineProperty(Constructor, "prototype", { writable: false });
	return Constructor;
}
function _callSuper(t, o, e) {
	return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn(self, call) {
	if (call && (_typeof(call) === "object" || typeof call === "function")) return call;
	else if (call !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
	return _assertThisInitialized(self);
}
function _assertThisInitialized(self) {
	if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
	return self;
}
function _isNativeReflectConstruct() {
	try {
		var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
	} catch (t) {}
	return (_isNativeReflectConstruct = function _isNativeReflectConstruct() {
		return !!t;
	})();
}
function _getPrototypeOf(o) {
	_getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
		return o.__proto__ || Object.getPrototypeOf(o);
	};
	return _getPrototypeOf(o);
}
function _inherits(subClass, superClass) {
	if (typeof superClass !== "function" && superClass !== null) throw new TypeError("Super expression must either be null or a function");
	subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: {
		value: subClass,
		writable: true,
		configurable: true
	} });
	Object.defineProperty(subClass, "prototype", { writable: false });
	if (superClass) _setPrototypeOf(subClass, superClass);
}
function _setPrototypeOf(o, p) {
	_setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
		o.__proto__ = p;
		return o;
	};
	return _setPrototypeOf(o, p);
}
function _defineProperty(obj, key, value) {
	key = _toPropertyKey(key);
	if (key in obj) Object.defineProperty(obj, key, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else obj[key] = value;
	return obj;
}
function _toPropertyKey(t) {
	var i = _toPrimitive(t, "string");
	return "symbol" == _typeof(i) ? i : i + "";
}
function _toPrimitive(t, r) {
	if ("object" != _typeof(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != _typeof(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var Funnel = /*#__PURE__*/ function(_PureComponent) {
	function Funnel() {
		var _this;
		_classCallCheck(this, Funnel);
		for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
		_this = _callSuper(this, Funnel, [].concat(args));
		_defineProperty(_this, "state", { isAnimationFinished: false });
		_defineProperty(_this, "handleAnimationEnd", function() {
			var onAnimationEnd = _this.props.onAnimationEnd;
			_this.setState({ isAnimationFinished: true });
			if ((0, import_isFunction.default)(onAnimationEnd)) onAnimationEnd();
		});
		_defineProperty(_this, "handleAnimationStart", function() {
			var onAnimationStart = _this.props.onAnimationStart;
			_this.setState({ isAnimationFinished: false });
			if ((0, import_isFunction.default)(onAnimationStart)) onAnimationStart();
		});
		return _this;
	}
	_inherits(Funnel, _PureComponent);
	return _createClass(Funnel, [
		{
			key: "isActiveIndex",
			value: function isActiveIndex(i) {
				var activeIndex = this.props.activeIndex;
				if (Array.isArray(activeIndex)) return activeIndex.indexOf(i) !== -1;
				return i === activeIndex;
			}
		},
		{
			key: "renderTrapezoidsStatically",
			value: function renderTrapezoidsStatically(trapezoids) {
				var _this2 = this;
				var _this$props = this.props, shape = _this$props.shape, activeShape = _this$props.activeShape;
				return trapezoids.map(function(entry, i) {
					var trapezoidOptions = _this2.isActiveIndex(i) ? activeShape : shape;
					var trapezoidProps = _objectSpread(_objectSpread({}, entry), {}, {
						isActive: _this2.isActiveIndex(i),
						stroke: entry.stroke
					});
					return /*#__PURE__*/ import_react.createElement(Layer, _extends({ className: "recharts-funnel-trapezoid" }, adaptEventsOfChild(_this2.props, entry, i), {
						key: "trapezoid-".concat(entry === null || entry === void 0 ? void 0 : entry.x, "-").concat(entry === null || entry === void 0 ? void 0 : entry.y, "-").concat(entry === null || entry === void 0 ? void 0 : entry.name, "-").concat(entry === null || entry === void 0 ? void 0 : entry.value),
						role: "img"
					}), /*#__PURE__*/ import_react.createElement(FunnelTrapezoid, _extends({ option: trapezoidOptions }, trapezoidProps)));
				});
			}
		},
		{
			key: "renderTrapezoidsWithAnimation",
			value: function renderTrapezoidsWithAnimation() {
				var _this3 = this;
				var _this$props2 = this.props, trapezoids = _this$props2.trapezoids, isAnimationActive = _this$props2.isAnimationActive, animationBegin = _this$props2.animationBegin, animationDuration = _this$props2.animationDuration, animationEasing = _this$props2.animationEasing, animationId = _this$props2.animationId;
				var prevTrapezoids = this.state.prevTrapezoids;
				return /*#__PURE__*/ import_react.createElement(es6_default, {
					begin: animationBegin,
					duration: animationDuration,
					isActive: isAnimationActive,
					easing: animationEasing,
					from: { t: 0 },
					to: { t: 1 },
					key: "funnel-".concat(animationId),
					onAnimationStart: this.handleAnimationStart,
					onAnimationEnd: this.handleAnimationEnd
				}, function(_ref) {
					var t = _ref.t;
					var stepData = trapezoids.map(function(entry, index) {
						var prev = prevTrapezoids && prevTrapezoids[index];
						if (prev) {
							var _interpolatorX = interpolateNumber$1(prev.x, entry.x);
							var _interpolatorY = interpolateNumber$1(prev.y, entry.y);
							var _interpolatorUpperWidth = interpolateNumber$1(prev.upperWidth, entry.upperWidth);
							var _interpolatorLowerWidth = interpolateNumber$1(prev.lowerWidth, entry.lowerWidth);
							var _interpolatorHeight = interpolateNumber$1(prev.height, entry.height);
							return _objectSpread(_objectSpread({}, entry), {}, {
								x: _interpolatorX(t),
								y: _interpolatorY(t),
								upperWidth: _interpolatorUpperWidth(t),
								lowerWidth: _interpolatorLowerWidth(t),
								height: _interpolatorHeight(t)
							});
						}
						var interpolatorX = interpolateNumber$1(entry.x + entry.upperWidth / 2, entry.x);
						var interpolatorY = interpolateNumber$1(entry.y + entry.height / 2, entry.y);
						var interpolatorUpperWidth = interpolateNumber$1(0, entry.upperWidth);
						var interpolatorLowerWidth = interpolateNumber$1(0, entry.lowerWidth);
						var interpolatorHeight = interpolateNumber$1(0, entry.height);
						return _objectSpread(_objectSpread({}, entry), {}, {
							x: interpolatorX(t),
							y: interpolatorY(t),
							upperWidth: interpolatorUpperWidth(t),
							lowerWidth: interpolatorLowerWidth(t),
							height: interpolatorHeight(t)
						});
					});
					return /*#__PURE__*/ import_react.createElement(Layer, null, _this3.renderTrapezoidsStatically(stepData));
				});
			}
		},
		{
			key: "renderTrapezoids",
			value: function renderTrapezoids() {
				var _this$props3 = this.props, trapezoids = _this$props3.trapezoids, isAnimationActive = _this$props3.isAnimationActive;
				var prevTrapezoids = this.state.prevTrapezoids;
				if (isAnimationActive && trapezoids && trapezoids.length && (!prevTrapezoids || !(0, import_isEqual.default)(prevTrapezoids, trapezoids))) return this.renderTrapezoidsWithAnimation();
				return this.renderTrapezoidsStatically(trapezoids);
			}
		},
		{
			key: "render",
			value: function render() {
				var _this$props4 = this.props, hide = _this$props4.hide, trapezoids = _this$props4.trapezoids, className = _this$props4.className, isAnimationActive = _this$props4.isAnimationActive;
				var isAnimationFinished = this.state.isAnimationFinished;
				if (hide || !trapezoids || !trapezoids.length) return null;
				var layerClass = clsx("recharts-trapezoids", className);
				return /*#__PURE__*/ import_react.createElement(Layer, { className: layerClass }, this.renderTrapezoids(), (!isAnimationActive || isAnimationFinished) && LabelList.renderCallByParent(this.props, trapezoids));
			}
		}
	], [{
		key: "getDerivedStateFromProps",
		value: function getDerivedStateFromProps(nextProps, prevState) {
			if (nextProps.animationId !== prevState.prevAnimationId) return {
				prevAnimationId: nextProps.animationId,
				curTrapezoids: nextProps.trapezoids,
				prevTrapezoids: prevState.curTrapezoids
			};
			if (nextProps.trapezoids !== prevState.curTrapezoids) return { curTrapezoids: nextProps.trapezoids };
			return null;
		}
	}]);
}(import_react.PureComponent);
_Funnel = Funnel;
_defineProperty(Funnel, "displayName", "Funnel");
_defineProperty(Funnel, "defaultProps", {
	stroke: "#fff",
	fill: "#808080",
	legendType: "rect",
	labelLine: true,
	hide: false,
	isAnimationActive: !Global.isSsr,
	animationBegin: 400,
	animationDuration: 1500,
	animationEasing: "ease",
	nameKey: "name",
	lastShapeType: "triangle"
});
_defineProperty(Funnel, "getRealFunnelData", function(item) {
	var _item$props = item.props, data = _item$props.data, children = _item$props.children;
	var presentationProps = filterProps(item.props, false);
	var cells = findAllByType(children, Cell);
	if (data && data.length) return data.map(function(entry, index) {
		return _objectSpread(_objectSpread(_objectSpread({ payload: entry }, presentationProps), entry), cells && cells[index] && cells[index].props);
	});
	if (cells && cells.length) return cells.map(function(cell) {
		return _objectSpread(_objectSpread({}, presentationProps), cell.props);
	});
	return [];
});
_defineProperty(Funnel, "getRealWidthHeight", function(item, offset) {
	var customWidth = item.props.width;
	var width = offset.width, height = offset.height, left = offset.left, right = offset.right, top = offset.top, bottom = offset.bottom;
	var realHeight = height;
	var realWidth = width;
	if ((0, import_isNumber.default)(customWidth)) realWidth = customWidth;
	else if ((0, import_isString.default)(customWidth)) realWidth = realWidth * parseFloat(customWidth) / 100;
	return {
		realWidth: realWidth - left - right - 50,
		realHeight: realHeight - bottom - top,
		offsetX: (width - realWidth) / 2,
		offsetY: (height - realHeight) / 2
	};
});
_defineProperty(Funnel, "getComposedData", function(_ref2) {
	var item = _ref2.item, offset = _ref2.offset;
	var funnelData = _Funnel.getRealFunnelData(item);
	var _item$props2 = item.props, dataKey = _item$props2.dataKey, nameKey = _item$props2.nameKey, tooltipType = _item$props2.tooltipType, lastShapeType = _item$props2.lastShapeType, reversed = _item$props2.reversed;
	var left = offset.left, top = offset.top;
	var _Funnel$getRealWidthH = _Funnel.getRealWidthHeight(item, offset), realHeight = _Funnel$getRealWidthH.realHeight, realWidth = _Funnel$getRealWidthH.realWidth, offsetX = _Funnel$getRealWidthH.offsetX, offsetY = _Funnel$getRealWidthH.offsetY;
	var maxValue = Math.max.apply(null, funnelData.map(function(entry) {
		return getValueByDataKey(entry, dataKey, 0);
	}));
	var len = funnelData.length;
	var rowHeight = realHeight / len;
	var parentViewBox = {
		x: offset.left,
		y: offset.top,
		width: offset.width,
		height: offset.height
	};
	var trapezoids = funnelData.map(function(entry, i) {
		var rawVal = getValueByDataKey(entry, dataKey, 0);
		var name = getValueByDataKey(entry, nameKey, i);
		var val = rawVal;
		var nextVal;
		if (i !== len - 1) {
			nextVal = getValueByDataKey(funnelData[i + 1], dataKey, 0);
			if (nextVal instanceof Array) nextVal = _slicedToArray(nextVal, 1)[0];
		} else if (rawVal instanceof Array && rawVal.length === 2) {
			var _rawVal = _slicedToArray(rawVal, 2);
			val = _rawVal[0];
			nextVal = _rawVal[1];
		} else if (lastShapeType === "rectangle") nextVal = val;
		else nextVal = 0;
		var x = (maxValue - val) * realWidth / (2 * maxValue) + top + 25 + offsetX;
		var y = rowHeight * i + left + offsetY;
		var upperWidth = val / maxValue * realWidth;
		var lowerWidth = nextVal / maxValue * realWidth;
		var tooltipPayload = [{
			name,
			value: val,
			payload: entry,
			dataKey,
			type: tooltipType
		}];
		var tooltipPosition = {
			x: x + upperWidth / 2,
			y: y + rowHeight / 2
		};
		return _objectSpread(_objectSpread({
			x,
			y,
			width: Math.max(upperWidth, lowerWidth),
			upperWidth,
			lowerWidth,
			height: rowHeight,
			name,
			val,
			tooltipPayload,
			tooltipPosition
		}, (0, import_omit.default)(entry, "width")), {}, {
			payload: entry,
			parentViewBox,
			labelViewBox: {
				x: x + (upperWidth - lowerWidth) / 4,
				y,
				width: Math.abs(upperWidth - lowerWidth) / 2 + Math.min(upperWidth, lowerWidth),
				height: rowHeight
			}
		});
	});
	if (reversed) trapezoids = trapezoids.map(function(entry, index) {
		var newY = entry.y - index * rowHeight + (len - 1 - index) * rowHeight;
		return _objectSpread(_objectSpread({}, entry), {}, {
			upperWidth: entry.lowerWidth,
			lowerWidth: entry.upperWidth,
			x: entry.x - (entry.lowerWidth - entry.upperWidth) / 2,
			y: entry.y - index * rowHeight + (len - 1 - index) * rowHeight,
			tooltipPosition: _objectSpread(_objectSpread({}, entry.tooltipPosition), {}, { y: newY + rowHeight / 2 }),
			labelViewBox: _objectSpread(_objectSpread({}, entry.labelViewBox), {}, { y: newY })
		});
	});
	return {
		trapezoids,
		data: funnelData
	};
});
//#endregion
//#region node_modules/recharts/es6/chart/FunnelChart.js
/**
* @fileOverview Funnel Chart
*/
var FunnelChart = generateCategoricalChart({
	chartName: "FunnelChart",
	GraphicalChild: Funnel,
	validateTooltipEventTypes: ["item"],
	defaultTooltipEventType: "item",
	axisComponents: [],
	defaultProps: { layout: "centric" }
});
//#endregion
//#region node_modules/recharts/es6/index.js
var es6_exports = /* @__PURE__ */ __exportAll({
	Area: () => Area,
	AreaChart: () => AreaChart,
	Bar: () => Bar,
	BarChart: () => BarChart,
	Brush: () => Brush,
	CartesianAxis: () => CartesianAxis,
	CartesianGrid: () => CartesianGrid,
	Cell: () => Cell,
	ComposedChart: () => ComposedChart,
	Cross: () => Cross,
	Curve: () => Curve,
	Customized: () => Customized,
	DefaultLegendContent: () => DefaultLegendContent,
	DefaultTooltipContent: () => DefaultTooltipContent,
	Dot: () => Dot,
	ErrorBar: () => ErrorBar,
	Funnel: () => Funnel,
	FunnelChart: () => FunnelChart,
	Global: () => Global,
	Label: () => Label,
	LabelList: () => LabelList,
	Layer: () => Layer,
	Legend: () => Legend,
	Line: () => Line,
	LineChart: () => LineChart,
	Pie: () => Pie,
	PieChart: () => PieChart,
	PolarAngleAxis: () => PolarAngleAxis,
	PolarGrid: () => PolarGrid,
	PolarRadiusAxis: () => PolarRadiusAxis,
	Polygon: () => Polygon,
	Radar: () => Radar,
	RadarChart: () => RadarChart,
	RadialBar: () => RadialBar,
	RadialBarChart: () => RadialBarChart,
	Rectangle: () => Rectangle,
	ReferenceArea: () => ReferenceArea,
	ReferenceDot: () => ReferenceDot,
	ReferenceLine: () => ReferenceLine,
	ResponsiveContainer: () => ResponsiveContainer,
	Sankey: () => Sankey,
	Scatter: () => Scatter,
	ScatterChart: () => ScatterChart,
	Sector: () => Sector,
	SunburstChart: () => SunburstChart,
	Surface: () => Surface,
	Symbols: () => Symbols,
	Text: () => Text,
	Tooltip: () => Tooltip,
	Trapezoid: () => Trapezoid,
	Treemap: () => Treemap,
	XAxis: () => XAxis,
	YAxis: () => YAxis,
	ZAxis: () => ZAxis
});
//#endregion
export { es6_exports as t };
